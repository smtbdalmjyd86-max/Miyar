package com.miyar.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MiyarDao {
    @Query("SELECT * FROM plantations ORDER BY name COLLATE NOCASE")
    fun observePlantations(): Flow<List<PlantationEntity>>

    @Insert
    suspend fun insertPlantation(item: PlantationEntity): Long

    @Query("SELECT COUNT(*) FROM expenses WHERE plantationId = :plantationId")
    suspend fun countExpensesForPlantation(plantationId: Long): Int

    @Query("DELETE FROM plantations WHERE id = :plantationId")
    suspend fun deletePlantationById(plantationId: Long): Int

    @Transaction
    suspend fun deletePlantationIfEmpty(plantationId: Long): Boolean {
        if (countExpensesForPlantation(plantationId) > 0) return false
        return deletePlantationById(plantationId) > 0
    }

    @Query("SELECT * FROM expenses WHERE plantationId = :plantationId ORDER BY dateMillis DESC, id DESC")
    fun observeExpenses(plantationId: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category != 'القطفات'")
    fun observeTotalExpenses(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category = 'القطفات'")
    fun observeTotalRevenue(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category != 'القطفات'")
    fun observePlantationExpenses(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category = 'القطفات'")
    fun observePlantationRevenue(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id = e.plantationId ORDER BY e.dateMillis DESC, e.id DESC")
    fun observeAllExpenses(): Flow<List<ExpenseWithPlantation>>

    @Query("SELECT category AS category, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total FROM expenses GROUP BY category")
    fun observeCategoryTotals(): Flow<List<CategoryTotal>>

    @Query("SELECT COUNT(*) FROM expenses WHERE category = 'القطفات'")
    fun observeHarvestCount(): Flow<Long>

    @Insert
    suspend fun insertExpense(item: ExpenseEntity): Long

    @Update
    suspend fun updateExpense(item: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(item: ExpenseEntity)

    // Invoice and inventory queries
    @Query("SELECT * FROM invoices ORDER BY dateMillis DESC, id DESC")
    fun observeInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoice_items ORDER BY id DESC")
    fun observeAllInvoiceItems(): Flow<List<InvoiceItemEntity>>

    @Query("SELECT * FROM stock_movements ORDER BY dateMillis DESC, id DESC")
    fun observeAllStockMovements(): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId ORDER BY id")
    suspend fun getInvoiceItems(invoiceId: Long): List<InvoiceItemEntity>

    @Query("SELECT * FROM stock_items ORDER BY productType, productName COLLATE NOCASE")
    fun observeStockItems(): Flow<List<StockItemEntity>>

    @Query("""
        SELECT s.id AS id, s.productType AS productType, s.productName AS productName,
               s.activeIngredient AS activeIngredient, s.baseUnit AS baseUnit,
               s.quantityBase AS quantityBase, s.treatmentType AS treatmentType,
               CASE WHEN COALESCE(SUM(ii.quantityBase), 0) > 0
                    THEN CAST((SUM(CAST(ii.lineTotalYer AS REAL)) * 1000.0) / SUM(ii.quantityBase) AS INTEGER)
                    ELSE 0 END AS averageCostPerBaseScaled
        FROM stock_items s
        LEFT JOIN invoice_items ii ON ii.stockItemId = s.id
        GROUP BY s.id
        ORDER BY s.productName COLLATE NOCASE
    """)
    fun observeStockPriceSuggestions(): Flow<List<StockPriceSuggestion>>

    @Query("SELECT * FROM stock_items WHERE id = :id LIMIT 1")
    suspend fun getStockItemById(id: Long): StockItemEntity?

    @Query("SELECT * FROM stock_items WHERE productType = :type AND productName COLLATE NOCASE = :name COLLATE NOCASE AND baseUnit = :baseUnit LIMIT 1")
    suspend fun findStockItem(type: String, name: String, baseUnit: String): StockItemEntity?

    @Insert
    suspend fun insertInvoice(invoice: InvoiceEntity): Long

    @Update
    suspend fun updateInvoice(invoice: InvoiceEntity)

    @Query("DELETE FROM invoices WHERE id = :id")
    suspend fun deleteInvoiceRow(id: Long)

    @Insert
    suspend fun insertInvoiceItem(item: InvoiceItemEntity): Long

    @Query("DELETE FROM invoice_items WHERE invoiceId = :invoiceId")
    suspend fun deleteInvoiceItems(invoiceId: Long)

    @Insert
    suspend fun insertStockItem(item: StockItemEntity): Long

    @Update
    suspend fun updateStockItem(item: StockItemEntity)

    @Insert
    suspend fun insertStockMovement(item: StockMovementEntity): Long

    @Query("SELECT * FROM stock_movements WHERE referenceType = :type AND referenceId = :id")
    suspend fun getMovements(type: String, id: Long): List<StockMovementEntity>

    @Query("DELETE FROM stock_movements WHERE referenceType = :type AND referenceId = :id")
    suspend fun deleteMovements(type: String, id: Long)

    @Transaction
    suspend fun saveInvoice(invoice: InvoiceEntity, lines: List<InvoiceItemEntity>): Long {
        require(invoice.supplier.isNotBlank() && invoice.invoiceNumber.isNotBlank()) { "أدخل اسم المورد ورقم الفاتورة." }
        require(invoice.exchangeRateScaled > 0 && invoice.totalForeign >= 0 && invoice.totalYer >= 0) { "قيمة الفاتورة أو سعر الصرف غير صالح." }
        require(lines.isNotEmpty()) { "أضف صنفًا واحدًا على الأقل إلى الفاتورة." }
        val linesForeign = lines.fold(0L) { total, line -> Math.addExact(total, line.lineTotalForeign) }
        val linesYer = lines.fold(0L) { total, line -> Math.addExact(total, line.lineTotalYer) }
        require(linesForeign == invoice.totalForeign && linesYer == invoice.totalYer) { "إجمالي الفاتورة لا يطابق مجموع أصنافها." }
        val invoiceId: Long
        if (invoice.id == 0L) {
            invoiceId = insertInvoice(invoice.copy(id = 0))
        } else {
            invoiceId = invoice.id
            val oldLines = getInvoiceItems(invoiceId)
            oldLines.forEach { old ->
                val stock = getStockItemById(old.stockItemId) ?: error("تعذر العثور على صنف المخزون المرتبط بالفاتورة.")
                check(stock.quantityBase >= old.quantityBase) {
                    "لا يمكن تعديل الفاتورة؛ استُخدمت بعض كمياتها بالفعل. أعد الكميات المستخدمة أولًا."
                }
                updateStockItem(stock.copy(
                    quantityBase = stock.quantityBase - old.quantityBase,
                    totalReceivedBase = (stock.totalReceivedBase - old.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("INVOICE", invoiceId)
            deleteInvoiceItems(invoiceId)
            updateInvoice(invoice)
        }
        lines.forEach { draft ->
            require(draft.productName.isNotBlank() && draft.productType.isNotBlank() && draft.packageSize > 0 && draft.quantityBase > 0 && draft.packageCount > 0 && draft.unitPriceForeign >= 0 && draft.lineTotalForeign >= 0 && draft.lineTotalYer >= 0) { "تحقق من اسم وكمية وسعر الصنف." }
            val baseUnit = if (draft.unit == "كجم" || draft.unit == "جرام") "g" else "ml"
            val existing = findStockItem(draft.productType, draft.productName.trim(), baseUnit)
            val stockId = if (existing == null) {
                insertStockItem(StockItemEntity(
                    productType = draft.productType,
                    productName = draft.productName.trim(),
                    activeIngredient = draft.activeIngredient.trim(),
                    treatmentType = draft.treatmentType,
                    baseUnit = baseUnit
                ))
            } else existing.id
            val stock = getStockItemById(stockId) ?: error("تعذر إنشاء صنف المخزون.")
            updateStockItem(stock.copy(
                activeIngredient = draft.activeIngredient.ifBlank { stock.activeIngredient },
                treatmentType = draft.treatmentType.ifBlank { stock.treatmentType },
                quantityBase = Math.addExact(stock.quantityBase, draft.quantityBase),
                totalReceivedBase = Math.addExact(stock.totalReceivedBase, draft.quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            insertInvoiceItem(draft.copy(id = 0, invoiceId = invoiceId, stockItemId = stockId))
            insertStockMovement(StockMovementEntity(
                stockItemId = stockId,
                referenceType = "INVOICE",
                referenceId = invoiceId,
                quantityBase = draft.quantityBase,
                dateMillis = invoice.dateMillis,
                description = "استلام من فاتورة ${invoice.invoiceNumber}"
            ))
        }
        return invoiceId
    }

    @Transaction
    suspend fun deleteInvoiceSafely(invoiceId: Long): Boolean {
        val lines = getInvoiceItems(invoiceId)
        val requiredByStock = lines.groupBy { it.stockItemId }.mapValues { (_, rows) ->
            rows.fold(0L) { total, row -> Math.addExact(total, row.quantityBase) }
        }
        for ((stockId, required) in requiredByStock) {
            val stock = getStockItemById(stockId) ?: return false
            if (stock.quantityBase < required) return false
        }
        lines.forEach { line ->
            val stock = getStockItemById(line.stockItemId) ?: return@forEach
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - line.quantityBase,
                totalReceivedBase = (stock.totalReceivedBase - line.quantityBase).coerceAtLeast(0),
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        deleteMovements("INVOICE", invoiceId)
        deleteInvoiceRow(invoiceId)
        return true
    }

    @Transaction
    suspend fun addOpeningStock(type: String, name: String, ingredient: String, unit: String, quantityBase: Long) {
        require(quantityBase > 0) { "أدخل كمية أكبر من صفر." }
        val baseUnit = if (unit == "كجم" || unit == "جرام") "g" else "ml"
        val item = findStockItem(type, name.trim(), baseUnit)
        val id = if (item == null) insertStockItem(StockItemEntity(
            productType = type, productName = name.trim(), activeIngredient = ingredient.trim(), treatmentType = "عام", baseUnit = baseUnit
        )) else item.id
        val stock = getStockItemById(id) ?: error("تعذر إنشاء صنف المخزون.")
        updateStockItem(stock.copy(
            activeIngredient = ingredient.ifBlank { stock.activeIngredient },
            quantityBase = Math.addExact(stock.quantityBase, quantityBase),
            totalReceivedBase = Math.addExact(stock.totalReceivedBase, quantityBase),
            updatedAtMillis = System.currentTimeMillis()
        ))
        insertStockMovement(StockMovementEntity(
            stockItemId = id, referenceType = "OPENING", referenceId = id,
            quantityBase = quantityBase, description = "إضافة رصيد يدوي"
        ))
    }

    @Transaction
    suspend fun saveExpenseWithStock(
        expense: ExpenseEntity,
        stockType: String? = null,
        stockBaseUnit: String? = null,
        quantityBase: Long = 0L
    ): Long {
        require(quantityBase >= 0L) { "كمية الاستخدام لا يمكن أن تكون سالبة." }
        if (expense.id != 0L) {
            getMovements("EXPENSE", expense.id).forEach { movement ->
                val stock = getStockItemById(movement.stockItemId) ?: error("صنف المخزون غير موجود.")
                updateStockItem(stock.copy(
                    quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                    totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("EXPENSE", expense.id)
            updateExpense(expense)
        }
        val expenseId = if (expense.id == 0L) insertExpense(expense) else expense.id
        if (!stockType.isNullOrBlank() && !stockBaseUnit.isNullOrBlank() && quantityBase > 0) {
            val stock = findStockItem(stockType, expense.title.trim(), stockBaseUnit)
                ?: error("الصنف «${expense.title}» غير مسجل في المخزون. أضف رصيده من الفاتورة أو من شاشة المخزون أولًا.")
            check(stock.quantityBase >= quantityBase) {
                "الرصيد المتبقي من «${expense.title}» غير كافٍ. المتاح ${stock.quantityBase} ${stock.baseUnit}."
            }
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - quantityBase,
                totalUsedBase = Math.addExact(stock.totalUsedBase, quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            insertStockMovement(StockMovementEntity(
                stockItemId = stock.id,
                referenceType = "EXPENSE",
                referenceId = expenseId,
                quantityBase = -quantityBase,
                dateMillis = expense.dateMillis,
                description = "استخدام في عملية ${expense.category}"
            ))
        }
        return expenseId
    }

    @Transaction
    suspend fun deleteExpenseAndRestoreStock(expense: ExpenseEntity) {
        getMovements("EXPENSE", expense.id).forEach { movement ->
            val stock = getStockItemById(movement.stockItemId) ?: return@forEach
            updateStockItem(stock.copy(
                quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        deleteMovements("EXPENSE", expense.id)
        deleteExpense(expense)
    }

    @Insert suspend fun insertPersonalHarvest(item: PersonalHarvestEntity): Long
    @Update suspend fun updatePersonalHarvest(item: PersonalHarvestEntity)
    @Query("DELETE FROM personal_harvests WHERE id=:id") suspend fun deletePersonalHarvest(id:Long)
    @Query("SELECT id FROM personal_harvest_days WHERE harvestId=:id") suspend fun getHarvestDayIds(id:Long):List<Long>
    @Query("SELECT (SELECT COUNT(*) FROM distributor_transactions WHERE sourceDayId=:dayId AND received>0) + (SELECT COUNT(*) FROM harvest_debtor_transactions WHERE sourceDayId=:dayId AND paid>0) + (SELECT COUNT(*) FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE sourceDayId=:dayId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE sourceDayId=:dayId)))")
    suspend fun countRecordedPaymentsForDay(dayId:Long):Int
    @Query("SELECT (SELECT COUNT(*) FROM distributor_transactions WHERE harvestId=:harvestId AND received>0) + (SELECT COUNT(*) FROM harvest_debtor_transactions WHERE harvestId=:harvestId AND paid>0) + (SELECT COUNT(*) FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE harvestId=:harvestId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE harvestId=:harvestId)))")
    suspend fun countRecordedPaymentsForHarvest(harvestId:Long):Int
    @Transaction suspend fun deletePersonalHarvestSafely(id:Long):Boolean {
        // Never erase the payment trail together with a harvest. Close its balances first.
        if (countRecordedPaymentsForHarvest(id) > 0) return false
        getHarvestDayIds(id).forEach { dayId ->
            deleteHarvestPartyPaymentsForDay(dayId)
            deleteDistributorTransactionsForDay(dayId)
            deleteDebtorTransactionsForDay(dayId)
            deleteHarvestDayLines(dayId)
            deletePersonalHarvestDay(dayId)
        }
        deleteHarvestPartyPaymentsForHarvest(id)
        deleteDistributorTransactionsForHarvest(id)
        deleteDebtorTransactionsForHarvest(id)
        deletePersonalHarvest(id)
        return true
    }
    @Transaction suspend fun deletePersonalHarvestDaySafely(dayId:Long):Boolean {
        if (countRecordedPaymentsForDay(dayId) > 0) return false
        deleteHarvestPartyPaymentsForDay(dayId)
        deleteDistributorTransactionsForDay(dayId)
        deleteDebtorTransactionsForDay(dayId)
        deleteHarvestDayLines(dayId)
        deletePersonalHarvestDay(dayId)
        return true
    }
    @Insert suspend fun insertPersonalHarvestDay(item:PersonalHarvestDayEntity):Long
    @Update suspend fun updatePersonalHarvestDay(item:PersonalHarvestDayEntity)
    @Query("DELETE FROM personal_harvest_days WHERE id=:id") suspend fun deletePersonalHarvestDay(id:Long)
    @Query("SELECT * FROM personal_harvest_days WHERE harvestId=:harvestId ORDER BY dateMillis DESC,id DESC") fun observeHarvestDays(harvestId:Long):Flow<List<PersonalHarvestDayEntity>>
    @Query("SELECT * FROM personal_harvest_days ORDER BY dateMillis DESC,id DESC") fun observeAllHarvestDays():Flow<List<PersonalHarvestDayEntity>>
    @Insert suspend fun insertPersonalHarvestDayLine(item:PersonalHarvestDayLineEntity):Long
    @Query("SELECT * FROM personal_harvest_day_lines WHERE dayId=:dayId ORDER BY id") fun observeHarvestDayLines(dayId:Long):Flow<List<PersonalHarvestDayLineEntity>>
    @Query("SELECT * FROM personal_harvest_day_lines WHERE dayId=:dayId ORDER BY id") suspend fun getHarvestDayLines(dayId:Long):List<PersonalHarvestDayLineEntity>
    @Update suspend fun updateHarvestDayLine(item:PersonalHarvestDayLineEntity)
    @Query("SELECT * FROM personal_harvest_day_lines ORDER BY createdAt DESC,id DESC") fun observeAllHarvestDayLines():Flow<List<PersonalHarvestDayLineEntity>>
    @Query("DELETE FROM personal_harvest_day_lines WHERE dayId=:dayId") suspend fun deleteHarvestDayLines(dayId:Long)
    @Query("DELETE FROM personal_harvest_day_lines WHERE id=:id") suspend fun deleteHarvestDayLine(id:Long)
    @Query("SELECT * FROM market_distributors WHERE name=:name COLLATE NOCASE LIMIT 1") suspend fun findDistributor(name:String):MarketDistributorEntity?
    @Query("SELECT * FROM harvest_debtors WHERE name=:name COLLATE NOCASE LIMIT 1") suspend fun findDebtor(name:String):HarvestDebtorEntity?
    @Query("SELECT * FROM qat_buyers WHERE name=:name COLLATE NOCASE LIMIT 1") suspend fun findBuyer(name:String):QatBuyerEntity?
    @Query("SELECT * FROM personal_harvests ORDER BY createdAt DESC") fun observePersonalHarvests(): Flow<List<PersonalHarvestEntity>>
    @Query("SELECT * FROM personal_harvests WHERE id=:id LIMIT 1") suspend fun getPersonalHarvestById(id:Long):PersonalHarvestEntity?
    @Query("SELECT * FROM personal_harvest_days WHERE id=:id LIMIT 1") suspend fun getPersonalHarvestDayById(id:Long):PersonalHarvestDayEntity?
    @Insert suspend fun insertDebtor(item: HarvestDebtorEntity): Long
    @Query("SELECT * FROM harvest_debtors ORDER BY name COLLATE NOCASE") fun observeDebtors(): Flow<List<HarvestDebtorEntity>>
    @Query("SELECT * FROM harvest_debtors WHERE id=:id LIMIT 1") suspend fun getDebtorById(id:Long):HarvestDebtorEntity?
    @Query("SELECT p.name FROM harvest_debtors p LEFT JOIN harvest_debtor_transactions t ON t.debtorId=p.id GROUP BY p.id ORDER BY MAX(t.dateMillis) DESC, COUNT(t.id) DESC, p.name COLLATE NOCASE") fun observeDebtorNameSuggestions():Flow<List<String>>
    @Insert suspend fun insertDebtorTransaction(item: HarvestDebtorTransactionEntity): Long
    @Update suspend fun updateDebtorTransaction(item:HarvestDebtorTransactionEntity)
    @Query("SELECT * FROM harvest_debtor_transactions WHERE debtorId=:debtorId ORDER BY dateMillis DESC,id DESC") fun observeDebtorTransactions(debtorId:Long): Flow<List<HarvestDebtorTransactionEntity>>
    @Query("SELECT * FROM harvest_debtor_transactions WHERE id=:id LIMIT 1") suspend fun getDebtorTransaction(id:Long):HarvestDebtorTransactionEntity?
    @Query("DELETE FROM harvest_debtor_transactions WHERE id=:id") suspend fun deleteDebtorTransaction(id:Long)
    @Query("SELECT * FROM harvest_debtor_transactions ORDER BY dateMillis DESC,id DESC") fun observeAllDebtorTransactions():Flow<List<HarvestDebtorTransactionEntity>>
    @Query("DELETE FROM harvest_debtor_transactions WHERE sourceDayId=:dayId") suspend fun deleteDebtorTransactionsForDay(dayId:Long)
    @Query("DELETE FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE sourceDayId=:dayId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE sourceDayId=:dayId))") suspend fun deleteHarvestPartyPaymentsForDay(dayId:Long)
    @Query("DELETE FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE harvestId=:harvestId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE harvestId=:harvestId))") suspend fun deleteHarvestPartyPaymentsForHarvest(harvestId:Long)
    @Query("DELETE FROM distributor_transactions WHERE harvestId=:harvestId") suspend fun deleteDistributorTransactionsForHarvest(harvestId:Long)
    @Query("DELETE FROM harvest_debtor_transactions WHERE harvestId=:harvestId") suspend fun deleteDebtorTransactionsForHarvest(harvestId:Long)
    @Insert suspend fun insertBuyer(item: QatBuyerEntity): Long
    @Query("SELECT * FROM qat_buyers ORDER BY name COLLATE NOCASE") fun observeBuyers(): Flow<List<QatBuyerEntity>>
    @Query("SELECT * FROM qat_buyers WHERE id=:id LIMIT 1") suspend fun getBuyerById(id:Long):QatBuyerEntity?
    @Query("SELECT p.name FROM qat_buyers p LEFT JOIN buyer_sales s ON s.buyerId=p.id GROUP BY p.id ORDER BY MAX(s.saleDateMillis) DESC, COUNT(s.id) DESC, p.name COLLATE NOCASE") fun observeBuyerNameSuggestions():Flow<List<String>>
    @Insert suspend fun insertBuyerSale(item: BuyerSaleEntity): Long
    @Update suspend fun updateBuyerSale(item:BuyerSaleEntity)
    @Query("SELECT * FROM buyer_sales WHERE buyerId=:buyerId ORDER BY saleDateMillis DESC") fun observeBuyerSales(buyerId:Long): Flow<List<BuyerSaleEntity>>
    @Query("SELECT * FROM buyer_sales ORDER BY saleDateMillis DESC") fun observeAllBuyerSales(): Flow<List<BuyerSaleEntity>>
    @Query("SELECT * FROM buyer_sales WHERE id=:id LIMIT 1") suspend fun getBuyerSaleById(id:Long):BuyerSaleEntity?
    @Insert suspend fun insertBuyerPayment(item: BuyerPaymentEntity): Long
    @Query("SELECT * FROM buyer_payments WHERE saleId=:saleId ORDER BY dateMillis DESC") fun observeBuyerPayments(saleId:Long): Flow<List<BuyerPaymentEntity>>
    @Query("SELECT * FROM buyer_payments ORDER BY dateMillis DESC,id DESC") fun observeAllBuyerPayments():Flow<List<BuyerPaymentEntity>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM buyer_payments WHERE saleId=:saleId") fun observeBuyerPaymentsTotal(saleId:Long): Flow<Long>
    @Insert suspend fun insertDistributor(item: MarketDistributorEntity): Long
    @Query("SELECT * FROM market_distributors ORDER BY name COLLATE NOCASE") fun observeDistributors(): Flow<List<MarketDistributorEntity>>
    @Query("SELECT * FROM market_distributors WHERE id=:id LIMIT 1") suspend fun getDistributorById(id:Long):MarketDistributorEntity?
    @Query("SELECT p.name FROM market_distributors p LEFT JOIN distributor_transactions t ON t.distributorId=p.id GROUP BY p.id ORDER BY MAX(t.dateMillis) DESC, COUNT(t.id) DESC, p.name COLLATE NOCASE") fun observeDistributorNameSuggestions():Flow<List<String>>
    @Insert suspend fun insertDistributorTransaction(item: DistributorTransactionEntity): Long
    @Update suspend fun updateDistributorTransaction(item:DistributorTransactionEntity)
    @Query("SELECT * FROM distributor_transactions WHERE distributorId=:id ORDER BY dateMillis DESC,id DESC") fun observeDistributorTransactions(id:Long): Flow<List<DistributorTransactionEntity>>
    @Query("SELECT * FROM distributor_transactions WHERE id=:id LIMIT 1") suspend fun getDistributorTransaction(id:Long):DistributorTransactionEntity?
    @Query("DELETE FROM distributor_transactions WHERE id=:id") suspend fun deleteDistributorTransaction(id:Long)
    @Query("SELECT * FROM distributor_transactions ORDER BY dateMillis DESC,id DESC") fun observeAllDistributorTransactions():Flow<List<DistributorTransactionEntity>>
    @Query("DELETE FROM distributor_transactions WHERE sourceDayId=:dayId") suspend fun deleteDistributorTransactionsForDay(dayId:Long)
    @Insert suspend fun insertHarvestPartyPayment(item:HarvestPartyPaymentEntity):Long
    @Query("SELECT * FROM harvest_party_payments WHERE partyType=:partyType AND partyId=:partyId ORDER BY dateMillis DESC,id DESC") fun observeHarvestPartyPayments(partyType:String,partyId:Long):Flow<List<HarvestPartyPaymentEntity>>
    @Query("SELECT * FROM harvest_party_payments ORDER BY dateMillis DESC,id DESC") fun observeAllHarvestPartyPayments():Flow<List<HarvestPartyPaymentEntity>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM harvest_party_payments WHERE partyType=:partyType AND transactionId=:transactionId") fun observeHarvestPartyPaymentTotal(partyType:String,transactionId:Long):Flow<Long>
    @Query("SELECT (CASE WHEN :partyType='DISTRIBUTOR' THEN COALESCE((SELECT received FROM distributor_transactions WHERE id=:transactionId),0) ELSE COALESCE((SELECT paid FROM harvest_debtor_transactions WHERE id=:transactionId),0) END) + COALESCE((SELECT SUM(amount) FROM harvest_party_payments WHERE partyType=:partyType AND transactionId=:transactionId),0)") suspend fun getAccountCollectedTotal(partyType:String,transactionId:Long):Long
    @Query("DELETE FROM harvest_party_payments WHERE partyType=:partyType AND transactionId=:transactionId") suspend fun deleteHarvestPartyPaymentsForTransaction(partyType:String,transactionId:Long)
    @Query("UPDATE harvest_party_payments SET partyId=:newPartyId WHERE partyType=:partyType AND transactionId=:transactionId") suspend fun moveHarvestPartyPayments(transactionId:Long,partyType:String,newPartyId:Long)
    @Query("SELECT productType FROM personal_harvest_day_lines GROUP BY productType ORDER BY COUNT(*) DESC, MAX(createdAt) DESC, productType COLLATE NOCASE") fun observeHarvestProductSuggestions():Flow<List<String>>

    @Query("SELECT COALESCE(SUM(total),0) FROM personal_harvest_day_lines WHERE category IN ('distributor','cash','debt')") fun observePersonalHarvestRevenue():Flow<Long>
    // Transactions created directly from seller/customer files are also income. Daily rows are
    // already represented by personal_harvest_day_lines and are excluded here to prevent double counting.
    @Query("SELECT (SELECT COALESCE(SUM(total),0) FROM distributor_transactions WHERE sourceDayId=0) + (SELECT COALESCE(SUM(total),0) FROM harvest_debtor_transactions WHERE sourceDayId=0)") fun observeManualPartyRevenue():Flow<Long>
    @Query("SELECT (SELECT COALESCE(SUM(t.total),0) FROM distributor_transactions t INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE t.sourceDayId=0 AND h.plantationId=:plantationId) + (SELECT COALESCE(SUM(t.total),0) FROM harvest_debtor_transactions t INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE t.sourceDayId=0 AND h.plantationId=:plantationId)") fun observePlantationManualPartyRevenue(plantationId:Long):Flow<Long>
    // Include legacy costs captured by 0.7.0 as well as all later daily costs. New harvest
    // records created by 0.8.x leave the legacy fields at zero, so this does not double count.
    @Query("SELECT COALESCE((SELECT SUM(pickerCount*pickerWage+extraWages+bagsAndOther+transportAndClearance) FROM personal_harvests),0) + COALESCE((SELECT SUM(pickerCount*pickerWage+otherExpenses) FROM personal_harvest_days),0)") fun observePersonalHarvestCosts():Flow<Long>
    @Query("SELECT COALESCE(SUM(MAX(agreedAmount-discountAmount,0)),0) FROM buyer_sales") fun observeBuyerNetRevenue():Flow<Long>
    @Query("SELECT COUNT(*) FROM personal_harvest_days") fun observePersonalHarvestDayCount():Flow<Long>
    @Query("SELECT COUNT(*) FROM buyer_sales") fun observeBuyerSaleCount():Flow<Long>
    @Query("SELECT COALESCE(SUM(l.total),0) FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId") fun observePlantationHarvestRevenue(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE((SELECT SUM(h.pickerCount*h.pickerWage+h.extraWages+h.bagsAndOther+h.transportAndClearance) FROM personal_harvests h WHERE h.plantationId=:plantationId),0) + COALESCE((SELECT SUM(d.pickerCount*d.pickerWage+d.otherExpenses) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId),0)") fun observePlantationHarvestCosts(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(MAX(agreedAmount-discountAmount,0)),0) FROM buyer_sales WHERE plantationId=:plantationId") fun observePlantationBuyerRevenue(plantationId:Long):Flow<Long>
}

@Database(
    entities = [PlantationEntity::class, ExpenseEntity::class, InvoiceEntity::class, StockItemEntity::class, InvoiceItemEntity::class, StockMovementEntity::class, PersonalHarvestEntity::class, HarvestDebtorEntity::class, HarvestDebtorTransactionEntity::class, QatBuyerEntity::class, BuyerSaleEntity::class, BuyerPaymentEntity::class, MarketDistributorEntity::class, DistributorTransactionEntity::class, PersonalHarvestDayEntity::class, PersonalHarvestDayLineEntity::class, HarvestPartyPaymentEntity::class],
    version = 6,
    exportSchema = true
)
abstract class MiyarDatabase : RoomDatabase() {
    abstract fun dao(): MiyarDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `invoices` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `supplier` TEXT NOT NULL, `invoiceNumber` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `paymentStatus` TEXT NOT NULL, `currency` TEXT NOT NULL, `exchangeRateScaled` INTEGER NOT NULL, `totalForeign` INTEGER NOT NULL, `totalYer` INTEGER NOT NULL, `notes` TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `productType` TEXT NOT NULL, `productName` TEXT NOT NULL, `activeIngredient` TEXT NOT NULL, `baseUnit` TEXT NOT NULL, `quantityBase` INTEGER NOT NULL, `totalReceivedBase` INTEGER NOT NULL, `totalUsedBase` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_stock_items_productType_productName_baseUnit` ON `stock_items` (`productType`, `productName`, `baseUnit`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `invoice_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `invoiceId` INTEGER NOT NULL, `stockItemId` INTEGER NOT NULL, `productType` TEXT NOT NULL, `productName` TEXT NOT NULL, `activeIngredient` TEXT NOT NULL, `packageName` TEXT NOT NULL, `packageSize` INTEGER NOT NULL, `packageCount` INTEGER NOT NULL, `unit` TEXT NOT NULL, `quantityBase` INTEGER NOT NULL, `unitPriceForeign` INTEGER NOT NULL, `lineTotalForeign` INTEGER NOT NULL, `lineTotalYer` INTEGER NOT NULL, FOREIGN KEY(`invoiceId`) REFERENCES `invoices`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_items_invoiceId` ON `invoice_items` (`invoiceId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_items_stockItemId` ON `invoice_items` (`stockItemId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_movements` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `stockItemId` INTEGER NOT NULL, `referenceType` TEXT NOT NULL, `referenceId` INTEGER NOT NULL, `quantityBase` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `description` TEXT NOT NULL, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_stockItemId` ON `stock_movements` (`stockItemId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_referenceType_referenceId` ON `stock_movements` (`referenceType`, `referenceId`)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE stock_items ADD COLUMN treatmentType TEXT NOT NULL DEFAULT 'عام'")
                db.execSQL("ALTER TABLE invoice_items ADD COLUMN treatmentType TEXT NOT NULL DEFAULT 'عام'")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS personal_harvests (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, plantationId INTEGER NOT NULL, name TEXT NOT NULL, startMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, productsText TEXT NOT NULL, cashSalesText TEXT NOT NULL, debtorSalesText TEXT NOT NULL, pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, extraWages INTEGER NOT NULL, bagsAndOther INTEGER NOT NULL, transportAndClearance INTEGER NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS harvest_debtors (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_harvest_debtors_name ON harvest_debtors(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS harvest_debtor_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, debtorId INTEGER NOT NULL, harvestId INTEGER NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, paid INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_debtorId ON harvest_debtor_transactions(debtorId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS qat_buyers (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_qat_buyers_name ON qat_buyers(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS buyer_sales (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, buyerId INTEGER NOT NULL, harvestName TEXT NOT NULL, agreedAmount INTEGER NOT NULL, initialPaid INTEGER NOT NULL, saleDateMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, discountAmount INTEGER NOT NULL, discountReason TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_buyer_sales_buyerId ON buyer_sales(buyerId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS buyer_payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, saleId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_buyer_payments_saleId ON buyer_payments(saleId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS market_distributors (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_market_distributors_name ON market_distributors(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS distributor_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, distributorId INTEGER NOT NULL, harvestId INTEGER NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, received INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_distributorId ON distributor_transactions(distributorId)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4,5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS personal_harvest_days (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, harvestId INTEGER NOT NULL, dateMillis INTEGER NOT NULL, pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, otherExpenses INTEGER NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_days_harvestId ON personal_harvest_days(harvestId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_days_harvestId_dateMillis ON personal_harvest_days(harvestId,dateMillis)")
                db.execSQL("CREATE TABLE IF NOT EXISTS personal_harvest_day_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, dayId INTEGER NOT NULL, category TEXT NOT NULL, partyName TEXT NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_day_lines_dayId ON personal_harvest_day_lines(dayId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_day_lines_partyName ON personal_harvest_day_lines(partyName)")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5,6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE buyer_sales ADD COLUMN plantationId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN sourceDayId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN sourceLineId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN sourceDayId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN sourceLineId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_day_lines ADD COLUMN accountTransactionId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_sourceDayId ON distributor_transactions(sourceDayId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_sourceLineId ON distributor_transactions(sourceLineId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_sourceDayId ON harvest_debtor_transactions(sourceDayId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_sourceLineId ON harvest_debtor_transactions(sourceLineId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS harvest_party_payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, partyType TEXT NOT NULL, partyId INTEGER NOT NULL, transactionId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_party_payments_partyType_partyId ON harvest_party_payments(partyType,partyId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_party_payments_transactionId ON harvest_party_payments(transactionId)")
                // Rebuild party profiles from historic daily lines before linking those lines to ledgers.
                db.execSQL("INSERT OR IGNORE INTO market_distributors(name,phone,notes) SELECT DISTINCT TRIM(partyName),'','' FROM personal_harvest_day_lines WHERE category='distributor' AND TRIM(partyName)!=''")
                db.execSQL("INSERT OR IGNORE INTO harvest_debtors(name,phone,notes) SELECT DISTINCT TRIM(partyName),'','' FROM personal_harvest_day_lines WHERE category='debt' AND TRIM(partyName)!=''")
                db.execSQL("INSERT INTO distributor_transactions(distributorId,harvestId,productType,quantity,unitPrice,total,received,dateMillis,notes,sourceDayId,sourceLineId) SELECT p.id,h.id,l.productType,l.quantity,l.unitPrice,l.total,0,d.dateMillis,'ترحيل من سجل يوم القطفة',d.id,l.id FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId INNER JOIN market_distributors p ON p.name=TRIM(l.partyName) WHERE l.category='distributor'")
                db.execSQL("INSERT INTO harvest_debtor_transactions(debtorId,harvestId,productType,quantity,unitPrice,total,paid,dateMillis,notes,sourceDayId,sourceLineId) SELECT p.id,h.id,l.productType,l.quantity,l.unitPrice,l.total,0,d.dateMillis,'ترحيل من سجل يوم القطفة',d.id,l.id FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId INNER JOIN harvest_debtors p ON p.name=TRIM(l.partyName) WHERE l.category='debt'")
                db.execSQL("UPDATE personal_harvest_day_lines SET accountTransactionId=COALESCE((SELECT id FROM distributor_transactions WHERE sourceLineId=personal_harvest_day_lines.id LIMIT 1),(SELECT id FROM harvest_debtor_transactions WHERE sourceLineId=personal_harvest_day_lines.id LIMIT 1),0)")
            }
        }

        @Volatile private var INSTANCE: MiyarDatabase? = null

        fun get(context: Context): MiyarDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MiyarDatabase::class.java,
                    "miyar.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6).build().also { INSTANCE = it }
            }
    }
}
