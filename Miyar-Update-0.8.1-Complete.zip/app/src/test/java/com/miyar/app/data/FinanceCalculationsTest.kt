package com.miyar.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class FinanceCalculationsTest {
    @Test fun kilogramPackagesConvertToGrams() {
        assertEquals(25000L, FinanceCalculations.quantityToBase(5, "كجم", 5))
    }

    @Test fun gramPackagesRemainGrams() {
        assertEquals(1500L, FinanceCalculations.quantityToBase(500, "جرام", 3))
    }

    @Test fun litersConvertToMilliliters() {
        assertEquals(12000L, FinanceCalculations.quantityToBase(2, "لتر", 6))
    }

    @Test fun millilitersRemainMilliliters() {
        assertEquals(750L, FinanceCalculations.quantityToBase(250, "مل", 3))
    }

    @Test fun invoiceLineTotalUsesPackageCount() {
        assertEquals(3600L, FinanceCalculations.lineTotal(12, 300))
    }

    @Test fun exchangeRateConvertsCurrencyToYER() {
        assertEquals(2505L, FinanceCalculations.toYemeniRials(10, 250500))
    }

    @Test fun weightedAverageUnitCostIsBasedOnYemeniRials() {
        assertEquals(530L, FinanceCalculations.averageCostPerBaseScaled(53000L, 100000L))
    }

    @Test fun usageCostUsesWeightedAverageCost() {
        assertEquals(53L, FinanceCalculations.usageCostYer(100L, 530L))
    }

    @Test fun agreedInvoiceExampleConvertsToYERAndCorrectUnitCost() {
        // 100 USD x 530 YER/USD, for 5 packages x 20 kg = 100 kg.
        val totalYer = FinanceCalculations.toYemeniRials(100L, 530000L)
        val quantityGrams = FinanceCalculations.quantityToBase(20L, "كجم", 5L)
        val averageCostScaled = FinanceCalculations.averageCostPerBaseScaled(totalYer, quantityGrams)
        assertEquals(53000L, totalYer)
        assertEquals(100000L, quantityGrams)
        assertEquals(530L, averageCostScaled) // 0.530 YER per gram = 530 YER per kg.
        assertEquals(1060L, FinanceCalculations.usageCostYer(2000L, averageCostScaled)) // 2 kg.
    }

    @Test(expected = ArithmeticException::class)
    fun quantityOverflowIsRejected() {
        FinanceCalculations.quantityToBase(Long.MAX_VALUE, "كجم", 2)
    }
}
