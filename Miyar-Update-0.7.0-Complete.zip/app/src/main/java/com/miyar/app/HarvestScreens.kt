@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.miyar.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

private fun parseDate070(value:String):Long = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(value)?.time ?: System.currentTimeMillis() } catch (_:Exception) { System.currentTimeMillis() }
private fun date070(value:Long):String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(value))

@Composable
fun MiyarHarvestScreen(dao:MiyarDao, plantations:List<PlantationEntity>) {
 val scope= rememberCoroutineScope()
 var page by remember { mutableStateOf("choices") }
 var msg by remember { mutableStateOf("") }
 val buyers by dao.observeBuyers().collectAsStateWithLifecycle(initialValue= emptyList())
 val harvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(initialValue= emptyList())
 val allSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(initialValue= emptyList())
 var selectedBuyer by remember { mutableStateOf<QatBuyerEntity?>(null) }
 var selectedSale by remember { mutableStateOf<BuyerSaleEntity?>(null) }
 val payments = selectedSale?.let { dao.observeBuyerPayments(it.id).collectAsStateWithLifecycle(initialValue= emptyList()).value } ?: emptyList()
 Column(Modifier.fillMaxSize()) {
  if(page!="choices") TextButton(onClick={page="choices";selectedBuyer=null;selectedSale=null}) { Text("← رجوع إلى خيارات القطفات") }
  when(page) {
   "choices" -> {
    Text("قسم القطفات", style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Emerald)
    Spacer(Modifier.height(12.dp))
    Card(onClick={page="personal"}, modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor= androidx.compose.ui.graphics.Color.White)) { Row(Modifier.padding(20.dp),horizontalArrangement=Arrangement.spacedBy(14.dp)) { Text("🌿",style=MaterialTheme.typography.headlineLarge); Column { Text("قطفة شخصية",fontWeight=FontWeight.Bold);Text("إدارة الإنتاج والمبيعات النقدية والديون وموزعي السوق والمصاريف") } } }
    Spacer(Modifier.height(10.dp))
    Card(onClick={page="buyer"},modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor= androidx.compose.ui.graphics.Color.White)) { Row(Modifier.padding(20.dp),horizontalArrangement=Arrangement.spacedBy(14.dp)) { Text("🤝",style=MaterialTheme.typography.headlineLarge);Column { Text("البيع لمشتري",fontWeight=FontWeight.Bold);Text("تسجيل الاتفاق والمدة والواصلات وتقييم المشتري") } } }
    Spacer(Modifier.height(16.dp)); Text("القطفات الشخصية المسجلة",fontWeight=FontWeight.Bold)
    harvests.forEach { h -> Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) { Column(Modifier.padding(12.dp)) { Text(h.name,fontWeight=FontWeight.Bold);Text("بدأت ${date070(h.startMillis)} • المتوقع ${date070(h.expectedEndMillis)}");Text("عدد القطافين: ${h.pickerCount} • أجورهم: ${h.pickerCount*h.pickerWage}") } } }
    Text("عمليات البيع لمشترٍ",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
    allSales.forEach { s -> val b=buyers.firstOrNull{it.id==s.buyerId}; Card(Modifier.fillMaxWidth().padding(vertical=4.dp),onClick={selectedSale=s;selectedBuyer=b;page="saleDetail"}) { Column(Modifier.padding(12.dp)) { Text(b?.name ?: "مشتري",fontWeight=FontWeight.Bold);Text("${s.harvestName} • المتفق عليه ${s.agreedAmount} ريال") } } }
   }
   "personal" -> PersonalHarvestForm(dao,plantations,onSaved={page="choices";msg="تم حفظ بيانات القطفة"})
   "buyer" -> BuyerSaleForm(dao,buyers,onSaved={page="choices"})
   "saleDetail" -> {
    val sale=selectedSale; val buyer=selectedBuyer
    if(sale!=null && buyer!=null) {
     Text("ملف ${buyer.name}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Emerald)
     val paid=sale.initialPaid+payments.sumOf{it.amount}; val balance=(sale.agreedAmount-sale.discountAmount-paid).coerceAtLeast(0)
     val late=sale.actualEndMillis>0 && (sale.actualEndMillis-sale.saleDateMillis)/86400000 > (sale.expectedEndMillis-sale.saleDateMillis)/86400000
     val color=when { balance==0L && sale.discountAmount==0L -> androidx.compose.ui.graphics.Color(0xFF168447); sale.discountAmount>0 || late -> androidx.compose.ui.graphics.Color(0xFFD92D20); else -> androidx.compose.ui.graphics.Color(0xFFEAAA08) }
     Text("التقييم: ${if(color==androidx.compose.ui.graphics.Color(0xFF168447)) "أخضر" else if(color==androidx.compose.ui.graphics.Color(0xFFD92D20)) "أحمر" else "أصفر"}",color=color,fontWeight=FontWeight.Bold)
     Text("القطفة: ${sale.harvestName}\nالمتفق عليه: ${sale.agreedAmount}\nالواصل: $paid\nالباقي: $balance\nالخصم: ${sale.discountAmount}\nمدة القطف: ${if(sale.actualEndMillis>0) (sale.actualEndMillis-sale.saleDateMillis)/86400000 else 0} يوم")
     var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
     OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("مبلغ دفعة جديدة")},modifier=Modifier.fillMaxWidth())
     OutlinedTextField(note,{note=it},label={Text("تفاصيل الدفعة")},modifier=Modifier.fillMaxWidth())
     Button(onClick={val n=amount.toLongOrNull() ?: 0; if(n>0) scope.launch { dao.insertBuyerPayment(BuyerPaymentEntity(saleId=sale.id,amount=n,notes=note));amount="";note="" }},modifier=Modifier.fillMaxWidth()) { Text("إضافة واصلة") }
     Text("سجل الواصلات",fontWeight=FontWeight.Bold)
     payments.forEach { Text("${date070(it.dateMillis)} • ${it.amount} ريال • ${it.notes}") }
    }
   }
  }
  if(msg.isNotBlank()) Text(msg,color=Green)
 }
}

@Composable private fun PersonalHarvestForm(dao:MiyarDao, plantations:List<PlantationEntity>,onSaved:()->Unit) {
 val scope= rememberCoroutineScope(); var plot by remember { mutableStateOf(plantations.firstOrNull()?.id?.toString() ?: "") }
 var name by remember { mutableStateOf("") };var start by remember { mutableStateOf(date070(System.currentTimeMillis())) };var expected by remember { mutableStateOf(start) }
 var productType by remember { mutableStateOf("عود") };var qty by remember { mutableStateOf("") };var unitPrice by remember { mutableStateOf("") };var productRows by remember { mutableStateOf(listOf<String>()) }
 var cashRows by remember { mutableStateOf("") };var debtorRows by remember { mutableStateOf("") }
 var workers by remember { mutableStateOf("") };var wage by remember { mutableStateOf("") };var extra by remember { mutableStateOf("") };var bags by remember { mutableStateOf("") };var transport by remember { mutableStateOf("") };var notes by remember { mutableStateOf("") }
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
  Text("قطفة شخصية جديدة",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Emerald)
  Text("بيانات القطفة",fontWeight=FontWeight.Bold)
  var expanded by remember { mutableStateOf(false) }
  ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) { OutlinedTextField(plantations.firstOrNull{it.id.toString()==plot}?.name ?: "اختر الموضع",{},readOnly=true,label={Text("الموضع الزراعي")},modifier=Modifier.fillMaxWidth().menuAnchor());ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { plantations.forEach { p-> DropdownMenuItem(text={Text(p.name)},onClick={plot=p.id.toString();expanded=false}) } } }
  OutlinedTextField(name,{name=it},label={Text("اسم / رقم القطفة")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(start,{start=it},label={Text("تاريخ بدء القطف yyyy-MM-dd")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(expected,{expected=it},label={Text("التاريخ المتوقع للانتهاء yyyy-MM-dd")},modifier=Modifier.fillMaxWidth())
  HorizontalDivider();Text("الإنتاج حسب النوع",fontWeight=FontWeight.Bold)
  var typeExpanded by remember { mutableStateOf(false) }
  ExposedDropdownMenuBox(expanded=typeExpanded,onExpandedChange={typeExpanded=it}) { OutlinedTextField(productType,{},readOnly=true,label={Text("نوع المنتج")},modifier=Modifier.fillMaxWidth().menuAnchor());ExposedDropdownMenu(expanded=typeExpanded,onDismissRequest={typeExpanded=false}) { listOf("عود","قطل","مدبوش","آخر").forEach { DropdownMenuItem(text={Text(it)},onClick={productType=it;typeExpanded=false}) } } }
  OutlinedTextField(qty,{qty=it.filter(Char::isDigit)},label={Text("عدد العلاقيات")},modifier=Modifier.fillMaxWidth());OutlinedTextField(unitPrice,{unitPrice=it.filter(Char::isDigit)},label={Text("سعر العلاقية")},modifier=Modifier.fillMaxWidth())
  Button(onClick={val q=qty.toLongOrNull()?:0;val p=unitPrice.toLongOrNull()?:0;if(q>0) {productRows=productRows+"$productType|$q|$p|${q*p}";qty="";unitPrice=""}},modifier=Modifier.fillMaxWidth()) { Text("إضافة صنف للإنتاج") }
  productRows.forEach { Text(it.replace("|"," • ")) }
  HorizontalDivider();Text("المبيعات النقدية",fontWeight=FontWeight.Bold);OutlinedTextField(cashRows,{cashRows=it},label={Text("سجل المبيعات النقدية: النوع، العدد، السعر، التفاصيل")},modifier=Modifier.fillMaxWidth(),minLines=2)
  Text("المبيعات بالأجل",fontWeight=FontWeight.Bold);OutlinedTextField(debtorRows,{debtorRows=it},label={Text("أسماء العملاء وكمياتهم وأسعارهم وتفاصيل الديون")},modifier=Modifier.fillMaxWidth(),minLines=2)
  HorizontalDivider();Text("أجور ومصاريف القطفة",fontWeight=FontWeight.Bold)
  OutlinedTextField(workers,{workers=it.filter(Char::isDigit)},label={Text("عدد القطافين")},modifier=Modifier.fillMaxWidth());OutlinedTextField(wage,{wage=it.filter(Char::isDigit)},label={Text("أجر القطاف الواحد")},modifier=Modifier.fillMaxWidth())
  Text("إجمالي أجور القطافين: ${(workers.toLongOrNull()?:0)*(wage.toLongOrNull()?:0)} ريال",fontWeight=FontWeight.Bold,color=Emerald)
  OutlinedTextField(extra,{extra=it.filter(Char::isDigit)},label={Text("أجور إضافية")},modifier=Modifier.fillMaxWidth());OutlinedTextField(bags,{bags=it.filter(Char::isDigit)},label={Text("قيمة الأكياس وخرج آخر")},modifier=Modifier.fillMaxWidth());OutlinedTextField(transport,{transport=it.filter(Char::isDigit)},label={Text("أجر التوصيل والتخليص")},modifier=Modifier.fillMaxWidth());OutlinedTextField(notes,{notes=it},label={Text("ملاحظات أخرى")},modifier=Modifier.fillMaxWidth(),minLines=2)
  Button(onClick={val plotId=plot.toLongOrNull();if(plotId!=null && name.isNotBlank() && productRows.isNotEmpty()) scope.launch { dao.insertPersonalHarvest(PersonalHarvestEntity(plantationId=plotId,name=name,startMillis=parseDate070(start),expectedEndMillis=parseDate070(expected),productsText=productRows.joinToString(";"),cashSalesText=cashRows,debtorSalesText=debtorRows,pickerCount=workers.toLongOrNull()?:0,pickerWage=wage.toLongOrNull()?:0,extraWages=extra.toLongOrNull()?:0,bagsAndOther=bags.toLongOrNull()?:0,transportAndClearance=transport.toLongOrNull()?:0,notes=notes));onSaved()}},modifier=Modifier.fillMaxWidth()) { Text("حفظ القطفة") }
 }
}

@Composable private fun BuyerSaleForm(dao:MiyarDao,buyers:List<QatBuyerEntity>,onSaved:()->Unit) {
 val scope= rememberCoroutineScope();var buyerName by remember { mutableStateOf("") };var harvest by remember { mutableStateOf("") };var agreed by remember { mutableStateOf("") };var paid by remember { mutableStateOf("") };var saleDate by remember { mutableStateOf(date070(System.currentTimeMillis())) };var expected by remember { mutableStateOf(saleDate) };var actual by remember { mutableStateOf("") };var discount by remember { mutableStateOf("0") };var reason by remember { mutableStateOf("") };var notes by remember { mutableStateOf("") }
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
  Text("البيع لمشتري",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Emerald)
  OutlinedTextField(buyerName,{buyerName=it},label={Text("اسم المشتري")},modifier=Modifier.fillMaxWidth())
  if(buyers.isNotEmpty()) Text("المشترون المسجلون: ${buyers.joinToString("، "){it.name}}",style=MaterialTheme.typography.bodySmall)
  OutlinedTextField(harvest,{harvest=it},label={Text("اسم القطفة / رقمها")},modifier=Modifier.fillMaxWidth());OutlinedTextField(agreed,{agreed=it.filter(Char::isDigit)},label={Text("السعر المتفق عليه")},modifier=Modifier.fillMaxWidth());OutlinedTextField(paid,{paid=it.filter(Char::isDigit)},label={Text("الواصل منه عند البيع")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(saleDate,{saleDate=it},label={Text("تاريخ البيع yyyy-MM-dd")},modifier=Modifier.fillMaxWidth());OutlinedTextField(expected,{expected=it},label={Text("التاريخ المتوقع للانتهاء yyyy-MM-dd")},modifier=Modifier.fillMaxWidth());OutlinedTextField(actual,{actual=it},label={Text("تاريخ الانتهاء الفعلي yyyy-MM-dd (عند الانتهاء)")},modifier=Modifier.fillMaxWidth())
  val days=if(actual.isNotBlank()) ((parseDate070(actual)-parseDate070(saleDate))/86400000).coerceAtLeast(0) else ((System.currentTimeMillis()-parseDate070(saleDate))/86400000).coerceAtLeast(0)
  Text("مدة القطف حتى الآن / الانتهاء: $days يوم",fontWeight=FontWeight.Bold,color=Emerald)
  OutlinedTextField(discount,{discount=it.filter(Char::isDigit)},label={Text("الخصم من السعر المتفق عليه (إن وجد)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(reason,{reason=it},label={Text("سبب الخصم")},modifier=Modifier.fillMaxWidth());OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())
  Text("الباقي المبدئي: ${((agreed.toLongOrNull()?:0)-(paid.toLongOrNull()?:0)-(discount.toLongOrNull()?:0)).coerceAtLeast(0)} ريال",fontWeight=FontWeight.Bold)
  Button(onClick={val a=agreed.toLongOrNull()?:0;val p=paid.toLongOrNull()?:0;if(buyerName.isNotBlank() && harvest.isNotBlank() && a>0) scope.launch { val existing=buyers.firstOrNull{it.name.trim().equals(buyerName.trim(),true)};val id=existing?.id ?: dao.insertBuyer(QatBuyerEntity(name=buyerName.trim()));dao.insertBuyerSale(BuyerSaleEntity(buyerId=id,harvestName=harvest,agreedAmount=a,initialPaid=p,saleDateMillis=parseDate070(saleDate),expectedEndMillis=parseDate070(expected),actualEndMillis=if(actual.isBlank())0 else parseDate070(actual),discountAmount=discount.toLongOrNull()?:0,discountReason=reason,notes=notes));onSaved()}},modifier=Modifier.fillMaxWidth()) { Text("حفظ عملية البيع") }
 }
}
