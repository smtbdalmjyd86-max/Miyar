@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.miyar.app

import android.os.Bundle
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.window.PopupProperties
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import java.security.MessageDigest
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale
import java.util.Date


private fun Context.findHostActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

internal val Emerald = androidx.compose.ui.graphics.Color(0xFF103D32)
internal val Green = androidx.compose.ui.graphics.Color(0xFF147D64)
internal val Cream = androidx.compose.ui.graphics.Color(0xFFF7F3E8)
internal val Gold = androidx.compose.ui.graphics.Color(0xFFC7A65A)

class MainActivity : ComponentActivity() {
    private val dao by lazy { MiyarDatabase.get(this).dao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 731)
        }
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Emerald,
                    onPrimary = androidx.compose.ui.graphics.Color.White,
                    primaryContainer = androidx.compose.ui.graphics.Color(0xFFDCEFE7),
                    onPrimaryContainer = Emerald,
                    secondary = Gold,
                    onSecondary = Emerald,
                    secondaryContainer = androidx.compose.ui.graphics.Color(0xFFF1E5C8),
                    onSecondaryContainer = Emerald,
                    tertiary = Green,
                    background = Cream,
                    onBackground = Emerald,
                    surface = androidx.compose.ui.graphics.Color(0xFFFFFEFA),
                    onSurface = Emerald,
                    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFECE8DC),
                    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF53665E),
                    outline = androidx.compose.ui.graphics.Color(0xFFB9A36B)
                )
            ) {
                MiyarApp(dao)
            }
        }
    }
}

private val PlantationStateSaver = androidx.compose.runtime.saveable.listSaver<PlantationEntity?, String>(
    save = { value -> if (value == null) emptyList() else listOf(value.id.toString(), value.name, value.createdAt.toString()) },
    restore = { values -> if (values.size < 3) null else PlantationEntity(values[0].toLong(), values[1], values[2].toLong()) }
)
private val ExpenseStateSaver = androidx.compose.runtime.saveable.listSaver<ExpenseEntity?, String>(
    save = { value -> if (value == null) emptyList() else listOf(value.id.toString(), value.plantationId.toString(), value.category, value.title, value.amount.toString(), value.currency, value.dateMillis.toString(), value.notes) },
    restore = { v -> if (v.size < 8) null else ExpenseEntity(v[0].toLong(), v[1].toLong(), v[2], v[3], v[4].toLong(), v[5], v[6].toLong(), v[7]) }
)

@Composable
private fun MiyarApp(dao: MiyarDao) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_security", android.content.Context.MODE_PRIVATE) }
    var configuredPin by remember { mutableStateOf(prefs.getString("pin_hash", null)) }
    var unlocked by rememberSaveable { mutableStateOf(configuredPin == null) }
    var pinInput by rememberSaveable { mutableStateOf("") }
    var pinError by rememberSaveable { mutableStateOf("") }
    var showPinSettings by rememberSaveable { mutableStateOf(false) }
    var showPinSetup by rememberSaveable { mutableStateOf(false) }
    var newPin by rememberSaveable { mutableStateOf("") }
    var confirmPin by rememberSaveable { mutableStateOf("") }
    var pinSettingsMessage by rememberSaveable { mutableStateOf("") }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, configuredPin) {
        val observer = LifecycleEventObserver { _, event ->
            // Do not relock or discard an active form during a configuration change
            // such as portrait/landscape rotation.
            if (event == Lifecycle.Event.ON_STOP && configuredPin != null &&
                context.findHostActivity()?.isChangingConfigurations != true) {
                unlocked = false
                pinInput = ""
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val totalExpenses by dao.observeTotalExpenses().collectAsStateWithLifecycle(initialValue = 0L)
    val totalRevenue by dao.observeTotalRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    val harvestCount by dao.observeHarvestCount().collectAsStateWithLifecycle(initialValue = 0L)
    val stockSuggestions by dao.observeStockPriceSuggestions().collectAsStateWithLifecycle(initialValue = emptyList())
    var selected by rememberSaveable(stateSaver = PlantationStateSaver) { mutableStateOf<PlantationEntity?>(null) }
    var showAddPlantation by rememberSaveable { mutableStateOf(false) }
    var showAddExpense by rememberSaveable { mutableStateOf(false) }
    var expenseSaving by rememberSaveable { mutableStateOf(false) }
    var showChoosePlantation by rememberSaveable { mutableStateOf(false) }
    var showChooseCategory by rememberSaveable { mutableStateOf(false) }
    var editingExpense by rememberSaveable(stateSaver = ExpenseStateSaver) { mutableStateOf<ExpenseEntity?>(null) }
    var plantationToDelete by rememberSaveable(stateSaver = PlantationStateSaver) { mutableStateOf<PlantationEntity?>(null) }
    var deleteMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var currentSection by rememberSaveable { mutableStateOf("الرئيسية") }
    val sections = listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات", "الفواتير", "المخزون", "التقارير")
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    BackHandler(enabled = unlocked && (selected != null || currentSection != "الرئيسية" || showPinSettings || showPinSetup || showAbout || showChooseCategory || showChoosePlantation || (showAddExpense && !expenseSaving) || showAddPlantation)) {
        when {
            showPinSettings -> showPinSettings = false
            showPinSetup -> showPinSetup = false
            showAbout -> showAbout = false
            showChooseCategory -> showChooseCategory = false
            showChoosePlantation -> showChoosePlantation = false
            showAddExpense && !expenseSaving -> { showAddExpense = false; editingExpense = null }
            showAddPlantation -> showAddPlantation = false
            selected != null -> selected = null
            currentSection != "الرئيسية" -> { currentSection = "الرئيسية"; selected = null }
            else -> { /* في الرئيسية لا نغلق التطبيق من زر الرجوع؛ نترك النظام يضعه بالخلفية */ }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = Cream) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MiyarMark(Modifier.size(54.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("أهلاً بك في معيار", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
                                Text("إدارة أدق - مردود أوضح", color = Green, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    HorizontalDivider(color = Gold.copy(alpha = 0.6f))
                    Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("الرئيسية") },
                        selected = currentSection == "الرئيسية",
                        onClick = { currentSection = "الرئيسية"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        icon = { Text("🌱") },
                        label = { Text("المواضع الزراعية") },
                        selected = currentSection == "المواضع الزراعية",
                        onClick = { currentSection = "المواضع الزراعية"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    sections.forEach { section ->
                        NavigationDrawerItem(
                            icon = { Text(when (section) { "الأسمدة" -> "🌿"; "السموم" -> "🐛"; "المياه", "المياه والري" -> "💧"; "الأعمال اليدوية" -> "🧑‍🌾"; "القطفات" -> "🧺"; "الفواتير" -> "🧾"; "المخزون" -> "📦"; "التقارير" -> "📊"; else -> "📝" }) },
                            label = { Text(section) },
                            selected = currentSection == section,
                            onClick = { currentSection = section; selected = null; scope.launch { drawerState.close() } },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    NavigationDrawerItem(
                        icon = { Text("🔒") },
                        label = { Text("الإعدادات") },
                        selected = currentSection == "الإعدادات",
                        onClick = { currentSection = "الإعدادات"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Info, contentDescription = null) },
                        label = { Text("عن مِعيار") },
                        selected = false,
                        onClick = { showAbout = true; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    }
                }
            }
        ) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                if (unlocked && currentSection !in listOf("الإعدادات", "الفواتير", "المخزون", "التقارير", "القطفات")) FloatingActionButton(
                    onClick = {
                        when {
                            selected != null && (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") -> showChooseCategory = true
                            selected != null -> showAddExpense = true
                            currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" -> showAddPlantation = true
                            else -> showChoosePlantation = true
                        }
                    },
                    containerColor = Emerald,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).then(if (currentSection == "الرئيسية" && selected == null || currentSection == "الإعدادات") Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
                Header(onMenuClick = { scope.launch { drawerState.open() } })
                if (currentSection == "الرئيسية") {
                    Text("أهلاً بك في معيار", modifier = Modifier.padding(top = 10.dp, start = 4.dp), style = MaterialTheme.typography.titleMedium, color = Emerald, fontWeight = FontWeight.ExtraBold)
                    Text("إدارة أدق - مردود أوضح", modifier = Modifier.padding(start = 4.dp), style = MaterialTheme.typography.bodyMedium, color = Green)
                }
                Spacer(Modifier.height(12.dp))
                if (!unlocked) {
                    PinLockScreen(pinInput = pinInput, onInput = { pinInput = it.filter(Char::isDigit).take(8); pinError = "" },
                        onUnlock = {
                            if (pinInput.isNotBlank() && sha256(pinInput) == configuredPin) { unlocked = true; pinInput = ""; pinError = "" }
                            else pinError = "رمز PIN غير صحيح"
                        }, error = pinError, hasPin = configuredPin != null)
                } else if (currentSection == "القطفات" && selected == null) {
                    MiyarHarvestScreen(dao, plantations)
                } else if (currentSection == "الفواتير" && selected == null) {
                    MiyarInvoiceScreen(dao)
                } else if (currentSection == "المخزون" && selected == null) {
                    MiyarInventoryScreen(dao)
                } else if (currentSection == "التقارير" && selected == null) {
                    MiyarReportsScreen(dao)
                } else if (currentSection == "الإعدادات" && selected == null) {
                    Text("الإعدادات", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    FinancialCard("🔒 قفل التطبيق", if (configuredPin == null) "غير مفعّل" else "مفعّل", "رمز PIN عند العودة إلى التطبيق")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { newPin = ""; confirmPin = ""; pinSettingsMessage = ""; showPinSettings = true }, modifier = Modifier.fillMaxWidth()) { Text(if (configuredPin == null) "تعيين رمز PIN" else "تغيير أو إلغاء رمز PIN") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showAbout = true }, modifier = Modifier.fillMaxWidth()) { Text("معلومات التطبيق") }
                } else if (selected == null) {
                    Text(if (currentSection == "الرئيسية") "مواضعي الزراعية" else if (currentSection == "المواضع الزراعية") "المواضع الزراعية" else currentSection,
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                    Spacer(Modifier.height(8.dp))
                    if (currentSection != "الرئيسية" && currentSection != "المواضع الزراعية" && currentSection !in listOf("الفواتير", "المخزون", "التقارير")) {
                        val allRecords by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
                        val filteredRecords = allRecords.filter { record ->
                            record.category == currentSection ||
                            (currentSection == "المياه والري" && record.category == "المياه")
                        }
                        if (filteredRecords.isEmpty()) {
                            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                    Text("لا توجد عمليات مسجلة في قسم $currentSection", fontWeight = FontWeight.Bold)
                                    Text("اضغط إضافة عملية، ثم اختر الموضع الزراعي.")
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(filteredRecords, key = { it.id }) { record ->
                                    var details by remember(record.id) { mutableStateOf(false) }
                                    var menu by remember(record.id) { mutableStateOf(false) }
                                    var confirmDelete by remember(record.id) { mutableStateOf(false) }
                                    Card(modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { details = true }, onLongClick = { menu = true }), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(record.title, fontWeight = FontWeight.Bold, color = Emerald)
                                                Text("الموضع: ${record.plantationName} • ${record.category}", style = MaterialTheme.typography.bodySmall)
                                                Text(java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(record.dateMillis)), style = MaterialTheme.typography.labelSmall, color = Green)
                                            }
                                            Text(formatMoney(record.amount), fontWeight = FontWeight.Bold, color = Emerald)
                                        }
                                    }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; selected = plantations.firstOrNull { it.id == record.plantationId }; currentSection = record.category; editingExpense = ExpenseEntity(id = record.id, plantationId = record.plantationId, category = record.category, title = record.title, amount = record.amount, currency = record.currency, dateMillis = record.dateMillis, notes = record.notes); showAddExpense = true })
                                        DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
                                    }
                                    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("تأكيد حذف العملية") }, text = { Text("هل تريد حذف «${record.title}»؟") }, confirmButton = { TextButton(onClick = { scope.launch { dao.deleteExpenseAndRestoreStock(ExpenseEntity(id = record.id, plantationId = record.plantationId, category = record.category, title = record.title, amount = record.amount, currency = record.currency, dateMillis = record.dateMillis, notes = record.notes)); ReminderScheduler.cancel(context, record.id) }; confirmDelete = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } })
                                    if (details) AlertDialog(onDismissRequest = { details = false }, title = { Text(record.title) }, text = { Text("الموضع: ${record.plantationName}\\nنوع العملية: ${record.category}\\nالقيمة: ${formatMoney(record.amount)}\\n${record.notes}") }, confirmButton = { TextButton(onClick = { details = false }) { Text("إغلاق") } })
                                }
                            }
                        }
                    } else if (plantations.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("أهلًا بك في مِعيار 🌿", fontWeight = FontWeight.Bold)
                                Text("أضف أول موضع زراعي للبدء.")
                            }
                        }
                    } else if (currentSection != "الرئيسية") {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(plantations, key = { it.id }) { p ->
                                var menu by remember(p.id) { mutableStateOf(false) }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌱", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 8.dp))
                                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                            Text(p.name, fontWeight = FontWeight.SemiBold)
                                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "عرض تفاصيل الموضع ←" else "اختيار الموضع لهذا القسم ←", color = Green, style = MaterialTheme.typography.labelMedium)
                                        }
                                        TextButton(onClick = { selected = p }) { Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "فتح" else "اختيار") }
                                        Box {
                                            IconButton(onClick = { menu = true }) {
                                                Icon(Icons.Default.MoreVert, contentDescription = "إجراءات الموضع")
                                            }
                                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                                DropdownMenuItem(
                                                    text = { Text("حذف الموضع") },
                                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                                                    onClick = { menu = false; plantationToDelete = p }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (currentSection == "الرئيسية") {
                        Spacer(Modifier.height(12.dp))
                        FinancialCard("💸 إجمالي الخرج لجميع المواضع", formatMoney(totalExpenses), "مجموع المصروفات الزراعية المسجلة")
                        Spacer(Modifier.height(8.dp))
                        FinancialCard("💰 إجمالي المردود • عدد القطفات: $harvestCount", formatMoney(totalRevenue), "مجموع المبالغ الناتجة عن القطفات")
                        Spacer(Modifier.height(12.dp))
                        Text("ملخص الأنشطة الزراعية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        val categoryTotals by dao.observeCategoryTotals().collectAsStateWithLifecycle(initialValue = emptyList())
                        val totals = categoryTotals.associate { it.category to (it.count to it.total) }
                        val summaryCategories = listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات")
                        summaryCategories.chunked(2).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowItems.forEach { category ->
                                    val pair = if (category == "المياه والري") {
                                                val a = totals["المياه"] ?: (0L to 0L)
                                                val b = totals["المياه والري"] ?: (0L to 0L)
                                                (a.first + b.first) to (a.second + b.second)
                                            } else totals[category] ?: (0L to 0L)
                                    Card(onClick = { currentSection = category; selected = null }, modifier = Modifier.weight(1f).padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                            Text(category, color = Emerald, fontWeight = FontWeight.Bold)
                                            Text("عدد العمليات: ${pair.first}", style = MaterialTheme.typography.bodySmall)
                                            Text(formatMoney(pair.second), color = Green, fontWeight = FontWeight.ExtraBold)
                                            Text("عرض التفاصيل ←", style = MaterialTheme.typography.labelSmall, color = Gold)
                                        }
                                    }
                                }
                                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("آخر العمليات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        val recent by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
                        recent.take(5).forEach { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(12.dp)) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.Bold)
                                        Text("${item.plantationName} • ${item.category}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text("افتح أي بطاقة لعرض سجلاتها، واضغط مطولًا على العملية لتعديلها أو حذفها.", style = MaterialTheme.typography.bodySmall)
                    } else if (currentSection == "التقارير") {
                        Spacer(Modifier.height(8.dp))
                        Text("اختر موضعًا لعرض ملخص سجلاته وتقرير عملياته.", style = MaterialTheme.typography.bodyMedium)
                    } else if (currentSection != "المواضع الزراعية") {
                        Text("اختر الموضع الزراعي الذي تريد تسجيل بيانات قسم ${currentSection} عليه.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                        Column {
                            Text(selected!!.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "ملخص الموضع" else currentSection, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val allExpenses by dao.observeExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = emptyList())
                    val expenses = if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "التقارير") allExpenses else allExpenses.filter { it.category == currentSection }
                    val plantationTotal by dao.observePlantationExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationRevenue by dao.observePlantationRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    Spacer(Modifier.height(8.dp))
                    FinancialCard("💸 إجمالي خرج الموضع", formatMoney(plantationTotal), "يتحدث تلقائيًا من سجلات المصروفات")
                    FinancialCard("💰 إجمالي مردود الموضع", formatMoney(plantationRevenue), "إجمالي القطفات المسجلة لهذا الموضع")
                    Spacer(Modifier.height(12.dp))
                    Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "التقارير") "سجل العمليات" else "سجل ${currentSection}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (expenses.isEmpty()) Text(if (currentSection == "التقارير") "لا توجد عمليات مسجلة لعرضها في التقرير." else "لا توجد سجلات في هذا القسم لهذا الموضع بعد.", modifier = Modifier.padding(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(expenses, key = { it.id }) { expense ->
                            ExpenseRow(expense, stockSuggestions,
                                onUpdate = { updated, complete -> scope.launch {
                                    try {
                                        val quantityBase = extractQuantityBase(updated.notes)
                                        val unit = extractNoteValue(updated.notes, "وحدة القياس")
                                        val stockType = updated.category.takeIf { it == "السموم" || it == "الأسمدة" }
                                        val savedId = dao.saveExpenseWithStock(updated, stockType, unit?.let(::stockBaseUnit), quantityBase)
                                        val nextDate = extractNoteValue(updated.notes, "تاريخ العملية القادمة")
                                        if (!nextDate.isNullOrBlank()) ReminderScheduler.schedule(context, savedId, updated.title, updated.category, selected!!.name, nextDate)
                                        else ReminderScheduler.cancel(context, savedId)
                                        complete(true)
                                    } catch (t: Throwable) {
                                        deleteMessage = t.message ?: "تعذر تحديث العملية."
                                        complete(false)
                                    }
                                } },
                                onDelete = { item -> scope.launch { dao.deleteExpenseAndRestoreStock(item); ReminderScheduler.cancel(context, item.id) } }
                            )
                        }
                    }
                }
            }
        }
        }
    }

    if (!unlocked && configuredPin != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = {}, properties = androidx.compose.ui.window.DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = Cream) {
                PinLockScreen(pinInput = pinInput, onInput = { pinInput = it.filter(Char::isDigit).take(8); pinError = "" },
                    onUnlock = { if (pinInput.isNotBlank() && sha256(pinInput) == configuredPin) { unlocked = true; pinInput = ""; pinError = "" } else pinError = "رمز PIN غير صحيح" },
                    error = pinError, hasPin = true)
            }
        }
    }
    if (showPinSettings) {
        AlertDialog(
            onDismissRequest = { showPinSettings = false },
            title = { Text("قفل التطبيق برمز PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (configuredPin == null) "أنشئ رمزًا من 4 إلى 8 أرقام. سيُطلب عند العودة إلى التطبيق بعد مغادرته." else "القفل مفعّل. يمكنك تغيير الرمز أو إلغاء القفل.")
                    if (configuredPin != null) {
                        OutlinedButton(onClick = { prefs.edit().remove("pin_hash").apply(); configuredPin = null; unlocked = true; pinSettingsMessage = "تم إلغاء قفل التطبيق." }, modifier = Modifier.fillMaxWidth()) { Text("إلغاء رمز PIN") }
                    }
                    OutlinedButton(onClick = { showPinSettings = false; showPinSetup = true; newPin = ""; confirmPin = ""; pinSettingsMessage = "" }, modifier = Modifier.fillMaxWidth()) { Text(if (configuredPin == null) "إنشاء رمز PIN" else "تغيير رمز PIN") }
                    if (pinSettingsMessage.isNotBlank()) Text(pinSettingsMessage, color = Green)
                }
            },
            confirmButton = { TextButton(onClick = { showPinSettings = false }) { Text("إغلاق") } }
        )
    }
    if (showPinSetup) {
        AlertDialog(
            onDismissRequest = { showPinSetup = false },
            title = { Text(if (configuredPin == null) "إنشاء رمز PIN" else "تغيير رمز PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit).take(8) }, label = { Text("رمز PIN (4 إلى 8 أرقام)") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(8) }, label = { Text("تأكيد الرمز") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    if (pinSettingsMessage.isNotBlank()) Text(pinSettingsMessage, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (newPin.length < 4) pinSettingsMessage = "يجب أن يتكون الرمز من 4 أرقام على الأقل."
                else if (newPin != confirmPin) pinSettingsMessage = "الرمزان غير متطابقين."
                else {
                    val hash = sha256(newPin)
                    prefs.edit().putString("pin_hash", hash).apply()
                    configuredPin = hash
                    unlocked = true
                    pinSettingsMessage = ""
                    showPinSetup = false
                    showPinSettings = false
                }
            }) { Text("حفظ الرمز") } },
            dismissButton = { TextButton(onClick = { showPinSetup = false }) { Text("إلغاء") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("عن مِعيار") },
            text = { Text("مِعيار تطبيقك الذكي وعاملك التكنولوجي لإدارة ومتابعة مواضعك الزراعية بطريقة تواكب التطور الزراعي.\n\nتنفيذ وحقوق التطبيق: المهندس (أبو مجيد).") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("حسنًا") } }
        )
    }

    if (plantationToDelete != null) {
        val target = plantationToDelete!!
        AlertDialog(
            onDismissRequest = { plantationToDelete = null },
            title = { Text("تأكيد حذف الموضع") },
            text = { Text("هل تريد حذف الموضع «${target.name}»؟ لا يمكن حذف أي موضع يحتوي على مصروفات مسجلة.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val deleted = dao.deletePlantationIfEmpty(target.id)
                        if (!deleted) deleteMessage = "لا يمكن حذف الموضع «${target.name}» لأنه يحتوي على مصروفات مسجلة. احذف المصروفات أو احتفظ بالموضع."
                    }
                    plantationToDelete = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { plantationToDelete = null }) { Text("إلغاء") } }
        )
    }
    if (deleteMessage != null) {
        AlertDialog(
            onDismissRequest = { deleteMessage = null },
            title = { Text("تنبيه") },
            text = { Text(deleteMessage!!) },
            confirmButton = { TextButton(onClick = { deleteMessage = null }) { Text("حسنًا") } }
        )
    }

    if (showChooseCategory) {
        AlertDialog(
            onDismissRequest = { showChooseCategory = false },
            title = { Text("اختر نوع العملية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات").forEach { category ->
                        OutlinedButton(onClick = { currentSection = category; showChooseCategory = false; showAddExpense = true }, modifier = Modifier.fillMaxWidth()) { Text(category) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChooseCategory = false }) { Text("إلغاء") } }
        )
    }
    if (showChoosePlantation) {
        AlertDialog(
            onDismissRequest = { showChoosePlantation = false },
            title = { Text("اختر الموضع للعملية الجديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (plantations.isEmpty()) Text("أضف موضعًا زراعيًا أولًا من الصفحة الرئيسية.")
                    plantations.forEach { p ->
                        OutlinedButton(onClick = { selected = p; showChoosePlantation = false; showAddExpense = true }, modifier = Modifier.fillMaxWidth()) { Text(p.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChoosePlantation = false }) { Text("إلغاء") } }
        )
    }
    if (showAddPlantation) {
        TextEntryDialog("إضافة موضع زراعي", "اسم الموضع", onDismiss = { showAddPlantation = false }) { name ->
            scope.launch { dao.insertPlantation(PlantationEntity(name = name.trim())) }
            showAddPlantation = false
        }
    }
    if (showAddExpense && selected != null) {
        ExpenseDialog(initial = editingExpense, category = currentSection, stockSuggestions = stockSuggestions, onDismiss = { if (!expenseSaving) { showAddExpense = false; editingExpense = null } }) { title, amount, notes, complete ->
            expenseSaving = true
            scope.launch {
                try {
                    val normalizedCategory = editingExpense?.category ?: currentSection
                    val dateMillis = extractOperationDate(notes) ?: (editingExpense?.dateMillis ?: System.currentTimeMillis())
                    val item = ExpenseEntity(id = editingExpense?.id ?: 0L, plantationId = selected!!.id, category = normalizedCategory, title = title.trim(), amount = amount, dateMillis = dateMillis, notes = notes)
                    val quantityBase = extractQuantityBase(notes)
                    val unit = extractNoteValue(notes, "وحدة القياس")
                    val stockType = normalizedCategory.takeIf { it == "السموم" || it == "الأسمدة" }
                    val savedId = dao.saveExpenseWithStock(item, stockType, unit?.let(::stockBaseUnit), quantityBase)
                    val nextDate = extractNoteValue(notes, "تاريخ العملية القادمة")
                    if (!nextDate.isNullOrBlank()) {
                        ReminderScheduler.schedule(context, savedId, title.trim(), normalizedCategory, selected!!.name, nextDate)
                    } else ReminderScheduler.cancel(context, savedId)
                    showAddExpense = false
                    editingExpense = null
                    expenseSaving = false
                    complete(true)
                } catch (t: Throwable) {
                    deleteMessage = t.message ?: "تعذر حفظ العملية. تحقق من المخزون والبيانات."
                    expenseSaving = false
                    complete(false)
                }
            }
        }
    }
}

@Composable
private fun Header(onMenuClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, contentDescription = "فتح القائمة الجانبية", tint = androidx.compose.ui.graphics.Color.White)
            }
            MiyarMark(Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("مِعيار", style = MaterialTheme.typography.headlineMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                Text("إدارة أدق - مردود أوضح", color = Gold, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun MiyarMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .padding(2.dp)
            .then(Modifier),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(50),
            color = Emerald,
            border = androidx.compose.foundation.BorderStroke(2.dp, Gold)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("🌿", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}

@Composable
internal fun FinancialCard(title: String, value: String, caption: String) {
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(caption, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpenseRow(item: ExpenseEntity, stockSuggestions: List<StockPriceSuggestion>, onUpdate: (ExpenseEntity, (Boolean) -> Unit) -> Unit, onDelete: (ExpenseEntity) -> Unit) {
    var menu by rememberSaveable { mutableStateOf(false) }
    var editDialog by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { }, onLongClick = { menu = true }),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; editDialog = true })
                DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    if (editDialog) {
        ExpenseDialog(initial = item, stockSuggestions = stockSuggestions, onDismiss = { editDialog = false }) { title, amount, notes, complete ->
            onUpdate(item.copy(title = title.trim(), amount = amount, notes = notes, dateMillis = extractOperationDate(notes) ?: item.dateMillis)) { success ->
                if (success) editDialog = false
                complete(success)
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل تريد حذف المصروف «${item.title}»؟ لا يمكن التراجع عن هذه العملية.") },
            confirmButton = { TextButton(onClick = { onDelete(item); confirmDelete = false }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onSave(value) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun extractNoteValue(notes: String, label: String): String? =
    Regex("(?m)^\\s*${Regex.escape(label)}:\\s*(.*?)\\s*$").find(notes)?.groupValues?.get(1)?.trim()

private fun extractOperationDate(notes: String): Long? {
    val raw = extractNoteValue(notes, "تاريخ العملية") ?: return null
    return runCatching { java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(raw)?.time }.getOrNull()
}

private fun extractQuantityBase(notes: String): Long {
    val amount = extractNoteValue(notes, "الكمية")?.filter(Char::isDigit)?.toLongOrNull() ?: return 0L
    val unit = extractNoteValue(notes, "وحدة القياس")
    val multiplier = if (unit == "كجم" || unit == "لتر") 1000L else 1L
    return runCatching { Math.multiplyExact(amount, multiplier) }.getOrDefault(0L)
}

private fun formatStockQuantity(value: Long, unit: String): String = when (unit) {
    "g" -> if (value >= 1000 && value % 1000L == 0L) "${value / 1000} كجم" else "$value جرام"
    else -> if (value >= 1000 && value % 1000L == 0L) "${value / 1000} لتر" else "$value مل"
}

private fun stockBaseUnit(unit: String): String = if (unit == "كجم" || unit == "جرام") "g" else "ml"

private fun editableUserNotes(notes: String): String {
    val marker = "ملاحظات:"
    if (notes.contains(marker)) return notes.substringAfter(marker).trim()
    val labels = listOf("نوع العملية:", "نوع العمل:", "المادة الفعالة/العنصر:", "الكمية:", "وحدة القياس:",
        "نوع الوقود:", "قيمة الوقود:", "عدد الساعات:", "عدد العمال:", "تكاليف العمال:", "خرج آخر:",
        "أجر العامل:", "تاريخ العملية:", "تاريخ العملية القادمة:")
    return notes.lines().filterNot { line -> labels.any { line.trim().startsWith(it) } }.joinToString("\n").trim()
}

@Composable
private fun ExpenseDialog(initial: ExpenseEntity? = null, category: String = initial?.category ?: "أخرى", stockSuggestions: List<StockPriceSuggestion> = emptyList(), onDismiss: () -> Unit, onSave: (String, Long, String, (Boolean) -> Unit) -> Unit) {
    val focusManager = LocalFocusManager.current
    val nextFieldAction = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Next) })
    var title by rememberSaveable(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var amountText by rememberSaveable(initial?.id) { mutableStateOf(initial?.amount?.toString() ?: "") }
    var notes by rememberSaveable(initial?.id) { mutableStateOf(editableUserNotes(initial?.notes.orEmpty())) }
    var opDate by rememberSaveable(initial?.id) { mutableLongStateOf(initial?.dateMillis ?: System.currentTimeMillis()) }
    var nextDateMillis by rememberSaveable(initial?.id) {
        mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "تاريخ العملية القادمة")?.let {
            runCatching { java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(it)?.time }.getOrNull()
        })
    }
    var showNextDate by rememberSaveable(initial?.id) { mutableStateOf(nextDateMillis != null) }
    var opType by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "نوع العملية") ?: "حشري") }
    var ingredient by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "المادة الفعالة/العنصر").orEmpty()) }
    var quantity by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "الكمية").orEmpty()) }
    var quantityUnit by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "وحدة القياس") ?: if (category == "السموم") "مل" else "جرام") }
    var fuel by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "نوع الوقود") ?: "ديزل") }
    var fuelCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "قيمة الوقود").orEmpty()) }
    var hours by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "عدد الساعات").orEmpty()) }
    var workers by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "عدد عمال العملية") ?: extractNoteValue(initial?.notes.orEmpty(), "عدد العمال").orEmpty()) }
    var laborCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "تكاليف العمال").orEmpty()) }
    var otherCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "خرج آخر").orEmpty()) }
    var unitWage by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "أجر العامل").orEmpty()) }
    var workerCount by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "عدد العمال").orEmpty()) }
    var workType by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "نوع العمل") ?: "الحجين") }
    var saving by rememberSaveable(initial?.id) { mutableStateOf(false) }
    val isChemical = category == "السموم" || category == "الأسمدة"
    val isWater = category == "المياه" || category == "المياه والري"
    val isLabor = category == "الأعمال اليدوية"
    val isHarvest = category == "القطفات"
    var showProductSuggestions by rememberSaveable(initial?.id) { mutableStateOf(false) }
    var selectedStockId by rememberSaveable(initial?.id) {
        mutableLongStateOf(stockSuggestions.firstOrNull {
            it.productType == category && it.baseUnit == stockBaseUnit(quantityUnit) && it.productName.equals(title, true)
        }?.id ?: 0L)
    }
    // Preserve the saved historical expense amount while opening/editing a record.
    // Recalculate only after the user changes its product, quantity, or unit.
    var allowCostRecalculation by rememberSaveable(initial?.id) { mutableStateOf(initial == null) }
    val matchingProducts = stockSuggestions.filter {
        it.productType == category && it.baseUnit == stockBaseUnit(quantityUnit) && title.isNotBlank() && it.productName.contains(title.trim(), ignoreCase = true)
    }.take(6)
    LaunchedEffect(title, category, quantityUnit, stockSuggestions) {
        val exact = stockSuggestions.firstOrNull {
            it.productType == category && it.baseUnit == stockBaseUnit(quantityUnit) && it.productName.equals(title.trim(), true)
        }
        selectedStockId = exact?.id ?: 0L
        if (exact != null && ingredient.isBlank()) ingredient = exact.activeIngredient
    }
    LaunchedEffect(selectedStockId, quantity, quantityUnit, stockSuggestions, allowCostRecalculation) {
        val product = stockSuggestions.firstOrNull { it.id == selectedStockId }
        val amount = quantity.toLongOrNull()
        if (allowCostRecalculation && product != null && product.baseUnit == stockBaseUnit(quantityUnit) && amount != null && amount > 0L && product.averageCostPerBaseScaled > 0L) {
            val baseQty = runCatching { FinanceCalculations.quantityToBase(amount, quantityUnit) }.getOrNull()
            if (baseQty != null) {
                amountText = runCatching {
                    FinanceCalculations.usageCostYer(baseQty, product.averageCostPerBaseScaled).toString()
                }.getOrDefault(amountText)
            }
        }
    }
    val parsed = amountText.toLongOrNull()
    val autoTotal = if (isWater || isLabor) runCatching {
        val extras = Math.addExact(
            if (isWater) fuelCost.toLongOrNull() ?: 0L else 0L,
            if (isWater) laborCost.toLongOrNull() ?: 0L else 0L
        ).let { Math.addExact(it, otherCost.toLongOrNull() ?: 0L) }
        if (isLabor) Math.addExact(
            Math.multiplyExact(workerCount.toLongOrNull() ?: 0L, unitWage.toLongOrNull() ?: 0L),
            extras
        ) else extras
    }.getOrNull() else null
    var laborInputsTouched by rememberSaveable(initial?.id) { mutableStateOf(false) }
    LaunchedEffect(autoTotal, laborInputsTouched) {
        if (autoTotal != null && (initial == null || laborInputsTouched)) amountText = autoTotal.toString()
    }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (initial == null) "إضافة عملية: $category" else "تعديل عملية: $category") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (isChemical) {
                    Text("نوع العملية", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("حشري", "فطري", "ورقي", "جذري").forEach { t -> FilterChip(selected = opType == t, onClick = { opType = t }, label = { Text(t) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = when (t) {
                                "حشري" -> androidx.compose.ui.graphics.Color(0xFFFFE0B2)
                                "فطري" -> androidx.compose.ui.graphics.Color(0xFFE1BEE7)
                                "ورقي" -> androidx.compose.ui.graphics.Color(0xFFC8E6C9)
                                else -> androidx.compose.ui.graphics.Color(0xFFBBDEFB)
                            })) }
                    }
                }
                if (isLabor) {
                    Text("نوع العمل", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("الحشات", "الحجين", "البرح", "التراب", "أخرى").forEach { t -> FilterChip(selected = workType == t, onClick = { workType = t }, label = { Text(t) }) }
                    }
                    if (workType == "أخرى") OutlinedTextField(title, { title = it }, label = { Text("اسم العمل المخصص") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                if (!isLabor || workType != "أخرى") {
                    if (isChemical) {
                        Box(Modifier.fillMaxWidth()) {
                            OutlinedTextField(title, {
                                title = it
                                allowCostRecalculation = true
                                showProductSuggestions = true
                            }, label = { Text(if (category == "السموم") "اسم السم / المبيد" else "اسم السماد") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                            DropdownMenu(expanded = showProductSuggestions && matchingProducts.isNotEmpty(), onDismissRequest = { showProductSuggestions = false }, properties = PopupProperties(focusable = false)) {
                                matchingProducts.forEach { product ->
                                    DropdownMenuItem(
                                        text = { Column {
                                            Text(product.productName, fontWeight = FontWeight.SemiBold)
                                            Text(if (product.activeIngredient.isBlank()) "لا توجد مادة فعالة مسجلة" else product.activeIngredient, style = MaterialTheme.typography.bodySmall)
                                        } },
                                        onClick = {
                                            title = product.productName
                                            ingredient = product.activeIngredient
                                            selectedStockId = product.id
                                            allowCostRecalculation = true
                                            showProductSuggestions = false
                                        }
                                    )
                                }
                            }
                        }
                    } else {
                        OutlinedTextField(title, { title = it }, label = { Text(when {
                            isWater -> "بيان عملية المياه والري"
                            isLabor -> "بيان العمل (اختياري)"
                            isHarvest -> "بيان القطفة / المشتري"
                            else -> "بيان العملية"
                        }) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
                if (isChemical) {
                    OutlinedTextField(ingredient, { ingredient = it }, label = { Text(if (category == "السموم") "اسم المادة الفعالة" else "اسم العنصر") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(quantity, {
                        quantity = it.filter(Char::isDigit)
                        allowCostRecalculation = true
                    }, label = { Text("الكمية المستخدمة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        (if (category == "السموم") listOf("لتر", "مل", "جرام") else listOf("كجم", "جرام", "لتر", "مل")).forEach { unit ->
                            FilterChip(selected = quantityUnit == unit, onClick = {
                                quantityUnit = unit
                                allowCostRecalculation = true
                            }, label = { Text(unit) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = if (unit == "كجم" || unit == "لتر") androidx.compose.ui.graphics.Color(0xFFDCEFE2) else androidx.compose.ui.graphics.Color(0xFFE3ECFA)))
                        }
                    }
                    val chosenProduct = stockSuggestions.firstOrNull { it.id == selectedStockId }
                    val unitCostYer = chosenProduct?.let { product ->
                        if (product.averageCostPerBaseScaled <= 0L) null else runCatching {
                            val multiplier = if (quantityUnit == "كجم" || quantityUnit == "لتر") 1000L else 1L
                            BigDecimal(product.averageCostPerBaseScaled).multiply(BigDecimal(multiplier))
                                .divide(BigDecimal(1000), 3, RoundingMode.HALF_UP)
                        }.getOrNull()
                    }
                    if (chosenProduct != null) {
                        Text("المتاح في المخزون: ${formatStockQuantity(chosenProduct.quantityBase, chosenProduct.baseUnit)}", color = Green, style = MaterialTheme.typography.bodySmall)
                        Text(unitCostYer?.let { "سعر ${quantityUnit} من الفاتورة: ${String.format(Locale.US, "%.3f", it)} YER" }
                            ?: "لا يوجد سعر شراء مسجل لهذا الصنف", color = Emerald, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Text("تكلفة الكمية المستخدمة: ${formatMoney(amountText.toLongOrNull() ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                    }
                }
                MiyarDateField("تاريخ العملية", opDate) { opDate = it }
                if (isChemical || isWater) {
                    if (showNextDate && nextDateMillis != null) {
                        MiyarDateField("تاريخ العملية القادمة", nextDateMillis!!) { nextDateMillis = it }
                        TextButton(onClick = { showNextDate = false; nextDateMillis = null }) { Text("إلغاء موعد التذكير") }
                    } else TextButton(onClick = { showNextDate = true; nextDateMillis = System.currentTimeMillis() }) { Text("+ إضافة موعد العملية القادمة") }
                }
                if (isWater) {
                    Text("نوع الوقود", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("بترول", "ديزل", "غاز", "طاقة شمسية").forEach { t -> FilterChip(selected = fuel == t, onClick = { fuel = t }, label = { Text(t) }) }
                    }
                    OutlinedTextField(fuelCost, { fuelCost = it.filter(Char::isDigit); laborInputsTouched = true }, label = { Text("قيمة الوقود") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    OutlinedTextField(hours, { hours = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("عدد الساعات") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next), singleLine = true)
                    OutlinedTextField(workers, { workers = it.filter(Char::isDigit) }, label = { Text("عدد عمال العملية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    OutlinedTextField(laborCost, { laborCost = it.filter(Char::isDigit); laborInputsTouched = true }, label = { Text("تكاليف العمال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    OutlinedTextField(otherCost, { otherCost = it.filter(Char::isDigit); laborInputsTouched = true }, label = { Text("خرج آخر للعملية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    Text("إجمالي تكلفة العملية: ${formatMoney(autoTotal ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                } else if (isLabor) {
                    OutlinedTextField(workerCount, { workerCount = it.filter(Char::isDigit); laborInputsTouched = true }, label = { Text("عدد العمال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    OutlinedTextField(unitWage, { unitWage = it.filter(Char::isDigit); laborInputsTouched = true }, label = { Text("أجر العامل الواحد") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    OutlinedTextField(otherCost, { otherCost = it.filter(Char::isDigit); laborInputsTouched = true }, label = { Text("الخرج الإضافي") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                    Text("إجمالي تكلفة العملية: ${formatMoney(autoTotal ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                } else {
                    OutlinedTextField(amountText, { amountText = it.filter(Char::isDigit) }, label = { Text(if (isHarvest) "مبلغ المردود بالريال اليمني" else "مبلغ العملية بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), singleLine = true)
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات / بيانات أخرى") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = !saving && (title.isNotBlank() || isLabor) && parsed != null && parsed >= 0 && (!(isWater || isLabor) || autoTotal != null) && (!isChemical || (quantity.toLongOrNull() ?: 0L) > 0L || (initial != null && quantity.isBlank())), onClick = {
            val details = buildString {
                if (isChemical) {
                    append("نوع العملية: $opType\nالمادة الفعالة/العنصر: $ingredient\nالكمية: ${quantity.ifBlank { "0" }}\nوحدة القياس: $quantityUnit\n")
                }
                if (isWater) append("نوع الوقود: $fuel\nقيمة الوقود: $fuelCost\nعدد الساعات: $hours\nعدد عمال العملية: $workers\nتكاليف العمال: $laborCost\nخرج آخر: $otherCost\n")
                if (isLabor) append("نوع العمل: $workType\nعدد العمال: $workerCount\nأجر العامل: $unitWage\nخرج آخر: $otherCost\n")
                append("تاريخ العملية: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(opDate))}\n")
                if (showNextDate && nextDateMillis != null) append("تاريخ العملية القادمة: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(nextDateMillis!!))}\n")
                if (notes.isNotBlank()) append("ملاحظات: $notes")
            }
            saving = true
            onSave(if (title.isBlank() && isLabor) workType else title, requireNotNull(parsed), details) { saving = false }
        }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ العملية") } },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

internal fun formatMoney(amount: Long): String =
    NumberFormat.getIntegerInstance(Locale.US).format(amount) + " ر.ي"


@Composable
private fun PinLockScreen(pinInput: String, onInput: (String) -> Unit, onUnlock: () -> Unit, error: String, hasPin: Boolean) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        MiyarMark(Modifier.size(76.dp))
        Spacer(Modifier.height(16.dp))
        Text("مِعيار", style = MaterialTheme.typography.headlineLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
        Text("أدخل رمز PIN للمتابعة", color = Green)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = pinInput, onValueChange = onInput, label = { Text("رمز PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = onUnlock, enabled = hasPin && pinInput.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("فتح التطبيق") }
    }
}

private fun sha256(value: String): String =
    MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
