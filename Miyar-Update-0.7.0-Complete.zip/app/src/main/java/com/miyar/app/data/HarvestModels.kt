package com.miyar.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(tableName = "personal_harvests")
data class PersonalHarvestEntity(
 @PrimaryKey(autoGenerate=true) val id:Long=0, val plantationId:Long, val name:String,
 val startMillis:Long, val expectedEndMillis:Long, val actualEndMillis:Long=0,
 val productsText:String, val cashSalesText:String, val debtorSalesText:String,
 val pickerCount:Long, val pickerWage:Long, val extraWages:Long, val bagsAndOther:Long,
 val transportAndClearance:Long, val notes:String, val createdAt:Long=System.currentTimeMillis()
)
@Entity(tableName="harvest_debtors", indices=[Index(value=["name"], unique=true)])
data class HarvestDebtorEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String="",val notes:String="")
@Entity(tableName="harvest_debtor_transactions", indices=[Index("debtorId")])
data class HarvestDebtorTransactionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val debtorId:Long,val harvestId:Long,val productType:String,val quantity:Long,val unitPrice:Long,val total:Long,val paid:Long=0,val dateMillis:Long=System.currentTimeMillis(),val notes:String="")
@Entity(tableName="qat_buyers", indices=[Index(value=["name"], unique=true)])
data class QatBuyerEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String="",val notes:String="")
@Entity(tableName="buyer_sales", indices=[Index("buyerId")])
data class BuyerSaleEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val buyerId:Long,val harvestName:String,val agreedAmount:Long,val initialPaid:Long,val saleDateMillis:Long,val expectedEndMillis:Long,val actualEndMillis:Long=0,val discountAmount:Long=0,val discountReason:String="",val notes:String="")
@Entity(tableName="buyer_payments", indices=[Index("saleId")])
data class BuyerPaymentEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val saleId:Long,val amount:Long,val dateMillis:Long=System.currentTimeMillis(),val method:String="نقدًا",val notes:String="")
@Entity(tableName="market_distributors", indices=[Index(value=["name"], unique=true)])
data class MarketDistributorEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String="",val notes:String="")
@Entity(tableName="distributor_transactions", indices=[Index("distributorId")])
data class DistributorTransactionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val distributorId:Long,val harvestId:Long,val productType:String,val quantity:Long,val unitPrice:Long,val total:Long,val received:Long=0,val dateMillis:Long=System.currentTimeMillis(),val notes:String="")
