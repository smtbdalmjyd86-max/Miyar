@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.miyar.app

import android.os.Bundle
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.background
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.window.PopupProperties
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import java.security.MessageDigest
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date


private fun Context.findHostActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

internal val Emerald = androidx.compose.ui.graphics.Color(0xFF006B3C)
internal val Green = androidx.compose.ui.graphics.Color(0xFF00A94F)
internal val Cream = androidx.compose.ui.graphics.Color(0xFFF8FFF3)
internal val Gold = androidx.compose.ui.graphics.Color(0xFFFFC400)

/** Keep numeric fields internally consistent: Arabic/Persian numerals are displayed and stored as 0-9. */
internal fun latinDigitsOnly(value: String): String = buildString {
    value.forEach { ch ->
        val digit = when (ch) {
            in '0'..'9' -> ch - '0'
            in '٠'..'٩' -> ch - '٠'
            in '۰'..'۹' -> ch - '۰'
            else -> -1
        }
        if (digit >= 0) append(('0'.code + digit).toChar())
    }
}

/**
 * Formats money while typing: 2000000 -> 2.000.000.
 * Dots are thousands separators because monetary values are stored as integer Longs.
 */
private fun groupedDigits(value: String): String {
    val normalized = value.trimStart('0').ifEmpty { if (value.isEmpty()) "" else "0" }
    return normalized.reversed().chunked(3).joinToString(".").reversed()
}

internal fun moneyInput(value: String): String {
    return groupedDigits(latinDigitsOnly(value))
}

/** Currency rates allow up to three fractional digits, using a comma as decimal separator. */
internal fun rateInput(value: String): String {
    val commaIndex = maxOf(value.lastIndexOf(','), value.lastIndexOf('٫'))
    val dotCount = value.count { it == '.' }
    val dotTailLength = value.substringAfterLast('.', "").count { it.isDigit() }
    val decimalIndex = when {
        commaIndex >= 0 -> commaIndex
        dotCount == 1 && dotTailLength < 3 -> value.indexOf('.')
        else -> -1
    }
    val integerPart = if (decimalIndex >= 0) value.substring(0, decimalIndex) else value
    val fractionPart = if (decimalIndex >= 0) latinDigitsOnly(value.substring(decimalIndex + 1)).take(3) else ""
    val groupedInteger = groupedDigits(latinDigitsOnly(integerPart))
    val hasDecimalSeparator = decimalIndex >= 0
    return if (hasDecimalSeparator) "$groupedInteger,$fractionPart" else groupedInteger
}

/** Parse grouped or ungrouped monetary input without treating grouping dots as decimals. */
internal fun moneyToLong(value: String): Long = latinDigitsOnly(value).toLongOrNull() ?: 0L

private fun normalizedSearchText(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    .replace('ى', 'ي').lowercase(Locale.ROOT)

private fun searchDate(value: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(value))

class MainActivity : ComponentActivity() {
    private val dao by lazy { MiyarDatabase.get(this).dao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.scheduleDailyActivityCheck(this)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 731)
        }
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Emerald,
                    onPrimary = androidx.compose.ui.graphics.Color.White,
                    primaryContainer = androidx.compose.ui.graphics.Color(0xFFB9F6CA),
                    onPrimaryContainer = Emerald,
                    secondary = Gold,
                    onSecondary = Emerald,
                    secondaryContainer = androidx.compose.ui.graphics.Color(0xFFFFF3CD),
                    onSecondaryContainer = Emerald,
                    tertiary = Green,
                    background = androidx.compose.ui.graphics.Color.White,
                    onBackground = Emerald,
                    surface = androidx.compose.ui.graphics.Color.White,
                    onSurface = Emerald,
                    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFEAF5EE),
                    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF37634A),
                    outline = androidx.compose.ui.graphics.Color(0xFFB58A24),
                    outlineVariant = androidx.compose.ui.graphics.Color(0xFFB9D8C3),
                    error = androidx.compose.ui.graphics.Color(0xFFB3261E)
                )
            ) {
                MiyarApp(dao)
            }
        }
    }
}

private val PlantationStateSaver = androidx.compose.runtime.saveable.listSaver<PlantationEntity?, String>(
    save = { value -> if (value == null) emptyList() else listOf(value.id.toString(), value.name, value.createdAt.toString(), value.icon, value.colorArgb.toString()) },
    restore = { values -> if (values.size < 3) null else PlantationEntity(values[0].toLong(), values[1], values[2].toLong(), values.getOrElse(3) { "🌱" }, values.getOrElse(4) { "-16749764" }.toLong()) }
)
private val ExpenseStateSaver = androidx.compose.runtime.saveable.listSaver<ExpenseEntity?, String>(
    save = { value -> if (value == null) emptyList() else listOf(value.id.toString(), value.plantationId.toString(), value.category, value.title, value.amount.toString(), value.currency, value.dateMillis.toString(), value.notes) },
    restore = { v -> if (v.size < 8) null else ExpenseEntity(v[0].toLong(), v[1].toLong(), v[2], v[3], v[4].toLong(), v[5], v[6].toLong(), v[7]) }
)

@Composable
private fun MiyarApp(dao: MiyarDao) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_security", android.content.Context.MODE_PRIVATE) }
    var configuredPin by remember { mutableStateOf(prefs.getString("pin_hash", null)) }
    var unlocked by rememberSaveable { mutableStateOf(configuredPin == null) }
    var pinInput by rememberSaveable { mutableStateOf("") }
    var pinError by rememberSaveable { mutableStateOf("") }
    var showPinSettings by rememberSaveable { mutableStateOf(false) }
    var showPinSetup by rememberSaveable { mutableStateOf(false) }
    var newPin by rememberSaveable { mutableStateOf("") }
    var confirmPin by rememberSaveable { mutableStateOf("") }
    var pinSettingsMessage by rememberSaveable { mutableStateOf("") }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, configuredPin) {
        val observer = LifecycleEventObserver { _, event ->
            // Do not relock or discard an active form during a configuration change
            // such as portrait/landscape rotation.
            if (event == Lifecycle.Event.ON_STOP && configuredPin != null &&
                context.findHostActivity()?.isChangingConfigurations != true) {
                unlocked = false
                pinInput = ""
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalExpenses by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalInvoices by dao.observeInvoices().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalInvoiceItems by dao.observeAllInvoiceItems().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalStock by dao.observeStockItems().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalStockMovements by dao.observeAllStockMovements().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalSuppliers by dao.observeSuppliers().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalSupplierPayments by dao.observeSupplierPaymentsWithName().collectAsStateWithLifecycle(initialValue = emptyList())
    val activeOperationReminders by dao.observeOperationReminders().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalHarvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalBuyers by dao.observeBuyers().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalDebtors by dao.observeDebtors().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalDistributors by dao.observeDistributors().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalHarvestDays by dao.observeAllHarvestDays().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalHarvestDayLines by dao.observeAllHarvestDayLines().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalBuyerSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalBuyerPayments by dao.observeAllBuyerPayments().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalDebtorTransactions by dao.observeAllDebtorTransactions().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalDistributorTransactions by dao.observeAllDistributorTransactions().collectAsStateWithLifecycle(initialValue = emptyList())
    val globalPartyPayments by dao.observeAllHarvestPartyPayments().collectAsStateWithLifecycle(initialValue = emptyList())
    val personalHarvestRevenue by dao.observePersonalHarvestRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    val manualPartyRevenue by dao.observeManualPartyRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    val personalHarvestCosts by dao.observePersonalHarvestCosts().collectAsStateWithLifecycle(initialValue = 0L)
    val buyerHarvestRevenue by dao.observeBuyerNetRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    val buyerSaleCount by dao.observeBuyerSaleCount().collectAsStateWithLifecycle(initialValue = 0L)
    val personalHarvestDayCount by dao.observePersonalHarvestDayCount().collectAsStateWithLifecycle(initialValue = 0L)
    var drawerSearch by rememberSaveable { mutableStateOf("") }
    var harvestSearchTarget by rememberSaveable { mutableStateOf<String?>(null) }
    val searchPrefs = remember { context.getSharedPreferences("miyar_search", Context.MODE_PRIVATE) }
    var recentSearches by remember { mutableStateOf(searchPrefs.getString("recent_queries", "").orEmpty().split('\n').filter { it.isNotBlank() }) }
    var saveSearchHistory by remember { mutableStateOf(searchPrefs.getBoolean("save_history", true)) }
    fun rememberSearchQuery(value: String) {
        if (!saveSearchHistory) return
        val clean = value.trim().replace('\n', ' ').take(80)
        if (clean.isNotBlank()) {
            recentSearches = (listOf(clean) + recentSearches.filterNot { it.equals(clean, ignoreCase = true) }).take(8)
            searchPrefs.edit().putString("recent_queries", recentSearches.joinToString("\n")).apply()
        }
    }
    val totalExpenses by dao.observeTotalExpenses().collectAsStateWithLifecycle(initialValue = 0L)
    val totalRevenue by dao.observeTotalRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    val harvestCount by dao.observeHarvestCount().collectAsStateWithLifecycle(initialValue = 0L)
    val dashboardRevenue = totalRevenue + personalHarvestRevenue + manualPartyRevenue + buyerHarvestRevenue
    val dashboardExpenses = totalExpenses + personalHarvestCosts
    val dashboardNet = dashboardRevenue - dashboardExpenses
    val dashboardHarvestCount = harvestCount + globalHarvests.size.toLong() + globalBuyerSales.size.toLong()
    val stockSuggestions by dao.observeStockPriceSuggestions().collectAsStateWithLifecycle(initialValue = emptyList())
    var selected by rememberSaveable(stateSaver = PlantationStateSaver) { mutableStateOf<PlantationEntity?>(null) }
    var showAddPlantation by rememberSaveable { mutableStateOf(false) }
    var showAddExpense by rememberSaveable { mutableStateOf(false) }
    var expenseSaving by rememberSaveable { mutableStateOf(false) }
    var showChoosePlantation by rememberSaveable { mutableStateOf(false) }
    var showChooseCategory by rememberSaveable { mutableStateOf(false) }
    var editingExpense by rememberSaveable(stateSaver = ExpenseStateSaver) { mutableStateOf<ExpenseEntity?>(null) }
    var editingChemicalLines by remember { mutableStateOf<List<ChemicalOperationLineEntity>>(emptyList()) }
    var plantationToDelete by rememberSaveable(stateSaver = PlantationStateSaver) { mutableStateOf<PlantationEntity?>(null) }
    var plantationToEdit by rememberSaveable(stateSaver = PlantationStateSaver) { mutableStateOf<PlantationEntity?>(null) }
    var editedPlantationName by rememberSaveable { mutableStateOf("") }
    var harvestScreenEpoch by rememberSaveable { mutableIntStateOf(0) }
    var deleteMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var currentSection by rememberSaveable { mutableStateOf("الرئيسية") }
    val drawerGroups = listOf(
        "الأنشطة الزراعية" to listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات"),
        "الإدارة المالية" to listOf("الفواتير", "المخزون", "التجار والموردون", "الديون والمستحقات", "الإيرادات والمبيعات"),
        "التقارير" to listOf("التقارير"),
        "النظام" to listOf("التنبيهات", "الإعدادات")
    )
    val sections = drawerGroups.flatMap { it.second }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    BackHandler(enabled = unlocked && (selected != null || currentSection != "الرئيسية" || showPinSettings || showPinSetup || showAbout || showChooseCategory || showChoosePlantation || (showAddExpense && !expenseSaving) || showAddPlantation)) {
        when {
            showPinSettings -> showPinSettings = false
            showPinSetup -> showPinSetup = false
            showAbout -> showAbout = false
            showChooseCategory -> showChooseCategory = false
            showChoosePlantation -> showChoosePlantation = false
            showAddExpense && !expenseSaving -> { showAddExpense = false; editingExpense = null }
            showAddPlantation -> showAddPlantation = false
            selected != null -> selected = null
            currentSection != "الرئيسية" -> { currentSection = "الرئيسية"; selected = null }
            else -> { /* في الرئيسية لا نغلق التطبيق من زر الرجوع؛ نترك النظام يضعه بالخلفية */ }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(modifier = Modifier.fillMaxWidth(0.70f), drawerContainerColor = androidx.compose.ui.graphics.Color(0xFF003F2C)) {
                    Column(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Color(0xFF004C35)).padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MiyarMark(Modifier.size(54.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("أهلاً بك في معيار", style = MaterialTheme.typography.titleLarge, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                                Text("إدارة أدق - مردود أوضح", color = Gold, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    HorizontalDivider(color = Gold.copy(alpha = 0.6f))
                    OutlinedTextField(
                        value = drawerSearch,
                        onValueChange = { drawerSearch = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = { if (drawerSearch.isNotBlank()) IconButton(onClick = { drawerSearch = "" }) { Text("×") } },
                        placeholder = { Text("بحث شامل في مِعيار...") }
                    )
                    Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    if (drawerSearch.isBlank() && recentSearches.isNotEmpty()) {
                        Text("عمليات بحث حديثة", modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), color = Green, fontWeight = FontWeight.Bold)
                        recentSearches.take(8).forEach { previous ->
                            Row(Modifier.fillMaxWidth().combinedClickable(
                                onClick = { drawerSearch = previous },
                                onLongClick = {
                                    recentSearches = recentSearches.filterNot { it == previous }
                                    searchPrefs.edit().putString("recent_queries", recentSearches.joinToString("\n")).apply()
                                }
                            ).padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Text("↻  $previous", modifier = Modifier.weight(1f))
                                Text("اضغط مطولًا للحذف", color = Green, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                    }
                    if (drawerSearch.isNotBlank()) {
                        val q = normalizedSearchText(drawerSearch.trim())
                        val queryTerms = q.split(Regex("\\s+")).filter { it.isNotBlank() }
                        val matches = buildList {
                            fun addIfMatch(label: String, target: String, searchable: String) {
                                val normalized = normalizedSearchText(searchable)
                                if (queryTerms.isNotEmpty() && queryTerms.all { normalized.contains(it) }) add(label to target)
                            }
                            plantations.forEach { addIfMatch("موضع: ${it.name}", "المواضع الزراعية", it.name) }
                            globalExpenses.forEach { item ->
                                addIfMatch("مصروف: ${item.title} • ${item.plantationName}", item.category,
                                    "${item.title} ${item.notes} ${item.category} ${item.plantationName} ${item.amount} ${searchDate(item.dateMillis)}")
                            }
                            globalInvoices.forEach { invoice ->
                                addIfMatch("فاتورة: ${invoice.supplier} • ${invoice.invoiceNumber}", "الفواتير",
                                    "${invoice.supplier} ${invoice.invoiceNumber} ${invoice.notes} ${invoice.paymentStatus} ${invoice.currency} ${invoice.totalYer} ${invoice.totalForeign} ${searchDate(invoice.dateMillis)}")
                            }
                            globalInvoiceItems.forEach { line ->
                                val invoice = globalInvoices.firstOrNull { it.id == line.invoiceId }
                                addIfMatch("صنف فاتورة: ${line.productName} • ${invoice?.invoiceNumber.orEmpty()}", "الفواتير",
                                    "${line.productName} ${line.activeIngredient} ${line.productType} ${line.treatmentType} ${line.packageName} ${line.unit} ${line.packageSize} ${line.packageCount} ${line.quantityBase} ${line.unitPriceForeign} ${line.lineTotalYer} ${invoice?.supplier.orEmpty()} ${invoice?.invoiceNumber.orEmpty()}")
                            }
                            globalStock.forEach { stock ->
                                addIfMatch("مخزون: ${stock.productName}", "المخزون",
                                    "${stock.productName} ${stock.activeIngredient} ${stock.productType} ${stock.baseUnit} ${stock.quantityBase} ${stock.totalReceivedBase} ${stock.totalUsedBase} ${stock.treatmentType}")
                            }
                            globalStockMovements.forEach { movement ->
                                val stock = globalStock.firstOrNull { it.id == movement.stockItemId }
                                addIfMatch("حركة مخزون: ${stock?.productName.orEmpty()}", "المخزون",
                                    "${stock?.productName.orEmpty()} ${stock?.activeIngredient.orEmpty()} ${movement.referenceType} ${movement.referenceId} ${movement.quantityBase} ${movement.description} ${searchDate(movement.dateMillis)}")
                            }
                            globalSuppliers.forEach { supplier ->
                                addIfMatch("مورد: ${supplier.name}", "التجار والموردون", "${supplier.name} ${supplier.phone} ${supplier.notes}")
                            }
                            globalSupplierPayments.forEach { payment ->
                                addIfMatch("دفعة مورد: ${payment.supplierName} • ${payment.amountYer}", "التجار والموردون",
                                    "${payment.supplierName} ${payment.currency} ${payment.amountForeign} ${payment.amountYer} ${payment.paymentMethod} ${payment.notes} ${searchDate(payment.dateMillis)}")
                            }
                            globalHarvests.forEach { harvest ->
                                val plot = plantations.firstOrNull { it.id == harvest.plantationId }?.name.orEmpty()
                                addIfMatch("قطفة شخصية: ${harvest.name} • $plot", "harvest:${harvest.id}",
                                    "${harvest.name} $plot ${harvest.notes} ${harvest.productsText} ${harvest.cashSalesText} ${harvest.debtorSalesText} ${harvest.pickerCount} ${harvest.pickerWage} ${harvest.extraWages} ${harvest.bagsAndOther} ${harvest.transportAndClearance} ${searchDate(harvest.startMillis)} ${searchDate(harvest.expectedEndMillis)} ${if (harvest.actualEndMillis > 0) searchDate(harvest.actualEndMillis) else ""}")
                            }
                            globalHarvestDays.forEach { day ->
                                val harvest = globalHarvests.firstOrNull { it.id == day.harvestId }
                                val plot = plantations.firstOrNull { it.id == harvest?.plantationId }?.name.orEmpty()
                                addIfMatch("يوم قطف: ${harvest?.name.orEmpty()} • ${searchDate(day.dateMillis)}", "day:${day.id}",
                                    "${harvest?.name.orEmpty()} $plot ${day.notes} ${day.pickerCount} ${day.pickerWage} ${day.otherExpenses} ${searchDate(day.dateMillis)}")
                            }
                            globalHarvestDayLines.forEach { line ->
                                val day = globalHarvestDays.firstOrNull { it.id == line.dayId }
                                val harvest = globalHarvests.firstOrNull { it.id == day?.harvestId }
                                val plot = plantations.firstOrNull { it.id == harvest?.plantationId }?.name.orEmpty()
                                addIfMatch("تفصيل قطف: ${line.partyName} • ${line.productType}", day?.id?.let { "day:$it" } ?: "القطفات",
                                    "${line.partyName} ${line.productType} ${line.category} ${line.quantity} ${line.unitPrice} ${line.total} ${harvest?.name.orEmpty()} $plot ${day?.notes.orEmpty()} ${day?.dateMillis?.let(::searchDate).orEmpty()}")
                            }
                            globalBuyers.forEach { buyer -> addIfMatch("مشتري: ${buyer.name}", "buyer:${buyer.id}", "${buyer.name} ${buyer.phone} ${buyer.notes}") }
                            globalDebtors.forEach { debtor -> addIfMatch("عميل آجل: ${debtor.name}", "debtor:${debtor.id}", "${debtor.name} ${debtor.phone} ${debtor.notes}") }
                            globalDistributors.forEach { seller -> addIfMatch("بائع: ${seller.name}", "distributor:${seller.id}", "${seller.name} ${seller.phone} ${seller.notes}") }
                            globalBuyerSales.forEach { sale ->
                                val buyerName = globalBuyers.firstOrNull { it.id == sale.buyerId }?.name.orEmpty()
                                val plot = plantations.firstOrNull { it.id == sale.plantationId }?.name.orEmpty()
                                addIfMatch("بيع لمشتري: ${buyerName} • ${sale.harvestName}", "sale:${sale.id}",
                                    "$buyerName $plot ${sale.harvestName} ${sale.agreedAmount} ${sale.discountAmount} ${sale.discountReason} ${sale.notes} ${sale.initialPaid} ${searchDate(sale.saleDateMillis)} ${searchDate(sale.expectedEndMillis)} ${if (sale.actualEndMillis > 0) searchDate(sale.actualEndMillis) else ""}")
                            }
                            globalBuyerPayments.forEach { payment ->
                                val sale = globalBuyerSales.firstOrNull { it.id == payment.saleId }
                                val buyerName = globalBuyers.firstOrNull { it.id == sale?.buyerId }?.name.orEmpty()
                                addIfMatch("دفعة مشتري: $buyerName • ${payment.amount}", sale?.id?.let { "sale:$it" } ?: "القطفات",
                                    "$buyerName ${payment.amount} ${payment.method} ${payment.notes} ${searchDate(payment.dateMillis)}")
                            }
                            globalDistributorTransactions.forEach { transaction ->
                                val seller = globalDistributors.firstOrNull { it.id == transaction.distributorId }?.name.orEmpty()
                                addIfMatch("عملية بائع: $seller • ${transaction.productType}", "distributor:${transaction.distributorId}",
                                    "$seller ${transaction.productType} ${transaction.quantity} ${transaction.unitPrice} ${transaction.total} ${transaction.notes} ${searchDate(transaction.dateMillis)}")
                            }
                            globalDebtorTransactions.forEach { transaction ->
                                val debtor = globalDebtors.firstOrNull { it.id == transaction.debtorId }?.name.orEmpty()
                                addIfMatch("عملية عميل: $debtor • ${transaction.productType}", "debtor:${transaction.debtorId}",
                                    "$debtor ${transaction.productType} ${transaction.quantity} ${transaction.unitPrice} ${transaction.total} ${transaction.notes} ${searchDate(transaction.dateMillis)}")
                            }
                            globalPartyPayments.forEach { payment ->
                                val partyName = if (payment.partyType == "DISTRIBUTOR") globalDistributors.firstOrNull { it.id == payment.partyId }?.name.orEmpty() else globalDebtors.firstOrNull { it.id == payment.partyId }?.name.orEmpty()
                                addIfMatch("دفعة حساب: $partyName • ${payment.amount}", if (payment.partyType == "DISTRIBUTOR") "distributor:${payment.partyId}" else "debtor:${payment.partyId}",
                                    "$partyName ${payment.amount} ${payment.method} ${payment.notes} ${searchDate(payment.dateMillis)}")
                            }
                            sections.filter { section -> queryTerms.isNotEmpty() && queryTerms.all { normalizedSearchText(section).contains(it) } }.forEach { add("قسم: $it" to it) }
                        }.distinctBy { it.first }
                        if (matches.isEmpty()) Text("لا توجد نتائج مطابقة", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        matches.forEach { (label, target) ->
                            NavigationDrawerItem(
                                label = { Text(label, maxLines = 2) },
                                selected = false,
                                onClick = {
                                    rememberSearchQuery(drawerSearch)
                                    if (target.substringBefore(":") in setOf("harvest", "day", "buyer", "sale", "distributor", "debtor")) {
                                        harvestSearchTarget = target
                                        currentSection = "القطفات"
                                    } else {
                                        currentSection = target
                                    }
                                    selected = null
                                    drawerSearch = ""
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    }
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("الرئيسية") },
                        selected = currentSection == "الرئيسية",
                        onClick = { currentSection = "الرئيسية"; selected = null; scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Green.copy(alpha = 0.34f), unselectedContainerColor = Emerald, selectedTextColor = androidx.compose.ui.graphics.Color.White, unselectedTextColor = androidx.compose.ui.graphics.Color.White, selectedIconColor = Gold, unselectedIconColor = Gold),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        icon = { Text("🌱") },
                        label = { Text("المواضع الزراعية") },
                        selected = currentSection == "المواضع الزراعية",
                        onClick = { currentSection = "المواضع الزراعية"; selected = null; scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Green.copy(alpha = 0.34f), unselectedContainerColor = Emerald, selectedTextColor = androidx.compose.ui.graphics.Color.White, unselectedTextColor = androidx.compose.ui.graphics.Color.White, selectedIconColor = Gold, unselectedIconColor = Gold),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    drawerGroups.forEach { (groupTitle, groupSections) ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 5.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFF004D35))
                        ) {
                            Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                                Text(
                                    groupTitle,
                                    modifier = Modifier.padding(horizontal = 15.dp, vertical = 5.dp),
                                    color = Gold,
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.labelLarge
                                )
                                groupSections.forEach { section ->
                                    NavigationDrawerItem(
                                        icon = { Text(when (section) {
                                            "الأسمدة" -> "🌿"
                                            "السموم" -> "🐛"
                                            "المياه", "المياه والري" -> "💧"
                                            "الأعمال اليدوية" -> "🧑‍🌾"
                                            "القطفات" -> "🧺"
                                            "الفواتير" -> "🧾"
                                            "المخزون" -> "📦"
                                            "التجار والموردون" -> "🏪"
                                            "الديون والمستحقات" -> "🤝"
                                            "الإيرادات والمبيعات" -> "💰"
                                            "التقارير" -> "📊"
                                            "التنبيهات" -> "🔔"
                                            "الإعدادات" -> "⚙️"
                                            else -> "📝"
                                        }) },
                                        label = { Text(section, fontWeight = if (currentSection == section) FontWeight.Bold else FontWeight.Medium) },
                                        selected = currentSection == section,
                                        onClick = {
                                            currentSection = section
                                            selected = null
                                            harvestScreenEpoch++
                                            scope.launch { drawerState.close() }
                                        },
                                        colors = NavigationDrawerItemDefaults.colors(
                                            selectedContainerColor = Green.copy(alpha = 0.34f),
                                            unselectedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                            selectedTextColor = androidx.compose.ui.graphics.Color.White,
                                            unselectedTextColor = androidx.compose.ui.graphics.Color.White,
                                            selectedIconColor = Gold,
                                            unselectedIconColor = Gold
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Info, contentDescription = null, tint = Gold) },
                        label = { Text("عن مِعيار", color = androidx.compose.ui.graphics.Color.White) },
                        selected = false,
                        onClick = { showAbout = true; scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Emerald, unselectedTextColor = androidx.compose.ui.graphics.Color.White, unselectedIconColor = Gold),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    }
                }
            }
        ) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                if (unlocked && currentSection !in listOf("الإعدادات", "الفواتير", "المخزون", "التجار والموردون", "الديون والمستحقات", "الإيرادات والمبيعات", "التقارير", "القطفات", "التنبيهات")) FloatingActionButton(
                    onClick = {
                        when {
                            selected != null && (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") -> showChooseCategory = true
                            selected != null -> showAddExpense = true
                            currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" -> showAddPlantation = true
                            else -> showChoosePlantation = true
                        }
                    },
                    containerColor = Emerald,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).then(if ((currentSection == "الرئيسية" && selected == null) || currentSection == "الإعدادات" || selected != null) Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
                Header(onMenuClick = { scope.launch { drawerState.open() } })
                if (currentSection == "الرئيسية") {
                    Text("أهلاً بك في معيار", modifier = Modifier.padding(top = 10.dp, start = 4.dp), style = MaterialTheme.typography.titleMedium, color = Emerald, fontWeight = FontWeight.ExtraBold)
                    Text("إدارة أدق - مردود أوضح", modifier = Modifier.padding(start = 4.dp), style = MaterialTheme.typography.bodyMedium, color = Green)
                }
                Spacer(Modifier.height(12.dp))
                if (!unlocked) {
                    PinLockScreen(pinInput = pinInput, onInput = { pinInput = it.filter(Char::isDigit).take(8); pinError = "" },
                        onUnlock = {
                            if (pinInput.isNotBlank() && sha256(pinInput) == configuredPin) { unlocked = true; pinInput = ""; pinError = "" }
                            else pinError = "رمز PIN غير صحيح"
                        }, error = pinError, hasPin = configuredPin != null)
                } else if (currentSection == "التنبيهات" && selected == null) {
                    MiyarRemindersScreen(dao, modifier = Modifier.weight(1f))
                } else if (currentSection == "التجار والموردون" && selected == null) {
                    MiyarSuppliersScreen(dao, modifier = Modifier.weight(1f))
                } else if (currentSection == "الديون والمستحقات" && selected == null) {
                    key("parties-$harvestScreenEpoch") { MiyarHarvestScreen(dao, plantations, initialPage = "parties", onExitScreen = { currentSection = "الرئيسية"; selected = null }, modifier = Modifier.weight(1f)) }
                } else if (currentSection == "الإيرادات والمبيعات" && selected == null) {
                    key("revenue-$harvestScreenEpoch") { MiyarHarvestScreen(dao, plantations, initialPage = "revenue", onExitScreen = { currentSection = "الرئيسية"; selected = null }, modifier = Modifier.weight(1f)) }
                } else if (currentSection == "القطفات" && selected == null) {
                    key("harvests-$harvestScreenEpoch") { MiyarHarvestScreen(dao, plantations, harvestSearchTarget, onSearchTargetConsumed = { harvestSearchTarget = null }, modifier = Modifier.weight(1f)) }
                } else if (currentSection == "الفواتير" && selected == null) {
                    MiyarInvoiceScreen(dao, modifier = Modifier.weight(1f))
                } else if (currentSection == "المخزون" && selected == null) {
                    MiyarInventoryScreen(dao, modifier = Modifier.weight(1f))
                } else if (currentSection == "التقارير" && selected == null) {
                    MiyarReportsScreen(dao, modifier = Modifier.weight(1f))
                } else if (currentSection == "الإعدادات" && selected == null) {
                    Text("الإعدادات", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    FinancialCard("🔒 قفل التطبيق", if (configuredPin == null) "غير مفعّل" else "مفعّل", "رمز PIN عند العودة إلى التطبيق")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { newPin = ""; confirmPin = ""; pinSettingsMessage = ""; showPinSettings = true }, modifier = Modifier.fillMaxWidth()) { Text(if (configuredPin == null) "تعيين رمز PIN" else "تغيير أو إلغاء رمز PIN") }
                    Spacer(Modifier.height(12.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("حفظ عمليات البحث", color = Emerald, fontWeight = FontWeight.Bold)
                                Text(if (saveSearchHistory) "سيحتفظ مِعيار بعمليات البحث الأخيرة." else "لن تُحفظ عمليات البحث الجديدة." , style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = saveSearchHistory, onCheckedChange = { enabled ->
                                saveSearchHistory = enabled
                                searchPrefs.edit().putBoolean("save_history", enabled).apply()
                            })
                        }
                    }
                    Text("اضغط مطولًا على أي عملية بحث محفوظة في القائمة الجانبية لحذفها.", color = Green, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    MiyarCurrencySettingsCard()
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showAbout = true }, modifier = Modifier.fillMaxWidth()) { Text("معلومات التطبيق") }
                } else if (selected == null) {
                    Text(if (currentSection == "الرئيسية") "مواضعي الزراعية" else if (currentSection == "المواضع الزراعية") "المواضع الزراعية" else currentSection,
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                    Spacer(Modifier.height(8.dp))
                    if (currentSection != "الرئيسية" && currentSection != "المواضع الزراعية" && currentSection !in listOf("الفواتير", "المخزون", "التجار والموردون", "الديون والمستحقات", "الإيرادات والمبيعات", "التقارير")) {
                        val allRecords by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
                        val filteredRecords = allRecords.filter { record ->
                            record.category == currentSection ||
                            (currentSection == "المياه والري" && record.category == "المياه")
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = categoryTint(currentSection).copy(alpha = 0.12f)), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(12.dp)) { Text("عدد العمليات", color = categoryTint(currentSection), fontWeight = FontWeight.Bold); Text(filteredRecords.size.toString(), color = Emerald, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold) } }
                            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = categoryTint(currentSection).copy(alpha = 0.12f)), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(12.dp)) { Text("إجمالي المبالغ", color = categoryTint(currentSection), fontWeight = FontWeight.Bold); Text(formatMoney(filteredRecords.sumOf { it.amount }), color = Emerald, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold) } }
                        }
                        if (filteredRecords.isEmpty()) {
                            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                    Text("لا توجد عمليات مسجلة في قسم $currentSection", fontWeight = FontWeight.Bold)
                                    Text("اضغط إضافة عملية، ثم اختر الموضع الزراعي.")
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(filteredRecords, key = { it.id }) { record ->
                                    var details by remember(record.id) { mutableStateOf(false) }
                                    var menu by remember(record.id) { mutableStateOf(false) }
                                    var confirmDelete by remember(record.id) { mutableStateOf(false) }
                                    var detailChemicalLines by remember(record.id) { mutableStateOf<List<ChemicalOperationLineEntity>>(emptyList()) }
                                    Card(modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { scope.launch { detailChemicalLines = dao.getChemicalOperationLines(record.id); details = true } }, onLongClick = { menu = true }), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("${categoryEmoji(record.category)}  ${record.title}", fontWeight = FontWeight.Bold, color = categoryTint(record.category))
                                                Text("الموضع: ${record.plantationName} • ${record.category}", style = MaterialTheme.typography.bodySmall)
                                                Text(java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(record.dateMillis)), style = MaterialTheme.typography.labelSmall, color = Green)
                                            }
                                            Text(formatMoney(record.amount), fontWeight = FontWeight.Bold, color = Emerald)
                                        }
                                    }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; scope.launch { editingChemicalLines = dao.getChemicalOperationLines(record.id); selected = plantations.firstOrNull { it.id == record.plantationId }; currentSection = record.category; editingExpense = ExpenseEntity(id = record.id, plantationId = record.plantationId, category = record.category, title = record.title, amount = record.amount, currency = record.currency, dateMillis = record.dateMillis, notes = record.notes); showAddExpense = true } })
                                        DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
                                    }
                                    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("تأكيد حذف العملية") }, text = { Text("هل تريد حذف «${record.title}»؟") }, confirmButton = { TextButton(onClick = { scope.launch { dao.deleteExpenseAndRestoreStock(ExpenseEntity(id = record.id, plantationId = record.plantationId, category = record.category, title = record.title, amount = record.amount, currency = record.currency, dateMillis = record.dateMillis, notes = record.notes)); ReminderScheduler.cancel(context, record.id) }; confirmDelete = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } })
                                    if (details) AlertDialog(
                                        onDismissRequest = { details = false },
                                        title = { Text(record.title, color = Emerald, fontWeight = FontWeight.ExtraBold) },
                                        text = {
                                            Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                                Text("الموضع: ${record.plantationName}", fontWeight = FontWeight.Bold)
                                                Text("نوع العملية: ${record.category}")
                                                Text("التاريخ: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(record.dateMillis))}")
                                                Text("القيمة: ${formatMoney(record.amount)}", color = Green, fontWeight = FontWeight.ExtraBold)
                                                if (detailChemicalLines.isNotEmpty()) {
                                                    HorizontalDivider()
                                                    Text("تفاصيل الأصناف", color = Emerald, fontWeight = FontWeight.Bold)
                                                    detailChemicalLines.forEach { line ->
                                                        Card(colors = CardDefaults.cardColors(containerColor = Cream)) {
                                                            Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                                Text(line.productName, color = Emerald, fontWeight = FontWeight.Bold)
                                                                Text("${line.productType} • ${line.treatmentType} • ${line.unit}", style = MaterialTheme.typography.bodySmall)
                                                                if (line.activeIngredient.isNotBlank()) Text("المادة الفعالة: ${line.activeIngredient}", style = MaterialTheme.typography.bodySmall)
                                                                Text("الكمية: ${line.enteredQuantity} • القيمة المحتسبة: ${formatMoney(line.costAmountYer)}", fontWeight = FontWeight.SemiBold)
                                                            }
                                                        }
                                                    }
                                                }
                                                if (record.notes.isNotBlank()) Text(record.notes)
                                            }
                                        },
                                        confirmButton = { TextButton(onClick = { details = false }) { Text("إغلاق") } }
                                    )
                                }
                            }
                        }
                    } else if (plantations.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("أهلًا بك في مِعيار 🌿", fontWeight = FontWeight.Bold)
                                Text("أضف أول موضع زراعي للبدء.")
                            }
                        }
                    } else if (currentSection != "الرئيسية") {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(plantations, key = { it.id }) { p ->
                                var menu by remember(p.id) { mutableStateOf(false) }
                                Card(
                                    modifier = Modifier.combinedClickable(onClick = { selected = p }, onLongClick = { menu = true }),
                                    colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(p.colorArgb).copy(alpha = 0.10f)),
                                    shape = RoundedCornerShape(16.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, androidx.compose.ui.graphics.Color(p.colorArgb).copy(alpha = 0.55f))
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(shape = RoundedCornerShape(50), color = androidx.compose.ui.graphics.Color(p.colorArgb).copy(alpha = 0.16f), modifier = Modifier.size(44.dp)) { Box(contentAlignment = Alignment.Center) { Text(p.icon, style = MaterialTheme.typography.headlineSmall) } }
                                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                            Text(p.name, fontWeight = FontWeight.SemiBold)
                                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "عرض تفاصيل الموضع ←" else "اختيار الموضع لهذا القسم ←", color = Green, style = MaterialTheme.typography.labelMedium)
                                        }
                                        if (currentSection != "الرئيسية" && currentSection != "المواضع الزراعية") Text("اختيار", color = Green, modifier = Modifier.clickable { selected = p }.padding(8.dp))
                                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                            DropdownMenuItem(text = { Text("تعديل اسم الموضع") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; plantationToEdit = p; editedPlantationName = p.name })
                                            DropdownMenuItem(text = { Text("حذف الموضع وجميع بياناته") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; plantationToDelete = p })
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (currentSection == "الرئيسية") {
                        Spacer(Modifier.height(12.dp))
                        val financialCards = listOf(
                            Triple("💸 إجمالي الخرج", formatMoney(dashboardExpenses), "جميع المواضع"),
                            Triple("💰 إجمالي المردود", formatMoney(dashboardRevenue), "عدد القطفات: $dashboardHarvestCount"),
                            Triple("📈 صافي المردود", formatMoney(dashboardNet), "بعد خصم المصروفات"),
                            Triple("🔔 التنبيهات", activeOperationReminders.size.toString(), "المواعيد القادمة")
                        )
                        financialCards.chunked(2).forEachIndexed { index, rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowItems.forEachIndexed { itemIndex, item ->
                                    Card(
                                        modifier = Modifier.weight(1f).heightIn(min = 112.dp).clickable {
                                            when (index * 2 + itemIndex) {
                                                1 -> { currentSection = "القطفات"; selected = null }
                                                3 -> { currentSection = "التنبيهات"; selected = null }
                                            }
                                        },
                                        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(item.first, color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                            Text(item.second, color = Green, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                            Text(item.third, color = Emerald.copy(alpha = 0.72f), style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("ملخص الأنشطة الزراعية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        val categoryTotals by dao.observeCategoryTotals().collectAsStateWithLifecycle(initialValue = emptyList())
                        val totals = categoryTotals.associate { it.category to (it.count to it.total) }
                        val summaryCategories = listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات")
                        summaryCategories.chunked(3).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowItems.forEach { category ->
                                    val pair = when (category) {
                                        "المياه والري" -> {
                                            val a = totals["المياه"] ?: (0L to 0L)
                                            val b = totals["المياه والري"] ?: (0L to 0L)
                                            (a.first + b.first) to (a.second + b.second)
                                        }
                                        "القطفات" -> ((personalHarvestDayCount + buyerSaleCount + (totals["القطفات"]?.first ?: 0L)) to
                                            ((totals["القطفات"]?.second ?: 0L) + personalHarvestRevenue + manualPartyRevenue + buyerHarvestRevenue))
                                        else -> totals[category] ?: (0L to 0L)
                                    }
                                    Card(onClick = { currentSection = category; selected = null }, modifier = Modifier.weight(1f).padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = categoryTint(category).copy(alpha = 0.075f)), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, categoryTint(category).copy(alpha = 0.35f))) {
                                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(categoryEmoji(category), style = MaterialTheme.typography.titleMedium)
                                                Text(category, color = categoryTint(category), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                                            }
                                            Text("عدد العمليات: ${pair.first}", style = MaterialTheme.typography.labelSmall)
                                            Text(formatMoney(pair.second), color = categoryTint(category), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall)
                                            Text("عرض التفاصيل ←", style = MaterialTheme.typography.labelSmall, color = Gold)
                                        }
                                    }
                                }
                                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("آخر العمليات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        val recent by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
                        recent.take(5).forEach { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(12.dp)) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.Bold)
                                        Text("${item.plantationName} • ${item.category}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (globalHarvestDays.isNotEmpty() || globalBuyerSales.isNotEmpty()) {
                            Text("آخر عمليات القطف", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                            globalHarvestDays.take(4).forEach { day ->
                                val harvest = globalHarvests.firstOrNull { it.id == day.harvestId }
                                val plotName = plantations.firstOrNull { it.id == harvest?.plantationId }?.name.orEmpty()
                                Card(onClick = { currentSection = "القطفات"; selected = null }, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text("${harvest?.name ?: "قطفة شخصية"} • $plotName", fontWeight = FontWeight.Bold)
                                        Text("يوم ${searchDate(day.dateMillis)} • ${day.pickerCount} قطافين • أجور ومصاريف ${formatMoney(day.pickerCount * day.pickerWage + day.otherExpenses)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            globalBuyerSales.take(4).forEach { sale ->
                                val buyerName = globalBuyers.firstOrNull { it.id == sale.buyerId }?.name ?: "مشتري"
                                Card(onClick = { currentSection = "القطفات"; selected = null }, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text("بيع لمشتري: $buyerName • ${sale.harvestName}", fontWeight = FontWeight.Bold)
                                        Text("${searchDate(sale.saleDateMillis)} • صافي الاتفاق ${formatMoney((sale.agreedAmount - sale.discountAmount).coerceAtLeast(0))}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                        Text("افتح أي بطاقة لعرض سجلاتها، واضغط مطولًا على العملية لتعديلها أو حذفها.", style = MaterialTheme.typography.bodySmall)
                    } else if (currentSection == "التقارير") {
                        Spacer(Modifier.height(8.dp))
                        Text("اختر موضعًا لعرض ملخص سجلاته وتقرير عملياته.", style = MaterialTheme.typography.bodyMedium)
                    } else if (currentSection != "المواضع الزراعية") {
                        Text("اختر الموضع الزراعي الذي تريد تسجيل بيانات قسم ${currentSection} عليه.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                        Column {
                            Text(selected!!.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "ملخص الموضع" else currentSection, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val allExpenses by dao.observeExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = emptyList())
                    val expenses = if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "التقارير") allExpenses else allExpenses.filter { it.category == currentSection }
                    val plantationTotal by dao.observePlantationExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationRevenue by dao.observePlantationRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationHarvestRevenue by dao.observePlantationHarvestRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationBuyerRevenue by dao.observePlantationBuyerRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationHarvestCosts by dao.observePlantationHarvestCosts(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationManualPartyRevenue by dao.observePlantationManualPartyRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plotExpenses = plantationTotal + plantationHarvestCosts
                    val plotRevenue = plantationRevenue + plantationHarvestRevenue + plantationBuyerRevenue + plantationManualPartyRevenue
                    Spacer(Modifier.height(8.dp))
                    val plotCards = listOf(Triple("💸 خرج الموضع", formatMoney(plotExpenses), "خرجيات وأجور"), Triple("💰 مردود الموضع", formatMoney(plotRevenue), "القطف والمبيعات"), Triple("📈 صافي المردود", formatMoney(plotRevenue - plotExpenses), "بعد خصم الخرج"), Triple("🧺 خرج القطفات", formatMoney(plantationHarvestCosts), "تكاليف القطفات"), Triple("🧾 عدد العمليات", expenses.size.toString(), "في هذا الموضع"))
                    plotCards.chunked(3).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { row.forEach { item -> Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(12.dp)) { Column(Modifier.padding(9.dp)) { Text(item.first, color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium); Text(item.second, color = Green, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall); Text(item.third, style = MaterialTheme.typography.labelSmall) } } }; repeat(3-row.size) { Spacer(Modifier.weight(1f)) } }; Spacer(Modifier.height(6.dp)) }
                    val activityGroups = listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى")
                    activityGroups.chunked(2).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { cat -> val matches = expenses.filter { it.category == cat || (cat == "المياه والري" && it.category == "المياه") }; Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(12.dp)) { Column(Modifier.padding(7.dp)) { Text("${categoryEmoji(cat)} $cat", color = categoryTint(cat), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium); Text("${matches.size} عملية", style = MaterialTheme.typography.labelSmall); Text(formatMoney(matches.sumOf { it.amount }), color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium) } } } }; Spacer(Modifier.height(6.dp)) }
                    Spacer(Modifier.height(8.dp))
                    Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "التقارير") "سجل العمليات" else "سجل ${currentSection}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (expenses.isEmpty()) Text(if (currentSection == "التقارير") "لا توجد عمليات مسجلة لعرضها في التقرير." else "لا توجد سجلات في هذا القسم لهذا الموضع بعد.", modifier = Modifier.padding(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        expenses.forEach { expense ->
                            ExpenseRow(expense, stockSuggestions, selected!!.name, dao,
                                onUpdate = { updated, chemicalLines, complete -> scope.launch {
                                    try {
                                        val savedId = if (updated.category == "السموم" || updated.category == "الأسمدة") {
                                            dao.saveChemicalExpense(updated, chemicalLines)
                                        } else {
                                            val quantityBase = extractQuantityBase(updated.notes)
                                            val unit = extractNoteValue(updated.notes, "وحدة القياس")
                                            val stockType = updated.category.takeIf { it == "السموم" || it == "الأسمدة" }
                                            dao.saveExpenseWithStock(updated, stockType, unit?.let(::stockBaseUnit), quantityBase)
                                        }
                                        syncExpenseReminder(dao, context, savedId, updated.title, updated.category, selected!!.name, updated.notes)
                                        complete(true)
                                    } catch (t: Throwable) {
                                        deleteMessage = t.message ?: "تعذر تحديث العملية."
                                        complete(false)
                                    }
                                } },
                                onDelete = { item -> scope.launch { dao.deleteExpenseAndRestoreStock(item); ReminderScheduler.cancel(context, item.id) } }
                            )
                        }
                    }
                }
            }
            if (unlocked) {
                Spacer(Modifier.height(8.dp))
                MiyarPageFooter(currentSection)
            }
        }
        }
    }

    if (!unlocked && configuredPin != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = {}, properties = androidx.compose.ui.window.DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = Cream) {
                PinLockScreen(pinInput = pinInput, onInput = { pinInput = it.filter(Char::isDigit).take(8); pinError = "" },
                    onUnlock = { if (pinInput.isNotBlank() && sha256(pinInput) == configuredPin) { unlocked = true; pinInput = ""; pinError = "" } else pinError = "رمز PIN غير صحيح" },
                    error = pinError, hasPin = true)
            }
        }
    }
    if (showPinSettings) {
        AlertDialog(
            onDismissRequest = { showPinSettings = false },
            title = { Text("قفل التطبيق برمز PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (configuredPin == null) "أنشئ رمزًا من 4 إلى 8 أرقام. سيُطلب عند العودة إلى التطبيق بعد مغادرته." else "القفل مفعّل. يمكنك تغيير الرمز أو إلغاء القفل.")
                    if (configuredPin != null) {
                        OutlinedButton(onClick = { prefs.edit().remove("pin_hash").apply(); configuredPin = null; unlocked = true; pinSettingsMessage = "تم إلغاء قفل التطبيق." }, modifier = Modifier.fillMaxWidth()) { Text("إلغاء رمز PIN") }
                    }
                    OutlinedButton(onClick = { showPinSettings = false; showPinSetup = true; newPin = ""; confirmPin = ""; pinSettingsMessage = "" }, modifier = Modifier.fillMaxWidth()) { Text(if (configuredPin == null) "إنشاء رمز PIN" else "تغيير رمز PIN") }
                    if (pinSettingsMessage.isNotBlank()) Text(pinSettingsMessage, color = Green)
                }
            },
            confirmButton = { TextButton(onClick = { showPinSettings = false }) { Text("إغلاق") } }
        )
    }
    if (showPinSetup) {
        AlertDialog(
            onDismissRequest = { showPinSetup = false },
            title = { Text(if (configuredPin == null) "إنشاء رمز PIN" else "تغيير رمز PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit).take(8) }, label = { Text("رمز PIN (4 إلى 8 أرقام)") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(8) }, label = { Text("تأكيد الرمز") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    if (pinSettingsMessage.isNotBlank()) Text(pinSettingsMessage, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (newPin.length < 4) pinSettingsMessage = "يجب أن يتكون الرمز من 4 أرقام على الأقل."
                else if (newPin != confirmPin) pinSettingsMessage = "الرمزان غير متطابقين."
                else {
                    val hash = sha256(newPin)
                    prefs.edit().putString("pin_hash", hash).apply()
                    configuredPin = hash
                    unlocked = true
                    pinSettingsMessage = ""
                    showPinSetup = false
                    showPinSettings = false
                }
            }) { Text("حفظ الرمز") } },
            dismissButton = { TextButton(onClick = { showPinSetup = false }) { Text("إلغاء") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("عن مِعيار") },
            text = { Text("مِعيار تطبيقك الذكي وعاملك التكنولوجي لإدارة ومتابعة مواضعك الزراعية بطريقة تواكب التطور الزراعي.\n\nتنفيذ وحقوق التطبيق: المهندس (أبو مجيد).") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("حسنًا") } }
        )
    }


    if (plantationToEdit != null) {
        val target = plantationToEdit!!
        AlertDialog(onDismissRequest = { plantationToEdit = null }, title = { Text("تعديل اسم الموضع") },
            text = { OutlinedTextField(value = editedPlantationName, onValueChange = { editedPlantationName = it }, label = { Text("اسم الموضع") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { val clean = editedPlantationName.trim(); if (clean.isNotBlank()) scope.launch { dao.updatePlantation(target.copy(name = clean)) }; plantationToEdit = null }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { plantationToEdit = null }) { Text("إلغاء") } })
    }

    if (plantationToDelete != null) {
        val target = plantationToDelete!!
        AlertDialog(
            onDismissRequest = { plantationToDelete = null },
            title = { Text("تأكيد حذف الموضع") },
            text = { Text("هل تريد حذف الموضع «${target.name}»؟ لا يمكن حذف أي موضع يحتوي على مصروفات مسجلة.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val deleted = dao.deletePlantationIfEmpty(target.id)
                        if (!deleted) deleteMessage = "لا يمكن حذف الموضع «${target.name}» لأنه يحتوي على مصروفات مسجلة. احذف المصروفات أو احتفظ بالموضع."
                    }
                    plantationToDelete = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { plantationToDelete = null }) { Text("إلغاء") } }
        )
    }
    if (deleteMessage != null) {
        AlertDialog(
            onDismissRequest = { deleteMessage = null },
            title = { Text("تنبيه") },
            text = { Text(deleteMessage!!) },
            confirmButton = { TextButton(onClick = { deleteMessage = null }) { Text("حسنًا") } }
        )
    }

    if (showChooseCategory) {
        AlertDialog(
            onDismissRequest = { showChooseCategory = false },
            title = { Text("اختر نوع العملية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات").forEach { category ->
                        OutlinedButton(onClick = { currentSection = category; showChooseCategory = false; showAddExpense = true }, modifier = Modifier.fillMaxWidth()) { Text(category) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChooseCategory = false }) { Text("إلغاء") } }
        )
    }
    if (showChoosePlantation) {
        AlertDialog(
            onDismissRequest = { showChoosePlantation = false },
            title = { Text("اختر الموضع للعملية الجديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (plantations.isEmpty()) Text("أضف موضعًا زراعيًا أولًا من الصفحة الرئيسية.")
                    plantations.forEach { p ->
                        OutlinedButton(onClick = { selected = p; showChoosePlantation = false; showAddExpense = true }, modifier = Modifier.fillMaxWidth()) { Text(p.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChoosePlantation = false }) { Text("إلغاء") } }
        )
    }
    if (showAddPlantation) {
        PlantationEditorDialog(
            onDismiss = { showAddPlantation = false },
            onSave = { name, icon, color ->
                scope.launch { dao.insertPlantation(PlantationEntity(name = name.trim(), icon = icon, colorArgb = color)) }
                showAddPlantation = false
            }
        )
    }
    if (showAddExpense && selected != null) {
        ExpenseDialog(initial = editingExpense, category = currentSection, plantationName = selected!!.name, stockSuggestions = stockSuggestions, initialChemicalLines = editingChemicalLines, onDismiss = { if (!expenseSaving) { showAddExpense = false; editingExpense = null; editingChemicalLines = emptyList() } }) { title, amount, notes, chemicalLines, complete ->
            expenseSaving = true
            scope.launch {
                try {
                    val normalizedCategory = editingExpense?.category ?: currentSection
                    val dateMillis = extractOperationDate(notes) ?: (editingExpense?.dateMillis ?: System.currentTimeMillis())
                    val item = ExpenseEntity(id = editingExpense?.id ?: 0L, plantationId = selected!!.id, category = normalizedCategory, title = title.trim(), amount = amount, dateMillis = dateMillis, notes = notes)
                    val savedId = if (normalizedCategory == "السموم" || normalizedCategory == "الأسمدة") {
                        dao.saveChemicalExpense(item, chemicalLines)
                    } else {
                        val quantityBase = extractQuantityBase(notes)
                        val unit = extractNoteValue(notes, "وحدة القياس")
                        dao.saveExpenseWithStock(item, null, unit?.let(::stockBaseUnit), quantityBase)
                    }
                    syncExpenseReminder(dao, context, savedId, title.trim(), normalizedCategory, selected!!.name, notes)
                    showAddExpense = false
                    editingExpense = null
                    editingChemicalLines = emptyList()
                    expenseSaving = false
                    complete(true)
                } catch (t: Throwable) {
                    deleteMessage = t.message ?: "تعذر حفظ العملية. تحقق من المخزون والبيانات."
                    expenseSaving = false
                    complete(false)
                }
            }
        }
    }
}

@Composable
private fun MiyarPageFooter(section: String) {
    val tagline = when (section) {
        "الفواتير", "التجار والموردون", "الديون والمستحقات" -> "إدارة مالية دقيقة • حسابات واضحة ومستحقات محفوظة"
        "المخزون" -> "مخزون متكامل • أرصدة محدثة من الفواتير والاستخدام"
        "التقارير" -> "تقارير زراعية شاملة • قراءة أوضح لأداء مواضعك"
        "التنبيهات" -> "متابعة في وقتها • لا تفوّت موعد عملية مهمة"
        "القطفات", "الإيرادات والمبيعات" -> "مردود أوضح • كل قطفة ودفعة في سجلها"
        else -> "مِعيار… شريكك في إدارة زراعتك بذكاء"
    }
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🌿 مِعيار", color = Gold, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(10.dp))
            Text(tagline, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun Header(onMenuClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, contentDescription = "فتح القائمة الجانبية", tint = androidx.compose.ui.graphics.Color.White)
            }
            MiyarMark(Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("مِعيار", style = MaterialTheme.typography.headlineMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                Text("إدارة أدق - مردود أوضح", color = Gold, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun MiyarMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .padding(2.dp)
            .then(Modifier),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(50),
            color = Emerald,
            border = androidx.compose.foundation.BorderStroke(2.dp, Gold)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("🌿", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}

@Composable
internal fun FinancialCard(title: String, value: String, caption: String, onClick: (() -> Unit)? = null) {
    Card(modifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(caption, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpenseRow(
    item: ExpenseEntity, stockSuggestions: List<StockPriceSuggestion>, plantationName: String, dao: MiyarDao,
    onUpdate: (ExpenseEntity, List<ChemicalOperationLineInput>, (Boolean) -> Unit) -> Unit,
    onDelete: (ExpenseEntity) -> Unit
) {
    val scope = rememberCoroutineScope()
    var menu by rememberSaveable { mutableStateOf(false) }
    var editDialog by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var initialLines by remember(item.id) { mutableStateOf<List<ChemicalOperationLineEntity>>(emptyList()) }
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { }, onLongClick = { menu = true }),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                Text(java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(item.dateMillis)), color = Green, style = MaterialTheme.typography.labelSmall)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = {
                    menu = false
                    scope.launch { initialLines = dao.getChemicalOperationLines(item.id); editDialog = true }
                })
                DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    if (editDialog) {
        ExpenseDialog(initial = item, plantationName = plantationName, stockSuggestions = stockSuggestions, initialChemicalLines = initialLines, onDismiss = { editDialog = false }) { title, amount, details, lines, complete ->
            onUpdate(item.copy(title = title.trim(), amount = amount, notes = details, dateMillis = extractOperationDate(details) ?: item.dateMillis), lines) { success ->
                if (success) editDialog = false
                complete(success)
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("تأكيد الحذف") },
            text = { Text("هل تريد حذف المصروف «${item.title}»؟ لا يمكن التراجع عن هذه العملية.") },
            confirmButton = { TextButton(onClick = { onDelete(item); confirmDelete = false }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } })
    }
}

private fun categoryEmoji(category: String): String = when (category) {
    "السموم" -> "🧪"
    "الأسمدة" -> "🌿"
    "المياه والري", "المياه" -> "💧"
    "الأعمال اليدوية" -> "🧑‍🌾"
    "القطفات" -> "🧺"
    "الفواتير" -> "🧾"
    "المخزون" -> "📦"
    else -> "📝"
}

private fun categoryTint(category: String): androidx.compose.ui.graphics.Color = when (category) {
    "السموم" -> androidx.compose.ui.graphics.Color(0xFF9A5700)
    "الأسمدة" -> androidx.compose.ui.graphics.Color(0xFF177245)
    "المياه والري", "المياه" -> androidx.compose.ui.graphics.Color(0xFF0876B9)
    "الأعمال اليدوية" -> androidx.compose.ui.graphics.Color(0xFF80552A)
    "القطفات" -> androidx.compose.ui.graphics.Color(0xFF008577)
    else -> Emerald
}

@Composable
private fun PlantationEditorDialog(onDismiss: () -> Unit, onSave: (String, String, Long) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var selectedIcon by rememberSaveable { mutableStateOf("🌱") }
    var selectedColor by rememberSaveable { mutableLongStateOf(-16749764L) }
    var error by rememberSaveable { mutableStateOf("") }
    val icons = listOf("🌱", "🌳", "🌿", "🍃", "🪴", "🌾", "☘️", "🌴")
    val colors = listOf(
        "زمردي" to -16749764L,
        "أزرق" to 0xFF1976D2L,
        "ذهبي" to 0xFFC08A00L,
        "بنفسجي" to 0xFF7B4FA3L,
        "فيروزي" to 0xFF008C95L,
        "ترابي" to 0xFF93613DL
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة موضع زراعي", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(name, { name = it; error = "" }, label = { Text("اسم الموضع") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("اختر أيقونة الموضع", color = Emerald, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    icons.forEach { icon -> FilterChip(selected = selectedIcon == icon, onClick = { selectedIcon = icon }, label = { Text(icon) }) }
                }
                Text("لون الموضع", color = Emerald, fontWeight = FontWeight.Bold)
                colors.forEach { (label, color) ->
                    FilterChip(selected = selectedColor == color, onClick = { selectedColor = color }, label = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(shape = RoundedCornerShape(50), color = androidx.compose.ui.graphics.Color(color), modifier = Modifier.size(17.dp)) {}
                            Text(label)
                        }
                    })
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { Button(onClick = { if (name.isBlank()) error = "أدخل اسم الموضع." else onSave(name, selectedIcon, selectedColor) }) { Text("حفظ الموضع") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun TextEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onSave(value) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ReminderTimePickerField(value: String, onTimeChanged: (String) -> Unit) {
    val context = LocalContext.current
    val parts = value.split(":")
    val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 9
    val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 0
    OutlinedButton(onClick = {
        android.app.TimePickerDialog(context, { _, selectedHour, selectedMinute ->
            onTimeChanged(String.format(Locale.US, "%02d:%02d", selectedHour, selectedMinute))
        }, hour, minute, false).show()
    }, modifier = Modifier.fillMaxWidth()) {
        Text("وقت الإشعار: ${String.format(Locale.US, "%02d:%02d", if (hour % 12 == 0) 12 else hour % 12, minute)} ${if (hour < 12) "صباحًا" else "مساءً"} • تغيير الوقت")
    }
}

private suspend fun syncExpenseReminder(
    dao: MiyarDao, context: Context, id: Long, title: String, category: String, plantation: String, notes: String
) {
    val date = extractNoteValue(notes, "تاريخ العملية القادمة")
    val time = extractNoteValue(notes, "وقت الإشعار") ?: "09:00"
    if (!date.isNullOrBlank() && isValidReminderTime(time)) {
        ReminderScheduler.schedule(context, id, title, category, plantation, date, time, "EXPENSE")
        val parsed = runCatching { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).parse("$date $time")?.time }.getOrNull()
            ?: (System.currentTimeMillis() + 5_000L)
        dao.upsertOperationReminder(OperationReminderEntity(
            referenceType = "EXPENSE", referenceId = id, title = title, category = category,
            plantationName = plantation, scheduledAtMillis = parsed
        ))
    } else {
        ReminderScheduler.cancel(context, id, "EXPENSE")
        dao.deleteOperationReminder("EXPENSE", id)
    }
}

private fun extractNoteValue(notes: String, label: String): String? =
    Regex("(?m)^\\s*${Regex.escape(label)}:\\s*(.*?)\\s*$").find(notes)?.groupValues?.get(1)?.trim()

private fun extractOperationDate(notes: String): Long? {
    val raw = extractNoteValue(notes, "تاريخ العملية") ?: return null
    return runCatching { java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(raw)?.time }.getOrNull()
}

private fun extractQuantityBase(notes: String): Long {
    val amount = extractNoteValue(notes, "الكمية")?.let(::latinDigitsOnly)?.toLongOrNull() ?: return 0L
    val unit = extractNoteValue(notes, "وحدة القياس")
    val multiplier = if (unit == "كجم" || unit == "لتر") 1000L else 1L
    return runCatching { Math.multiplyExact(amount, multiplier) }.getOrDefault(0L)
}

private fun formatStockQuantity(value: Long, unit: String): String = when (unit) {
    "g" -> if (value >= 1000 && value % 1000L == 0L) "${value / 1000} كجم" else "$value جرام"
    else -> if (value >= 1000 && value % 1000L == 0L) "${value / 1000} لتر" else "$value مل"
}

private fun stockBaseUnit(unit: String): String = if (unit == "كجم" || unit == "جرام") "g" else "ml"

private fun editableUserNotes(notes: String): String {
    val marker = "ملاحظات:"
    if (notes.contains(marker)) return notes.substringAfter(marker).trim()
    val labels = listOf("نوع العملية:", "نوع العمل:", "المادة الفعالة/العنصر:", "الكمية:", "وحدة القياس:",
        "نوع الوقود:", "قيمة الوقود:", "عدد الساعات:", "عدد العمال:", "تكاليف العمال:", "خرج آخر:",
        "أجر العامل:", "تاريخ العملية:", "تاريخ العملية القادمة:", "وقت الإشعار:")
    return notes.lines().filterNot { line -> labels.any { line.trim().startsWith(it) } }.joinToString("\n").trim()
}

private data class ChemicalLineUi(
    val productName: String = "",
    val activeIngredient: String = "",
    val treatmentType: String = "عام",
    val unit: String = "كجم",
    val quantity: String = ""
)

@Composable
private fun ExpenseDialog(
    initial: ExpenseEntity? = null,
    category: String = initial?.category ?: "أخرى",
    plantationName: String = "",
    stockSuggestions: List<StockPriceSuggestion> = emptyList(),
    initialChemicalLines: List<ChemicalOperationLineEntity> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (String, Long, String, List<ChemicalOperationLineInput>, (Boolean) -> Unit) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val nextFieldAction = KeyboardActions(
        onNext = { if (!focusManager.moveFocus(FocusDirection.Next)) keyboardController?.hide() },
        onDone = { keyboardController?.hide(); focusManager.clearFocus() }
    )
    val isChemical = category == "السموم" || category == "الأسمدة"
    val isWater = category == "المياه" || category == "المياه والري"
    val isLabor = category == "الأعمال اليدوية"
    val isHarvest = category == "القطفات"
    var title by rememberSaveable(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var amountText by rememberSaveable(initial?.id) { mutableStateOf(initial?.amount?.toString() ?: "") }
    var notes by rememberSaveable(initial?.id) { mutableStateOf(editableUserNotes(initial?.notes.orEmpty())) }
    var opDate by rememberSaveable(initial?.id) { mutableLongStateOf(initial?.dateMillis ?: System.currentTimeMillis()) }
    var nextDateMillis by rememberSaveable(initial?.id) {
        mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "تاريخ العملية القادمة")?.let {
            runCatching { java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(it)?.time }.getOrNull()
        })
    }
    var showNextDate by rememberSaveable(initial?.id) { mutableStateOf(nextDateMillis != null) }
    var reminderTime by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "وقت الإشعار") ?: "09:00") }
    var chemicalOtherCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "خرج آخر للعملية").orEmpty()) }
    var operationPeriod by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "الفترة المستخدمة") ?: "الفترة الصباحية") }
    var opType by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "نوع العملية") ?: "حشري") }
    var ingredient by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "المادة الفعالة/العنصر").orEmpty()) }
    var quantity by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "الكمية").orEmpty()) }
    var quantityUnit by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "وحدة القياس") ?: if (category == "السموم") "ملي" else "كجم") }
    var fuel by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "نوع الوقود") ?: "ديزل") }
    var fuelCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "قيمة الوقود").orEmpty()) }
    var hours by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "عدد الساعات").orEmpty()) }
    var workers by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "عدد عمال العملية") ?: extractNoteValue(initial?.notes.orEmpty(), "عدد العمال").orEmpty()) }
    var laborCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "تكاليف العمال").orEmpty()) }
    var otherCost by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "خرج آخر").orEmpty()) }
    var unitWage by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "أجر العامل").orEmpty()) }
    var workerCount by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "عدد العمال").orEmpty()) }
    var workType by rememberSaveable(initial?.id) { mutableStateOf(extractNoteValue(initial?.notes.orEmpty(), "نوع العمل") ?: "الحجين") }
    var operationRating by rememberSaveable(initial?.id) { mutableIntStateOf(extractNoteValue(initial?.notes.orEmpty(), "تقييم العملية")?.toIntOrNull() ?: 0) }
    var saving by rememberSaveable(initial?.id) { mutableStateOf(false) }
    var activeSuggestionRow by rememberSaveable(initial?.id) { mutableIntStateOf(-1) }
    val chemicalRows = remember(initial?.id) {
        mutableStateListOf<ChemicalLineUi>().apply {
            if (initialChemicalLines.isNotEmpty()) {
                initialChemicalLines.forEach { row -> add(ChemicalLineUi(row.productName, row.activeIngredient, row.treatmentType,
                    row.unit, row.enteredQuantity.toString())) }
            } else if (isChemical) {
                val oldUnitRaw = extractNoteValue(initial?.notes.orEmpty(), "وحدة القياس") ?: if (category == "السموم") "مل" else "كجم"
                val oldUnit = if (oldUnitRaw == "مل") "ملي" else oldUnitRaw
                add(ChemicalLineUi(
                    productName = initial?.title.orEmpty(),
                    activeIngredient = extractNoteValue(initial?.notes.orEmpty(), "المادة الفعالة/العنصر").orEmpty(),
                    treatmentType = if (category == "الأسمدة") "عام" else (extractNoteValue(initial?.notes.orEmpty(), "نوع العملية") ?: "حشري"),
                    unit = oldUnit,
                    quantity = extractNoteValue(initial?.notes.orEmpty(), "الكمية").orEmpty()
                ))
            }
        }
    }
    var laborInputsTouched by rememberSaveable(initial?.id) { mutableStateOf(false) }
    val autoTotal = if (isWater || isLabor) runCatching {
        val extras = Math.addExact(
            if (isWater) moneyToLong(fuelCost) else 0L,
            if (isWater) moneyToLong(laborCost) else 0L
        ).let { Math.addExact(it, moneyToLong(otherCost)) }
        if (isLabor) Math.addExact(
            Math.multiplyExact(workerCount.toLongOrNull() ?: 0L, moneyToLong(unitWage)), extras
        ) else extras
    }.getOrNull() else null
    LaunchedEffect(autoTotal, laborInputsTouched) {
        if (autoTotal != null && (initial == null || laborInputsTouched)) amountText = autoTotal.toString()
    }

    val calculatedChemicalLines = chemicalRows.map { row ->
        val status = row.treatmentType
        val matching = stockSuggestions.firstOrNull {
            it.productType == category && it.baseUnit == stockBaseUnit(row.unit) &&
                it.productName.equals(row.productName.trim(), true) && it.treatmentType == status
        }
        val entered = row.quantity.toLongOrNull() ?: 0L
        val base = runCatching { FinanceCalculations.quantityToBase(entered, row.unit) }.getOrDefault(0L)
        val cost = if (matching != null && base > 0L && matching.averageCostPerBaseScaled > 0L)
            runCatching { FinanceCalculations.usageCostYer(base, matching.averageCostPerBaseScaled) }.getOrDefault(0L) else 0L
        Triple(matching, base, cost)
    }
    val chemicalTotal = calculatedChemicalLines.sumOf { it.third }
    val chemicalValid = isChemical && chemicalRows.isNotEmpty() && chemicalRows.indices.all { i ->
        val row = chemicalRows[i]
        row.productName.isNotBlank() && row.quantity.toLongOrNull()?.let { it > 0L } == true &&
            calculatedChemicalLines[i].first != null && calculatedChemicalLines[i].first!!.averageCostPerBaseScaled > 0L &&
            calculatedChemicalLines[i].second > 0L &&
            calculatedChemicalLines[i].first!!.quantityBase >= calculatedChemicalLines[i].second
    }
    val parsed = amountText.takeIf { it.isNotBlank() }?.let(::moneyToLong)

    AlertDialog(
        modifier = if (isChemical) Modifier.fillMaxWidth(0.98f) else Modifier,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = !isChemical),
        onDismissRequest = { if (!saving) onDismiss() },
        title = {
            Text(if (isChemical) "إدخال عملية ${if (category == "الأسمدة") "تسميد" else "سموم"}" else if (initial == null) "إضافة عملية: $category" else "تعديل عملية: $category",
                color = Emerald, fontWeight = FontWeight.ExtraBold)
        },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (isChemical) {
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE9F8EE)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("🌳  الموضع: $plantationName", color = Emerald, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("📆  تاريخ العملية", color = Emerald, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                MiyarDateField("تاريخ العملية", opDate) { opDate = it }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("⌛️  تاريخ العملية القادمة", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Switch(checked = showNextDate, onCheckedChange = { showNextDate = it; if (it && nextDateMillis == null) nextDateMillis = System.currentTimeMillis() })
                            }
                            if (showNextDate) {
                                MiyarDateField("التاريخ القادم", nextDateMillis ?: System.currentTimeMillis()) { nextDateMillis = it }
                                ReminderTimePickerField(reminderTime) { reminderTime = it }
                            }
                        }
                    }
                    if (category == "السموم") {
                        Text("حالة الصنف للعملية", color = Emerald, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf("حشري", "فطري", "ورقي", "جذري").forEach { kind ->
                                FilterChip(selected = opType == kind, onClick = {
                                    opType = kind
                                    chemicalRows.indices.forEach { rowIndex -> chemicalRows[rowIndex] = chemicalRows[rowIndex].copy(treatmentType = kind) }
                                }, label = { Text(kind) })
                            }
                        }
                    } else {
                        Text("تصنيف السماد لكل صنف", color = Emerald, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("عام", "نمو", "تجذير", "ورقي").forEach { status ->
                                FilterChip(selected = chemicalRows.all { it.treatmentType == status }, onClick = {
                                    chemicalRows.indices.forEach { rowIndex -> chemicalRows[rowIndex] = chemicalRows[rowIndex].copy(treatmentType = status) }
                                }, label = { Text(status, style = MaterialTheme.typography.labelSmall) })
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("تفاصيل الأصناف — ${chemicalRows.size} صنف", color = Emerald, fontWeight = FontWeight.Bold)
                            val scroll = rememberScrollState()
                            Column(Modifier.fillMaxWidth().horizontalScroll(scroll)) {
                                Row(Modifier.background(Emerald, RoundedCornerShape(8.dp)).padding(7.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    listOf("اسم الصنف", "المادة الفعالة / العنصر", "حالة الصنف", "الوحدة", "الكمية", "القيمة من الفاتورة").forEachIndexed { index, label ->
                                        Text(label, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.width(listOf(160, 165, 105, 90, 95, 135)[index].dp))
                                    }
                                }
                                chemicalRows.forEachIndexed { index, row ->
                                    val suggested = stockSuggestions.filter {
                                        it.productType == category && row.productName.isNotBlank() &&
                                            it.productName.contains(row.productName.trim(), true)
                                    }.distinctBy { it.productName }.take(8)
                                    val match = calculatedChemicalLines[index].first
                                    Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.width(160.dp)) {
                                            OutlinedTextField(
                                                value = row.productName,
                                                onValueChange = { value ->
                                                    chemicalRows[index] = row.copy(productName = value)
                                                    activeSuggestionRow = index
                                                    val exact = stockSuggestions.firstOrNull { it.productType == category && it.productName.equals(value.trim(), true) }
                                                    if (exact != null) chemicalRows[index] = chemicalRows[index].copy(
                                                        activeIngredient = exact.activeIngredient,
                                                        treatmentType = exact.treatmentType,
                                                        unit = if (exact.baseUnit.equals("ml", true)) "ملي" else if (exact.baseUnit.equals("g", true)) "جرام" else if (exact.baseUnit.equals("l", true)) "لتر" else "كجم"
                                                    )
                                                },
                                                label = { Text("اسم الصنف") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth()
                                            )
                                            DropdownMenu(expanded = activeSuggestionRow == index && suggested.isNotEmpty(), onDismissRequest = { activeSuggestionRow = -1 }, properties = PopupProperties(focusable = false)) {
                                                suggested.forEach { item -> DropdownMenuItem(
                                                    text = { Column { Text(item.productName, fontWeight = FontWeight.Bold); Text(item.activeIngredient, style = MaterialTheme.typography.bodySmall) } },
                                                    onClick = { chemicalRows[index] = row.copy(
                                                        productName = item.productName,
                                                        activeIngredient = item.activeIngredient,
                                                        treatmentType = item.treatmentType,
                                                        unit = if (item.baseUnit.equals("ml", true)) "ملي" else if (item.baseUnit.equals("g", true)) "جرام" else if (item.baseUnit.equals("l", true)) "لتر" else "كجم"
                                                    ); activeSuggestionRow = -1 }
                                                ) }
                                            }
                                        }
                                        OutlinedTextField(row.activeIngredient, { chemicalRows[index] = row.copy(activeIngredient = it) }, label = { Text("المادة الفعالة") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(165.dp))
                                        Column(Modifier.width(105.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            (if (category == "الأسمدة") listOf("عام", "نمو", "تجذير", "ورقي") else listOf("حشري", "فطري", "ورقي", "جذري")).forEach { status ->
                                                FilterChip(selected = row.treatmentType == status, onClick = { chemicalRows[index] = row.copy(treatmentType = status) }, label = { Text(status, style = MaterialTheme.typography.labelSmall) })
                                            }
                                        }
                                        Column(Modifier.width(90.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            listOf("كجم", "لتر", "جرام", "ملي").forEach { unit ->
                                                FilterChip(selected = row.unit == unit, onClick = { chemicalRows[index] = row.copy(unit = unit) }, label = { Text(unit, style = MaterialTheme.typography.labelSmall) })
                                            }
                                        }
                                        OutlinedTextField(row.quantity, { chemicalRows[index] = row.copy(quantity = latinDigitsOnly(it)) }, label = { Text("الكمية") }, singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, modifier = Modifier.width(95.dp))
                                        Column(Modifier.width(135.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(
                                                when {
                                                    match == null -> "غير مسجل"
                                                    match.averageCostPerBaseScaled <= 0L -> "لا توجد فاتورة مسعّرة"
                                                    else -> formatMoney(calculatedChemicalLines[index].third)
                                                },
                                                color = if (match == null || match.averageCostPerBaseScaled <= 0L) androidx.compose.ui.graphics.Color(0xFFB3261E) else Emerald,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(match?.let { "متاح: ${formatStockQuantity(it.quantityBase, it.baseUnit)}" } ?: "الصنف غير موجود في المخزون", color = if (match == null) androidx.compose.ui.graphics.Color(0xFFB3261E) else Green, style = MaterialTheme.typography.labelSmall)
                                        }
                                        IconButton(onClick = { if (chemicalRows.size > 1) chemicalRows.removeAt(index) }) { Icon(Icons.Default.Delete, contentDescription = "حذف الصنف", tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) }
                                    }
                                    HorizontalDivider(color = Gold.copy(alpha = 0.5f))
                                }
                            }
                            FilledTonalButton(onClick = { chemicalRows.add(ChemicalLineUi(treatmentType = if (category == "الأسمدة") "عام" else opType, unit = if (category == "الأسمدة") "كجم" else "ملي")) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Add, null); Text("إضافة نوع آخر")
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3D4))) {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text("القيمة المحتسبة من الفاتورة", color = Emerald, fontWeight = FontWeight.Bold)
                            Text(formatMoney(chemicalTotal), color = Green, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                            Text("تُحسب من تكلفة الشراء المسجلة للصنف وكمية الاستخدام، وتُخصم الكمية من المخزون عند الحفظ.", style = MaterialTheme.typography.bodySmall)
                            MiyarMoneyInputField(chemicalOtherCost, { chemicalOtherCost = it }, label = "خرج آخر للعملية", modifier = Modifier.fillMaxWidth())
                            Text("إجمالي خرج العملية: ${formatMoney(chemicalTotal + (moneyToLong(chemicalOtherCost)))}", color = Emerald, fontWeight = FontWeight.Bold)
                            Text("الوقت المستخدم للعملية", color = Emerald, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("الفترة الصباحية", "الفترة المسائية").forEach { period -> FilterChip(selected = operationPeriod == period, onClick = { operationPeriod = period }, label = { Text(period) }) } }
                        }
                    }
                    OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات العملية") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = nextFieldAction, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Text("تقييم العملية", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        (1..5).forEach { score -> TextButton(onClick = { operationRating = score }) { Text(if (operationRating >= score) "★" else "☆", color = Gold, style = MaterialTheme.typography.titleLarge) } }
                        TextButton(onClick = { operationRating = 0 }) { Text("مسح") }
                    }
                } else {
                    if (isLabor) {
                        Text("نوع العمل", color = Emerald, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            listOf("الحشات", "الحجين", "البرح", "الفقح", "التراب", "أخرى").forEach { t -> FilterChip(selected = workType == t, onClick = { workType = t }, label = { Text(t) }) }
                        }
                        if (workType == "أخرى") OutlinedTextField(title, { title = it }, label = { Text("اسم العمل المخصص") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    if (!isLabor || workType != "أخرى") OutlinedTextField(title, { title = it }, label = { Text(if (isWater) "بيان عملية المياه والري" else if (isHarvest) "بيان القطفة / المشتري" else "بيان العملية") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                    MiyarDateField("تاريخ العملية", opDate) { opDate = it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("تاريخ العملية القادمة (اختياري)", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Switch(checked = showNextDate, onCheckedChange = { showNextDate = it; if (it && nextDateMillis == null) nextDateMillis = System.currentTimeMillis() })
                    }
                    if (showNextDate) {
                        MiyarDateField("تاريخ العملية القادمة", nextDateMillis ?: System.currentTimeMillis()) { nextDateMillis = it }
                        ReminderTimePickerField(reminderTime) { reminderTime = it }
                    }
                    if (isWater) {
                        Text("نوع الوقود", color = Emerald, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) { listOf("بترول", "ديزل", "غاز", "طاقة شمسية").forEach { t -> FilterChip(selected = fuel == t, onClick = { fuel = t }, label = { Text(t) }) } }
                        MiyarMoneyInputField(fuelCost, { fuelCost = it; laborInputsTouched = true }, label = "قيمة الوقود", modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(hours, { hours = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("عدد الساعات") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true)
                        OutlinedTextField(workers, { workers = latinDigitsOnly(it) }, label = { Text("عدد عمال العملية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true)
                        MiyarMoneyInputField(laborCost, { laborCost = it; laborInputsTouched = true }, label = "تكاليف العمال", modifier = Modifier.fillMaxWidth())
                        MiyarMoneyInputField(otherCost, { otherCost = it; laborInputsTouched = true }, label = "خرج آخر للعملية", modifier = Modifier.fillMaxWidth())
                        Text("إجمالي تكلفة العملية: ${formatMoney(autoTotal ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                    } else if (isLabor) {
                        OutlinedTextField(workerCount, { workerCount = latinDigitsOnly(it); laborInputsTouched = true }, label = { Text("عدد العمال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true)
                        MiyarMoneyInputField(unitWage, { unitWage = it; laborInputsTouched = true }, label = "أجر العامل الواحد", modifier = Modifier.fillMaxWidth())
                        MiyarMoneyInputField(otherCost, { otherCost = it; laborInputsTouched = true }, label = "الخرج الإضافي", modifier = Modifier.fillMaxWidth())
                        Text("إجمالي تكلفة العملية: ${formatMoney(autoTotal ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                    } else {
                        MiyarMoneyInputField(amountText, { amountText = it }, label = if (isHarvest) "مبلغ المردود بالريال اليمني" else "مبلغ العملية بالريال اليمني", modifier = Modifier.fillMaxWidth())
                    }
                    OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات العملية") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = nextFieldAction, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Text("تقييم العملية", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        (1..5).forEach { score -> TextButton(onClick = { operationRating = score }) { Text(if (operationRating >= score) "★" else "☆", color = Gold, style = MaterialTheme.typography.titleLarge) } }
                        TextButton(onClick = { operationRating = 0 }) { Text("مسح") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !saving && if (isChemical) chemicalValid && (!showNextDate || isValidReminderTime(reminderTime)) else (title.isNotBlank() || isLabor) && (parsed != null && parsed >= 0) && (!(isWater || isLabor) || autoTotal != null) && (!showNextDate || isValidReminderTime(reminderTime)), onClick = {
                val details = buildString {
                    if (isChemical) {
                        append("نوع العملية: $opType\nالفترة المستخدمة: $operationPeriod\nخرج آخر للعملية: ${moneyToLong(chemicalOtherCost)}\n")
                        append("تاريخ العملية: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(opDate))}\n")
                        if (showNextDate && nextDateMillis != null) append("تاريخ العملية القادمة: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(nextDateMillis!!))}\nوقت الإشعار: $reminderTime\n")
                        chemicalRows.forEachIndexed { index, row ->
                            append("الصنف ${index + 1}: ${row.productName} | ${row.activeIngredient} | ${row.treatmentType} | ${row.quantity} ${row.unit} | ${formatMoney(calculatedChemicalLines[index].third)}\n")
                        }
                        if (notes.isNotBlank()) append("ملاحظات: $notes\n")
                        if (operationRating > 0) append("تقييم العملية: $operationRating/5")
                    } else {
                        if (isWater) append("نوع الوقود: $fuel\nقيمة الوقود: $fuelCost\nعدد الساعات: $hours\nعدد عمال العملية: $workers\nتكاليف العمال: $laborCost\nخرج آخر: $otherCost\n")
                        if (isLabor) append("نوع العمل: $workType\nعدد العمال: $workerCount\nأجر العامل: $unitWage\nخرج آخر: $otherCost\n")
                        append("تاريخ العملية: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(opDate))}\n")
                        if (showNextDate && nextDateMillis != null) append("تاريخ العملية القادمة: ${java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(nextDateMillis!!))}\nوقت الإشعار: $reminderTime\n")
                        if (notes.isNotBlank()) append("ملاحظات: $notes\n")
                        if (operationRating > 0) append("تقييم العملية: $operationRating/5")
                    }
                }
                val chemicalInputs = if (isChemical) chemicalRows.mapIndexed { index, row ->
                    ChemicalOperationLineInput(
                        productType = category,
                        productName = row.productName.trim(),
                        activeIngredient = row.activeIngredient.trim(),
                        treatmentType = row.treatmentType,
                        unit = row.unit,
                        enteredQuantity = row.quantity.toLong(),
                        quantityBase = calculatedChemicalLines[index].second,
                        costAmountYer = calculatedChemicalLines[index].third
                    )
                } else emptyList()
                saving = true
                onSave(
                    if (isChemical) "عملية ${if (category == "الأسمدة") "تسميد" else "سموم"} (${chemicalRows.size} أصناف)" else if (title.isBlank() && isLabor) workType else title,
                    if (isChemical) Math.addExact(chemicalTotal, moneyToLong(chemicalOtherCost)) else requireNotNull(if (isWater || isLabor) autoTotal else parsed),
                    details, chemicalInputs
                ) { saving = false }
            }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ العملية") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun isValidReminderTime(value: String): Boolean =
    Regex("^(?:[01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(value.trim())


internal fun formatNumber(amount: Long): String = NumberFormat.getIntegerInstance(Locale.GERMANY).format(amount)

internal fun formatMoney(amount: Long): String = formatNumber(amount) + " ر.ي"


@Composable
private fun PinLockScreen(pinInput: String, onInput: (String) -> Unit, onUnlock: () -> Unit, error: String, hasPin: Boolean) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        MiyarMark(Modifier.size(76.dp))
        Spacer(Modifier.height(16.dp))
        Text("مِعيار", style = MaterialTheme.typography.headlineLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
        Text("أدخل رمز PIN للمتابعة", color = Green)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = pinInput, onValueChange = onInput, label = { Text("رمز PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = onUnlock, enabled = hasPin && pinInput.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("فتح التطبيق") }
    }
}

private fun sha256(value: String): String =
    MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
