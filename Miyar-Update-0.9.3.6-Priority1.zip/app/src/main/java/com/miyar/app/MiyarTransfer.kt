package com.miyar.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.miyar.app.data.MiyarDatabase
import java.io.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Full local backup: Room database plus all app preference XML files. */
object MiyarTransfer {
    fun createBackup(context: Context, destination: Uri) {
        val db = context.getDatabasePath("miyar.db")
        require(db.exists() && db.length() > 0) { "قاعدة بيانات مِعيار غير موجودة." }
        MiyarDatabase.get(context).openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        context.contentResolver.openOutputStream(destination, "w")?.use { raw ->
            ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                zip.putNextEntry(ZipEntry("backup_info.txt"))
                zip.write(("MIYAR_BACKUP\nversion=1\ncreated=${System.currentTimeMillis()}\n").toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("database/miyar.db")); db.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                val prefs = File(context.applicationInfo.dataDir, "shared_prefs")
                prefs.listFiles()?.filter { it.isFile && it.extension == "xml" }?.forEach { file ->
                    zip.putNextEntry(ZipEntry("preferences/${file.name}")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                }
            }
        } ?: error("تعذر فتح مكان حفظ النسخة.")
    }

    fun restoreBackup(context: Context, source: Uri) {
        val temp = File(context.cacheDir, "miyar_restore_${System.currentTimeMillis()}").apply { mkdirs() }
        var databaseFound = false
        try {
            context.contentResolver.openInputStream(source)?.use { input ->
                ZipInputStream(BufferedInputStream(input)).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        val out = when {
                            entry.name == "database/miyar.db" -> File(temp, "miyar.db").also { databaseFound = true }
                            entry.name.startsWith("preferences/") && entry.name.substringAfterLast('/').matches(Regex("[A-Za-z0-9_.-]+\\.xml")) -> File(temp, entry.name.substringAfterLast('/'))
                            entry.name == "backup_info.txt" -> File(temp, "backup_info.txt")
                            else -> null
                        }
                        if (out != null) { out.parentFile?.mkdirs(); FileOutputStream(out).use { zip.copyTo(it) } }
                        zip.closeEntry()
                    }
                }
            } ?: error("تعذر قراءة ملف النسخة الاحتياطية.")
            val restoredDb = File(temp, "miyar.db")
            require(databaseFound && restoredDb.length() > 100 && restoredDb.inputStream().use { byteArrayOf(it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte()).toString(Charsets.US_ASCII) } == "SQLite ") { "الملف ليس نسخة مِعيار سليمة." }
            require(File(temp, "backup_info.txt").readText().contains("MIYAR_BACKUP")) { "صيغة النسخة غير معروفة." }
            // Validate SQLite integrity before replacing current data.
            android.database.sqlite.SQLiteDatabase.openDatabase(restoredDb.absolutePath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY).use { sql ->
                sql.rawQuery("PRAGMA quick_check", null).use { cursor -> require(cursor.moveToFirst() && cursor.getString(0) == "ok") { "قاعدة البيانات داخل النسخة تالفة." } }
            }
            MiyarDatabase.closeInstance()
            val target = context.getDatabasePath("miyar.db")
            target.parentFile?.mkdirs()
            File(target.parentFile, "miyar.db-wal").delete(); File(target.parentFile, "miyar.db-shm").delete()
            restoredDb.copyTo(target, overwrite = true)
            val prefsTarget = File(context.applicationInfo.dataDir, "shared_prefs").apply { mkdirs() }
            temp.listFiles()?.filter { it.extension == "xml" }?.forEach { it.copyTo(File(prefsTarget, it.name), overwrite = true) }
        } finally { temp.deleteRecursively() }
    }


    fun exportAllTablesCsv(context: Context, destination: Uri) {
        val db = MiyarDatabase.get(context).openHelper.readableDatabase
        context.contentResolver.openOutputStream(destination, "w")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
            writer.write("\uFEFFمِعيار - تصدير شامل لبيانات التطبيق\r\n")
            val tables = db.query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name != 'room_master_table' ORDER BY name")
            val names = mutableListOf<String>()
            while (tables.moveToNext()) names += tables.getString(0)
            tables.close()
            names.forEach { table ->
                writer.write("\r\nجدول: ${csv(table)}\r\n")
                val cursor = db.query("SELECT * FROM `${table.replace("`", "``")}`")
                val columns = (0 until cursor.columnCount).map { cursor.getColumnName(it) }
                writer.write(columns.joinToString(",") { csv(it) } + "\r\n")
                while (cursor.moveToNext()) {
                    writer.write(columns.indices.joinToString(",") { index ->
                        when (cursor.getType(index)) {
                            android.database.Cursor.FIELD_TYPE_NULL -> ""
                            android.database.Cursor.FIELD_TYPE_BLOB -> csv("[BLOB ${cursor.getBlob(index).size} bytes]")
                            android.database.Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(index).toString()
                            android.database.Cursor.FIELD_TYPE_FLOAT -> cursor.getDouble(index).toString()
                            else -> csv(cursor.getString(index) ?: "")
                        }
                    } + "\r\n")
                }
                cursor.close()
            }
        } ?: error("تعذر فتح مكان حفظ ملف التصدير.")
    }

    private fun csv(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    fun shareOperationPdf(context: Context, title: String, plantation: String, category: String, dateMillis: Long, amount: Long, notes: String, chemicalLines: List<String>) {
        val pdf = PdfDocument(); val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; color = android.graphics.Color.rgb(0, 80, 48) }
        var y = 58f
        fun line(text: String, bold: Boolean = false) { paint.typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT; page.canvas.drawText(text.take(75), 545f, y, paint); y += 30f }
        line("MIYAR | مِعيار", true); line("تفاصيل العملية الزراعية", true); y += 12
        line("اسم العملية: $title"); line("الموضع: $plantation"); line("القسم: $category")
        line("التاريخ: ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(dateMillis))}")
        line("القيمة: ${formatMoney(amount)}"); y += 10
        line("تفاصيل المواد:", true)
        chemicalLines.forEach { if (y < 760) line("• $it") }
        y += 10; line("ملاحظات:", true)
        notes.split('\n').forEach { if (y < 790) line(it) }
        page.canvas.drawText("تم استخراج هذا التقرير من تطبيق مِعيار", 300f, 815f, paint)
        pdf.finishPage(page)
        val file = File(context.cacheDir, "miyar_operation_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { pdf.writeTo(it) }; pdf.close()
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "مشاركة تقرير العملية"))
    }
}
