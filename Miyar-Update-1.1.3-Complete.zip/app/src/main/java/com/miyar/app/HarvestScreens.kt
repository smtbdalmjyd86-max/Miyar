@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)
package com.miyar.app

import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private fun hDate(value: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(value))
private fun money(value: Long): String = formatMoney(value).replace("ر.ي", "ريال")
private fun safeProduct(a: Long, b: Long): Long = try { Math.multiplyExact(a, b) } catch (_: ArithmeticException) { Long.MAX_VALUE }
private fun safeSum(values: Iterable<Long>): Long = try { values.fold(0L) { total, value -> Math.addExact(total, value) } } catch (_: ArithmeticException) { Long.MAX_VALUE }
private fun isValidMoneyInput(value: String): Boolean = value.isBlank() || latinDigitsOnly(value).toLongOrNull() != null

private val MIYAR_PRODUCT_TYPES = listOf("عود", "مدبوش", "فراد", "قطل", "خوالف")

@Composable
private fun ProductTypeField(value: String, onValue: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("نوع المنتج: ${value.ifBlank { "اختر النوع" }}")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            MIYAR_PRODUCT_TYPES.forEach { type ->
                DropdownMenuItem(text = { Text(type) }, onClick = { onValue(type); expanded = false })
            }
        }
    }
}

@Composable
private fun DateField(label: String, value: Long, onChange: (Long) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) {
        Text("$label: ${hDate(value)}")
    }
    if (show) {
        val state = rememberDatePickerState(initialSelectedDateMillis = value.takeIf { it > 0 } ?: System.currentTimeMillis())
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = { state.selectedDateMillis?.let(onChange); show = false }) { Text("اختيار") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } }
        ) { DatePicker(state) }
    }
}

@Composable
private fun NumField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth()) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(latinDigitsOnly(it)) },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
        keyboardActions = KeyboardActions(
            onNext = { if (!focusManager.moveFocus(FocusDirection.Next)) keyboardController?.hide() },
            onDone = { keyboardController?.hide(); focusManager.clearFocus() }
        )
    )
}

@Composable
private fun MoneyField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth()) {
    MiyarMoneyInputField(value = value, onValueChange = onValue, label = label, modifier = modifier)
}

@Composable
private fun SuggestedTextField(
    label: String,
    value: String,
    onValue: (String) -> Unit,
    suggestions: List<String>,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    Column(modifier) {
        OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        val matches = remember(value, suggestions) {
            if (value.isBlank()) emptyList() else suggestions.distinct().filter { it.contains(value, ignoreCase = true) }.take(5)
        }
        if (matches.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                matches.forEach { suggestion ->
                    TextButton(onClick = { onValue(suggestion) }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)) {
                        Text(suggestion, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun HarvestMetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) { Text(label, color = Emerald, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold); Text(value, color = Green, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
fun MiyarHarvestScreen(
    dao: MiyarDao,
    plantations: List<PlantationEntity>,
    searchTarget: String? = null,
    onSearchTargetConsumed: () -> Unit = {},
    initialPage: String = "home",
    onExitScreen: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var page by remember(initialPage) { mutableStateOf(initialPage) }
    var selectedHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }
    var selectedDay by remember { mutableStateOf<PersonalHarvestDayEntity?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var newPlotId by remember { mutableLongStateOf(0L) }
    var selectedPersonalPlotId by rememberSaveable { mutableLongStateOf(0L) }
    var distributorParentPage by rememberSaveable { mutableStateOf("sellerFiles") }
    var debtorParentPage by rememberSaveable { mutableStateOf("debtorFiles") }
    var editingHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }
    var longPressedHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }
    var longPressedDay by remember { mutableStateOf<PersonalHarvestDayEntity?>(null) }
    var dataProtectionMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedSale by remember { mutableStateOf<BuyerSaleEntity?>(null) }
    var selectedBuyer by remember { mutableStateOf<QatBuyerEntity?>(null) }
    var selectedDistributor by remember { mutableStateOf<MarketDistributorEntity?>(null) }
    var selectedDebtor by remember { mutableStateOf<HarvestDebtorEntity?>(null) }

    val harvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(emptyList())
    val buyers by dao.observeBuyers().collectAsStateWithLifecycle(emptyList())
    val allSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(emptyList())
    val distributors by dao.observeDistributors().collectAsStateWithLifecycle(emptyList())
    val debtors by dao.observeDebtors().collectAsStateWithLifecycle(emptyList())
    val distributorTransactions by dao.observeAllDistributorTransactions().collectAsStateWithLifecycle(emptyList())
    val debtorTransactions by dao.observeAllDebtorTransactions().collectAsStateWithLifecycle(emptyList())
    val partyPayments by dao.observeAllHarvestPartyPayments().collectAsStateWithLifecycle(emptyList())
    val allDistributorAdjustments by dao.observeAllDistributorAdjustments().collectAsStateWithLifecycle(emptyList())
    val distributorSuggestions by dao.observeDistributorNameSuggestions().collectAsStateWithLifecycle(emptyList())
    val debtorSuggestions by dao.observeDebtorNameSuggestions().collectAsStateWithLifecycle(emptyList())
    val buyerSuggestions by dao.observeBuyerNameSuggestions().collectAsStateWithLifecycle(emptyList())
    val productSuggestions by dao.observeHarvestProductSuggestions().collectAsStateWithLifecycle(emptyList())

    LaunchedEffect(searchTarget) {
        val route = searchTarget?.split(":", limit = 2)
        val id = route?.getOrNull(1)?.toLongOrNull()
        if (route != null && id != null) {
            when (route[0]) {
                "harvest" -> dao.getPersonalHarvestById(id)?.let { selectedHarvest = it; selectedDay = null; page = "harvest" }
                "day" -> dao.getPersonalHarvestDayById(id)?.let { day ->
                    dao.getPersonalHarvestById(day.harvestId)?.let { harvest -> selectedHarvest = harvest; selectedDay = day; page = "day" }
                }
                "buyer" -> dao.getBuyerById(id)?.let { selectedBuyer = it; page = "buyerDetail" }
                "sale" -> dao.getBuyerSaleById(id)?.let { sale ->
                    selectedSale = sale
                    selectedBuyer = dao.getBuyerById(sale.buyerId)
                    page = if (selectedBuyer == null) "buyerFiles" else "saleDetail"
                }
                "distributor" -> dao.getDistributorById(id)?.let { distributorParentPage = "parties"; selectedDistributor = it; page = "distributorDetail" }
                "debtor" -> dao.getDebtorById(id)?.let { debtorParentPage = "parties"; selectedDebtor = it; page = "debtorDetail" }
            }
        }
        if (!searchTarget.isNullOrBlank()) onSearchTargetConsumed()
    }

    fun navigateBack() {
        when (page) {
            "day", "newDay", "editDay", "harvestEdit" -> page = "harvest"
            "harvest" -> page = "personalPlot"
            "personalPlot" -> page = "personal"
            "personal", "parties", "buyer", "buyerFiles", "salesList" -> page = if (initialPage == "revenue") "revenue" else "home"
            "sellerFiles", "debtorFiles" -> page = "parties"
            "distributorDetail" -> page = distributorParentPage
            "debtorDetail" -> page = debtorParentPage
            "buyerDetail" -> page = "buyerFiles"
            "buyerNewSale" -> page = "buyerDetail"
            "saleDetail" -> page = "buyerDetail"
            else -> page = if (initialPage == "revenue") "revenue" else "home"
        }
        selectedDay = null
    }

    val isDedicatedRootPage = initialPage != "home" && page == initialPage
    BackHandler(enabled = (page != "home" && page != "commerce") || showNew || editingHarvest != null || longPressedDay != null || longPressedHarvest != null) {
        when {
            longPressedDay != null -> longPressedDay = null
            longPressedHarvest != null -> longPressedHarvest = null
            editingHarvest != null -> editingHarvest = null
            showNew -> showNew = false
            isDedicatedRootPage -> onExitScreen()
            else -> navigateBack()
        }
    }

    Column(modifier.fillMaxSize()) {
        if (page != "home" && page != "commerce") {
            if (initialPage == "parties") {
                if (!isDedicatedRootPage) {
                    IconButton(onClick = { navigateBack() }, modifier = Modifier.align(Alignment.Start)) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "عودة", tint = Emerald)
                    }
                }
            } else {
                TextButton(onClick = { if (isDedicatedRootPage) onExitScreen() else navigateBack() }, modifier = Modifier.align(Alignment.Start)) { Text("← رجوع") }
            }
        }
        when (page) {
            "commerce" -> MiyarCommerceHubScreen(dao = dao, plantations = plantations, onBack = { page = "home" }, modifier = Modifier.fillMaxSize())

            "revenue" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("الإيرادات والمبيعات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Emerald)
                val agreed = FinanceCalculations.sumExact(allSales.map { it.agreedAmount })
                val discounts = FinanceCalculations.sumExact(allSales.map { it.discountAmount })
                val totalPayments by dao.observeAllBuyerPaymentsTotal().collectAsStateWithLifecycle(0L)
                val remaining = (agreed - discounts - totalPayments).coerceAtLeast(0L)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HarvestMetricCard("إجمالي الاتفاقات", money(agreed - discounts), Modifier.weight(1f))
                    HarvestMetricCard("المبالغ المحصلة", money(totalPayments), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HarvestMetricCard("المتبقي", money(remaining), Modifier.weight(1f))
                    HarvestMetricCard("عدد المبيعات", allSales.size.toString(), Modifier.weight(1f))
                }
                HarvestChoice("🧾", "سجل المبيعات", "عرض كل عمليات البيع والتحصيل") { page = "salesList" }
                HarvestChoice("👥", "ملفات المشترين", "كشف حساب كل مشترٍ والدفعات والمبالغ المتبقية") { page = "buyerFiles" }
                Text("إيرادات البيع والتحصيلات المسجلة للمشترين", style = MaterialTheme.typography.bodySmall, color = Green)
                Text("أحدث المبيعات", fontWeight = FontWeight.Bold)
                allSales.take(12).forEach { sale -> val buyer = buyers.firstOrNull { it.id == sale.buyerId }; Card(onClick = { selectedSale = sale; selectedBuyer = buyer; page = "saleDetail" }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(buyer?.name ?: "مشتري", fontWeight = FontWeight.Bold); Text("${sale.harvestName} • ${money(sale.agreedAmount - sale.discountAmount)}"); Text(hDate(sale.saleDateMillis), style = MaterialTheme.typography.bodySmall) } } }
            }

            "salesList" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سجل المبيعات والتحصيلات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                allSales.forEach { sale -> val buyer = buyers.firstOrNull { it.id == sale.buyerId }; Card(onClick = { selectedSale = sale; selectedBuyer = buyer; page = "saleDetail" }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(buyer?.name ?: "مشتري", fontWeight = FontWeight.Bold); Text("${sale.harvestName} • ${money(sale.agreedAmount - sale.discountAmount)}"); Text("${hDate(sale.saleDateMillis)} • افتح التفاصيل") } } }
                if (allSales.isEmpty()) Text("لا توجد مبيعات مسجلة بعد.")
            }

            "home" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("قسم القطفات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Emerald)
                HarvestChoice("🌿", "مركز القطفات والمبيعات الجديد", "ملفات الأطراف وسجل البيع متعدد المنتجات والتحصيلات") { page = "commerce" }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { HarvestChoice("🌿", "قطفة شخصية", "إدارة القطفات الشخصية") { page = "personal" } }
                    Box(Modifier.weight(1f)) { HarvestChoice("📁", "البائعون والعملاء", "${distributors.size} بائع • ${debtors.size} عميل") { page = "parties" } }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { HarvestChoice("🤝", "البيع لمشتري", "تسجيل البيع والمدة والدفعات") { page = "buyer" } }
                    Box(Modifier.weight(1f)) { HarvestChoice("📂", "ملفات المشترين", "القطفات وكشوف الحساب") { page = "buyerFiles" } }
                }
                Text("أحدث عمليات البيع لمشترٍ", fontWeight = FontWeight.Bold)
                allSales.take(8).forEach { sale ->
                    val buyer = buyers.firstOrNull { it.id == sale.buyerId }
                    Card(onClick = { selectedSale = sale; selectedBuyer = buyer; page = "saleDetail" }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(buyer?.name ?: "مشتري", fontWeight = FontWeight.Bold)
                            Text("${sale.harvestName} • ${money(sale.agreedAmount - sale.discountAmount)}")
                            Text("تاريخ البيع: ${hDate(sale.saleDateMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            "personal" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("اختر الموضع الذي سيتم القطف منه", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                plantations.forEach { plot ->
                    Card(onClick = { selectedPersonalPlotId = plot.id; page = "personalPlot" }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(plot.colorArgb).copy(alpha = 0.10f))) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(plot.icon, style = MaterialTheme.typography.titleLarge)
                            Text(plot.name, Modifier.padding(start = 10.dp).weight(1f), fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(plot.colorArgb))
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Emerald)
                        }
                    }
                }
                if (plantations.isEmpty()) Text("لا توجد مواضع مسجلة. أضف موضعًا أولًا.")
            }

            "personalPlot" -> {
                val plot = plantations.firstOrNull { it.id == selectedPersonalPlotId }
                val plotHarvests = harvests.filter { it.plantationId == selectedPersonalPlotId }
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("القطفات الشخصية • ${plot?.name ?: "الموضع"}", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { selectedHarvest = null; newPlotId = selectedPersonalPlotId; showNew = true }, modifier = Modifier.fillMaxWidth(), enabled = plot != null) { Text("＋ إنشاء ملف قطفة شخصية") }
                    if (plotHarvests.isEmpty()) Text("لا توجد ملفات قطفات شخصية في هذا الموضع بعد.", color = Green)
                    plotHarvests.forEach { harvest ->
                        Card(modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = { selectedHarvest = harvest; page = "harvest" },
                            onLongClick = { longPressedHarvest = harvest }
                        )) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(harvest.name, fontWeight = FontWeight.Bold, color = Emerald)
                                Text("${plot?.name ?: "موضع"} • ${hDate(harvest.startMillis)}")
                            }
                        }
                    }
                }
            }

            "harvest" -> {
                val harvest = selectedHarvest
                if (harvest != null) HarvestDetailScreen(dao, harvest, plantations, onAddDay = { selectedDay = null; page = "newDay" }, onOpenDay = { selectedDay = it; page = "day" }, onLongPressDay = { longPressedDay = it })
            }

            "newDay" -> selectedHarvest?.let { harvest ->
                DayEditor(dao, harvest, plantations, null, distributorSuggestions, debtorSuggestions, productSuggestions, onSaved = { page = "harvest" })
            }

            "editDay" -> if (selectedHarvest != null && selectedDay != null) {
                DayEditor(dao, selectedHarvest!!, plantations, selectedDay!!, distributorSuggestions, debtorSuggestions, productSuggestions, onSaved = { page = "harvest" })
            }

            "day" -> if (selectedHarvest != null && selectedDay != null) DayDetails(dao, selectedHarvest!!, selectedDay!!, plantations)

            "parties" -> {
                val sellerTotalsByTransaction = distributorTransactions.associate { transaction ->
                    val related = allDistributorAdjustments.filter { it.transactionId == transaction.id }
                    val discounts = FinanceCalculations.sumExact(related.filter { it.kind == "SELLER_DISCOUNT" }.map { it.amount })
                    val distribution = FinanceCalculations.sumExact(related.filter { it.kind == "DISTRIBUTION_EXPENSE" }.map { it.amount })
                    val net = FinanceCalculations.sellerNetSale(transaction.total, discounts, distribution)
                    transaction.id to net
                }
                val sellerTotal = FinanceCalculations.sumExact(sellerTotalsByTransaction.values)
                val sellerReceived = Math.addExact(
                    FinanceCalculations.sumExact(distributorTransactions.map { it.received }),
                    FinanceCalculations.sumExact(partyPayments.filter { it.partyType == "DISTRIBUTOR" }.map { it.amount })
                )
                val sellerBalance = FinanceCalculations.sumExact(distributorTransactions.map { transaction ->
                    val collectedForTransaction = Math.addExact(
                        transaction.received,
                        FinanceCalculations.sumExact(partyPayments.filter { it.partyType == "DISTRIBUTOR" && it.transactionId == transaction.id }.map { it.amount })
                    )
                    FinanceCalculations.sellerBalance(sellerTotalsByTransaction[transaction.id] ?: transaction.total, collectedForTransaction)
                })
                val sellerRemaining = sellerBalance.coerceAtLeast(0L)
                val sellerCredit = if (sellerBalance < 0L) -sellerBalance else 0L
                val debtorTotal = FinanceCalculations.sumExact(debtorTransactions.map { it.total })
                val debtorReceived = Math.addExact(
                    FinanceCalculations.sumExact(debtorTransactions.map { it.paid }),
                    FinanceCalculations.sumExact(partyPayments.filter { it.partyType == "DEBTOR" }.map { it.amount })
                )
                val debtorRemaining = FinanceCalculations.sumExact(debtorTransactions.map { transaction ->
                    val collectedForTransaction = Math.addExact(
                        transaction.paid,
                        FinanceCalculations.sumExact(partyPayments.filter { it.partyType == "DEBTOR" && it.transactionId == transaction.id }.map { it.amount })
                    )
                    (transaction.total - collectedForTransaction).coerceAtLeast(0L)
                })
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("إدارة ملفات البائعين والعملاء والأرصدة المستحقة", color = Emerald, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PartyFolderCard(
                            title = "ملفات البائعين",
                            subtitle = "${distributors.size} ملف",
                            emoji = "🧑‍💼",
                            tint = androidx.compose.ui.graphics.Color(0xFFE7F1E8),
                            modifier = Modifier.weight(1f)
                        ) { page = "sellerFiles" }
                        PartyFolderCard(
                            title = "ملفات العملاء بالأجل",
                            subtitle = "${debtors.size} ملف",
                            emoji = "👥",
                            tint = androidx.compose.ui.graphics.Color(0xFFE9E8F5),
                            modifier = Modifier.weight(1f)
                        ) { page = "debtorFiles" }
                    }
                    Text("مبالغ ملفات البائعين", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PartyAmountCard("إجمالي العمليات", money(sellerTotal), androidx.compose.ui.graphics.Color(0xFFE6EDF8), Modifier.weight(1f))
                        PartyAmountCard("الواصل منهم", money(sellerReceived), androidx.compose.ui.graphics.Color(0xFFDFF1E8), Modifier.weight(1f))
                        PartyAmountCard("المتبقي عليهم", money(sellerRemaining), androidx.compose.ui.graphics.Color(0xFFFFEBD9), Modifier.weight(1f))
                    }
                    if (sellerCredit > 0L) Text("زيادة التحصيل / رصيد دائن للبائعين: ${money(sellerCredit)}", color = Green, style = MaterialTheme.typography.bodySmall)
                    Text("مبالغ ملفات العملاء بالآجل", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PartyAmountCard("إجمالي العمليات", money(debtorTotal), androidx.compose.ui.graphics.Color(0xFFEAE5F5), Modifier.weight(1f))
                        PartyAmountCard("الواصل منهم", money(debtorReceived), androidx.compose.ui.graphics.Color(0xFFDDF1F0), Modifier.weight(1f))
                        PartyAmountCard("المتبقي عليهم", money(debtorRemaining), androidx.compose.ui.graphics.Color(0xFFFBE5E5), Modifier.weight(1f))
                    }
                }
            }

            "sellerFiles" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("ملفات البائعين", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                if (distributors.isEmpty()) Text("لا توجد ملفات بائعين بعد.", color = Green)
                distributors.forEach { seller ->
                    Card(
                        onClick = { distributorParentPage = "sellerFiles"; selectedDistributor = seller; page = "distributorDetail" },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFEAF3EA)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🧑‍💼", fontSize = 22.sp)
                            Spacer(Modifier.width(9.dp))
                            Text(seller.name, modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Emerald)
                        }
                    }
                }
            }

            "debtorFiles" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("ملفات العملاء بالأجل", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                if (debtors.isEmpty()) Text("لا توجد ملفات عملاء بالآجل بعد.", color = Green)
                debtors.forEach { debtor ->
                    Card(
                        onClick = { debtorParentPage = "debtorFiles"; selectedDebtor = debtor; page = "debtorDetail" },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFF0EDF8)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("👤", fontSize = 22.sp)
                            Spacer(Modifier.width(9.dp))
                            Text(debtor.name, modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Emerald)
                        }
                    }
                }
            }

            "distributorDetail" -> selectedDistributor?.let { DistributorFileScreen(dao, it, harvests, plantations) }
            "debtorDetail" -> selectedDebtor?.let { DebtorFileScreen(dao, it, harvests, plantations) }

            "buyer" -> BuyerSaleForm(
                dao = dao,
                plantations = plantations,
                buyers = buyers,
                buyerSuggestions = buyerSuggestions,
                initialBuyer = null,
                onSaved = { page = if (initialPage == "revenue") "revenue" else "home" }
            )

            "buyerFiles" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("ملفات المشترين", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                buyers.forEach { buyer ->
                    val salesForBuyer = allSales.filter { it.buyerId == buyer.id }
                    Card(onClick = { selectedBuyer = buyer; page = "buyerDetail" }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(buyer.name, fontWeight = FontWeight.Bold)
                            Text("عدد القطفات: ${salesForBuyer.size} • إجمالي الاتفاقات: ${money(FinanceCalculations.sumExact(salesForBuyer.map { it.agreedAmount }))}")
                        }
                    }
                }
                if (buyers.isEmpty()) Text("سيظهر المشترون هنا تلقائيًا بعد تسجيل أول عملية بيع.")
            }

            "buyerDetail" -> selectedBuyer?.let { buyer ->
                BuyerFileScreen(dao, buyer, plantations, onNewSale = { page = "buyerNewSale" }, onOpenSale = { sale -> selectedSale = sale; page = "saleDetail" })
            }

            "buyerNewSale" -> BuyerSaleForm(dao, plantations, buyers, buyerSuggestions, selectedBuyer) { page = "buyerDetail" }

            "saleDetail" -> if (selectedSale != null && selectedBuyer != null) {
                BuyerSaleDetailScreen(dao, selectedSale!!, selectedBuyer!!, plantations)
            }
        }
    }

    if (showNew) {
        NewHarvestDialog(
            dao = dao,
            plots = plantations,
            plotId = newPlotId,
            onSaved = { harvest -> showNew = false; selectedHarvest = harvest; page = "harvest" },
            onCancel = { showNew = false }
        )
    }

    longPressedHarvest?.let { harvest ->
        AlertDialog(
            onDismissRequest = { longPressedHarvest = null },
            title = { Text(harvest.name) },
            text = { Text("اختر الإجراء المطلوب للقطفة") },
            confirmButton = { TextButton(onClick = { longPressedHarvest = null; editingHarvest = harvest }) { Text("تعديل") } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        scope.launch {
                            val deleted = dao.deletePersonalHarvestSafely(harvest.id)
                            longPressedHarvest = null
                            if (deleted) {
                                ReminderScheduler.cancel(context, harvest.id, "HARVEST")
                                dao.deleteOperationReminder("HARVEST", harvest.id)
                                if (selectedHarvest?.id == harvest.id) { selectedHarvest = null; page = "personalPlot" }
                            } else {
                                dataProtectionMessage = "لا يمكن حذف هذه القطفة الآن؛ توجد دفعات مالية مرتبطة بحسابات البائعين أو العملاء. راجع الملفات وسوِّ الدفعات أولًا حتى لا تضيع السجلات المالية."
                            }
                        }
                    }) { Text("حذف") }
                    TextButton(onClick = { longPressedHarvest = null; selectedHarvest = harvest; page = "harvest" }) { Text("فتح") }
                }
            }
        )
    }

    if (editingHarvest != null) {
        EditHarvestDialog(
            dao = dao,
            harvest = editingHarvest!!,
            onDone = { updated -> editingHarvest = null; selectedHarvest = updated; page = "harvest" },
            onCancel = { editingHarvest = null }
        )
    }

    dataProtectionMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { dataProtectionMessage = null },
            title = { Text("حماية السجلات المالية") },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { dataProtectionMessage = null }) { Text("حسنًا") } }
        )
    }

    longPressedDay?.let { day ->
        AlertDialog(
            onDismissRequest = { longPressedDay = null },
            title = { Text("يوم ${hDate(day.dateMillis)}") },
            text = { Text("هل تريد تعديل بيانات اليوم أم حذفه؟") },
            confirmButton = { TextButton(onClick = { longPressedDay = null; selectedDay = day; page = "editDay" }) { Text("تعديل") } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        scope.launch {
                            val deleted = dao.deletePersonalHarvestDaySafely(day.id)
                            longPressedDay = null
                            if (!deleted) dataProtectionMessage = "لا يمكن حذف يوم القطفة؛ توجد دفعة مالية مسجلة لأحد البائعين أو العملاء في هذا اليوم. راجع الحسابات أولًا حتى لا نفقد سجل الدفع."
                        }
                    }) { Text("حذف") }
                    TextButton(onClick = { longPressedDay = null }) { Text("إلغاء") }
                }
            }
        )
    }
}

@Composable
private fun PartyFolderCard(
    title: String,
    subtitle: String,
    emoji: String,
    tint: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(onClick = onClick, modifier = modifier.heightIn(min = 88.dp), colors = CardDefaults.cardColors(containerColor = tint), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(emoji, fontSize = 23.sp)
                Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Emerald, modifier = Modifier.size(19.dp))
            }
            Text(title, color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, color = Green, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun PartyAmountCard(title: String, value: String, tint: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = tint), shape = RoundedCornerShape(12.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall, maxLines = 2, minLines = 2)
            Text(value, color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelLarge, maxLines = 2, softWrap = true)
        }
    }
}

@Composable
private fun HarvestChoice(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(emoji, style = MaterialTheme.typography.headlineMedium)
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
private fun NewHarvestDialog(dao: MiyarDao, plots: List<PlantationEntity>, plotId: Long, onSaved: (PersonalHarvestEntity) -> Unit, onCancel: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var start by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var expected by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val plot = plots.firstOrNull { it.id == plotId }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("بيانات القطفة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الموضع: ${plot?.name ?: ""}", fontWeight = FontWeight.Bold)
                OutlinedTextField(name, { name = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                DateField("تاريخ بداية القطفة", start) { start = it }
                DateField("التاريخ المتوقع للانتهاء", expected) { expected = it }
                Text("يمكن إدخال تاريخ الانتهاء الفعلي لاحقًا من تعديل بيانات القطفة.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && plot != null && expected >= start) scope.launch {
                    val entity = PersonalHarvestEntity(
                        plantationId = plot.id, name = name.trim(), startMillis = start,
                        expectedEndMillis = expected, actualEndMillis = 0,
                        productsText = "", cashSalesText = "", debtorSalesText = "",
                        pickerCount = 0, pickerWage = 0, extraWages = 0,
                        bagsAndOther = 0, transportAndClearance = 0, notes = ""
                    )
                    val id = dao.insertPersonalHarvest(entity)
                    dao.insertAuditEvent(MiyarAuditEventEntity(entityType = "PERSONAL_HARVEST_PROFILE", entityId = id, eventType = "CREATE", afterSnapshot = "plantationId=${entity.plantationId};name=${entity.name};startMillis=${entity.startMillis};expectedEndMillis=${entity.expectedEndMillis}"))
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(expected))
                    val reminderAt = java.util.Calendar.getInstance().apply { timeInMillis = expected; set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
                    ReminderScheduler.schedule(context, id, name.trim(), "نهاية القطفة المتوقعة", plot.name, date, "09:00", "HARVEST")
                    dao.upsertOperationReminder(OperationReminderEntity(referenceType = "HARVEST", referenceId = id, title = name.trim(), category = "نهاية القطفة المتوقعة", plantationName = plot.name, scheduledAtMillis = reminderAt, plantationId = plot.id, priority = "NORMAL", suggestedAction = "راجع حالة القطفة وحدّث تاريخ انتهائها عند الحاجة."))
                    onSaved(entity.copy(id = id))
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("إلغاء") } }
    )
}

@Composable
private fun EditHarvestDialog(dao: MiyarDao, harvest: PersonalHarvestEntity, onDone: (PersonalHarvestEntity) -> Unit, onCancel: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var name by remember { mutableStateOf(harvest.name) }
    var start by remember { mutableLongStateOf(harvest.startMillis) }
    var expected by remember { mutableLongStateOf(harvest.expectedEndMillis) }
    var actual by remember { mutableLongStateOf(harvest.actualEndMillis) }
    var showActual by remember { mutableStateOf(harvest.actualEndMillis > 0) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("تعديل بيانات القطفة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth())
                DateField("بداية القطفة", start) { start = it }
                DateField("الانتهاء المتوقع", expected) { expected = it }
                TextButton(onClick = { showActual = !showActual; if (!showActual) actual = 0L }) { Text(if (showActual) "إخفاء تاريخ الانتهاء الفعلي" else "إدخال تاريخ الانتهاء الفعلي") }
                if (showActual) DateField("الانتهاء الفعلي", actual.takeIf { it > 0 } ?: System.currentTimeMillis()) { actual = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && expected >= start) scope.launch {
                    val updated = harvest.copy(name = name.trim(), startMillis = start, expectedEndMillis = expected, actualEndMillis = if (showActual) actual else 0L)
                    dao.updatePersonalHarvest(updated)
                    dao.insertAuditEvent(MiyarAuditEventEntity(entityType = "PERSONAL_HARVEST_PROFILE", entityId = updated.id, eventType = "UPDATE", beforeSnapshot = "plantationId=${harvest.plantationId};name=${harvest.name};startMillis=${harvest.startMillis};expectedEndMillis=${harvest.expectedEndMillis};actualEndMillis=${harvest.actualEndMillis}", afterSnapshot = "plantationId=${updated.plantationId};name=${updated.name};startMillis=${updated.startMillis};expectedEndMillis=${updated.expectedEndMillis};actualEndMillis=${updated.actualEndMillis}"))
                    val plotName = dao.getPlantationById(updated.plantationId)?.name ?: "الموضع الزراعي"
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(expected))
                    val reminderAt = java.util.Calendar.getInstance().apply { timeInMillis = expected; set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
                    if (updated.actualEndMillis == 0L) {
                        ReminderScheduler.schedule(context, updated.id, updated.name, "نهاية القطفة المتوقعة", plotName, date, "09:00", "HARVEST")
                        dao.upsertOperationReminder(OperationReminderEntity(referenceType = "HARVEST", referenceId = updated.id, title = updated.name, category = "نهاية القطفة المتوقعة", plantationName = plotName, scheduledAtMillis = reminderAt, plantationId = updated.plantationId, priority = "NORMAL", suggestedAction = "راجع حالة القطفة وحدّث تاريخ انتهائها عند الحاجة."))
                    } else {
                        ReminderScheduler.cancel(context, updated.id, "HARVEST")
                        dao.deleteOperationReminder("HARVEST", updated.id)
                    }
                    onDone(updated)
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("إلغاء") } }
    )
}

@Composable
private fun HarvestDetailScreen(
    dao: MiyarDao,
    harvest: PersonalHarvestEntity,
    plots: List<PlantationEntity>,
    onAddDay: () -> Unit,
    onOpenDay: (PersonalHarvestDayEntity) -> Unit,
    onLongPressDay: (PersonalHarvestDayEntity) -> Unit
) {
    val days by dao.observeHarvestDays(harvest.id).collectAsStateWithLifecycle(emptyList())
    val lines by dao.observeAllHarvestDayLines().collectAsStateWithLifecycle(emptyList())
    val manualDistributorTransactions by dao.observeAllDistributorTransactions().collectAsStateWithLifecycle(emptyList())
    val manualDebtorTransactions by dao.observeAllDebtorTransactions().collectAsStateWithLifecycle(emptyList())
    val distributorProfiles by dao.observeDistributors().collectAsStateWithLifecycle(emptyList())
    val debtorProfiles by dao.observeDebtors().collectAsStateWithLifecycle(emptyList())
    val plotName = plots.firstOrNull { it.id == harvest.plantationId }?.name ?: "موضع غير معروف"
    val dayIds = days.map { it.id }.toSet()
    val harvestLines = lines.filter { it.dayId in dayIds }
    val linkedManualDistributor = manualDistributorTransactions.filter { it.harvestId == harvest.id && it.sourceDayId == 0L }
    val linkedManualDebtors = manualDebtorTransactions.filter { it.harvestId == harvest.id && it.sourceDayId == 0L }
    val distributorTotal = Math.addExact(FinanceCalculations.sumExact(harvestLines.filter { it.category == "distributor" }.map { it.total }), FinanceCalculations.sumExact(linkedManualDistributor.map { it.total }))
    val cashTotal = FinanceCalculations.sumExact(harvestLines.filter { it.category == "cash" }.map { it.total })
    val debtTotal = Math.addExact(FinanceCalculations.sumExact(harvestLines.filter { it.category == "debt" }.map { it.total }), FinanceCalculations.sumExact(linkedManualDebtors.map { it.total }))
    val allProductCounts = linkedMapOf<String, Long>()
    harvestLines.forEach { line -> allProductCounts[line.productType] = Math.addExact(allProductCounts[line.productType] ?: 0L, line.quantity) }
    linkedManualDistributor.forEach { line -> allProductCounts[line.productType] = Math.addExact(allProductCounts[line.productType] ?: 0L, line.quantity) }
    linkedManualDebtors.forEach { line -> allProductCounts[line.productType] = Math.addExact(allProductCounts[line.productType] ?: 0L, line.quantity) }
    val harvestProductCount = FinanceCalculations.sumExact(allProductCounts.values.toList())
    val harvestProductBreakdown = allProductCounts.entries.sortedBy { it.key }.joinToString(" • ") { (type, quantity) -> "$type: $quantity" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("${harvest.name} — $plotName", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
        Text("بداية القطفة: ${hDate(harvest.startMillis)} • المتوقع: ${hDate(harvest.expectedEndMillis)}")
        if (harvest.actualEndMillis > 0) Text("الانتهاء الفعلي: ${hDate(harvest.actualEndMillis)}")
        SummaryLine("إجمالي العدد", harvestProductCount, true)
        if (harvestProductBreakdown.isNotBlank()) Text(harvestProductBreakdown, style = MaterialTheme.typography.bodySmall, color = Green)
        SummaryLine("إجمالي الموزعين", distributorTotal)
        linkedManualDistributor.forEach { transaction ->
            val sellerName = distributorProfiles.firstOrNull { it.id == transaction.distributorId }?.name ?: "بائع"
            Text("عملية ملف البائع: $sellerName • ${transaction.productType} • ${money(transaction.total)}", style = MaterialTheme.typography.bodySmall)
        }
        if (cashTotal == Long.MAX_VALUE) Text("إجمالي المبيعات النقدية يتجاوز الحد الحسابي.", color = MaterialTheme.colorScheme.error) else SummaryLine("إجمالي المبيعات النقدية", cashTotal)
        if (debtTotal == Long.MAX_VALUE) Text("إجمالي المبيعات بالأجل يتجاوز الحد الحسابي.", color = MaterialTheme.colorScheme.error) else SummaryLine("إجمالي المبيعات بالأجل", debtTotal)
        linkedManualDebtors.forEach { transaction ->
            val debtorName = debtorProfiles.firstOrNull { it.id == transaction.debtorId }?.name ?: "عميل"
            Text("عملية ملف العميل: $debtorName • ${transaction.productType} • ${money(transaction.total)}", style = MaterialTheme.typography.bodySmall)
        }
        SummaryLine("إجمالي المبيعات", distributorTotal + cashTotal + debtTotal, strong = true)
        if (harvest.productsText.isNotBlank() || harvest.cashSalesText.isNotBlank() || harvest.debtorSalesText.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("بيانات محفوظة من إصدار سابق", fontWeight = FontWeight.Bold)
                    if (harvest.productsText.isNotBlank()) {
                        Text("تفاصيل الإنتاج القديم:", fontWeight = FontWeight.SemiBold)
                        harvest.productsText.split(';').filter { it.isNotBlank() }.forEach { Text("• ${it.replace("|", " • ")}", style = MaterialTheme.typography.bodySmall) }
                    }
                    if (harvest.cashSalesText.isNotBlank()) Text("المبيعات النقدية القديمة: ${harvest.cashSalesText}", style = MaterialTheme.typography.bodySmall)
                    if (harvest.debtorSalesText.isNotBlank()) Text("المبيعات الآجلة القديمة: ${harvest.debtorSalesText}", style = MaterialTheme.typography.bodySmall)
                    Text("تم إظهار النصوص القديمة كما حُفظت؛ لم تُحوّل تلقائيًا إلى مبيعات رقمية حتى لا تُحسب مبالغ غير مؤكدة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Button(onClick = onAddDay, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة يوم جديد") }
        Text("أيام القطفة", fontWeight = FontWeight.Bold)
        days.forEach { day ->
            val dailyLines = harvestLines.filter { it.dayId == day.id }
            Card(
                modifier = Modifier.fillMaxWidth().combinedClickable(
                    onClick = { onOpenDay(day) },
                    onLongClick = { onLongPressDay(day) }
                )
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("$plotName • ${harvest.name}", fontWeight = FontWeight.Bold)
                    Text("يوم القطفة • ${hDate(day.dateMillis)}")
                    val dailyQuantity = FinanceCalculations.sumExact(dailyLines.map { it.quantity })
                    val dailyBreakdown = dailyLines.groupBy { it.productType }.entries.sortedBy { it.key }.joinToString(" • ") { (type, items) -> "$type: ${FinanceCalculations.sumExact(items.map { it.quantity })}" }
                    Text("إجمالي المنتجات: $dailyQuantity${if (dailyBreakdown.isNotBlank()) " • $dailyBreakdown" else ""}", style = MaterialTheme.typography.bodySmall, color = Emerald)
                    Text("الموزع: ${money(FinanceCalculations.sumExact(dailyLines.filter { it.category == "distributor" }.map { it.total }))} • النقدي: ${money(FinanceCalculations.sumExact(dailyLines.filter { it.category == "cash" }.map { it.total }))}", style = MaterialTheme.typography.bodySmall)
                    val dayGross = runCatching { FinanceCalculations.sumExact(dailyLines.map { it.total }) }.getOrDefault(Long.MAX_VALUE)
                    val effectivePickerWages = day.pickerWagesManual ?: day.pickerWagesCalculated.takeIf { it > 0L } ?: FinanceCalculations.harvestPickerWages(day.pickerCount, day.pickerWage)
                    val dayCost = runCatching { Math.addExact(effectivePickerWages, day.otherExpenses) }.getOrDefault(Long.MAX_VALUE)
                    val dayFinancialIncomplete = dailyLines.any { !it.isValueComplete } || (day.pickerWagesManual == null && (day.pickerCountEntered xor day.pickerWageEntered)) || dayGross == Long.MAX_VALUE || dayCost == Long.MAX_VALUE
                    Text("الآجل: ${money(FinanceCalculations.sumExact(dailyLines.filter { it.category == "debt" }.map { it.total }))} • إجمالي اليوم: ${if (dayGross == Long.MAX_VALUE) "يتجاوز الحد" else money(dayGross)}", style = MaterialTheme.typography.bodySmall)
                    Text("تكاليف القطاف: ${if (dayCost == Long.MAX_VALUE) "تجاوز حسابي" else money(dayCost)} • الصافي: ${if (dayFinancialIncomplete) "غير نهائي" else money(dayGross - dayCost)}", style = MaterialTheme.typography.bodySmall, color = if (dayFinancialIncomplete) MaterialTheme.colorScheme.error else Green)
                }
            }
        }
        if (days.isEmpty()) Text("لم تسجل أيام لهذه القطفة بعد.")
    }
}

@Composable
internal fun SummaryLine(label: String, amount: Long, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal)
        Text(money(amount), fontWeight = if (strong) FontWeight.ExtraBold else FontWeight.SemiBold, color = if (strong) Green else MaterialTheme.colorScheme.onSurface)
    }
}

private data class HarvestRowState(val category: String, val party: String, val type: String, val quantity: String, val price: String, val lineId: Long = 0L, val accountTransactionId: Long = 0L, val manualTotal: String = "", val isTotalManual: Boolean = false)

@Composable
private fun DayEditor(
    dao: MiyarDao,
    harvest: PersonalHarvestEntity,
    plots: List<PlantationEntity>,
    editing: PersonalHarvestDayEntity?,
    distributorNames: List<String>,
    debtorNames: List<String>,
    historicalProductNames: List<String>,
    onSaved: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var date by remember(editing?.id) { mutableLongStateOf(editing?.dateMillis ?: System.currentTimeMillis()) }
    var pickerCount by remember(editing?.id) { mutableStateOf(editing?.takeIf { it.pickerCountEntered || it.pickerCount > 0L }?.pickerCount?.toString().orEmpty()) }
    var pickerWage by remember(editing?.id) { mutableStateOf(editing?.takeIf { it.pickerWageEntered || it.pickerWage > 0L }?.pickerWage?.toString().orEmpty()) }
    var pickerOtherCost by remember(editing?.id) { mutableStateOf(editing?.takeIf { it.otherExpensesEntered || it.otherExpenses > 0L }?.otherExpenses?.toString().orEmpty()) }
    var pickerWagesManualText by remember(editing?.id) { mutableStateOf(editing?.pickerWagesManual?.let { moneyInput(it.toString()) }.orEmpty()) }
    var pickerWagesIsManual by remember(editing?.id) { mutableStateOf(editing?.pickerWagesManual != null) }
    var notes by remember(editing?.id) { mutableStateOf(editing?.notes ?: "") }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var rows by remember(editing?.id) { mutableStateOf(listOf(HarvestRowState("distributor", "", MIYAR_PRODUCT_TYPES.first(), "", ""))) }
    var editingLinesReady by remember(editing?.id) { mutableStateOf(editing == null) }
    LaunchedEffect(editing?.id) {
        if (editing != null) {
            editingLinesReady = false
            val loadedLines = dao.getHarvestDayLines(editing.id)
            rows = if (loadedLines.isEmpty()) listOf(HarvestRowState("distributor", "", MIYAR_PRODUCT_TYPES.first(), "", "")) else loadedLines.map {
                HarvestRowState(it.category, it.partyName, it.productType, it.quantity.toString(), it.unitPrice.takeIf { price -> it.isValueComplete || price > 0L }?.toString().orEmpty(), it.id, it.accountTransactionId, if (it.isTotalManual) moneyInput(it.total.toString()) else "", it.isTotalManual)
            }
            editingLinesReady = true
        }
    }
    fun calculatedRowTotal(row: HarvestRowState): Long = safeProduct(row.quantity.toLongOrNull() ?: 0L, moneyToLong(row.price))
    fun effectiveRowTotal(row: HarvestRowState): Long = if (row.isTotalManual) moneyToLong(row.manualTotal) else calculatedRowTotal(row)
    val distributorTotal = safeSum(rows.filter { it.category == "distributor" }.map(::effectiveRowTotal))
    val cashTotal = safeSum(rows.filter { it.category == "cash" }.map(::effectiveRowTotal))
    val debtTotal = safeSum(rows.filter { it.category == "debt" }.map(::effectiveRowTotal))
    val gross = safeSum(listOf(distributorTotal, cashTotal, debtTotal))
    val pickerCountValue = pickerCount.toLongOrNull() ?: 0L
    val pickerWageValue = moneyToLong(pickerWage)
    val pickerOtherValue = moneyToLong(pickerOtherCost)
    val pickerWagesCalculated = runCatching { FinanceCalculations.harvestPickerWages(pickerCountValue, pickerWageValue) }.getOrDefault(Long.MAX_VALUE)
    val pickerWages = if (pickerWagesIsManual) moneyToLong(pickerWagesManualText) else pickerWagesCalculated
    val harvestCost = runCatching { Math.addExact(pickerWages, pickerOtherValue) }.getOrDefault(Long.MAX_VALUE)
    val hasIncompleteSaleValues = rows.any { (it.party.isNotBlank() || it.quantity.isNotBlank() || it.price.isNotBlank() || it.manualTotal.isNotBlank()) && !it.isTotalManual && it.price.isBlank() }
    val hasIncompletePickerCosts = !pickerWagesIsManual && (pickerCount.isBlank() xor pickerWage.isBlank())
    val netHarvest = if (gross == Long.MAX_VALUE || distributorTotal == Long.MAX_VALUE || cashTotal == Long.MAX_VALUE || debtTotal == Long.MAX_VALUE || harvestCost == Long.MAX_VALUE || hasIncompleteSaleValues || hasIncompletePickerCosts) Long.MIN_VALUE else runCatching { FinanceCalculations.harvestNetRevenue(gross, harvestCost) }.getOrDefault(Long.MIN_VALUE)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (editing == null) "إضافة يوم جديد" else "تعديل يوم القطفة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
        Text("اسم الموضع: ${plots.firstOrNull { it.id == harvest.plantationId }?.name ?: ""}")
        Text("اسم / رقم القطفة: ${harvest.name}", fontWeight = FontWeight.Bold)
        DateField("تاريخ يوم القطفة", date) { date = it }

        Text("الموزع للسوق", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        rows.mapIndexedNotNull { index, row -> if (row.category == "distributor") index to row else null }.forEach { (index, row) ->
            HarvestDayLineEditor(row, distributorNames, MIYAR_PRODUCT_TYPES, onChange = { changed -> rows = rows.toMutableList().also { it[index] = changed } }, onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } })
        }
        OutlinedButton(onClick = { rows = rows + HarvestRowState("distributor", "", MIYAR_PRODUCT_TYPES.first(), "", "") }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة بائع آخر") }
        if (distributorTotal == Long.MAX_VALUE) Text("إجمالي الموزع يتجاوز الحد الحسابي.", color = MaterialTheme.colorScheme.error) else SummaryLine("إجمالي الموزع", distributorTotal)

        HorizontalDivider()
        Text("المبيعات النقدية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        rows.mapIndexedNotNull { index, row -> if (row.category == "cash") index to row else null }.forEach { (index, row) ->
            HarvestDayLineEditor(row, emptyList(), MIYAR_PRODUCT_TYPES, onChange = { changed -> rows = rows.toMutableList().also { it[index] = changed } }, onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } })
        }
        OutlinedButton(onClick = { rows = rows + HarvestRowState("cash", "", MIYAR_PRODUCT_TYPES.first(), "", "") }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة صنف نقدي") }
        if (cashTotal == Long.MAX_VALUE) Text("إجمالي المبيعات النقدية يتجاوز الحد الحسابي.", color = MaterialTheme.colorScheme.error) else SummaryLine("إجمالي المبيعات النقدية", cashTotal)

        HorizontalDivider()
        Text("المبيعات بالأجل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        rows.mapIndexedNotNull { index, row -> if (row.category == "debt") index to row else null }.forEach { (index, row) ->
            HarvestDayLineEditor(row, debtorNames, MIYAR_PRODUCT_TYPES, onChange = { changed -> rows = rows.toMutableList().also { it[index] = changed } }, onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } })
        }
        OutlinedButton(onClick = { rows = rows + HarvestRowState("debt", "", MIYAR_PRODUCT_TYPES.first(), "", "") }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة عميل آخر") }
        if (debtTotal == Long.MAX_VALUE) Text("إجمالي المبيعات بالأجل يتجاوز الحد الحسابي.", color = MaterialTheme.colorScheme.error) else SummaryLine("إجمالي المبيعات بالأجل", debtTotal)

        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFEAF3E9)), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("تكاليف القطافين", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                NumField("عدد القطافين", pickerCount, { pickerCount = it })
                MoneyField("أجر القطاف الواحد (اختياري)", pickerWage, { pickerWage = it })
                MoneyField(
                    "إجمالي أجور القطافين (يمكن تعديله يدويًا)",
                    if (pickerWagesIsManual) pickerWagesManualText else if (pickerWagesCalculated == Long.MAX_VALUE || (pickerCount.isBlank() && pickerWage.isBlank())) "" else moneyInput(pickerWagesCalculated.toString()),
                    { value ->
                        pickerWagesManualText = value
                        pickerWagesIsManual = value.isNotBlank()
                    }
                )
                if (pickerWagesIsManual) Text("القيمة اليدوية معتمدة ولن يستبدلها التطبيق بالحساب التلقائي.", style = MaterialTheme.typography.labelSmall, color = Emerald)
                MoneyField("خرج آخر للقطافين (أكياس، توصيل وغيرها)", pickerOtherCost, { pickerOtherCost = it })
                val hasPickerCostInput = pickerWagesIsManual || pickerCount.isNotBlank() || pickerWage.isNotBlank() || pickerOtherCost.isNotBlank()
                if (hasPickerCostInput && harvestCost != Long.MAX_VALUE) SummaryLine("إجمالي تكاليف القطافين", harvestCost, true)
            }
        }
        if (gross == Long.MAX_VALUE) Text("إجمالي المبيعات في هذا اليوم يتجاوز الحد الحسابي؛ راجع الأسعار والكميات.", color = MaterialTheme.colorScheme.error)
        else SummaryLine("إجمالي المبيعات في هذا اليوم", gross, strong = true)
        if (netHarvest == Long.MIN_VALUE) {
            Text("صافي المردود غير نهائي: توجد قيمة بيع أو تكلفة قطاف لم تُستكمل أو تجاوز حسابي يحتاج إلى مراجعة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        } else SummaryLine("صافي مردود يوم القطاف", netHarvest, strong = true)

        val productSummary = rows.filter { it.quantity.toLongOrNull()?.let { q -> q > 0L } == true }
            .groupBy { it.type }
            .toSortedMap()
        if (productSummary.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFF2F6F2))) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("ملخص المنتجات", fontWeight = FontWeight.Bold, color = Emerald)
                    productSummary.forEach { (type, items) ->
                        val distributorQty = safeSum(items.filter { it.category == "distributor" }.map { it.quantity.toLongOrNull() ?: 0L })
                        val cashQty = safeSum(items.filter { it.category == "cash" }.map { it.quantity.toLongOrNull() ?: 0L })
                        val debtQty = safeSum(items.filter { it.category == "debt" }.map { it.quantity.toLongOrNull() ?: 0L })
                        val allQty = safeSum(listOf(distributorQty, cashQty, debtQty))
                        val value = safeSum(items.map(::effectiveRowTotal))
                        Text("$type • الموزع: $distributorQty • النقدي: $cashQty • الآجل: $debtQty • الإجمالي: $allQty", style = MaterialTheme.typography.bodySmall, color = Green)
                        Text("قيمة هذا النوع: ${money(value)}", style = MaterialTheme.typography.labelSmall, color = Emerald)
                    }
                    val allQty = safeSum(productSummary.values.flatten().map { it.quantity.toLongOrNull() ?: 0L })
                    Text("إجمالي العدد المدخل: $allQty", fontWeight = FontWeight.Bold, color = Emerald)
                    Text("الملخص محسوب من أسطر المنتجات ولا يتغير عند تعديل إجمالي المبيعات يدويًا.", style = MaterialTheme.typography.labelSmall, color = Green)
                }
            }
        }
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات أخرى") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)

        Button(
            enabled = !saving && date > 0 && editingLinesReady,
            onClick = {
                val touchedRows = rows.filter { it.party.isNotBlank() || it.quantity.isNotBlank() || it.price.isNotBlank() || it.manualTotal.isNotBlank() }
                val validRows = touchedRows.filter {
                    it.quantity.toLongOrNull()?.let { q -> q > 0 } == true &&
                        it.type in MIYAR_PRODUCT_TYPES &&
                        isValidMoneyInput(it.price) && isValidMoneyInput(it.manualTotal) &&
                        (it.category == "cash" || it.party.isNotBlank())
                }
                if (validRows.size != touchedRows.size) {
                    error = "راجع الأصناف: يلزم إدخال اسم البائع أو العميل عند الحاجة، ونوع المنتج والعدد والسعر بصورة صحيحة."
                } else if (validRows.any { calculatedRowTotal(it) == Long.MAX_VALUE } || gross == Long.MAX_VALUE ||
                    !isValidMoneyInput(pickerWage) || !isValidMoneyInput(pickerOtherCost) || !isValidMoneyInput(pickerWagesManualText) ||
                    pickerCountValue < 0L || pickerWageValue < 0L || pickerOtherValue < 0L || pickerWages == Long.MAX_VALUE || harvestCost == Long.MAX_VALUE) {
                    error = "تحقق من عدد القطافين وأجورهم ومصاريف القطاف؛ القيم يجب أن تكون صحيحة وغير سالبة وضمن الحد المسموح."
                } else {
                    saving = true
                    error = ""
                    scope.launch {
                        try {
                            val oldLines = if (editing == null) emptyList() else dao.getHarvestDayLines(editing.id)
                            // Do not silently discard a payment history when a row is removed or its category changes.
                            oldLines.filter { old ->
                                val matching = validRows.firstOrNull { it.lineId == old.id }
                                val identityChanged = matching != null && old.category == matching.category &&
                                    old.partyName.trim() != matching.party.trim()
                                matching == null || matching.category != old.category || identityChanged
                            }.forEach { old ->
                                val partyType = when (old.category) { "distributor" -> "DISTRIBUTOR"; "debt" -> "DEBTOR"; else -> "" }
                                if (partyType.isNotBlank() && old.accountTransactionId > 0) {
                                    check(dao.getAccountCollectedTotal(partyType, old.accountTransactionId) == 0L) {
                                        "لا يمكن حذف السطر أو تغيير نوعه أو اسم صاحبه بعد تسجيل دفعة مالية مرتبطة به. عالج الحساب أولًا حتى لا تنتقل الدفعة إلى ملف شخص آخر."
                                    }
                                }
                            }
                            val dayId = if (editing == null) {
                                dao.insertPersonalHarvestDay(PersonalHarvestDayEntity(
                                    harvestId = harvest.id, dateMillis = date,
                                    pickerCount = pickerCountValue,
                                    pickerWage = pickerWageValue,
                                    otherExpenses = pickerOtherValue,
                                    notes = notes.trim(),
                                    pickerWagesCalculated = if (pickerWagesCalculated == Long.MAX_VALUE) 0L else pickerWagesCalculated,
                                    pickerWagesManual = if (pickerWagesIsManual) moneyToLong(pickerWagesManualText) else null,
                                    pickerCountEntered = pickerCount.isNotBlank(),
                                    pickerWageEntered = pickerWage.isNotBlank(),
                                    otherExpensesEntered = pickerOtherCost.isNotBlank()
                                ))
                            } else {
                                dao.updatePersonalHarvestDay(editing.copy(
                                    dateMillis = date,
                                    pickerCount = pickerCountValue,
                                    pickerWage = pickerWageValue,
                                    otherExpenses = pickerOtherValue,
                                    notes = notes.trim(),
                                    pickerWagesCalculated = if (pickerWagesCalculated == Long.MAX_VALUE) 0L else pickerWagesCalculated,
                                    pickerWagesManual = if (pickerWagesIsManual) moneyToLong(pickerWagesManualText) else null,
                                    pickerCountEntered = pickerCount.isNotBlank(),
                                    pickerWageEntered = pickerWage.isNotBlank(),
                                    otherExpensesEntered = pickerOtherCost.isNotBlank()
                                ))
                                editing.id
                            }
                            val retainedIds = validRows.mapNotNull { it.lineId.takeIf { id -> id > 0 } }.toSet()
                            oldLines.filter { it.id !in retainedIds }.forEach { oldLine ->
                                if (oldLine.accountTransactionId > 0) {
                                    when (oldLine.category) {
                                        "distributor" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DISTRIBUTOR", oldLine.accountTransactionId)
                                            dao.deleteDistributorTransaction(oldLine.accountTransactionId)
                                        }
                                        "debt" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DEBTOR", oldLine.accountTransactionId)
                                            dao.deleteDebtorTransaction(oldLine.accountTransactionId)
                                        }
                                    }
                                }
                                dao.deleteHarvestDayLine(oldLine.id)
                            }
                            validRows.forEach { row ->
                                val party = row.party.trim()
                                val quantity = row.quantity.toLong()
                                val unitPrice = moneyToLong(row.price)
                                val calculatedTotal = safeProduct(quantity, unitPrice)
                                val isTotalManual = row.isTotalManual
                                val total = if (isTotalManual) moneyToLong(row.manualTotal) else calculatedTotal
                                val isValueComplete = isTotalManual || row.price.isNotBlank()
                                var line = if (row.lineId > 0) {
                                    val prior = oldLines.firstOrNull { it.id == row.lineId }
                                    (prior ?: PersonalHarvestDayLineEntity(dayId = dayId, category = row.category, productType = row.type, quantity = quantity, unitPrice = unitPrice, total = total)).copy(
                                        category = row.category, partyName = party, productType = row.type.trim(),
                                        quantity = quantity, unitPrice = unitPrice, total = total,
                                        calculatedTotal = calculatedTotal, isTotalManual = isTotalManual, isValueComplete = isValueComplete
                                    )
                                } else PersonalHarvestDayLineEntity(
                                    dayId = dayId, category = row.category, partyName = party,
                                    productType = row.type.trim(), quantity = quantity,
                                    unitPrice = unitPrice, total = total, calculatedTotal = calculatedTotal,
                                    isTotalManual = isTotalManual, isValueComplete = isValueComplete
                                )
                                val lineId = if (line.id > 0) {
                                    dao.updateHarvestDayLine(line)
                                    line.id
                                } else dao.insertPersonalHarvestDayLine(line)
                                val priorLine = if (row.lineId > 0) oldLines.firstOrNull { it.id == row.lineId } else null
                                var transactionId = row.accountTransactionId
                                // Changing a row from distributor to cash/debt (or the reverse) must
                                // remove its old ledger entry and linked payments before creating a new one.
                                if (priorLine != null && priorLine.category != row.category && transactionId > 0) {
                                    when (priorLine.category) {
                                        "distributor" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DISTRIBUTOR", transactionId)
                                            dao.deleteDistributorTransaction(transactionId)
                                        }
                                        "debt" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DEBTOR", transactionId)
                                            dao.deleteDebtorTransaction(transactionId)
                                        }
                                    }
                                    transactionId = 0L
                                }
                                if (row.category == "distributor") {
                                    val seller = dao.findDistributor(party) ?: MarketDistributorEntity(name = party).let { dao.insertDistributor(it); dao.findDistributor(party) }
                                    if (seller != null) {
                                        val existing = transactionId.takeIf { it > 0 }?.let { dao.getDistributorTransaction(it) }
                                        if (existing != null) {
                                            val discounts = dao.getDistributorDiscountTotal(existing.id)
                                            val distributionCosts = dao.getDistributionExpenseTotal(existing.id)
                                            val netAfterAdjustments = FinanceCalculations.sellerNetSale(total, discounts, distributionCosts)
                                            check(dao.getAccountCollectedTotal("DISTRIBUTOR", existing.id) <= netAfterAdjustments) {
                                                "قيمة العملية الجديدة أقل من صافي المبلغ بعد الخصومات ومصاريف التوزيع والتحصيل السابق. عالج التسويات المرتبطة أولًا."
                                            }
                                            dao.updateDistributorTransaction(existing.copy(
                                                distributorId = seller.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId,
                                                calculatedTotal = calculatedTotal, isTotalManual = isTotalManual, isValueComplete = isValueComplete
                                            ))
                                            dao.moveHarvestPartyPayments(existing.id, "DISTRIBUTOR", seller.id)
                                        } else {
                                            transactionId = dao.insertDistributorTransaction(DistributorTransactionEntity(
                                                distributorId = seller.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId,
                                                calculatedTotal = calculatedTotal, isTotalManual = isTotalManual, isValueComplete = isValueComplete
                                            ))
                                        }
                                    }
                                } else if (row.category == "debt") {
                                    val debtor = dao.findDebtor(party) ?: HarvestDebtorEntity(name = party).let { dao.insertDebtor(it); dao.findDebtor(party) }
                                    if (debtor != null) {
                                        val existing = transactionId.takeIf { it > 0 }?.let { dao.getDebtorTransaction(it) }
                                        if (existing != null) {
                                            check(dao.getAccountCollectedTotal("DEBTOR", existing.id) <= total) { "قيمة العملية الجديدة أقل من المبلغ المسدد سابقًا من هذا العميل." }
                                            dao.updateDebtorTransaction(existing.copy(
                                                debtorId = debtor.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId,
                                                calculatedTotal = calculatedTotal, isTotalManual = isTotalManual, isValueComplete = isValueComplete
                                            ))
                                            dao.moveHarvestPartyPayments(existing.id, "DEBTOR", debtor.id)
                                        } else {
                                            transactionId = dao.insertDebtorTransaction(HarvestDebtorTransactionEntity(
                                                debtorId = debtor.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId,
                                                calculatedTotal = calculatedTotal, isTotalManual = isTotalManual, isValueComplete = isValueComplete
                                            ))
                                        }
                                    }
                                }
                                dao.updateHarvestDayLine(line.copy(id = lineId, accountTransactionId = transactionId))
                            }
                            val beforeSnapshot = editing?.let { "dateMillis=${it.dateMillis};pickerCount=${it.pickerCount};pickerWage=${it.pickerWage};otherExpenses=${it.otherExpenses};notes=${it.notes}" }.orEmpty()
                            val savedDay = dao.getPersonalHarvestDayById(dayId)
                            val afterSnapshot = savedDay?.let { "dateMillis=${it.dateMillis};pickerCount=${it.pickerCount};pickerWage=${it.pickerWage};otherExpenses=${it.otherExpenses};notes=${it.notes}" }.orEmpty()
                            dao.insertAuditEvent(MiyarAuditEventEntity(
                                entityType = "PERSONAL_HARVEST_DAY", entityId = dayId,
                                eventType = if (editing == null) "CREATE" else "UPDATE",
                                beforeSnapshot = beforeSnapshot, afterSnapshot = afterSnapshot,
                                referenceId = harvest.id
                            ))
                            saving = false
                            onSaved()
                        } catch (t: Throwable) {
                            saving = false
                            error = t.message ?: "تعذر حفظ يوم القطفة."
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (saving) "جارٍ الحفظ..." else "حفظ اليوم") }
    }
}

@Composable
private fun HarvestDayLineEditor(
    row: HarvestRowState,
    partySuggestions: List<String>,
    productSuggestions: List<String>,
    onChange: (HarvestRowState) -> Unit,
    onRemove: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(when (row.category) { "distributor" -> "بيانات البائع"; "cash" -> "صنف نقدي"; else -> "بيانات العميل" }, fontWeight = FontWeight.Bold)
            if (row.category != "cash") {
                SuggestedTextField(if (row.category == "debt") "اسم العميل" else "اسم البائع", row.party, { onChange(row.copy(party = it)) }, partySuggestions)
            }
            ProductTypeField(row.type, { onChange(row.copy(type = it)) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("عدد المنتج", row.quantity, { onChange(row.copy(quantity = it)) }, Modifier.weight(1f))
                MoneyField("سعر الوحدة (اختياري)", row.price, { onChange(row.copy(price = it)) }, Modifier.weight(1f))
            }
            val calculated = safeProduct(row.quantity.toLongOrNull() ?: 0L, moneyToLong(row.price))
            MoneyField(
                "إجمالي قيمة المنتج (قابل للتعديل)",
                if (row.isTotalManual) row.manualTotal else if (calculated == Long.MAX_VALUE) "" else moneyInput(calculated.toString()),
                { value -> onChange(row.copy(manualTotal = value, isTotalManual = value.isNotBlank())) }
            )
            if (row.isTotalManual) Text("قيمة يدوية معتمدة • المحسوب الأصلي: ${if (calculated == Long.MAX_VALUE) "خارج الحد" else money(calculated)}", style = MaterialTheme.typography.labelSmall, color = Emerald)
            else if (row.price.isBlank()) Text("القيمة غير مكتملة؛ يمكن حفظ العملية واستكمالها لاحقًا.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            TextButton(onClick = onRemove, modifier = Modifier.align(Alignment.End)) { Text("إزالة الصنف") }
        }
    }
}

@Composable
private fun DayDetails(dao: MiyarDao, harvest: PersonalHarvestEntity, day: PersonalHarvestDayEntity, plots: List<PlantationEntity>) {
    val lines by dao.observeHarvestDayLines(day.id).collectAsStateWithLifecycle(emptyList())
    val plotName = plots.firstOrNull { it.id == harvest.plantationId }?.name ?: ""
    val distributor = lines.filter { it.category == "distributor" }
    val cash = lines.filter { it.category == "cash" }
    val debt = lines.filter { it.category == "debt" }
    val gross = FinanceCalculations.sumExact(lines.map { it.total })
    val dayQuantityTotal = FinanceCalculations.sumExact(lines.map { it.quantity })
    val dayQuantityBreakdown = lines.groupBy { it.productType }.entries.sortedBy { it.key }.joinToString(" • ") { (type, items) -> "$type: ${FinanceCalculations.sumExact(items.map { it.quantity })}" }
    val hasIncompleteLines = lines.any { !it.isValueComplete }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("تفاصيل يوم القطفة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
        Text("اسم الموضع: $plotName")
        SummaryLine("إجمالي عدد المنتجات في اليوم", dayQuantityTotal, true)
        if (dayQuantityBreakdown.isNotBlank()) Text(dayQuantityBreakdown, style = MaterialTheme.typography.bodySmall, color = Green)
        Text("اسم / رقم القطفة: ${harvest.name}", fontWeight = FontWeight.Bold)
        Text("التاريخ: ${hDate(day.dateMillis)}")
        DayLinesSection("الموزع للسوق", distributor)
        SummaryLine("إجمالي الموزع والقيمة", FinanceCalculations.sumExact(distributor.map { it.total }), true)
        DayLinesSection("المبيعات النقدية", cash)
        SummaryLine("إجمالي المباع نقدًا والقيمة", FinanceCalculations.sumExact(cash.map { it.total }), true)
        DayLinesSection("المبيعات بالأجل", debt)
        SummaryLine("إجمالي الآجل والقيمة", FinanceCalculations.sumExact(debt.map { it.total }), true)
        HorizontalDivider()
        SummaryLine("إجمالي المبيعات في هذا اليوم", gross, true)
        if (hasIncompleteLines) Text("تنبيه: توجد أصناف لم تُستكمل قيمتها المالية؛ الإجمالي المعروض لا يشمل قيمة غير محددة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        val pickerWages = day.pickerWagesManual ?: day.pickerWagesCalculated.takeIf { it > 0L } ?: FinanceCalculations.harvestPickerWages(day.pickerCount, day.pickerWage)
        val harvestCostResult = runCatching { Math.addExact(pickerWages, day.otherExpenses) }
        val harvestCost = harvestCostResult.getOrDefault(Long.MAX_VALUE)
        val hasIncompletePickerCosts = day.pickerWagesManual == null && (day.pickerCountEntered xor day.pickerWageEntered)
        HorizontalDivider()
        Text("تكاليف القطاف", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("عدد القطافين")
            Text(if (day.pickerCountEntered || day.pickerCount > 0L) day.pickerCount.toString() else "غير مدخل")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("أجر القطاف الواحد")
            Text(if (day.pickerWageEntered || day.pickerWage > 0L) money(day.pickerWage) else "غير مدخل")
        }
        if (day.pickerWagesManual != null || day.pickerWagesCalculated > 0L || (day.pickerCountEntered && day.pickerWageEntered)) {
            SummaryLine("إجمالي أجور القطافين${if (day.pickerWagesManual != null) " (يدوي)" else ""}", pickerWages)
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("إجمالي أجور القطافين"); Text("غير محدد") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("خرج آخر للقطاف")
            Text(if (day.otherExpensesEntered || day.otherExpenses > 0L) money(day.otherExpenses) else "غير مدخل")
        }
        if (harvestCost != Long.MAX_VALUE) SummaryLine("إجمالي تكاليف القطاف", harvestCost, true)
        else Text("إجمالي تكاليف القطاف يتجاوز الحد الحسابي.", color = MaterialTheme.colorScheme.error)
        if (hasIncompleteLines || hasIncompletePickerCosts || harvestCost == Long.MAX_VALUE) {
            Text("صافي المردود غير نهائي لأن بعض القيم المالية لم تُستكمل أو تحتاج إلى مراجعة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        } else SummaryLine("صافي مردود يوم القطاف", FinanceCalculations.harvestNetRevenue(gross, harvestCost), true)
        Text("الملاحظات: ${day.notes.ifBlank { "لا توجد ملاحظات" }}")
    }
}

@Composable
private fun DayLinesSection(title: String, lines: List<PersonalHarvestDayLineEntity>) {
    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    if (lines.isEmpty()) Text("لا توجد عمليات مسجلة.", style = MaterialTheme.typography.bodySmall)
    lines.forEach { line ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (line.partyName.isNotBlank()) Text(line.partyName, fontWeight = FontWeight.Bold)
                Text("${line.productType} • العدد ${line.quantity} × ${line.unitPrice} ريال")
                Text("الإجمالي: ${money(line.total)}${if (line.isTotalManual) " • يدوي" else ""}", color = Green, fontWeight = FontWeight.Bold)
                if (!line.isValueComplete) Text("القيمة المالية غير مكتملة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun BuyerSaleForm(
    dao: MiyarDao,
    plantations: List<PlantationEntity>,
    buyers: List<QatBuyerEntity>,
    buyerSuggestions: List<String>,
    initialBuyer: QatBuyerEntity?,
    onSaved: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var buyerName by remember { mutableStateOf(initialBuyer?.name ?: "") }
    var harvestName by remember { mutableStateOf("") }
    var plotId by remember { mutableLongStateOf(0L) }
    var agreed by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var saleDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var expected by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var actual by remember { mutableLongStateOf(0L) }
    var showActual by remember { mutableStateOf(false) }
    var discount by remember { mutableStateOf("0") }
    var discountReason by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var plotMenu by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val selectedPlot = plantations.firstOrNull { it.id == plotId }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("البيع لمشتري", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Box {
            OutlinedButton(onClick = { plotMenu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedPlot?.name ?: "اختر الموضع الزراعي")
            }
            DropdownMenu(expanded = plotMenu, onDismissRequest = { plotMenu = false }) {
                plantations.forEach { plot -> DropdownMenuItem(text = { Text(plot.name) }, onClick = { plotId = plot.id; plotMenu = false }) }
            }
        }
        SuggestedTextField("اسم المشتري", buyerName, { buyerName = it }, (buyerSuggestions + buyers.map { it.name }).distinct())
        OutlinedTextField(harvestName, { harvestName = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth())
        MoneyField("السعر المتفق عليه", agreed, { agreed = it })
        MoneyField("الواصل عند البيع", paid, { paid = it })
        DateField("تاريخ البيع", saleDate) { saleDate = it }
        DateField("التاريخ المتوقع للانتهاء", expected) { expected = it }
        TextButton(onClick = { showActual = !showActual; if (!showActual) actual = 0L }) { Text(if (showActual) "إخفاء تاريخ الانتهاء الفعلي" else "إدخال تاريخ الانتهاء الفعلي") }
        if (showActual) DateField("التاريخ الفعلي لانتهاء القطفة", actual.takeIf { it > 0 } ?: System.currentTimeMillis()) { actual = it }
        HorizontalDivider()
        Text("الخصم من السعر المتفق عليه", fontWeight = FontWeight.Bold)
        MoneyField("قيمة الخصم إن وجد", discount, { discount = it })
        OutlinedTextField(discountReason, { discountReason = it }, label = { Text("سبب الخصم") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        SummaryLine("صافي المبلغ بعد الخصم", ((moneyToLong(agreed)) - (moneyToLong(discount))).coerceAtLeast(0), true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(
            enabled = !saving,
            onClick = {
                val agreement = moneyToLong(agreed)
                val firstPaid = moneyToLong(paid)
                val discountValue = moneyToLong(discount)
                when {
                    selectedPlot == null -> error = "اختر الموضع الزراعي أولًا."
                    buyerName.isBlank() || harvestName.isBlank() -> error = "أدخل اسم المشتري واسم القطفة."
                    agreement <= 0 || discountValue > agreement || firstPaid > agreement - discountValue -> error = "راجع السعر والخصم والواصل؛ القيم غير متوافقة."
                    expected < saleDate -> error = "تاريخ الانتهاء المتوقع لا يمكن أن يسبق تاريخ البيع."
                    showActual && actual < saleDate -> error = "تاريخ الانتهاء الفعلي لا يمكن أن يسبق تاريخ البيع."
                    discountValue > 0 && discountReason.isBlank() -> error = "اكتب سبب الخصم حتى يظهر التقييم بصورة صحيحة."
                    else -> {
                        error = ""
                        saving = true
                        scope.launch {
                            try {
                                val buyer = dao.findBuyer(buyerName.trim()) ?: QatBuyerEntity(name = buyerName.trim()).let { dao.insertBuyer(it); dao.findBuyer(buyerName.trim()) }
                                if (buyer == null) error = "تعذر إنشاء ملف المشتري."
                                else dao.insertBuyerSale(BuyerSaleEntity(
                                    buyerId = buyer.id, plantationId = selectedPlot.id,
                                    harvestName = harvestName.trim(), agreedAmount = agreement,
                                    initialPaid = firstPaid, saleDateMillis = saleDate,
                                    expectedEndMillis = expected, actualEndMillis = if (showActual) actual else 0L,
                                    discountAmount = discountValue, discountReason = discountReason.trim(), notes = notes.trim()
                                ))
                                if (error.isBlank()) onSaved()
                            } catch (t: Throwable) {
                                error = t.message ?: "تعذر حفظ عملية البيع."
                            } finally { saving = false }
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (saving) "جارٍ الحفظ..." else "حفظ عملية البيع") }
    }
}

@Composable
private fun BuyerFileScreen(
    dao: MiyarDao,
    buyer: QatBuyerEntity,
    plantations: List<PlantationEntity>,
    onNewSale: () -> Unit,
    onOpenSale: (BuyerSaleEntity) -> Unit
) {
    val sales by dao.observeBuyerSales(buyer.id).collectAsStateWithLifecycle(emptyList())
    val allPayments by dao.observeAllBuyerPayments().collectAsStateWithLifecycle(emptyList())
    val saleIds = remember(sales) { sales.map { it.id }.toSet() }
    val total = FinanceCalculations.sumExact(sales.map { (it.agreedAmount - it.discountAmount).coerceAtLeast(0) })
    val collected = Math.addExact(FinanceCalculations.sumExact(sales.map { it.initialPaid }), FinanceCalculations.sumExact(allPayments.filter { it.saleId in saleIds }.map { it.amount }))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف المشتري: ${buyer.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryLine("إجمالي المستحق بعد الخصومات", total, true)
        SummaryLine("إجمالي الواصل", collected)
        SummaryLine("إجمالي المتبقي", (total - collected).coerceAtLeast(0), true)
        Button(onClick = onNewSale, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة قطفة جديدة لهذا المشتري") }
        Text("سجل القطفات", fontWeight = FontWeight.Bold)
        sales.forEach { sale ->
            val plot = plantations.firstOrNull { it.id == sale.plantationId }?.name ?: "موضع غير محدد"
            Card(onClick = { onOpenSale(sale) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(sale.harvestName, fontWeight = FontWeight.Bold)
                    Text(plot)
                    Text("الاتفاق: ${money(sale.agreedAmount)} • الخصم: ${money(sale.discountAmount)}")
                    Text("من ${hDate(sale.saleDateMillis)} إلى ${if (sale.actualEndMillis > 0) hDate(sale.actualEndMillis) else "لم تنتهِ بعد"}")
                    Text("اضغط لعرض كشف الحساب والدفعات", style = MaterialTheme.typography.bodySmall, color = Green)
                }
            }
        }
    }
}

// Collect a Flow's first value without blocking the UI thread; this helper is used only inside a launched coroutine.

@Composable
private fun BuyerSaleDetailScreen(dao: MiyarDao, sale: BuyerSaleEntity, buyer: QatBuyerEntity, plantations: List<PlantationEntity>) {
    val allSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(emptyList())
    val details = allSales.firstOrNull { it.id == sale.id } ?: sale
    val payments by dao.observeBuyerPayments(details.id).collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    var paymentDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showEdit by remember { mutableStateOf(false) }
    val paid = Math.addExact(details.initialPaid, FinanceCalculations.sumExact(payments.map { it.amount }))
    val netAgreed = (details.agreedAmount - details.discountAmount).coerceAtLeast(0)
    val remaining = (netAgreed - paid).coerceAtLeast(0)
    val expectedDuration = TimeUnit.MILLISECONDS.toDays((details.expectedEndMillis - details.saleDateMillis).coerceAtLeast(0)).toInt()
    val actualDuration = if (details.actualEndMillis > 0) TimeUnit.MILLISECONDS.toDays((details.actualEndMillis - details.saleDateMillis).coerceAtLeast(0)).toInt() else null
    val expectedDeadline = details.expectedEndMillis + TimeUnit.DAYS.toMillis(1) - 1L
    val actualLate = (details.actualEndMillis > 0 && details.actualEndMillis > expectedDeadline) ||
        (details.actualEndMillis == 0L && System.currentTimeMillis() > expectedDeadline)
    val redReason = when {
        details.discountAmount > 0 && actualLate -> "تأخير في مدة القطف + خصم"
        details.discountAmount > 0 -> "خصم: ${details.discountReason.ifBlank { "لم يحدد السبب" }}"
        actualLate -> "تأخير في مدة القطف"
        else -> ""
    }
    val status = when {
        details.discountAmount > 0 || actualLate -> "أحمر — $redReason"
        details.actualEndMillis == 0L || remaining > 0 -> "أصفر — القطفة جارية أو توجد مستحقات"
        else -> "أخضر — اكتمل السداد دون خصم أو تأخير"
    }
    val statusColor = when {
        details.discountAmount > 0 || actualLate -> androidx.compose.ui.graphics.Color(0xFFB3261E)
        details.actualEndMillis == 0L || remaining > 0 -> androidx.compose.ui.graphics.Color(0xFFB7791F)
        else -> androidx.compose.ui.graphics.Color(0xFF237A49)
    }
    val plot = plantations.firstOrNull { it.id == details.plantationId }?.name ?: "موضع غير محدد"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف ${buyer.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("الموضع: $plot")
        Text("القطفة: ${details.harvestName}", fontWeight = FontWeight.Bold)
        TextButton(onClick = { showEdit = true }, modifier = Modifier.align(Alignment.End)) { Text("تعديل بيانات البيع") }
        SummaryLine("السعر المتفق عليه", details.agreedAmount)
        SummaryLine("الخصم", details.discountAmount)
        if (details.discountAmount > 0) Text("سبب الخصم: ${details.discountReason}")
        SummaryLine("صافي الاتفاق بعد الخصم", netAgreed, true)
        SummaryLine("الواصل", paid)
        if (details.initialPaid > 0) Text("الدفعة الأولى: ${money(details.initialPaid)} بتاريخ ${hDate(details.saleDateMillis)}")
        SummaryLine("المتبقي", remaining, true)
        Text("تاريخ البيع: ${hDate(details.saleDateMillis)}")
        Text("الانتهاء المتوقع: ${hDate(details.expectedEndMillis)}")
        Text("مدة القطف المتوقعة: $expectedDuration يومًا")
        Text("الانتهاء الفعلي: ${if (details.actualEndMillis > 0) hDate(details.actualEndMillis) else "لم يُسجل بعد"}")
        if (actualDuration != null) Text("مدة القطف الفعلية: $actualDuration يومًا")
        Text("التقييم: $status", color = statusColor, fontWeight = FontWeight.Bold)
        if (details.notes.isNotBlank()) Text("ملاحظات: ${details.notes}")
        HorizontalDivider()
        Text("إضافة دفعة جديدة", fontWeight = FontWeight.Bold)
        MoneyField("مبلغ الدفعة", amount, { amount = it })
        DateField("تاريخ الدفع", paymentDate) { paymentDate = it }
        OutlinedTextField(method, { method = it }, label = { Text("طريقة الدفع") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(notes, { notes = it }, label = { Text("تفاصيل الدفع / ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Button(
            onClick = {
                val value = moneyToLong(amount)
                if (value > 0 && value <= remaining) scope.launch {
                    dao.insertBuyerPayment(BuyerPaymentEntity(saleId = details.id, amount = value, dateMillis = paymentDate, method = method.trim().ifBlank { "نقدًا" }, notes = notes.trim()))
                    amount = ""
                    notes = ""
                }
            },
            enabled = (moneyToLong(amount)) in 1..remaining,
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ الدفعة") }
        Text("سجل الواصلات", fontWeight = FontWeight.Bold)
        if (details.initialPaid > 0) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("${money(details.initialPaid)} • ${hDate(details.saleDateMillis)}", fontWeight = FontWeight.Bold)
                    Text("طريقة الدفع: واصل عند البيع")
                    Text("دفعة أولى عند تسجيل الاتفاق", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        SummaryLine("الواصلات الإضافية", FinanceCalculations.sumExact(payments.map { it.amount }))
        if (payments.isEmpty()) Text("لا توجد دفعات إضافية مسجلة.")
        payments.forEach { payment ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("${money(payment.amount)} • ${hDate(payment.dateMillis)}", fontWeight = FontWeight.Bold)
                    Text("طريقة الدفع: ${payment.method}")
                    if (payment.notes.isNotBlank()) Text("التفاصيل: ${payment.notes}")
                }
            }
        }
    }
    if (showEdit) EditBuyerSaleDialog(dao, details, plantations, paid) { showEdit = false }
}

@Composable
private fun EditBuyerSaleDialog(dao: MiyarDao, sale: BuyerSaleEntity, plantations: List<PlantationEntity>, paid: Long, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var plotId by remember(sale.id) { mutableLongStateOf(sale.plantationId) }
    var harvestName by remember(sale.id) { mutableStateOf(sale.harvestName) }
    var agreed by remember(sale.id) { mutableStateOf(sale.agreedAmount.toString()) }
    var expected by remember(sale.id) { mutableLongStateOf(sale.expectedEndMillis) }
    var actual by remember(sale.id) { mutableLongStateOf(sale.actualEndMillis) }
    var showActual by remember(sale.id) { mutableStateOf(sale.actualEndMillis > 0) }
    var discount by remember(sale.id) { mutableStateOf(sale.discountAmount.toString()) }
    var reason by remember(sale.id) { mutableStateOf(sale.discountReason) }
    var notes by remember(sale.id) { mutableStateOf(sale.notes) }
    var plotMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text("تعديل بيانات البيع") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box {
                    OutlinedButton(onClick = { plotMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(plantations.firstOrNull { it.id == plotId }?.name ?: "اختر الموضع الزراعي")
                    }
                    DropdownMenu(expanded = plotMenu, onDismissRequest = { plotMenu = false }) {
                        plantations.forEach { plot -> DropdownMenuItem(text = { Text(plot.name) }, onClick = { plotId = plot.id; plotMenu = false }) }
                    }
                }
                OutlinedTextField(harvestName, { harvestName = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth())
                MoneyField("السعر المتفق عليه", agreed, { agreed = it })
                DateField("الانتهاء المتوقع", expected) { expected = it }
                TextButton(onClick = { showActual = !showActual; if (!showActual) actual = 0L }) { Text(if (showActual) "إخفاء الانتهاء الفعلي" else "إدخال الانتهاء الفعلي") }
                if (showActual) DateField("الانتهاء الفعلي", actual.takeIf { it > 0 } ?: System.currentTimeMillis()) { actual = it }
                MoneyField("قيمة الخصم", discount, { discount = it })
                OutlinedTextField(reason, { reason = it }, label = { Text("سبب الخصم") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("الملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(enabled = !saving, onClick = {
                if (saving) return@TextButton
                val a = moneyToLong(agreed)
                val d = moneyToLong(discount)
                when {
                    plotId <= 0 || plantations.none { it.id == plotId } -> error = "اختر الموضع الزراعي."
                    harvestName.isBlank() || a <= 0 || d > a -> error = "راجع اسم القطفة والسعر والخصم."
                    expected < sale.saleDateMillis -> error = "تاريخ الانتهاء المتوقع لا يمكن أن يسبق تاريخ البيع."
                    showActual && actual < sale.saleDateMillis -> error = "تاريخ الانتهاء الفعلي لا يمكن أن يسبق تاريخ البيع."
                    d > 0 && reason.isBlank() -> error = "أدخل سبب الخصم."
                    paid > a - d -> error = "لا يمكن تخفيض السعر إلى أقل من المبلغ الواصل."
                    else -> {
                        saving = true
                        scope.launch {
                            try {
                                dao.updateBuyerSale(sale.copy(
                                    plantationId = plotId, harvestName = harvestName.trim(), agreedAmount = a,
                                    expectedEndMillis = expected, actualEndMillis = if (showActual) actual else 0L,
                                    discountAmount = d, discountReason = reason.trim(), notes = notes.trim()
                                ))
                                onDismiss()
                            } finally {
                                saving = false
                            }
                        }
                    }
                }
            }) { Text("حفظ التعديل") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}


@Composable
private fun DistributorFileScreen(dao: MiyarDao, seller: MarketDistributorEntity, harvests: List<PersonalHarvestEntity>, plantations: List<PlantationEntity>) {
    val transactions by dao.observeDistributorTransactions(seller.id).collectAsStateWithLifecycle(emptyList())
    val payments by dao.observeHarvestPartyPayments("DISTRIBUTOR", seller.id).collectAsStateWithLifecycle(emptyList())
    val allAdjustments by dao.observeAllDistributorAdjustments().collectAsStateWithLifecycle(emptyList())
    val allDistributionPayments by dao.observeAllDistributionExpensePayments().collectAsStateWithLifecycle(emptyList())
    var showNewTransaction by remember { mutableStateOf(false) }
    var paymentTransaction by remember { mutableStateOf<DistributorTransactionEntity?>(null) }
    var adjustmentTransaction by remember { mutableStateOf<DistributorTransactionEntity?>(null) }
    var payingDistributionAdjustment by remember { mutableStateOf<DistributorTransactionAdjustmentEntity?>(null) }
    var editingTransaction by remember { mutableStateOf<DistributorTransactionEntity?>(null) }

    val adjustmentsByTransaction = remember(allAdjustments, transactions) {
        allAdjustments.filter { item -> transactions.any { it.id == item.transactionId } }.groupBy { it.transactionId }
    }
    fun totalsFor(transactionId: Long): Pair<Long, Long> {
        val adjustments = adjustmentsByTransaction[transactionId].orEmpty()
        return FinanceCalculations.sumExact(adjustments.filter { it.kind == "SELLER_DISCOUNT" }.map { it.amount }) to
            FinanceCalculations.sumExact(adjustments.filter { it.kind == "DISTRIBUTION_EXPENSE" }.map { it.amount })
    }
    val gross = FinanceCalculations.sumExact(transactions.map { it.total })
    val productQuantityTotal = FinanceCalculations.sumExact(transactions.map { it.quantity })
    val productQuantityBreakdown = transactions.groupBy { it.productType }.entries.sortedBy { it.key }.joinToString(" • ") { (type, items) -> "$type: ${FinanceCalculations.sumExact(items.map { it.quantity })}" }
    val discountTotal = FinanceCalculations.sumExact(adjustmentsByTransaction.values.flatten().filter { it.kind == "SELLER_DISCOUNT" }.map { it.amount })
    val distributionTotal = FinanceCalculations.sumExact(adjustmentsByTransaction.values.flatten().filter { it.kind == "DISTRIBUTION_EXPENSE" }.map { it.amount })
    val netTotal = FinanceCalculations.sellerNetSale(gross, discountTotal, distributionTotal)
    val received = Math.addExact(FinanceCalculations.sumExact(payments.map { it.amount }), FinanceCalculations.sumExact(transactions.map { it.received }))
    val totalBalance = FinanceCalculations.sellerBalance(netTotal, received)
    val remaining = totalBalance.coerceAtLeast(0L)
    val credit = if (totalBalance < 0L) -totalBalance else 0L

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف البائع: ${seller.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryLine("إجمالي العدد", productQuantityTotal, true)
        if (productQuantityBreakdown.isNotBlank()) Text(productQuantityBreakdown, style = MaterialTheme.typography.bodySmall, color = Green)
        SummaryLine("إجمالي قيمة البيع الأصلية", gross)
        SummaryLine("إجمالي خصومات البائع", discountTotal)
        SummaryLine("إجمالي مصاريف التوزيع", distributionTotal)
        SummaryLine("صافي قيمة العمليات", netTotal, true)
        SummaryLine("إجمالي ما وصلنا من البائع", received)
        SummaryLine("المتبقي لنا عند البائع", remaining, true)
        if (credit > 0L) SummaryLine("زيادة تحصيل / رصيد دائن للبائع", credit, true)
        Button(onClick = { showNewTransaction = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة عملية جديدة") }
        Text("تفاصيل العمليات", fontWeight = FontWeight.Bold)
        transactions.forEach { transaction ->
            val (discount, distribution) = totalsFor(transaction.id)
            val net = FinanceCalculations.sellerNetSale(transaction.total, discount, distribution)
            val paidFor = Math.addExact(transaction.received, FinanceCalculations.sumExact(payments.filter { it.transactionId == transaction.id }.map { it.amount }))
            val balance = FinanceCalculations.sellerBalance(net, paidFor)
            val linkedHarvest = harvests.firstOrNull { it.id == transaction.harvestId }
            val linkedPlot = plantations.firstOrNull { it.id == linkedHarvest?.plantationId }?.name
            val transactionAdjustments = adjustmentsByTransaction[transaction.id].orEmpty()
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(transaction.productType, fontWeight = FontWeight.Bold)
                    Text("${hDate(transaction.dateMillis)} • العدد ${transaction.quantity} × ${transaction.unitPrice}")
                    Text("القطفة: ${linkedHarvest?.name ?: "عملية مستقلة"} • الموضع: ${linkedPlot ?: "غير محدد"}", style = MaterialTheme.typography.bodySmall)
                    SummaryLine("قيمة البيع الأصلية", transaction.total)
                    if (!transaction.isValueComplete) Text("قيمة هذه العملية غير مكتملة بعد.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    SummaryLine("خصومات البائع", discount)
                    SummaryLine("مصاريف التوزيع", distribution)
                    SummaryLine("صافي قيمة العملية", net, true)
                    SummaryLine("الدفعات المحصلة", paidFor)
                    if (balance >= 0L) SummaryLine("المتبقي", balance, true)
                    else SummaryLine("زيادة التحصيل / رصيد دائن", -balance, true)
                    if (transaction.sourceDayId == 0L) {
                        TextButton(onClick = { editingTransaction = transaction }, modifier = Modifier.align(Alignment.End)) { Text("تعديل العملية") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(
                            onClick = { paymentTransaction = transaction },
                            enabled = balance > 0L,
                            modifier = Modifier.weight(1f)
                        ) { Text("＋ تسجيل دفعة لهذه العملية") }
                        TextButton(
                            onClick = { adjustmentTransaction = transaction },
                            modifier = Modifier.weight(1f)
                        ) { Text("＋ تسجيل خرج أو خصم") }
                    }
                    transactionAdjustments.forEach { adjustment ->
                        val paidExpense = FinanceCalculations.sumExact(allDistributionPayments.filter { it.adjustmentId == adjustment.id }.map { it.amount })
                        val typeLabel = if (adjustment.kind == "SELLER_DISCOUNT") "خصم البائع" else "خرج توزيع"
                        HorizontalDivider()
                        Text("$typeLabel • ${money(adjustment.amount)} • ${hDate(adjustment.dateMillis)}", fontWeight = FontWeight.SemiBold)
                        Text(adjustment.description, style = MaterialTheme.typography.bodySmall)
                        if (adjustment.notes.isNotBlank()) Text(adjustment.notes, style = MaterialTheme.typography.bodySmall)
                        if (adjustment.kind == "DISTRIBUTION_EXPENSE") {
                            Text("المسدد: ${money(paidExpense)} • غير المسدد: ${money(adjustment.amount - paidExpense)}", style = MaterialTheme.typography.bodySmall)
                            TextButton(
                                onClick = { payingDistributionAdjustment = adjustment },
                                enabled = paidExpense < adjustment.amount
                            ) { Text("تسجيل سداد مصروف التوزيع") }
                        }
                    }
                    if (transaction.notes.isNotBlank()) Text(transaction.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("سجل الدفعات المحصلة من البائع", fontWeight = FontWeight.Bold)
        payments.forEach { payment -> Text("${hDate(payment.dateMillis)} • ${money(payment.amount)} • ${payment.method}${if (payment.notes.isNotBlank()) " • ${payment.notes}" else ""}") }
    }
    if (showNewTransaction) NewPartyTransactionDialog("DISTRIBUTOR", seller.id, dao, harvests, { showNewTransaction = false })
    editingTransaction?.let { transaction ->
        EditPartyTransactionDialog(
            partyType = "DISTRIBUTOR", transactionId = transaction.id,
            productType = transaction.productType, quantity = transaction.quantity,
            unitPrice = transaction.unitPrice, total = transaction.total,
            isTotalManual = transaction.isTotalManual, isValueComplete = transaction.isValueComplete,
            dateMillis = transaction.dateMillis, notes = transaction.notes, dao = dao,
            onDismiss = { editingTransaction = null }
        )
    }
    paymentTransaction?.let { transaction ->
        val (discount, distribution) = totalsFor(transaction.id)
        val net = FinanceCalculations.sellerNetSale(transaction.total, discount, distribution)
        val alreadyPaid = Math.addExact(transaction.received, FinanceCalculations.sumExact(payments.filter { it.transactionId == transaction.id }.map { it.amount }))
        val balance = FinanceCalculations.sellerBalance(net, alreadyPaid)
        PartyPaymentDialog("DISTRIBUTOR", seller.id, transaction.id, balance.coerceAtLeast(0L), dao, { paymentTransaction = null })
    }
    adjustmentTransaction?.let { transaction ->
        DistributorAdjustmentDialog(transaction, dao, { adjustmentTransaction = null })
    }
    payingDistributionAdjustment?.let { adjustment ->
        val paid = FinanceCalculations.sumExact(allDistributionPayments.filter { it.adjustmentId == adjustment.id }.map { it.amount })
        DistributionExpensePaymentDialog(adjustment, (adjustment.amount - paid).coerceAtLeast(0L), dao, { payingDistributionAdjustment = null })
    }
}



@Composable
private fun DistributorAdjustmentDialog(
    transaction: DistributorTransactionEntity,
    dao: MiyarDao,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf("SELLER_DISCOUNT") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var description by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val idempotencyKey = remember { java.util.UUID.randomUUID().toString() }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text("تسجيل خرج أو خصم لهذه العملية") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("قيمة البيع الأصلية: ${money(transaction.total)}", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = kind == "SELLER_DISCOUNT", onClick = { kind = "SELLER_DISCOUNT" }, label = { Text("خصم البائع") })
                    FilterChip(selected = kind == "DISTRIBUTION_EXPENSE", onClick = { kind = "DISTRIBUTION_EXPENSE" }, label = { Text("خرج توزيع") })
                }
                MoneyField("المبلغ", amount, { amount = it })
                DateField("التاريخ", date) { date = it }
                OutlinedTextField(description, { description = it }, label = { Text("بيان العملية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات اختيارية") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(enabled = !saving, onClick = {
                val value = moneyToLong(amount)
                if (value <= 0L) error = "أدخل مبلغًا أكبر من صفر."
                else if (description.isBlank()) error = "أدخل بيان العملية."
                else {
                    saving = true
                    scope.launch {
                        try {
                            dao.saveDistributorAdjustment(
                                DistributorTransactionAdjustmentEntity(
                                    transactionId = transaction.id,
                                    kind = kind,
                                    amount = value,
                                    dateMillis = date,
                                    description = description.trim(),
                                    notes = notes.trim(),
                                    idempotencyKey = idempotencyKey
                                )
                            )
                            onDismiss()
                        } catch (t: Throwable) {
                            error = t.message ?: "تعذر حفظ الحركة."
                        } finally { saving = false }
                    }
                }
            }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ الحركة") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun DistributionExpensePaymentDialog(
    adjustment: DistributorTransactionAdjustmentEntity,
    remaining: Long,
    dao: MiyarDao,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val idempotencyKey = remember { java.util.UUID.randomUUID().toString() }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text("سداد مصروف التوزيع") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryLine("المبلغ المستحق", remaining, true)
                MoneyField("مبلغ السداد", amount, { amount = it })
                DateField("تاريخ السداد", date) { date = it }
                OutlinedTextField(method, { method = it }, label = { Text("طريقة السداد") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(enabled = !saving && moneyToLong(amount) in 1..remaining, onClick = {
                saving = true
                scope.launch {
                    try {
                        dao.saveDistributionExpensePayment(
                            DistributionExpensePaymentEntity(
                                adjustmentId = adjustment.id,
                                amount = moneyToLong(amount),
                                dateMillis = date,
                                method = method.trim().ifBlank { "نقدًا" },
                                notes = notes.trim(),
                                idempotencyKey = idempotencyKey
                            )
                        )
                        onDismiss()
                    } catch (t: Throwable) {
                        error = t.message ?: "تعذر تسجيل السداد."
                    } finally { saving = false }
                }
            }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ السداد") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun DebtorFileScreen(dao: MiyarDao, debtor: HarvestDebtorEntity, harvests: List<PersonalHarvestEntity>, plantations: List<PlantationEntity>) {
    val transactions by dao.observeDebtorTransactions(debtor.id).collectAsStateWithLifecycle(emptyList())
    val payments by dao.observeHarvestPartyPayments("DEBTOR", debtor.id).collectAsStateWithLifecycle(emptyList())
    var showNewTransaction by remember { mutableStateOf(false) }
    var paymentTransaction by remember { mutableStateOf<HarvestDebtorTransactionEntity?>(null) }
    var editingTransaction by remember { mutableStateOf<HarvestDebtorTransactionEntity?>(null) }
    val total = FinanceCalculations.sumExact(transactions.map { it.total })
    val productQuantityTotal = FinanceCalculations.sumExact(transactions.map { it.quantity })
    val productQuantityBreakdown = transactions.groupBy { it.productType }.entries.sortedBy { it.key }.joinToString(" • ") { (type, items) -> "$type: ${FinanceCalculations.sumExact(items.map { it.quantity })}" }
    val paid = Math.addExact(FinanceCalculations.sumExact(payments.map { it.amount }), FinanceCalculations.sumExact(transactions.map { it.paid }))
    val credit = (paid - total).coerceAtLeast(0L)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف العميل: ${debtor.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryLine("إجمالي العدد", productQuantityTotal, true)
        if (productQuantityBreakdown.isNotBlank()) Text(productQuantityBreakdown, style = MaterialTheme.typography.bodySmall, color = Green)
        SummaryLine("إجمالي ما عليه", total, true)
        SummaryLine("إجمالي ما له / رصيد دائن", credit)
        SummaryLine("إجمالي ما دفعه العميل", paid)
        SummaryLine("المتبقي عليه لنا", (total - paid).coerceAtLeast(0), true)
        Button(onClick = { showNewTransaction = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة عملية جديدة") }
        Text("تفاصيل العمليات", fontWeight = FontWeight.Bold)
        transactions.forEach { transaction ->
            val paidFor = Math.addExact(transaction.paid, FinanceCalculations.sumExact(payments.filter { it.transactionId == transaction.id }.map { it.amount }))
            val linkedHarvest = harvests.firstOrNull { it.id == transaction.harvestId }
            val linkedPlot = plantations.firstOrNull { it.id == linkedHarvest?.plantationId }?.name
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(transaction.productType, fontWeight = FontWeight.Bold)
                    Text("${hDate(transaction.dateMillis)} • العدد ${transaction.quantity} × ${transaction.unitPrice}")
                    Text("القطفة: ${linkedHarvest?.name ?: "عملية مستقلة"} • الموضع: ${linkedPlot ?: "غير محدد"}", style = MaterialTheme.typography.bodySmall)
                    SummaryLine("قيمة العملية", transaction.total)
                    if (!transaction.isValueComplete) Text("قيمة هذه العملية غير مكتملة بعد.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    SummaryLine("الواصل", paidFor)
                    SummaryLine("المتبقي", (transaction.total - paidFor).coerceAtLeast(0), true)
                    if (transaction.sourceDayId == 0L) TextButton(onClick = { editingTransaction = transaction }) { Text("تعديل العملية") }
                    TextButton(onClick = { paymentTransaction = transaction }) { Text("＋ تسجيل دفعة لهذه العملية") }
                    if (transaction.notes.isNotBlank()) Text(transaction.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("سجل الدفعات", fontWeight = FontWeight.Bold)
        payments.forEach { payment -> Text("${hDate(payment.dateMillis)} • ${money(payment.amount)} • ${payment.method}${if (payment.notes.isNotBlank()) " • ${payment.notes}" else ""}") }
    }
    if (showNewTransaction) NewPartyTransactionDialog("DEBTOR", debtor.id, dao, harvests, { showNewTransaction = false })
    editingTransaction?.let { transaction ->
        EditPartyTransactionDialog(
            partyType = "DEBTOR", transactionId = transaction.id,
            productType = transaction.productType, quantity = transaction.quantity,
            unitPrice = transaction.unitPrice, total = transaction.total,
            isTotalManual = transaction.isTotalManual, isValueComplete = transaction.isValueComplete,
            dateMillis = transaction.dateMillis, notes = transaction.notes, dao = dao,
            onDismiss = { editingTransaction = null }
        )
    }
    paymentTransaction?.let { transaction ->
        val alreadyPaid = Math.addExact(transaction.paid, FinanceCalculations.sumExact(payments.filter { it.transactionId == transaction.id }.map { it.amount }))
        PartyPaymentDialog("DEBTOR", debtor.id, transaction.id, (transaction.total - alreadyPaid).coerceAtLeast(0), dao, { paymentTransaction = null })
    }
}

private data class PartyProductLineState(
    val productType: String = MIYAR_PRODUCT_TYPES.first(),
    val quantity: String = "",
    val unitPrice: String = "",
    val manualTotal: String = "",
    val isTotalManual: Boolean = false
)

@Composable
private fun NewPartyTransactionDialog(
    partyType: String,
    partyId: Long,
    dao: MiyarDao,
    harvests: List<PersonalHarvestEntity>,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val lines = remember { mutableStateListOf(PartyProductLineState()) }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var notes by remember { mutableStateOf("") }
    var harvestId by remember { mutableLongStateOf(0L) }
    var harvestMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }

    fun calculated(line: PartyProductLineState): Long = safeProduct(
        line.quantity.toLongOrNull() ?: 0L,
        moneyToLong(line.unitPrice)
    )
    fun effective(line: PartyProductLineState): Long = if (line.isTotalManual) moneyToLong(line.manualTotal) else calculated(line)
    val aggregateTotal = safeSum(lines.map(::effective))

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (partyType == "DISTRIBUTOR") "عملية جديدة للموزع" else "عملية جديدة للعميل الآجل") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Box {
                    OutlinedButton(onClick = { harvestMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(harvests.firstOrNull { it.id == harvestId }?.name ?: "ربط العملية بقطفة (اختياري)")
                    }
                    DropdownMenu(expanded = harvestMenu, onDismissRequest = { harvestMenu = false }) {
                        DropdownMenuItem(text = { Text("عملية مستقلة") }, onClick = { harvestId = 0L; harvestMenu = false })
                        harvests.forEach { harvest ->
                            DropdownMenuItem(text = { Text(harvest.name) }, onClick = { harvestId = harvest.id; harvestMenu = false })
                        }
                    }
                }
                Text("المنتجات", fontWeight = FontWeight.Bold, color = Emerald)
                lines.forEachIndexed { index, line ->
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFF2F7F2))) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الصنف ${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (lines.size > 1) TextButton(enabled = !saving, onClick = { lines.removeAt(index) }) { Text("إزالة") }
                            }
                            ProductTypeField(line.productType) { value -> lines[index] = line.copy(productType = value) }
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                NumField("العدد", line.quantity, { value -> lines[index] = line.copy(quantity = value) }, Modifier.weight(1f))
                                MoneyField("سعر الوحدة (اختياري)", line.unitPrice, { value -> lines[index] = line.copy(unitPrice = value) }, Modifier.weight(1f))
                            }
                            val calculatedTotal = calculated(line)
                            MoneyField(
                                "إجمالي المبيعات (اضغط للتعديل)",
                                if (line.isTotalManual) line.manualTotal else if (calculatedTotal == Long.MAX_VALUE) "" else moneyInput(calculatedTotal.toString()),
                                { value -> lines[index] = line.copy(manualTotal = value, isTotalManual = value.isNotBlank()) }
                            )
                            if (line.isTotalManual) {
                                Text("قيمة يدوية معتمدة • الإجمالي المحسوب: ${if (calculatedTotal == Long.MAX_VALUE) "خارج الحد" else money(calculatedTotal)}", color = Emerald, style = MaterialTheme.typography.labelSmall)
                            } else if (line.unitPrice.isBlank()) {
                                Text("السعر غير مكتمل؛ يمكن حفظ الصنف واستكمال قيمته لاحقًا.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                OutlinedButton(
                    enabled = !saving,
                    onClick = { lines.add(PartyProductLineState()) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ نوع آخر / إضافة صنف") }
                if (aggregateTotal == Long.MAX_VALUE) Text("مجموع قيم المنتجات يتجاوز الحد الحسابي المسموح؛ راجع الأسطر.", color = MaterialTheme.colorScheme.error)
                else SummaryLine("إجمالي قيمة المنتجات", aggregateTotal, true)
                DateField("تاريخ العملية", date) { date = it }
                OutlinedTextField(notes, { notes = it }, label = { Text("التفاصيل والملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(
                enabled = !saving,
                onClick = {
                    val drafts = lines.map { line ->
                        val quantity = line.quantity.toLongOrNull() ?: 0L
                        val calculatedTotal = calculated(line)
                        val isComplete = line.isTotalManual || line.unitPrice.isNotBlank()
                        HarvestPartySaleLineDraft(
                            productType = line.productType,
                            quantity = quantity,
                            unitPrice = moneyToLong(line.unitPrice),
                            total = effective(line),
                            calculatedTotal = if (calculatedTotal == Long.MAX_VALUE) 0L else calculatedTotal,
                            isTotalManual = line.isTotalManual,
                            isValueComplete = isComplete
                        )
                    }
                    when {
                        drafts.isEmpty() -> error = "أضف منتجًا واحدًا على الأقل."
                        drafts.any { it.productType !in MIYAR_PRODUCT_TYPES || it.quantity <= 0L } -> error = "اختر نوعًا معتمدًا وأدخل عددًا أكبر من صفر لكل صنف."
                        drafts.any { it.unitPrice < 0L || it.total < 0L || it.calculatedTotal < 0L } -> error = "راجع الأسعار والإجماليات؛ لا تقبل القيم السالبة أو غير الصالحة."
                        lines.any { calculated(it) == Long.MAX_VALUE } || aggregateTotal == Long.MAX_VALUE -> error = "إحدى القيم تتجاوز الحد الحسابي المسموح؛ خفّض الكمية أو السعر."
                        lines.any { !isValidMoneyInput(it.unitPrice) || !isValidMoneyInput(it.manualTotal) } -> error = "أدخل الأسعار والإجماليات بأرقام صحيحة ضمن الحد المسموح."
                        else -> {
                            saving = true
                            error = ""
                            scope.launch {
                                try {
                                    dao.insertPartySaleLines(
                                        partyType = partyType,
                                        partyId = partyId,
                                        harvestId = harvestId,
                                        dateMillis = date,
                                        notes = notes.trim(),
                                        lines = drafts
                                    )
                                    onDismiss()
                                } catch (t: Throwable) {
                                    error = t.message ?: "تعذر حفظ العملية."
                                } finally {
                                    saving = false
                                }
                            }
                        }
                    }
                }
            ) { Text(if (saving) "جارٍ الحفظ..." else "حفظ العملية") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun EditPartyTransactionDialog(
    partyType: String,
    transactionId: Long,
    productType: String,
    quantity: Long,
    unitPrice: Long,
    total: Long,
    isTotalManual: Boolean,
    isValueComplete: Boolean,
    dateMillis: Long,
    notes: String,
    dao: MiyarDao,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var selectedType by remember(transactionId) { mutableStateOf(productType) }
    var quantityText by remember(transactionId) { mutableStateOf(quantity.toString()) }
    var unitPriceText by remember(transactionId) { mutableStateOf(unitPrice.takeIf { isValueComplete || it > 0L }?.let { moneyInput(it.toString()) }.orEmpty()) }
    var manualTotalText by remember(transactionId) { mutableStateOf(if (isTotalManual) moneyInput(total.toString()) else "") }
    var totalIsManual by remember(transactionId) { mutableStateOf(isTotalManual) }
    var date by remember(transactionId) { mutableLongStateOf(dateMillis) }
    var memo by remember(transactionId) { mutableStateOf(notes) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val count = quantityText.toLongOrNull() ?: 0L
    val price = moneyToLong(unitPriceText)
    val calculated = if (count > 0L) safeProduct(count, price) else 0L
    val effective = if (totalIsManual) moneyToLong(manualTotalText) else calculated
    val complete = totalIsManual || unitPriceText.isNotBlank()

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (partyType == "DISTRIBUTOR") "تعديل عملية الموزع" else "تعديل عملية العميل الآجل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ProductTypeField(selectedType) { selectedType = it }
                NumField("عدد المنتجات", quantityText, { quantityText = it })
                MoneyField("سعر الوحدة (يمكن تركه فارغًا)", unitPriceText, { unitPriceText = it })
                MoneyField(
                    "إجمالي المبيعات (اضغط للتعديل اليدوي)",
                    if (totalIsManual) manualTotalText else if (calculated == Long.MAX_VALUE) "" else moneyInput(calculated.toString()),
                    { value -> manualTotalText = value; totalIsManual = value.isNotBlank() }
                )
                if (totalIsManual) Text("القيمة اليدوية هي المعتمدة. المحسوب الأصلي: ${if (calculated == Long.MAX_VALUE) "يتجاوز الحد" else money(calculated)}", color = Emerald, style = MaterialTheme.typography.labelSmall)
                else if (!complete) Text("القيمة غير مكتملة؛ يمكنك حفظ العملية واستكمال السعر لاحقًا.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                if (effective == Long.MAX_VALUE) {
                    Text("القيمة المعتمدة تتجاوز الحد الحسابي المسموح.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                } else {
                    SummaryLine("القيمة المعتمدة", effective, true)
                }
                DateField("تاريخ العملية", date) { date = it }
                OutlinedTextField(memo, { memo = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(enabled = !saving, onClick = {
                when {
                    selectedType !in MIYAR_PRODUCT_TYPES || count <= 0L -> error = "اختر نوع المنتج وأدخل عددًا أكبر من صفر."
                    !isValidMoneyInput(unitPriceText) || !isValidMoneyInput(manualTotalText) -> error = "تحقق من السعر والإجمالي؛ يجب أن تكون أرقامًا صحيحة."
                    calculated == Long.MAX_VALUE || effective == Long.MAX_VALUE -> error = "القيمة تتجاوز الحد الحسابي المسموح."
                    date <= 0L -> error = "حدد تاريخ العملية."
                    else -> {
                        saving = true
                        error = ""
                        scope.launch {
                            try {
                                val calculatedBaseline = FinanceCalculations.effectiveProductTotal(count, price, null)
                                if (partyType == "DISTRIBUTOR") {
                                    dao.updateDistributorTransactionSafely(
                                        transactionId, selectedType, count, price, effective,
                                        calculatedBaseline, totalIsManual, complete, date, memo
                                    )
                                } else {
                                    dao.updateDebtorTransactionSafely(
                                        transactionId, selectedType, count, price, effective,
                                        calculatedBaseline, totalIsManual, complete, date, memo
                                    )
                                }
                                onDismiss()
                            } catch (t: Throwable) {
                                error = t.message ?: "تعذر تعديل العملية."
                            } finally { saving = false }
                        }
                    }
                }
            }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ التعديل") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun PartyPaymentDialog(partyType: String, partyId: Long, transactionId: Long, remaining: Long, dao: MiyarDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    val idempotencyKey = remember { java.util.UUID.randomUUID().toString() }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (partyType == "DISTRIBUTOR") "تسجيل مبلغ وصل من البائع" else "تسجيل دفعة من العميل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MoneyField("مبلغ الدفعة", amount, { amount = it })
                DateField("تاريخ الدفع", date) { date = it }
                OutlinedTextField(method, { method = it }, label = { Text("طريقة الدفع") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("تفاصيل الدفع") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val value = moneyToLong(amount)
                if (value > 0 && value <= remaining && !saving) {
                    saving = true
                    scope.launch {
                        try {
                            dao.saveHarvestPartyPayment(HarvestPartyPaymentEntity(
                                partyType = partyType, partyId = partyId, transactionId = transactionId,
                                amount = value, dateMillis = date,
                                method = method.trim().ifBlank { "نقدًا" }, notes = notes.trim(),
                                idempotencyKey = idempotencyKey
                            ))
                            onDismiss()
                        } catch (t: Throwable) {
                            error = t.message ?: "تعذر تسجيل الدفعة."
                        } finally { saving = false }
                    }
                }
            }, enabled = !saving && (moneyToLong(amount)) in 1L..remaining) { Text(if (saving) "جارٍ الحفظ..." else "حفظ الدفعة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
