package com.miyar.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplier: String,
    val invoiceNumber: String,
    val dateMillis: Long,
    val paymentStatus: String,
    val currency: String,
    /** Exchange rate multiplied by 1000; 1.000 for YER. */
    val exchangeRateScaled: Long,
    val totalForeign: Long,
    val totalYer: Long,
    val notes: String = ""
)

@Entity(
    tableName = "stock_items",
    indices = [Index(value = ["productType", "productName", "baseUnit"], unique = true)]
)
data class StockItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productType: String,
    val productName: String,
    val activeIngredient: String = "",
    /** Canonical unit is g for solids and ml for liquids. */
    val baseUnit: String,
    val quantityBase: Long = 0,
    val totalReceivedBase: Long = 0,
    val totalUsedBase: Long = 0,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "invoice_items",
    foreignKeys = [
        ForeignKey(entity = InvoiceEntity::class, parentColumns = ["id"], childColumns = ["invoiceId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["invoiceId"]), Index(value = ["stockItemId"])]
)
data class InvoiceItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val packageName: String,
    val packageSize: Long,
    val packageCount: Long,
    val unit: String,
    val quantityBase: Long,
    val unitPriceForeign: Long,
    val lineTotalForeign: Long,
    val lineTotalYer: Long
)

@Entity(
    tableName = "stock_movements",
    foreignKeys = [ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["stockItemId"]), Index(value = ["referenceType", "referenceId"])]
)
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stockItemId: Long,
    val referenceType: String,
    val referenceId: Long,
    /** Positive for receipts; negative for usage. */
    val quantityBase: Long,
    val dateMillis: Long = System.currentTimeMillis(),
    val description: String = ""
)
