package com.miyar.app.data

import java.math.BigDecimal
import java.math.RoundingMode

/** Exact whole-number calculations used by invoice and inventory flows. */
object FinanceCalculations {
    fun quantityToBase(quantity: Long, unit: String, packageCount: Long = 1L): Long {
        require(quantity >= 0 && packageCount >= 0) { "الكمية لا يمكن أن تكون سالبة." }
        val multiplier = if (unit == "كجم" || unit == "لتر") 1000L else 1L
        return Math.multiplyExact(Math.multiplyExact(quantity, packageCount), multiplier)
    }

    fun lineTotal(packageCount: Long, pricePerPackage: Long): Long {
        require(packageCount >= 0 && pricePerPackage >= 0) { "الكمية والسعر لا يمكن أن يكونا سالبين." }
        return Math.multiplyExact(packageCount, pricePerPackage)
    }

    /** rateScaled is the exchange rate multiplied by 1000. */
    fun toYemeniRials(amountForeign: Long, rateScaled: Long): Long {
        require(amountForeign >= 0 && rateScaled > 0) { "تحقق من المبلغ وسعر الصرف." }
        return BigDecimal(amountForeign)
            .multiply(BigDecimal(rateScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }
}
