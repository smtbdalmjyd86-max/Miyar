package com.miyar.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

private data class InvoiceLineDraft(
    val productType: String = "الأسمدة",
    val productName: String = "",
    val activeIngredient: String = "",
    val packageName: String = "عبوة",
    val packageSize: String = "1",
    val packageCount: String = "1",
    val unit: String = "كجم",
    val unitPrice: String = ""
)

private fun localDate(millis: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(millis))
private fun parseDateOrToday(value: Long?): Long = value ?: System.currentTimeMillis()

// Material3 DatePicker uses UTC-midnight milliseconds. The app stores local-day
// timestamps, so convert explicitly to avoid a one-day shift in UTC+3/other zones.
private fun toPickerDateMillis(localMillis: Long): Long =
    Instant.ofEpochMilli(localMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        .atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()

private fun fromPickerDateMillis(pickerMillis: Long): Long =
    Instant.ofEpochMilli(pickerMillis).atZone(ZoneOffset.UTC).toLocalDate()
        .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
private fun digits(value: String): Long = value.filter { it.isDigit() }.toLongOrNull() ?: 0L
private fun rateScaled(value: String): Long = runCatching {
    BigDecimal(value.trim().replace(',', '.')).multiply(BigDecimal(1000)).setScale(0, RoundingMode.HALF_UP).longValueExact()
}.getOrDefault(0L)
private fun baseMultiplier(unit: String): Long = FinanceCalculations.quantityToBase(1L, unit)
private fun baseUnit(unit: String): String = if (unit == "كجم" || unit == "جرام") "g" else "ml"
private fun stockQuantity(value: Long, unit: String): String = when (unit) {
    "g" -> if (value >= 1000 && value % 1000L == 0L) "${value / 1000} كجم" else "$value جرام"
    else -> if (value >= 1000 && value % 1000L == 0L) "${value / 1000} لتر" else "$value مل"
}

@Composable
fun MiyarDateField(label: String, millis: Long, onDate: (Long) -> Unit) {
    var showPicker by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
        Text("$label: ${localDate(millis)}")
    }
    if (showPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = toPickerDateMillis(millis))
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = { state.selectedDateMillis?.let { onDate(fromPickerDateMillis(it)) }; showPicker = false }) { Text("اختيار") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("إلغاء") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
fun MiyarInvoiceScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val invoices by dao.observeInvoices().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<InvoiceEntity?>(null) }
    var initialLines by remember { mutableStateOf<List<InvoiceLineDraft>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var detailsFor by remember { mutableStateOf<InvoiceEntity?>(null) }
    var detailLines by remember { mutableStateOf<List<InvoiceItemEntity>>(emptyList()) }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("الفواتير", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                Text("تسجيل المشتريات وتحويل قيمتها وتحديث المخزون تلقائيًا", style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { editing = null; initialLines = listOf(InvoiceLineDraft()); showForm = true }) {
                Icon(Icons.Default.Add, null); Text("فاتورة")
            }
        }
        if (invoices.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ReceiptLong, null, tint = Emerald, modifier = Modifier.size(34.dp))
                    Text("لا توجد فواتير مسجلة بعد", fontWeight = FontWeight.Bold)
                    Text("أضف فاتورة لتسجيل الأصناف والكميات في المخزون.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        invoices.forEach { invoice ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(invoice.supplier, color = Emerald, fontWeight = FontWeight.Bold)
                            Text("فاتورة ${invoice.invoiceNumber} • ${localDate(invoice.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (invoice.paymentStatus == "آجل") "آجل" else "نقدًا", color = if (invoice.paymentStatus == "آجل") Gold else Green, fontWeight = FontWeight.Bold)
                    }
                    Text("الإجمالي: ${formatMoney(invoice.totalYer)}", fontWeight = FontWeight.ExtraBold)
                    Text("${invoice.totalForeign} ${invoice.currency} • سعر الصرف: ${invoice.exchangeRateScaled / 1000.0}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            scope.launch {
                                detailsFor = invoice
                                detailLines = dao.getInvoiceItems(invoice.id)
                            }
                        }) { Text("التفاصيل") }
                        TextButton(onClick = {
                            scope.launch {
                                val lines = dao.getInvoiceItems(invoice.id).map { item ->
                                    val unitSize = item.packageSize.toString()
                                    InvoiceLineDraft(item.productType, item.productName, item.activeIngredient, item.packageName,
                                        unitSize, item.packageCount.toString(), item.unit, item.unitPriceForeign.toString())
                                }
                                editing = invoice; initialLines = lines; showForm = true
                            }
                        }) { Icon(Icons.Default.Edit, null); Text("تعديل") }
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    val deleted = dao.deleteInvoiceSafely(invoice.id)
                                    if (!deleted) error = "لا يمكن حذف الفاتورة لأن جزءًا من كمياتها صُرف في عمليات زراعية. أعد الكميات المستخدمة أولًا."
                                } catch (t: Throwable) { error = t.message ?: "تعذر حذف الفاتورة." }
                            }
                        }) { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error); Text("حذف", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }

    if (showForm) {
        InvoiceFormDialog(
            initial = editing,
            initialLines = initialLines,
            initialSarRate = prefs.getString("sar", "") ?: "",
            initialUsdRate = prefs.getString("usd", "") ?: "",
            onDismiss = { showForm = false; editing = null },
            onSave = { invoice, lines, sarRate, usdRate, complete ->
                scope.launch {
                    try {
                        dao.saveInvoice(invoice, lines)
                        prefs.edit().putString("sar", sarRate).putString("usd", usdRate).apply()
                        showForm = false; editing = null
                        complete(true)
                    } catch (t: Throwable) {
                        error = t.message ?: "تعذر حفظ الفاتورة."
                        complete(false)
                    }
                }
            }
        )
    }
    if (detailsFor != null) {
        AlertDialog(
            onDismissRequest = { detailsFor = null },
            title = { Text("تفاصيل فاتورة ${detailsFor!!.invoiceNumber}") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("التاجر: ${detailsFor!!.supplier}")
                    detailLines.forEach { line ->
                        HorizontalDivider()
                        Text(line.productName, fontWeight = FontWeight.Bold)
                        Text("${line.productType} • ${line.activeIngredient}")
                        Text("${line.packageCount} × ${line.packageSize} ${line.unit} • ${line.packageName}")
                        Text("${line.lineTotalForeign} ${detailsFor!!.currency} = ${formatMoney(line.lineTotalYer)}")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detailsFor = null }) { Text("إغلاق") } }
        )
    }
    if (error != null) AlertDialog(onDismissRequest = { error = null }, title = { Text("تنبيه") }, text = { Text(error!!) }, confirmButton = { TextButton(onClick = { error = null }) { Text("حسنًا") } })
}

@Composable
private fun InvoiceFormDialog(
    initial: InvoiceEntity?,
    initialLines: List<InvoiceLineDraft>,
    initialSarRate: String,
    initialUsdRate: String,
    onDismiss: () -> Unit,
    onSave: (InvoiceEntity, List<InvoiceItemEntity>, String, String, (Boolean) -> Unit) -> Unit
) {
    var supplier by remember(initial?.id) { mutableStateOf(initial?.supplier ?: "") }
    var invoiceNumber by remember(initial?.id) { mutableStateOf(initial?.invoiceNumber ?: "") }
    var dateMillis by remember(initial?.id) { mutableLongStateOf(parseDateOrToday(initial?.dateMillis)) }
    var paymentStatus by remember(initial?.id) { mutableStateOf(initial?.paymentStatus ?: "نقدًا") }
    var currency by remember(initial?.id) { mutableStateOf(initial?.currency ?: "YER") }
    var sarRate by remember { mutableStateOf(initialSarRate) }
    var usdRate by remember { mutableStateOf(initialUsdRate) }
    var notes by remember(initial?.id) { mutableStateOf(initial?.notes ?: "") }
    val lines = remember(initial?.id) { mutableStateListOf<InvoiceLineDraft>().apply { addAll(initialLines.ifEmpty { listOf(InvoiceLineDraft()) }) } }
    val rateText = when (currency) { "SAR" -> sarRate; "USD" -> usdRate; else -> "1" }
    val rate = if (currency == "YER") 1000L else rateScaled(rateText)
    val lineTotals = lines.map { line ->
        runCatching { FinanceCalculations.lineTotal(digits(line.packageCount), digits(line.unitPrice)) }.getOrNull()
    }
    val quantityBases = lines.map { line ->
        runCatching { FinanceCalculations.quantityToBase(digits(line.packageSize), line.unit, digits(line.packageCount)) }.getOrNull()
    }
    val totalForeignResult = runCatching {
        lineTotals.fold(0L) { total, value -> Math.addExact(total, value ?: error("قيمة أحد الأصناف تتجاوز الحد المسموح.")) }
    }
    val totalForeign = totalForeignResult.getOrDefault(0L)
    val totalYerResult = runCatching {
        lineTotals.fold(0L) { total, value ->
            Math.addExact(total, FinanceCalculations.toYemeniRials(value ?: error("قيمة أحد الأصناف غير صالحة."), rate))
        }
    }
    val totalYer = totalYerResult.getOrDefault(0L)
    var validation by remember { mutableStateOf("") }
    var saving by remember(initial?.id) { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (initial == null) "إضافة فاتورة" else "تعديل الفاتورة") },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(supplier, { supplier = it }, label = { Text("اسم التاجر / المورد") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(invoiceNumber, { invoiceNumber = it }, label = { Text("رقم الفاتورة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                MiyarDateField("تاريخ الفاتورة", dateMillis) { dateMillis = it }
                Text("حالة الفاتورة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = paymentStatus == "نقدًا", onClick = { paymentStatus = "نقدًا" }, label = { Text("نقدًا") })
                    FilterChip(selected = paymentStatus == "آجل", onClick = { paymentStatus = "آجل" }, label = { Text("آجل") })
                }
                Text("عملة الفاتورة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("YER", "SAR", "USD").forEach { c -> FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) }) }
                }
                if (currency != "YER") {
                    OutlinedTextField(
                        value = rateText,
                        onValueChange = { if (currency == "SAR") sarRate = it.filter { c -> c.isDigit() || c == '.' || c == ',' } else usdRate = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                        label = { Text("سعر صرف 1 $currency مقابل الريال اليمني") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("أصناف الفاتورة", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { lines.add(InvoiceLineDraft()) }) { Icon(Icons.Default.Add, null); Text("إضافة صنف") }
                }
                lines.forEachIndexed { index, line ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الصنف ${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { if (lines.size > 1) lines.removeAt(index) }) { Icon(Icons.Default.Delete, "حذف الصنف") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf("الأسمدة", "السموم").forEach { type ->
                                    FilterChip(
                                        selected = line.productType == type,
                                        onClick = {
                                            val allowed = if (type == "الأسمدة") listOf("كجم", "جرام") else listOf("لتر", "مل", "جرام")
                                            lines[index] = line.copy(productType = type, unit = line.unit.takeIf { it in allowed } ?: allowed.first())
                                        },
                                        label = { Text(type) }
                                    )
                                }
                            }
                            OutlinedTextField(line.productName, { lines[index] = line.copy(productName = it) }, label = { Text("الاسم التجاري") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(line.activeIngredient, { lines[index] = line.copy(activeIngredient = it) }, label = { Text("المادة الفعالة / العنصر") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(line.packageName, { lines[index] = line.copy(packageName = it) }, label = { Text("اسم العبوة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(line.packageSize, { lines[index] = line.copy(packageSize = it.filter(Char::isDigit)) }, label = { Text("مقدار الوحدة داخل العبوة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                val units = if (line.productType == "الأسمدة") listOf("كجم", "جرام") else listOf("لتر", "مل", "جرام")
                                units.forEach { unit -> FilterChip(selected = line.unit == unit, onClick = { lines[index] = line.copy(unit = unit) }, label = { Text(unit) }) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                OutlinedTextField(line.packageCount, { lines[index] = line.copy(packageCount = it.filter(Char::isDigit)) }, label = { Text("عدد العبوات") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                                OutlinedTextField(line.unitPrice, { lines[index] = line.copy(unitPrice = it.filter(Char::isDigit)) }, label = { Text("سعر العبوة ($currency)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                            }
                            val lineTotal = lineTotals.getOrNull(index)
                            Text(
                                lineTotal?.let { "إجمالي الصنف: $it $currency" } ?: "تعذر احتساب قيمة هذا الصنف؛ راجع الكمية والسعر.",
                                fontWeight = FontWeight.SemiBold,
                                color = if (lineTotal == null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات الفاتورة") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                HorizontalDivider()
                Text("الإجمالي: $totalForeign $currency", fontWeight = FontWeight.Bold)
                Text("ما يعادله: ${formatMoney(totalYer)}", color = Emerald, fontWeight = FontWeight.ExtraBold)
                if (validation.isNotBlank()) Text(validation, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(enabled = !saving, onClick = {
                when {
                    supplier.isBlank() -> validation = "أدخل اسم التاجر أو المورد."
                    invoiceNumber.isBlank() -> validation = "أدخل رقم الفاتورة."
                    lines.any { it.productName.isBlank() || digits(it.packageCount) <= 0 || digits(it.packageSize) <= 0 || digits(it.unitPrice) <= 0 } -> validation = "أكمل اسم الصنف والعبوة والكمية والسعر لكل صنف."
                    quantityBases.any { it == null || it <= 0L } -> validation = "الكمية المدخلة أكبر من الحد المسموح أو غير صحيحة."
                    lineTotals.any { it == null } || totalForeignResult.isFailure -> validation = "إجمالي الفاتورة أكبر من الحد المسموح للحساب."
                    currency != "YER" && rate <= 0 -> validation = "أدخل سعر صرف صحيحًا."
                    totalYerResult.isFailure -> validation = "تعذر تحويل قيمة الفاتورة؛ راجع المبلغ وسعر الصرف."
                    else -> {
                        val invoice = InvoiceEntity(
                            id = initial?.id ?: 0,
                            supplier = supplier.trim(), invoiceNumber = invoiceNumber.trim(), dateMillis = dateMillis,
                            paymentStatus = paymentStatus, currency = currency, exchangeRateScaled = rate,
                            totalForeign = totalForeign, totalYer = totalYer, notes = notes.trim()
                        )
                        val invoiceItems = lines.mapIndexed { index, line ->
                            val packCount = digits(line.packageCount)
                            val packSize = digits(line.packageSize)
                            val qty = requireNotNull(quantityBases[index])
                            val foreign = requireNotNull(lineTotals[index])
                            val yer = FinanceCalculations.toYemeniRials(foreign, rate)
                            InvoiceItemEntity(
                                invoiceId = invoice.id, stockItemId = 0,
                                productType = line.productType, productName = line.productName.trim(), activeIngredient = line.activeIngredient.trim(),
                                packageName = line.packageName.trim(), packageSize = packSize, packageCount = packCount, unit = line.unit,
                                quantityBase = qty, unitPriceForeign = digits(line.unitPrice), lineTotalForeign = foreign, lineTotalYer = yer
                            )
                        }
                        saving = true
                        onSave(invoice, invoiceItems, sarRate, usdRate) { saving = false }
                    }
                }
            }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ الفاتورة") }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun MiyarInventoryScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val stock by dao.observeStockItems().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var selectedType by remember { mutableStateOf("الأسمدة") }
    var showAdd by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val filtered = stock.filter { it.productType == selectedType }
    val receivedGrams = filtered.filter { it.baseUnit == "g" }.sumOf { it.totalReceivedBase }
    val usedGrams = filtered.filter { it.baseUnit == "g" }.sumOf { it.totalUsedBase }
    val remainingGrams = filtered.filter { it.baseUnit == "g" }.sumOf { it.quantityBase }
    val receivedMl = filtered.filter { it.baseUnit == "ml" }.sumOf { it.totalReceivedBase }
    val usedMl = filtered.filter { it.baseUnit == "ml" }.sumOf { it.totalUsedBase }
    val remainingMl = filtered.filter { it.baseUnit == "ml" }.sumOf { it.quantityBase }
    fun mixedQuantity(grams: Long, ml: Long): String = listOfNotNull(
        grams.takeIf { it > 0 }?.let { stockQuantity(it, "g") },
        ml.takeIf { it > 0 }?.let { stockQuantity(it, "ml") }
    ).joinToString(" • ").ifBlank { "0" }

    Column(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("المخزون", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                Text("يتحدث من الفواتير والعمليات الزراعية", style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("رصيد") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("الأسمدة", "السموم").forEach { type -> FilterChip(selected = selectedType == type, onClick = { selectedType = type }, label = { Text(type) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SummaryMiniCard("عدد الأصناف", filtered.size.toString(), Modifier.weight(1f))
            SummaryMiniCard("المستلم", mixedQuantity(receivedGrams, receivedMl), Modifier.weight(1f))
            SummaryMiniCard("المستخدم", mixedQuantity(usedGrams, usedMl), Modifier.weight(1f))
        }
        FinancialCard("📦 الكمية المتبقية", mixedQuantity(remainingGrams, remainingMl), "الرصيد الحالي بعد خصم الاستخدامات المسجلة")
        if (filtered.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("لا توجد أصناف في مخزون $selectedType", fontWeight = FontWeight.Bold)
                    Text("سجّل فاتورة أو أضف رصيدًا افتتاحيًا.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
            items(filtered, key = { it.id }) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(item.productName, fontWeight = FontWeight.Bold, color = Emerald)
                        if (item.activeIngredient.isNotBlank()) Text("المادة الفعالة / العنصر: ${item.activeIngredient}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("المتبقي: ${stockQuantity(item.quantityBase, item.baseUnit)}", fontWeight = FontWeight.Bold)
                            Text("المستخدم: ${stockQuantity(item.totalUsedBase, item.baseUnit)}", color = Green)
                        }
                        Text("إجمالي المستلم: ${stockQuantity(item.totalReceivedBase, item.baseUnit)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    if (showAdd) StockOpeningDialog(selectedType, onDismiss = { showAdd = false }) { name, ingredient, unit, quantity ->
        scope.launch {
            try { dao.addOpeningStock(selectedType, name, ingredient, unit, quantity); showAdd = false }
            catch (t: Throwable) { error = t.message ?: "تعذر إضافة الرصيد." }
        }
    }
    if (error != null) AlertDialog(onDismissRequest = { error = null }, title = { Text("تنبيه المخزون") }, text = { Text(error!!) }, confirmButton = { TextButton(onClick = { error = null }) { Text("حسنًا") } })
}

@Composable
private fun SummaryMiniCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Green)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StockOpeningDialog(type: String, onDismiss: () -> Unit, onSave: (String, String, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var ingredient by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(if (type == "الأسمدة") "كجم" else "لتر") }
    var quantity by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة رصيد افتتاحي: $type") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم الصنف") }, singleLine = true)
                OutlinedTextField(ingredient, { ingredient = it }, label = { Text("المادة الفعالة / العنصر") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (if (type == "الأسمدة") listOf("كجم", "جرام") else listOf("لتر", "مل", "جرام")).forEach { u -> FilterChip(selected = unit == u, onClick = { unit = u }, label = { Text(u) }) }
                }
                OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit) }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = {
            val base = digits(quantity) * baseMultiplier(unit)
            if (name.isBlank() || base <= 0) error = "أدخل اسم الصنف وكمية أكبر من صفر."
            else onSave(name.trim(), ingredient.trim(), unit, base)
        }) { Text("إضافة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun MiyarReportsScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val expenses by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
    val invoices by dao.observeInvoices().collectAsStateWithLifecycle(initialValue = emptyList())
    val today = remember { System.currentTimeMillis() }
    val cal = remember { java.util.Calendar.getInstance().apply { timeInMillis = today; set(java.util.Calendar.DAY_OF_MONTH, 1); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) } }
    var from by remember { mutableLongStateOf(cal.timeInMillis) }
    var to by remember { mutableLongStateOf(today) }
    val endOfDay = remember(to) { java.util.Calendar.getInstance().apply { timeInMillis = to; set(java.util.Calendar.HOUR_OF_DAY, 23); set(java.util.Calendar.MINUTE, 59); set(java.util.Calendar.SECOND, 59); set(java.util.Calendar.MILLISECOND, 999) }.timeInMillis }
    val filtered = expenses.filter { it.dateMillis in from..endOfDay }
    val costs = filtered.filter { it.category != "القطفات" }
    val revenue = filtered.filter { it.category == "القطفات" }
    val totalCost = costs.sumOf { it.amount }
    val totalRevenue = revenue.sumOf { it.amount }
    val invoiceTotal = invoices.filter { it.dateMillis in from..endOfDay }.sumOf { it.totalYer }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("التقارير", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
        Text("حدد الفترة لعرض المصروفات والمردود والفواتير.", style = MaterialTheme.typography.bodySmall)
        MiyarDateField("من تاريخ", from) { from = it }
        MiyarDateField("إلى تاريخ", to) { to = it }
        FinancialCard("💸 إجمالي الخرج", formatMoney(totalCost), "${costs.size} عملية خلال الفترة")
        FinancialCard("💰 إجمالي المردود", formatMoney(totalRevenue), "${revenue.size} قطفة خلال الفترة")
        FinancialCard("🧾 قيمة الفواتير بالريال اليمني", formatMoney(invoiceTotal), "${invoices.count { it.dateMillis in from..endOfDay }} فاتورة خلال الفترة")
        FinancialCard("📊 صافي الفرق", formatMoney(totalRevenue - totalCost), "المردود ناقص المصروفات المسجلة")
        Text("تفصيل المصروفات حسب القسم", color = Emerald, fontWeight = FontWeight.Bold)
        costs.groupBy { it.category }.toSortedMap().forEach { (category, records) ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(category, fontWeight = FontWeight.Bold)
                        Text("${records.size} عملية", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(formatMoney(records.sumOf { it.amount }), fontWeight = FontWeight.Bold, color = Emerald)
                }
            }
        }
        Text("العمليات خلال الفترة", color = Emerald, fontWeight = FontWeight.Bold)
        filtered.forEach { record ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(record.title, fontWeight = FontWeight.SemiBold)
                        Text("${record.plantationName} • ${record.category} • ${localDate(record.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(formatMoney(record.amount), fontWeight = FontWeight.Bold)
                }
            }
        }
        if (filtered.isEmpty() && invoiceTotal == 0L) Text("لا توجد سجلات في الفترة المحددة.", color = Green)
    }
}
