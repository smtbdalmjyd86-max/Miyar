package com.miyar.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class FinanceCalculationsTest {
    @Test fun kilogramPackagesConvertToGrams() {
        assertEquals(25000L, FinanceCalculations.quantityToBase(5, "كجم", 5))
    }

    @Test fun gramPackagesRemainGrams() {
        assertEquals(1500L, FinanceCalculations.quantityToBase(500, "جرام", 3))
    }

    @Test fun litersConvertToMilliliters() {
        assertEquals(12000L, FinanceCalculations.quantityToBase(2, "لتر", 6))
    }

    @Test fun millilitersRemainMilliliters() {
        assertEquals(750L, FinanceCalculations.quantityToBase(250, "مل", 3))
    }

    @Test fun invoiceLineTotalUsesPackageCount() {
        assertEquals(3600L, FinanceCalculations.lineTotal(12, 300))
    }

    @Test fun exchangeRateConvertsCurrencyToYER() {
        assertEquals(2505L, FinanceCalculations.toYemeniRials(10, 250500))
    }

    @Test(expected = ArithmeticException::class)
    fun quantityOverflowIsRejected() {
        FinanceCalculations.quantityToBase(Long.MAX_VALUE, "كجم", 2)
    }
}
