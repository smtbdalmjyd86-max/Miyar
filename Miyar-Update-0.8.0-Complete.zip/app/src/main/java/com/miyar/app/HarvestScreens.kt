@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.miyar.app

import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun hDate(v:Long)=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(v))
private fun hParse(v:String)=try{SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(v)?.time?:System.currentTimeMillis()}catch(_:Exception){System.currentTimeMillis()}

@Composable private fun DateField(label:String,value:Long,onChange:(Long)->Unit) {
 var show by remember { mutableStateOf(false) }
 OutlinedButton(onClick={show=true},modifier=Modifier.fillMaxWidth()) { Text("$label: ${hDate(value)}") }
 if(show) { val state= rememberDatePickerState(initialSelectedDateMillis=value); DatePickerDialog(onDismissRequest={show=false},confirmButton={TextButton(onClick={state.selectedDateMillis?.let(onChange);show=false}){Text("اختيار")}},dismissButton={TextButton(onClick={show=false}){Text("إلغاء")}}){DatePicker(state)} }
}
@Composable private fun NumField(label:String,value:String,onValue:(String)->Unit,modifier:Modifier=Modifier.fillMaxWidth()) {
 OutlinedTextField(value=value,onValueChange={onValue(it.filter(Char::isDigit))},label={Text(label)},modifier=modifier,singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
}

@Composable fun MiyarHarvestScreen(dao:MiyarDao,plantations:List<PlantationEntity>) {
 val scope= rememberCoroutineScope(); var page by remember { mutableStateOf("home") }; var selectedHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }; var selectedDay by remember { mutableStateOf<PersonalHarvestDayEntity?>(null) }
 var showNew by remember { mutableStateOf(false) }; var newPlotId by remember { mutableLongStateOf(0L) }; var editingHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }; var longPressedHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }; var longPressedDay by remember { mutableStateOf<PersonalHarvestDayEntity?>(null) }; 
 val harvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(emptyList()); val buyers by dao.observeBuyers().collectAsStateWithLifecycle(emptyList()); val allSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(emptyList()); val distributors by dao.observeDistributors().collectAsStateWithLifecycle(emptyList()); val debtors by dao.observeDebtors().collectAsStateWithLifecycle(emptyList())
 var selectedSale by remember { mutableStateOf<BuyerSaleEntity?>(null) }; var selectedBuyer by remember { mutableStateOf<QatBuyerEntity?>(null) }
 Column(Modifier.fillMaxSize()) {
  if(page!="home") TextButton(onClick={page=if(page=="day"||page=="newDay"||page=="editDay") "harvest" else "home";selectedDay=null}){Text("← رجوع")}
  when(page){
   "home" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
    Text("قسم القطفات",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Emerald)
    HarvestChoice("🌿","قطفة شخصية","إدارة القطف اليومي والإنتاج والمبيعات") { page="personal" }
    HarvestChoice("📁","ملفات البائعين والعملاء","${distributors.size} بائع • ${debtors.size} عميل آجل") { page="parties" }
    HarvestChoice("🤝","البيع لمشتري","تسجيل الاتفاق والمدة والواصلات") { page="buyer" }
    HarvestChoice("📂","ملفات المشترين","سجلات المشترين والقطفات") { page="buyerFiles" }
    Text("عمليات البيع لمشترٍ",fontWeight=FontWeight.Bold)
    allSales.forEach { sale -> val b=buyers.firstOrNull{it.id==sale.buyerId}; Card(onClick={selectedSale=sale;selectedBuyer=b;page="saleDetail"},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(b?.name?:"مشتري",fontWeight=FontWeight.Bold);Text("${sale.harvestName} • ${sale.agreedAmount} ريال")}} }
   }
   "personal" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
    Text("اختر الموضع الذي سيتم القطف منه",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)
    plantations.forEach { p -> Card(onClick={showNew=true; selectedHarvest=null; newPlotId=p.id},modifier=Modifier.fillMaxWidth()){Text("🌱  ${p.name}",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)} }
    if(plantations.isEmpty()) Text("لا توجد مواضع مسجلة. أضف موضعًا أولًا.")
    Divider(); Text("القطفات الشخصية المسجلة",fontWeight=FontWeight.Bold)
    harvests.forEach { item -> Card(modifier=Modifier.fillMaxWidth().combinedClickable(onClick={selectedHarvest=item;page="harvest"},onLongClick={longPressedHarvest=item})) { Column(Modifier.padding(14.dp)){Text(item.name,fontWeight=FontWeight.Bold);Text("${plantations.firstOrNull{it.id==item.plantationId}?.name?:"موضع"} • ${hDate(item.startMillis)}");Text("اضغط للفتح، واضغط مطولًا للتعديل أو الحذف",style=MaterialTheme.typography.bodySmall)} } }
   }
   "harvest" -> {
    val h=selectedHarvest
    if(h!=null) Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
     val plotName=plantations.firstOrNull{it.id==h.plantationId}?.name?:"موضع غير معروف"
     Text("${h.name} — $plotName",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Emerald)
     Text("بداية القطفة: ${hDate(h.startMillis)} • المتوقع: ${hDate(h.expectedEndMillis)}")
     if(h.actualEndMillis>0) Text("الانتهاء الفعلي: ${hDate(h.actualEndMillis)}")
     val days by dao.observeHarvestDays(h.id).collectAsStateWithLifecycle(emptyList())
     Button(onClick={selectedDay=null;page="newDay"},modifier=Modifier.fillMaxWidth()){Text("＋ إضافة يوم جديد")}
     Text("أيام القطفة",fontWeight=FontWeight.Bold)
     days.forEach { day -> Card(modifier=Modifier.fillMaxWidth().combinedClickable(onClick={selectedDay=day;page="day"},onLongClick={longPressedDay=day})) { Column(Modifier.padding(14.dp)){Text("${plotName} • ${h.name}",fontWeight=FontWeight.Bold);Text("يوم القطفة • ${hDate(day.dateMillis)}");Text("القطافون: ${day.pickerCount} • الأجور: ${day.pickerCount*day.pickerWage} ريال");Text("اضغط للعرض، واضغط مطولًا للتعديل أو الحذف",style=MaterialTheme.typography.bodySmall)} } }
     if(days.isEmpty()) Text("لم تسجل أيام لهذه القطفة بعد.")
    }
   }
   "newDay" -> { val h=selectedHarvest; if(h!=null) DayEditor(dao,h,plantations, null, onSaved={page="harvest"}) }
   "day" -> { val h=selectedHarvest;val d=selectedDay;if(h!=null&&d!=null) DayDetails(dao,h,d,plantations) }
   "parties" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Text("ملفات البائعين",fontWeight=FontWeight.Bold);distributors.forEach{Card(Modifier.fillMaxWidth()){Text("🧑 ${it.name}",Modifier.padding(12.dp))}};Divider();Text("ملفات العملاء بالأجل",fontWeight=FontWeight.Bold);debtors.forEach{Card(Modifier.fillMaxWidth()){Text("👤 ${it.name}",Modifier.padding(12.dp))}} }
   "buyer" -> BuyerSaleForm080(dao,buyers){page="home"}
   "buyerFiles" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)){Text("ملفات المشترين",fontWeight=FontWeight.Bold);buyers.forEach{buyer->val count=allSales.count{it.buyerId==buyer.id};Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Column(Modifier.padding(12.dp)){Text(buyer.name,fontWeight=FontWeight.Bold);Text("عدد القطفات: $count")}}}}
   "saleDetail" -> { val sale=selectedSale;val buyer=selectedBuyer;if(sale!=null&&buyer!=null) SaleDetail080(dao,sale,buyer) }
  }
 }
 if(showNew) NewHarvestDialog(dao,plantations,newPlotId,{showNew=false;page="harvest";selectedHarvest=it},{showNew=false})
 longPressedHarvest?.let { h ->
  AlertDialog(onDismissRequest={longPressedHarvest=null},title={Text(h.name)},text={Text("اختر الإجراء")},
   confirmButton={TextButton(onClick={longPressedHarvest=null;editingHarvest=h}){Text("تعديل")}},
   dismissButton={Row {
    TextButton(onClick={scope.launch { dao.deletePersonalHarvestWithDays(h.id); longPressedHarvest=null }}){Text("حذف")}
    TextButton(onClick={longPressedHarvest=null;selectedHarvest=h;page="harvest"}){Text("فتح")}
   }})
 }
 if(editingHarvest!=null) EditHarvestDialog(dao,editingHarvest!!,onDone={updated->editingHarvest=null;selectedHarvest=updated;page="harvest"},onCancel={editingHarvest=null})
 longPressedDay?.let { d ->
  AlertDialog(onDismissRequest={longPressedDay=null},title={Text("يوم ${hDate(d.dateMillis)}")},text={Text("هل تريد تعديل اليوم أو حذفه؟")},
   confirmButton={TextButton(onClick={longPressedDay=null;selectedDay=d;page="editDay"}){Text("تعديل")}},
   dismissButton={Row {
    TextButton(onClick={scope.launch { dao.deleteHarvestDayLines(d.id); dao.deletePersonalHarvestDay(d.id); longPressedDay=null }}){Text("حذف")}
    TextButton(onClick={longPressedDay=null}){Text("إلغاء")}
   }})
 }
 if(page=="editDay" && selectedHarvest!=null && selectedDay!=null) DayEditor(dao,selectedHarvest!!,plantations,selectedDay!!,onSaved={page="harvest"})
}


@Composable private fun HarvestChoice(emoji:String,title:String,subtitle:String,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=androidx.compose.ui.graphics.Color.White)){Row(Modifier.padding(18.dp),horizontalArrangement=Arrangement.spacedBy(14.dp)){Text(emoji,style=MaterialTheme.typography.headlineLarge);Column{Text(title,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.bodySmall)}}}}

@Composable private fun NewHarvestDialog(dao:MiyarDao,plots:List<PlantationEntity>,plotId:Long,onSaved:(PersonalHarvestEntity)->Unit,onCancel:()->Unit){val scope= rememberCoroutineScope();var name by remember{mutableStateOf("")};var start by remember{mutableLongStateOf(System.currentTimeMillis())};var expected by remember{mutableLongStateOf(System.currentTimeMillis())};var actual by remember{mutableLongStateOf(0L)};var showActual by remember{mutableStateOf(false)};val plot=plots.firstOrNull{it.id==plotId};AlertDialog(onDismissRequest=onCancel,title={Text("بيانات القطفة")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("الموضع: ${plot?.name?:""}");OutlinedTextField(name,{name=it},label={Text("اسم / رقم القطفة")},modifier=Modifier.fillMaxWidth());DateField("تاريخ بداية القطفة",start){start=it};DateField("التاريخ المتوقع للانتهاء",expected){expected=it};TextButton(onClick={showActual=!showActual}){Text("إضافة تاريخ الانتهاء الفعلي لاحقًا")};if(showActual)DateField("التاريخ الفعلي للانتهاء",actual.takeIf{it>0}?:System.currentTimeMillis()){actual=it}}},confirmButton={TextButton(onClick={if(name.isNotBlank()&&plot!=null)scope.launch{val id=dao.insertPersonalHarvest(PersonalHarvestEntity(plantationId=plot.id,name=name.trim(),startMillis=start,expectedEndMillis=expected,actualEndMillis=actual,productsText="",cashSalesText="",debtorSalesText="",pickerCount=0,pickerWage=0,extraWages=0,bagsAndOther=0,transportAndClearance=0,notes=""));onSaved(PersonalHarvestEntity(id=id,plantationId=plot.id,name=name.trim(),startMillis=start,expectedEndMillis=expected,actualEndMillis=actual,productsText="",cashSalesText="",debtorSalesText="",pickerCount=0,pickerWage=0,extraWages=0,bagsAndOther=0,transportAndClearance=0,notes=""))}}){Text("حفظ")}},dismissButton={TextButton(onClick=onCancel){Text("إلغاء")}})}

@Composable private fun EditHarvestDialog(dao:MiyarDao,h:PersonalHarvestEntity,onDone:(PersonalHarvestEntity)->Unit,onCancel:()->Unit){val scope= rememberCoroutineScope();var name by remember{mutableStateOf(h.name)};var start by remember{mutableLongStateOf(h.startMillis)};var expected by remember{mutableLongStateOf(h.expectedEndMillis)};var actual by remember{mutableLongStateOf(h.actualEndMillis)};var showActual by remember{mutableStateOf(h.actualEndMillis>0)};AlertDialog(onDismissRequest=onCancel,title={Text("تعديل بيانات القطفة")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("اسم / رقم القطفة")},modifier=Modifier.fillMaxWidth());DateField("بداية القطفة",start){start=it};DateField("الانتهاء المتوقع",expected){expected=it};TextButton(onClick={showActual=!showActual;if(!showActual)actual=0L}){Text(if(showActual)"إخفاء تاريخ الانتهاء الفعلي" else "إدخال تاريخ الانتهاء الفعلي")};if(showActual)DateField("الانتهاء الفعلي",actual.takeIf{it>0}?:System.currentTimeMillis()){actual=it}}},confirmButton={TextButton(onClick={scope.launch{val updated=h.copy(name=name.trim(),startMillis=start,expectedEndMillis=expected,actualEndMillis=if(showActual)actual else 0L);dao.updatePersonalHarvest(updated);onDone(updated)}}){Text("حفظ")}},dismissButton={TextButton(onClick=onCancel){Text("إلغاء")}})}

@Composable private fun DayDetails(dao:MiyarDao,h:PersonalHarvestEntity,d:PersonalHarvestDayEntity,plots:List<PlantationEntity>){val lines by dao.observeHarvestDayLines(d.id).collectAsStateWithLifecycle(emptyList());val plot=plots.firstOrNull{it.id==h.plantationId}?.name?:"";Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("تفاصيل يوم القطفة",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Emerald);Text("اسم الموضع: $plot");Text("اسم / رقم القطفة: ${h.name}");Text("التاريخ: ${hDate(d.dateMillis)}");listOf("موزع السوق" to "distributor","المبيعات النقدية" to "cash","المبيعات بالأجل" to "debt").forEach{(title,cat)->Text(title,fontWeight=FontWeight.Bold);val group=lines.filter{it.category==cat};group.forEach{Text("${if(it.partyName.isNotBlank())it.partyName+" • " else ""}${it.productType} • العدد ${it.quantity} • الوحدة ${it.unitPrice} • الإجمالي ${it.total} ريال")};Text("الإجمالي: ${group.sumOf{it.total}} ريال",fontWeight=FontWeight.Bold)};Divider();Text("القطافون: ${d.pickerCount} × ${d.pickerWage} = ${d.pickerCount*d.pickerWage} ريال");Text("مصاريف أخرى: ${d.otherExpenses} ريال");Text("الملاحظات: ${d.notes}");Text("إجمالي المبيعات: ${lines.filter{it.category!="debt"}.sumOf{it.total}} ريال",fontWeight=FontWeight.Bold,color=Emerald);Text("إجمالي الآجل: ${lines.filter{it.category=="debt"}.sumOf{it.total}} ريال",fontWeight=FontWeight.Bold,color=Emerald)}}

private data class HarvestRowState(val category:String,val party:String,val type:String,val qty:String,val price:String)

@Composable private fun DayEditor(dao:MiyarDao,h:PersonalHarvestEntity,plots:List<PlantationEntity>,editing:PersonalHarvestDayEntity?,onSaved:()->Unit){val scope= rememberCoroutineScope();var date by remember{mutableLongStateOf(editing?.dateMillis?:System.currentTimeMillis())};var workers by remember{mutableStateOf(editing?.pickerCount?.toString()?:"")};var wage by remember{mutableStateOf(editing?.pickerWage?.toString()?:"")};var other by remember{mutableStateOf(editing?.otherExpenses?.toString()?:"")};var notes by remember{mutableStateOf(editing?.notes?:"")};var rows by remember{mutableStateOf(listOf(HarvestRowState("distributor","","عود","","")))};val existingLines by dao.observeHarvestDayLines(editing?.id?:-1L).collectAsStateWithLifecycle(emptyList());LaunchedEffect(editing?.id,existingLines){if(editing!=null && existingLines.isNotEmpty()) rows=existingLines.map{HarvestRowState(it.category,it.partyName,it.productType,it.quantity.toString(),it.unitPrice.toString())}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(if(editing==null)"إضافة يوم جديد" else "تعديل يوم القطفة",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Emerald);Text("اسم الموضع: ${plots.firstOrNull{it.id==h.plantationId}?.name?:""}");Text("اسم / رقم القطفة: ${h.name}");DateField("تاريخ يوم القطفة",date){date=it}
 rows.forEachIndexed{index,row->HarvestDayLineEditor(row,onChange={updated->rows=rows.toMutableList().also{it[index]=updated}},onRemove={rows=rows.toMutableList().also{it.removeAt(index)}})}
 Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){TextButton(onClick={rows=rows+HarvestRowState("distributor","","عود","","")}){Text("＋ بائع")};TextButton(onClick={rows=rows+HarvestRowState("cash","","عود","","")}){Text("＋ بيع نقدي")};TextButton(onClick={rows=rows+HarvestRowState("debt","","عود","","")}){Text("＋ عميل آجل")}}
 Text("أجور ومصاريف",fontWeight=FontWeight.Bold);NumField("عدد القطافين",workers,{workers=it});NumField("أجر القطاف الواحد",wage,{wage=it});Text("إجمالي أجور القطافين: ${(workers.toLongOrNull()?:0)*(wage.toLongOrNull()?:0)} ريال",fontWeight=FontWeight.Bold);NumField("خرج آخر: أكياس وتوصيل ومصاريف أخرى",other,{other=it});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات أخرى")},modifier=Modifier.fillMaxWidth(),minLines=2)
 Button(onClick={scope.launch{val dayId=if(editing==null)dao.insertPersonalHarvestDay(PersonalHarvestDayEntity(harvestId=h.id,dateMillis=date,pickerCount=workers.toLongOrNull()?:0,pickerWage=wage.toLongOrNull()?:0,otherExpenses=other.toLongOrNull()?:0,notes=notes)) else {dao.updatePersonalHarvestDay(editing.copy(dateMillis=date,pickerCount=workers.toLongOrNull()?:0,pickerWage=wage.toLongOrNull()?:0,otherExpenses=other.toLongOrNull()?:0,notes=notes));dao.deleteHarvestDayLines(editing.id);editing.id};rows.filter{it.qty.toLongOrNull()!=null&&it.price.toLongOrNull()!=null&&it.qty.toLong()>0}.forEach{r->val party=r.party.trim();if(r.category=="distributor"&&party.isNotBlank()&&dao.findDistributor(party)==null)dao.insertDistributor(MarketDistributorEntity(name=party));if(r.category=="debt"&&party.isNotBlank()&&dao.findDebtor(party)==null)dao.insertDebtor(HarvestDebtorEntity(name=party));val q=r.qty.toLong();val p=r.price.toLong();dao.insertPersonalHarvestDayLine(PersonalHarvestDayLineEntity(dayId=dayId,category=r.category,partyName=party,productType=r.type.trim().ifBlank{"غير محدد"},quantity=q,unitPrice=p,total=q*p))};onSaved()}},modifier=Modifier.fillMaxWidth()){Text("حفظ اليوم")}
 }
}


@Composable private fun HarvestDayLineEditor(row:HarvestRowState,onChange:(HarvestRowState)->Unit,onRemove:()->Unit){
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
  Text(when(row.category){"distributor"->"الموزع للسوق";"cash"->"المبيعات النقدية";else->"المبيعات بالأجل"},fontWeight=FontWeight.Bold)
  if(row.category!="cash") OutlinedTextField(row.party,{onChange(row.copy(party=it))},label={Text(if(row.category=="debt")"اسم العميل" else "اسم البائع")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(row.type,{onChange(row.copy(type=it))},label={Text("نوع المنتج")},modifier=Modifier.fillMaxWidth())
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
   NumField("عدد المنتج",row.qty,{onChange(row.copy(qty=it))},Modifier.weight(1f))
   NumField("سعر الوحدة",row.price,{onChange(row.copy(price=it))},Modifier.weight(1f))
  }
  Text("الإجمالي: ${(row.qty.toLongOrNull()?:0)*(row.price.toLongOrNull()?:0)} ريال",fontWeight=FontWeight.Bold)
  TextButton(onClick=onRemove){Text("إزالة هذا الصنف")}
 }}
}

@Composable private fun BuyerSaleForm080(dao:MiyarDao,buyers:List<QatBuyerEntity>,onSaved:()->Unit){val scope= rememberCoroutineScope();var name by remember{mutableStateOf("")};var harvest by remember{mutableStateOf("")};var agreed by remember{mutableStateOf("")};var paid by remember{mutableStateOf("")};var date by remember{mutableLongStateOf(System.currentTimeMillis())};var expected by remember{mutableLongStateOf(System.currentTimeMillis())};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("البيع لمشتري",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);OutlinedTextField(name,{name=it},label={Text("اسم المشتري")},modifier=Modifier.fillMaxWidth());if(buyers.isNotEmpty())Text("المشترون المسجلون: ${buyers.joinToString("، "){it.name}}",style=MaterialTheme.typography.bodySmall);OutlinedTextField(harvest,{harvest=it},label={Text("اسم / رقم القطفة")},modifier=Modifier.fillMaxWidth());NumField("السعر المتفق عليه",agreed,{agreed=it});NumField("الواصل عند البيع",paid,{paid=it});DateField("تاريخ البيع",date){date=it};DateField("التاريخ المتوقع للانتهاء",expected){expected=it};Button(onClick={val a=agreed.toLongOrNull()?:0;val p=paid.toLongOrNull()?:0;if(name.isNotBlank()&&harvest.isNotBlank()&&a>0)scope.launch{val old=buyers.firstOrNull{it.name.trim().equals(name.trim(),true)};val id=old?.id?:dao.insertBuyer(QatBuyerEntity(name=name.trim()));dao.insertBuyerSale(BuyerSaleEntity(buyerId=id,harvestName=harvest,agreedAmount=a,initialPaid=p,saleDateMillis=date,expectedEndMillis=expected));onSaved()}},modifier=Modifier.fillMaxWidth()){Text("حفظ عملية البيع")}}}
@Composable private fun SaleDetail080(dao:MiyarDao,sale:BuyerSaleEntity,buyer:QatBuyerEntity){val payments by dao.observeBuyerPayments(sale.id).collectAsStateWithLifecycle(emptyList());val scope= rememberCoroutineScope();var amount by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("ملف ${buyer.name}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);val paid=sale.initialPaid+payments.sumOf{it.amount};Text("القطفة: ${sale.harvestName}\nالمتفق عليه: ${sale.agreedAmount}\nالواصل: $paid\nالباقي: ${(sale.agreedAmount-paid).coerceAtLeast(0)} ريال");NumField("مبلغ واصلة جديدة",amount,{amount=it});Button(onClick={val n=amount.toLongOrNull()?:0;if(n>0)scope.launch{dao.insertBuyerPayment(BuyerPaymentEntity(saleId=sale.id,amount=n));amount=""}},modifier=Modifier.fillMaxWidth()){Text("إضافة واصلة")};Text("سجل الواصلات",fontWeight=FontWeight.Bold);payments.forEach{Text("${hDate(it.dateMillis)} • ${it.amount} ريال")}}}
