package com.miyar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import java.security.MessageDigest
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Emerald = androidx.compose.ui.graphics.Color(0xFF103D32)
private val Green = androidx.compose.ui.graphics.Color(0xFF147D64)
private val Cream = androidx.compose.ui.graphics.Color(0xFFF7F3E8)
private val Gold = androidx.compose.ui.graphics.Color(0xFFC7A65A)

class MainActivity : ComponentActivity() {
    private val dao by lazy { MiyarDatabase.get(this).dao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 731)
        }
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Emerald,
                    secondary = Gold,
                    background = Cream,
                    surface = androidx.compose.ui.graphics.Color.White
                )
            ) {
                MiyarApp(dao)
            }
        }
    }
}

@Composable
private fun MiyarApp(dao: MiyarDao) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_security", android.content.Context.MODE_PRIVATE) }
    var configuredPin by remember { mutableStateOf(prefs.getString("pin_hash", null)) }
    var unlocked by remember { mutableStateOf(configuredPin == null) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var showPinSettings by remember { mutableStateOf(false) }
    var showPinSetup by remember { mutableStateOf(false) }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var pinSettingsMessage by remember { mutableStateOf("") }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, configuredPin) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && configuredPin != null) {
                unlocked = false
                pinInput = ""
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val totalExpenses by dao.observeTotalExpenses().collectAsStateWithLifecycle(initialValue = 0L)
    val totalRevenue by dao.observeTotalRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    val harvestCount by dao.observeHarvestCount().collectAsStateWithLifecycle(initialValue = 0L)
    var selected by remember { mutableStateOf<PlantationEntity?>(null) }
    var showAddPlantation by remember { mutableStateOf(false) }
    var showAddExpense by remember { mutableStateOf(false) }
    var showChoosePlantation by remember { mutableStateOf(false) }
    var showChooseCategory by remember { mutableStateOf(false) }
    var editingExpense by remember { mutableStateOf<ExpenseEntity?>(null) }
    var plantationToDelete by remember { mutableStateOf<PlantationEntity?>(null) }
    var deleteMessage by remember { mutableStateOf<String?>(null) }
    var showAbout by remember { mutableStateOf(false) }
    var currentSection by remember { mutableStateOf("الرئيسية") }
    val sections = listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات", "الفواتير والتقارير")
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    BackHandler(enabled = unlocked && (selected != null || currentSection != "الرئيسية" || showPinSettings || showPinSetup || showAbout || showChooseCategory || showChoosePlantation || showAddExpense || showAddPlantation)) {
        when {
            showPinSettings -> showPinSettings = false
            showPinSetup -> showPinSetup = false
            showAbout -> showAbout = false
            showChooseCategory -> showChooseCategory = false
            showChoosePlantation -> showChoosePlantation = false
            showAddExpense -> { showAddExpense = false; editingExpense = null }
            showAddPlantation -> showAddPlantation = false
            selected != null -> selected = null
            currentSection != "الرئيسية" -> { currentSection = "الرئيسية"; selected = null }
            else -> { /* في الرئيسية لا نغلق التطبيق من زر الرجوع؛ نترك النظام يضعه بالخلفية */ }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = Cream) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MiyarMark(Modifier.size(54.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("أهلاً بك في معيار", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
                                Text("إدارة أدق - مردود أوضح", color = Green, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    HorizontalDivider(color = Gold.copy(alpha = 0.6f))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("الرئيسية") },
                        selected = currentSection == "الرئيسية",
                        onClick = { currentSection = "الرئيسية"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        icon = { Text("🌱") },
                        label = { Text("المواضع الزراعية") },
                        selected = currentSection == "المواضع الزراعية",
                        onClick = { currentSection = "المواضع الزراعية"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    sections.forEach { section ->
                        NavigationDrawerItem(
                            icon = { Text(when (section) { "الأسمدة" -> "🌿"; "السموم" -> "🐛"; "المياه" -> "💧"; "الأعمال اليدوية" -> "🧑‍🌾"; "القطفات" -> "🧺"; "الفواتير والتقارير" -> "📊"; else -> "📝" }) },
                            label = { Text(section) },
                            selected = currentSection == section,
                            onClick = { currentSection = section; selected = null; scope.launch { drawerState.close() } },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    NavigationDrawerItem(
                        icon = { Text("🔒") },
                        label = { Text("الإعدادات") },
                        selected = currentSection == "الإعدادات",
                        onClick = { currentSection = "الإعدادات"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Info, contentDescription = null) },
                        label = { Text("عن مِعيار") },
                        selected = false,
                        onClick = { showAbout = true; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        ) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                if (unlocked && currentSection != "الإعدادات") FloatingActionButton(
                    onClick = {
                        when {
                            currentSection == "الإعدادات" -> showPinSettings = true
                            selected != null && (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") -> showChooseCategory = true
                            selected != null && currentSection != "الفواتير والتقارير" -> showAddExpense = true
                            selected == null && (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") -> showAddPlantation = true
                            currentSection != "الفواتير والتقارير" -> showChoosePlantation = true
                        }
                    },
                    containerColor = Emerald,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).then(if (currentSection == "الرئيسية" && selected == null || currentSection == "الإعدادات") Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
                Header(onMenuClick = { scope.launch { drawerState.open() } })
                if (currentSection == "الرئيسية") {
                    Text("أهلاً بك في معيار", modifier = Modifier.padding(top = 10.dp, start = 4.dp), style = MaterialTheme.typography.titleMedium, color = Emerald, fontWeight = FontWeight.ExtraBold)
                    Text("إدارة أدق - مردود أوضح", modifier = Modifier.padding(start = 4.dp), style = MaterialTheme.typography.bodyMedium, color = Green)
                }
                Spacer(Modifier.height(12.dp))
                if (!unlocked) {
                    PinLockScreen(pinInput = pinInput, onInput = { pinInput = it.filter(Char::isDigit).take(8); pinError = "" },
                        onUnlock = {
                            if (pinInput.isNotBlank() && sha256(pinInput) == configuredPin) { unlocked = true; pinInput = ""; pinError = "" }
                            else pinError = "رمز PIN غير صحيح"
                        }, error = pinError, hasPin = configuredPin != null)
                } else if (currentSection == "الإعدادات" && selected == null) {
                    Text("الإعدادات", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    FinancialCard("🔒 قفل التطبيق", if (configuredPin == null) "غير مفعّل" else "مفعّل", "رمز PIN عند العودة إلى التطبيق")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { newPin = ""; confirmPin = ""; pinSettingsMessage = ""; showPinSettings = true }, modifier = Modifier.fillMaxWidth()) { Text(if (configuredPin == null) "تعيين رمز PIN" else "تغيير أو إلغاء رمز PIN") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showAbout = true }, modifier = Modifier.fillMaxWidth()) { Text("معلومات التطبيق") }
                } else if (selected == null) {
                    Text(if (currentSection == "الرئيسية") "مواضعي الزراعية" else if (currentSection == "المواضع الزراعية") "المواضع الزراعية" else currentSection,
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                    Spacer(Modifier.height(8.dp))
                    if (currentSection != "الرئيسية" && currentSection != "المواضع الزراعية" && currentSection != "الفواتير والتقارير") {
                        val allRecords by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
                        val filteredRecords = allRecords.filter { record ->
                            record.category == currentSection ||
                            (currentSection == "المياه والري" && record.category == "المياه")
                        }
                        if (filteredRecords.isEmpty()) {
                            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                    Text("لا توجد عمليات مسجلة في قسم $currentSection", fontWeight = FontWeight.Bold)
                                    Text("اضغط إضافة عملية، ثم اختر الموضع الزراعي.")
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(filteredRecords, key = { it.id }) { record ->
                                    var details by remember(record.id) { mutableStateOf(false) }
                                    var menu by remember(record.id) { mutableStateOf(false) }
                                    var confirmDelete by remember(record.id) { mutableStateOf(false) }
                                    Card(modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { details = true }, onLongClick = { menu = true }), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(record.title, fontWeight = FontWeight.Bold, color = Emerald)
                                                Text("الموضع: ${record.plantationName} • ${record.category}", style = MaterialTheme.typography.bodySmall)
                                                Text(java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(record.dateMillis)), style = MaterialTheme.typography.labelSmall, color = Green)
                                            }
                                            Text(formatMoney(record.amount), fontWeight = FontWeight.Bold, color = Emerald)
                                        }
                                    }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; selected = plantations.firstOrNull { it.id == record.plantationId }; currentSection = record.category; editingExpense = ExpenseEntity(id = record.id, plantationId = record.plantationId, category = record.category, title = record.title, amount = record.amount, currency = record.currency, dateMillis = record.dateMillis, notes = record.notes); showAddExpense = true })
                                        DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
                                    }
                                    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("تأكيد حذف العملية") }, text = { Text("هل تريد حذف «${record.title}»؟") }, confirmButton = { TextButton(onClick = { scope.launch { dao.deleteExpense(ExpenseEntity(id = record.id, plantationId = record.plantationId, category = record.category, title = record.title, amount = record.amount, currency = record.currency, dateMillis = record.dateMillis, notes = record.notes)) }; confirmDelete = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } })
                                    if (details) AlertDialog(onDismissRequest = { details = false }, title = { Text(record.title) }, text = { Text("الموضع: ${record.plantationName}\\nنوع العملية: ${record.category}\\nالقيمة: ${formatMoney(record.amount)}\\n${record.notes}") }, confirmButton = { TextButton(onClick = { details = false }) { Text("إغلاق") } })
                                }
                            }
                        }
                    } else if (plantations.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("أهلًا بك في مِعيار 🌿", fontWeight = FontWeight.Bold)
                                Text("أضف أول موضع زراعي للبدء.")
                            }
                        }
                    } else if (currentSection != "الرئيسية") {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(plantations, key = { it.id }) { p ->
                                var menu by remember(p.id) { mutableStateOf(false) }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌱", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 8.dp))
                                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                            Text(p.name, fontWeight = FontWeight.SemiBold)
                                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "عرض تفاصيل الموضع ←" else "اختيار الموضع لهذا القسم ←", color = Green, style = MaterialTheme.typography.labelMedium)
                                        }
                                        TextButton(onClick = { selected = p }) { Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "فتح" else "اختيار") }
                                        Box {
                                            IconButton(onClick = { menu = true }) {
                                                Icon(Icons.Default.MoreVert, contentDescription = "إجراءات الموضع")
                                            }
                                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                                DropdownMenuItem(
                                                    text = { Text("حذف الموضع") },
                                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                                                    onClick = { menu = false; plantationToDelete = p }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (currentSection == "الرئيسية") {
                        Spacer(Modifier.height(12.dp))
                        FinancialCard("💸 إجمالي الخرج لجميع المواضع", formatMoney(totalExpenses), "مجموع المصروفات الزراعية المسجلة")
                        Spacer(Modifier.height(8.dp))
                        FinancialCard("💰 إجمالي المردود • عدد القطفات: $harvestCount", formatMoney(totalRevenue), "مجموع المبالغ الناتجة عن القطفات")
                        Spacer(Modifier.height(12.dp))
                        Text("ملخص الأنشطة الزراعية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        val categoryTotals by dao.observeCategoryTotals().collectAsStateWithLifecycle(initialValue = emptyList())
                        val totals = categoryTotals.associate { it.category to (it.count to it.total) }
                        val summaryCategories = listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات")
                        summaryCategories.chunked(2).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowItems.forEach { category ->
                                    val pair = if (category == "المياه والري") {
                                                val a = totals["المياه"] ?: (0L to 0L)
                                                val b = totals["المياه والري"] ?: (0L to 0L)
                                                (a.first + b.first) to (a.second + b.second)
                                            } else totals[category] ?: (0L to 0L)
                                    Card(onClick = { currentSection = category; selected = null }, modifier = Modifier.weight(1f).padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                            Text(category, color = Emerald, fontWeight = FontWeight.Bold)
                                            Text("عدد العمليات: ${pair.first}", style = MaterialTheme.typography.bodySmall)
                                            Text(formatMoney(pair.second), color = Green, fontWeight = FontWeight.ExtraBold)
                                            Text("عرض التفاصيل ←", style = MaterialTheme.typography.labelSmall, color = Gold)
                                        }
                                    }
                                }
                                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("آخر العمليات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        val recent by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
                        recent.take(5).forEach { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(12.dp)) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.Bold)
                                        Text("${item.plantationName} • ${item.category}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text("افتح أي بطاقة لعرض سجلاتها، واضغط مطولًا على العملية لتعديلها أو حذفها.", style = MaterialTheme.typography.bodySmall)
                    } else if (currentSection == "الفواتير والتقارير") {
                        Spacer(Modifier.height(8.dp))
                        Text("اختر موضعًا لعرض ملخص سجلاته وتقرير عملياته.", style = MaterialTheme.typography.bodyMedium)
                    } else if (currentSection != "المواضع الزراعية") {
                        Text("اختر الموضع الزراعي الذي تريد تسجيل بيانات قسم ${currentSection} عليه.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                        Column {
                            Text(selected!!.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "ملخص الموضع" else currentSection, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val allExpenses by dao.observeExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = emptyList())
                    val expenses = if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "الفواتير والتقارير") allExpenses else allExpenses.filter { it.category == currentSection }
                    val plantationTotal by dao.observePlantationExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationRevenue by dao.observePlantationRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    Spacer(Modifier.height(8.dp))
                    FinancialCard("💸 إجمالي خرج الموضع", formatMoney(plantationTotal), "يتحدث تلقائيًا من سجلات المصروفات")
                    FinancialCard("💰 إجمالي مردود الموضع", formatMoney(plantationRevenue), "إجمالي القطفات المسجلة لهذا الموضع")
                    Spacer(Modifier.height(12.dp))
                    Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "الفواتير والتقارير") "سجل العمليات" else "سجل ${currentSection}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (expenses.isEmpty()) Text(if (currentSection == "الفواتير والتقارير") "لا توجد عمليات مسجلة لعرضها في التقرير." else "لا توجد سجلات في هذا القسم لهذا الموضع بعد.", modifier = Modifier.padding(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(expenses, key = { it.id }) { expense ->
                            ExpenseRow(expense,
                                onUpdate = { updated -> scope.launch { dao.updateExpense(updated) } },
                                onDelete = { item -> scope.launch { dao.deleteExpense(item) } }
                            )
                        }
                    }
                }
            }
        }
        }
    }

    if (!unlocked && configuredPin != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = {}, properties = androidx.compose.ui.window.DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = Cream) {
                PinLockScreen(pinInput = pinInput, onInput = { pinInput = it.filter(Char::isDigit).take(8); pinError = "" },
                    onUnlock = { if (pinInput.isNotBlank() && sha256(pinInput) == configuredPin) { unlocked = true; pinInput = ""; pinError = "" } else pinError = "رمز PIN غير صحيح" },
                    error = pinError, hasPin = true)
            }
        }
    }
    if (showPinSettings) {
        AlertDialog(
            onDismissRequest = { showPinSettings = false },
            title = { Text("قفل التطبيق برمز PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (configuredPin == null) "أنشئ رمزًا من 4 إلى 8 أرقام. سيُطلب عند العودة إلى التطبيق بعد مغادرته." else "القفل مفعّل. يمكنك تغيير الرمز أو إلغاء القفل.")
                    if (configuredPin != null) {
                        OutlinedButton(onClick = { prefs.edit().remove("pin_hash").apply(); configuredPin = null; unlocked = true; pinSettingsMessage = "تم إلغاء قفل التطبيق." }, modifier = Modifier.fillMaxWidth()) { Text("إلغاء رمز PIN") }
                    }
                    OutlinedButton(onClick = { showPinSettings = false; showPinSetup = true; newPin = ""; confirmPin = ""; pinSettingsMessage = "" }, modifier = Modifier.fillMaxWidth()) { Text(if (configuredPin == null) "إنشاء رمز PIN" else "تغيير رمز PIN") }
                    if (pinSettingsMessage.isNotBlank()) Text(pinSettingsMessage, color = Green)
                }
            },
            confirmButton = { TextButton(onClick = { showPinSettings = false }) { Text("إغلاق") } }
        )
    }
    if (showPinSetup) {
        AlertDialog(
            onDismissRequest = { showPinSetup = false },
            title = { Text(if (configuredPin == null) "إنشاء رمز PIN" else "تغيير رمز PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit).take(8) }, label = { Text("رمز PIN (4 إلى 8 أرقام)") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    OutlinedTextField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(8) }, label = { Text("تأكيد الرمز") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    if (pinSettingsMessage.isNotBlank()) Text(pinSettingsMessage, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (newPin.length < 4) pinSettingsMessage = "يجب أن يتكون الرمز من 4 أرقام على الأقل."
                else if (newPin != confirmPin) pinSettingsMessage = "الرمزان غير متطابقين."
                else {
                    val hash = sha256(newPin)
                    prefs.edit().putString("pin_hash", hash).apply()
                    configuredPin = hash
                    unlocked = true
                    pinSettingsMessage = ""
                    showPinSetup = false
                    showPinSettings = false
                }
            }) { Text("حفظ الرمز") } },
            dismissButton = { TextButton(onClick = { showPinSetup = false }) { Text("إلغاء") } }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("عن مِعيار") },
            text = { Text("مِعيار تطبيقك الذكي وعاملك التكنولوجي لإدارة ومتابعة مواضعك الزراعية بطريقة تواكب التطور الزراعي.\n\nتنفيذ وحقوق التطبيق: المهندس (أبو مجيد).") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("حسنًا") } }
        )
    }

    if (plantationToDelete != null) {
        val target = plantationToDelete!!
        AlertDialog(
            onDismissRequest = { plantationToDelete = null },
            title = { Text("تأكيد حذف الموضع") },
            text = { Text("هل تريد حذف الموضع «${target.name}»؟ لا يمكن حذف أي موضع يحتوي على مصروفات مسجلة.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val deleted = dao.deletePlantationIfEmpty(target.id)
                        if (!deleted) deleteMessage = "لا يمكن حذف الموضع «${target.name}» لأنه يحتوي على مصروفات مسجلة. احذف المصروفات أو احتفظ بالموضع."
                    }
                    plantationToDelete = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { plantationToDelete = null }) { Text("إلغاء") } }
        )
    }
    if (deleteMessage != null) {
        AlertDialog(
            onDismissRequest = { deleteMessage = null },
            title = { Text("تعذر حذف الموضع") },
            text = { Text(deleteMessage!!) },
            confirmButton = { TextButton(onClick = { deleteMessage = null }) { Text("حسنًا") } }
        )
    }

    if (showChooseCategory) {
        AlertDialog(
            onDismissRequest = { showChooseCategory = false },
            title = { Text("اختر نوع العملية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("السموم", "الأسمدة", "المياه والري", "الأعمال اليدوية", "أخرى", "القطفات").forEach { category ->
                        OutlinedButton(onClick = { currentSection = category; showChooseCategory = false; showAddExpense = true }, modifier = Modifier.fillMaxWidth()) { Text(category) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChooseCategory = false }) { Text("إلغاء") } }
        )
    }
    if (showChoosePlantation) {
        AlertDialog(
            onDismissRequest = { showChoosePlantation = false },
            title = { Text("اختر الموضع للعملية الجديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (plantations.isEmpty()) Text("أضف موضعًا زراعيًا أولًا من الصفحة الرئيسية.")
                    plantations.forEach { p ->
                        OutlinedButton(onClick = { selected = p; showChoosePlantation = false; showAddExpense = true }, modifier = Modifier.fillMaxWidth()) { Text(p.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChoosePlantation = false }) { Text("إلغاء") } }
        )
    }
    if (showAddPlantation) {
        TextEntryDialog("إضافة موضع زراعي", "اسم الموضع", onDismiss = { showAddPlantation = false }) { name ->
            scope.launch { dao.insertPlantation(PlantationEntity(name = name.trim())) }
            showAddPlantation = false
        }
    }
    if (showAddExpense && selected != null) {
        ExpenseDialog(initial = editingExpense, category = currentSection, onDismiss = { showAddExpense = false; editingExpense = null }) { title, amount, notes ->
            scope.launch {
                val normalizedCategory = currentSection
                val parsedDate = Regex("تاريخ العملية: (\\d{4})/(\\d{2})/(\\d{2})").find(notes)
                val dateMillis = parsedDate?.let { m ->
                    runCatching { java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).parse("${m.groupValues[1]}/${m.groupValues[2]}/${m.groupValues[3]}")?.time }.getOrNull()
                } ?: (editingExpense?.dateMillis ?: System.currentTimeMillis())
                val item = ExpenseEntity(id = editingExpense?.id ?: 0L, plantationId = selected!!.id, category = normalizedCategory, title = title.trim(), amount = amount, dateMillis = dateMillis, notes = notes)
                val savedId = if (editingExpense == null) dao.insertExpense(item) else { dao.updateExpense(item); editingExpense!!.id }
                val nextDateMatch = Regex("تاريخ العملية القادمة: (\\d{4})/(\\d{2})/(\\d{2})").find(notes)
                if (nextDateMatch != null) {
                    val nextDateValue = "${nextDateMatch.groupValues[1]}/${nextDateMatch.groupValues[2]}/${nextDateMatch.groupValues[3]}"
                    ReminderScheduler.schedule(context, savedId, title.trim(), normalizedCategory, selected!!.name, nextDateValue)
                } else {
                    ReminderScheduler.cancel(context, savedId)
                }
            }
            showAddExpense = false
            editingExpense = null
        }
    }
}

@Composable
private fun Header(onMenuClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, contentDescription = "فتح القائمة الجانبية", tint = androidx.compose.ui.graphics.Color.White)
            }
            MiyarMark(Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("مِعيار", style = MaterialTheme.typography.headlineMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                Text("إدارة أدق - مردود أوضح", color = Gold, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun MiyarMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .padding(2.dp)
            .then(Modifier),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(50),
            color = Emerald,
            border = androidx.compose.foundation.BorderStroke(2.dp, Gold)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("🌿", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}

@Composable
private fun FinancialCard(title: String, value: String, caption: String) {
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(caption, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpenseRow(item: ExpenseEntity, onUpdate: (ExpenseEntity) -> Unit, onDelete: (ExpenseEntity) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var editDialog by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { }, onLongClick = { menu = true }),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; editDialog = true })
                DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    if (editDialog) {
        ExpenseDialog(initial = item, onDismiss = { editDialog = false }) { title, amount, notes ->
            onUpdate(item.copy(title = title.trim(), amount = amount, notes = notes))
            editDialog = false
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل تريد حذف المصروف «${item.title}»؟ لا يمكن التراجع عن هذه العملية.") },
            confirmButton = { TextButton(onClick = { onDelete(item); confirmDelete = false }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onSave(value) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ExpenseDialog(initial: ExpenseEntity? = null, category: String = initial?.category ?: "أخرى", onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var amountText by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var opDate by remember { mutableStateOf(java.text.SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(initial?.dateMillis ?: System.currentTimeMillis()))) }
    var nextDate by remember { mutableStateOf(Regex("تاريخ العملية القادمة: (\\d{4}/\\d{2}/\\d{2})").find(initial?.notes.orEmpty())?.groupValues?.get(1) ?: "") }
    var opType by remember { mutableStateOf("حشري") }
    var ingredient by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var fuel by remember { mutableStateOf("ديزل") }
    var fuelCost by remember { mutableStateOf("") }
    var hours by remember { mutableStateOf("") }
    var workers by remember { mutableStateOf("") }
    var laborCost by remember { mutableStateOf("") }
    var otherCost by remember { mutableStateOf("") }
    var unitWage by remember { mutableStateOf("") }
    var workerCount by remember { mutableStateOf("") }
    var workType by remember { mutableStateOf("حجين") }
    val isChemical = category == "السموم" || category == "الأسمدة"
    val isWater = category == "المياه" || category == "المياه والري"
    val isLabor = category == "الأعمال اليدوية"
    val isHarvest = category == "القطفات"
    val parsed = amountText.toLongOrNull()
    val autoTotal = if (isWater) (fuelCost.toLongOrNull() ?: 0L) + (laborCost.toLongOrNull() ?: 0L) + (otherCost.toLongOrNull() ?: 0L)
        else if (isLabor) (workerCount.toLongOrNull() ?: 0L) * (unitWage.toLongOrNull() ?: 0L) + (otherCost.toLongOrNull() ?: 0L) else null
    if (autoTotal != null && initial == null) LaunchedEffect(autoTotal) { amountText = autoTotal.toString() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة عملية: $category" else "تعديل عملية: $category") },
        text = {
            Column(Modifier.heightIn(max = 540.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isChemical) {
                    Text("نوع العملية", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("حشري", "فطري", "ورقي", "جذري").forEach { t -> FilterChip(selected = opType == t, onClick = { opType = t }, label = { Text(t) }) }
                    }
                }
                if (isLabor) {
                    Text("نوع العمل", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("حجين", "حشيش", "فقح", "قحيز", "أخرى").forEach { t -> FilterChip(selected = workType == t, onClick = { workType = t }, label = { Text(t) }) }
                    }
                }
                OutlinedTextField(title, { title = it }, label = { Text(when {
                    isChemical && category == "السموم" -> "اسم السم / المبيد"
                    isChemical -> "اسم السماد"
                    isWater -> "بيان عملية المياه والري"
                    isLabor -> "بيان العمل (اختياري)"
                    isHarvest -> "بيان القطفة / المشتري"
                    else -> "بيان العملية"
                }) }, singleLine = true)
                if (isChemical) {
                    OutlinedTextField(ingredient, { ingredient = it }, label = { Text(if (category == "السموم") "اسم المادة الفعالة" else "اسم العنصر") }, singleLine = true)
                    OutlinedTextField(quantity, { quantity = it }, label = { Text("الكمية (مل / جرام)") }, singleLine = true)
                }
                OutlinedTextField(opDate, { opDate = it }, label = { Text("تاريخ العملية (سنة/شهر/يوم)") }, singleLine = true)
                if (isChemical || isWater) OutlinedTextField(nextDate, { nextDate = it }, label = { Text("تاريخ العملية القادمة (اختياري)") }, singleLine = true)
                if (isWater) {
                    Text("نوع الوقود", color = Emerald, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("بترول", "ديزل", "غاز", "طاقة شمسية").forEach { t -> FilterChip(selected = fuel == t, onClick = { fuel = t }, label = { Text(t) }) }
                    }
                    OutlinedTextField(fuelCost, { fuelCost = it.filter(Char::isDigit) }, label = { Text("قيمة الوقود") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(hours, { hours = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("عدد الساعات") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    OutlinedTextField(workers, { workers = it.filter(Char::isDigit) }, label = { Text("عدد عمال العملية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(laborCost, { laborCost = it.filter(Char::isDigit) }, label = { Text("تكاليف العمال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(otherCost, { otherCost = it.filter(Char::isDigit) }, label = { Text("خرج آخر للعملية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    Text("إجمالي تكلفة العملية: ${formatMoney(autoTotal ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                } else if (isLabor) {
                    OutlinedTextField(workerCount, { workerCount = it.filter(Char::isDigit) }, label = { Text("عدد العمال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(unitWage, { unitWage = it.filter(Char::isDigit) }, label = { Text("سعر الوحدة / أجر العامل") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(otherCost, { otherCost = it.filter(Char::isDigit) }, label = { Text("خرج العمال الإضافي") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    Text("إجمالي تكلفة العملية: ${formatMoney(autoTotal ?: 0L)}", color = Emerald, fontWeight = FontWeight.Bold)
                } else {
                    OutlinedTextField(amountText, { amountText = it.filter(Char::isDigit) }, label = { Text(if (isHarvest) "مبلغ المردود بالريال اليمني" else "مبلغ العملية بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات / بيانات أخرى / تقييم النتائج لاحقًا") }, minLines = 2)
            }
        },
        confirmButton = { TextButton(enabled = (title.isNotBlank() || isLabor) && parsed != null && parsed >= 0, onClick = {
            val details = buildString {
                if (isChemical) append("نوع العملية: $opType\nالمادة الفعالة/العنصر: $ingredient\nالكمية: $quantity\n")
                if (isWater) append("نوع الوقود: $fuel\nقيمة الوقود: $fuelCost\nعدد الساعات: $hours\nعدد العمال: $workers\nتكاليف العمال: $laborCost\nخرج آخر: $otherCost\n")
                if (isLabor) append("نوع العمل: $workType\nعدد العمال: $workerCount\nأجر العامل: $unitWage\nخرج العمال: $otherCost\n")
                append("تاريخ العملية: $opDate\n")
                if (nextDate.isNotBlank()) append("تاريخ العملية القادمة: $nextDate\n")
                if (notes.isNotBlank()) append("ملاحظات: $notes")
            }
            onSave(if (title.isBlank() && isLabor) workType else title, parsed, details)
        }) { Text("حفظ العملية") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun formatMoney(amount: Long): String =
    NumberFormat.getIntegerInstance(Locale.US).format(amount) + " ر.ي"


@Composable
private fun PinLockScreen(pinInput: String, onInput: (String) -> Unit, onUnlock: () -> Unit, error: String, hasPin: Boolean) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        MiyarMark(Modifier.size(76.dp))
        Spacer(Modifier.height(16.dp))
        Text("مِعيار", style = MaterialTheme.typography.headlineLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
        Text("أدخل رمز PIN للمتابعة", color = Green)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = pinInput, onValueChange = onInput, label = { Text("رمز PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = onUnlock, enabled = hasPin && pinInput.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("فتح التطبيق") }
    }
}

private fun sha256(value: String): String =
    MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
