package com.miyar.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object ReminderScheduler {
    private const val CHANNEL_ID = "miyar_agriculture_reminders"

    fun schedule(context: Context, id: Long, title: String, category: String, plantation: String, date: String) {
        val parsed = runCatching { SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(date) }.getOrNull() ?: return
        val calendar = Calendar.getInstance().apply {
            time = parsed
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            calendar.timeInMillis = System.currentTimeMillis() + 5_000L
        }
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("id", id.toInt())
            putExtra("title", title)
            putExtra("category", category)
            putExtra("plantation", plantation)
            putExtra("date", date)
        }
        val pending = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
    }

    fun cancel(context: Context, id: Long) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
        pending.cancel()
    }

    internal fun show(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "تنبيهات مِعيار الزراعية", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val title = intent.getStringExtra("title") ?: "عملية زراعية"
        val category = intent.getStringExtra("category") ?: "عملية"
        val plantation = intent.getStringExtra("plantation") ?: "موضع زراعي"
        val date = intent.getStringExtra("date") ?: ""
        val openApp = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير من مِعيار: $category")
            .setContentText("تذكير بموعد العملية: $title — $plantation")
            .setStyle(NotificationCompat.BigTextStyle().bigText("حان موعد العملية المجدولة ($category) «$title» في الموضع «$plantation». التاريخ: $date."))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        manager.notify(intent.getIntExtra("id", System.currentTimeMillis().toInt()), notification)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.show(context, intent)
    }
}
