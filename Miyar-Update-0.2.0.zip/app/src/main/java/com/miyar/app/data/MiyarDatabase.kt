package com.miyar.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Delete
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MiyarDao {
    @Query("SELECT * FROM plantations ORDER BY name COLLATE NOCASE")
    fun observePlantations(): Flow<List<PlantationEntity>>

    @Insert
    suspend fun insertPlantation(item: PlantationEntity): Long

    @Query("SELECT COUNT(*) FROM expenses WHERE plantationId = :plantationId")
    suspend fun countExpensesForPlantation(plantationId: Long): Int

    @Query("DELETE FROM plantations WHERE id = :plantationId")
    suspend fun deletePlantationById(plantationId: Long): Int

    @Transaction
    suspend fun deletePlantationIfEmpty(plantationId: Long): Boolean {
        if (countExpensesForPlantation(plantationId) > 0) return false
        return deletePlantationById(plantationId) > 0
    }

    @Query("SELECT * FROM expenses WHERE plantationId = :plantationId ORDER BY dateMillis DESC, id DESC")
    fun observeExpenses(plantationId: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category != 'القطفات'")
    fun observeTotalExpenses(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category = 'القطفات'")
    fun observeTotalRevenue(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category != 'القطفات'")
    fun observePlantationExpenses(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category = 'القطفات'")
    fun observePlantationRevenue(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id = e.plantationId ORDER BY e.dateMillis DESC, e.id DESC")
    fun observeAllExpenses(): Flow<List<ExpenseWithPlantation>>

    @Query("SELECT category AS category, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total FROM expenses GROUP BY category")
    fun observeCategoryTotals(): Flow<List<CategoryTotal>>

    @Query("SELECT COUNT(*) FROM expenses WHERE category = 'القطفات'")
    fun observeHarvestCount(): Flow<Long>

    @Insert
    suspend fun insertExpense(item: ExpenseEntity): Long

    @Update
    suspend fun updateExpense(item: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(item: ExpenseEntity)
}

@Database(
    entities = [PlantationEntity::class, ExpenseEntity::class],
    version = 1,
    exportSchema = true
)
abstract class MiyarDatabase : RoomDatabase() {
    abstract fun dao(): MiyarDao

    companion object {
        @Volatile private var INSTANCE: MiyarDatabase? = null

        fun get(context: Context): MiyarDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MiyarDatabase::class.java,
                    "miyar.db"
                ).build().also { INSTANCE = it }
            }
    }
}
