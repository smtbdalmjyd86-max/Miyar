@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.miyar.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.PopupProperties
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

private data class InvoiceLineDraft(
    val productType: String = "الأسمدة",
    val productName: String = "",
    val activeIngredient: String = "",
    val packageName: String = "كيس",
    val packageSize: String = "1",
    val packageCount: String = "1",
    val unit: String = "كجم",
    val unitPrice: String = "",
    val treatmentType: String = "عام"
)

private val InvoiceLinesSaver = androidx.compose.runtime.saveable.listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<InvoiceLineDraft>, String>(
    save = { rows -> rows.flatMap { row -> listOf(row.productType, row.productName, row.activeIngredient, row.packageName, row.packageSize, row.packageCount, row.unit, row.unitPrice, row.treatmentType) } },
    restore = { values -> androidx.compose.runtime.mutableStateListOf<InvoiceLineDraft>().apply {
        values.chunked(9).forEach { v -> if (v.size == 9) add(InvoiceLineDraft(v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8])) }
    } }
)

private val InvoiceDraftsSaver = androidx.compose.runtime.saveable.listSaver<List<InvoiceLineDraft>, String>(
    save = { rows -> rows.flatMap { row -> listOf(row.productType, row.productName, row.activeIngredient, row.packageName, row.packageSize, row.packageCount, row.unit, row.unitPrice, row.treatmentType) } },
    restore = { values -> values.chunked(9).filter { it.size == 9 }.map { v -> InvoiceLineDraft(v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8]) } }
)

private fun localDate(millis: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(millis))
private fun parseDateOrToday(value: Long?): Long = value ?: System.currentTimeMillis()

// Material3 DatePicker uses UTC-midnight milliseconds. The app stores local-day
// timestamps, so convert explicitly to avoid a one-day shift in UTC+3/other zones.
private fun toPickerDateMillis(localMillis: Long): Long =
    Instant.ofEpochMilli(localMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        .atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()

private fun fromPickerDateMillis(pickerMillis: Long): Long =
    Instant.ofEpochMilli(pickerMillis).atZone(ZoneOffset.UTC).toLocalDate()
        .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
private fun digits(value: String): Long = value.filter { it.isDigit() }.toLongOrNull() ?: 0L
private fun rateScaled(value: String): Long = runCatching {
    val normalized = rateInput(value).replace(".", "").replace(',', '.')
    BigDecimal(normalized).multiply(BigDecimal(1000)).setScale(0, RoundingMode.HALF_UP).longValueExact()
}.getOrDefault(0L)
private fun baseMultiplier(unit: String): Long = FinanceCalculations.quantityToBase(1L, unit)
private fun baseUnit(unit: String): String = if (unit == "كجم" || unit == "جرام") "g" else "ml"
private fun stockQuantity(value: Long, unit: String): String =
    FinanceCalculations.formatStockQuantity(value.coerceAtLeast(0L), unit)

@Composable
fun MiyarDateField(label: String, millis: Long, onDate: (Long) -> Unit) {
    var showPicker by rememberSaveable { mutableStateOf(false) }
    OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
        Text("$label: ${localDate(millis)}")
    }
    if (showPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = toPickerDateMillis(millis))
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = { state.selectedDateMillis?.let { onDate(fromPickerDateMillis(it)) }; showPicker = false }) { Text("اختيار") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("إلغاء") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
fun MiyarInvoiceScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val invoices = remember { androidx.compose.runtime.mutableStateListOf<InvoiceEntity>() }
    val invoiceSummary by dao.observeInvoiceLedgerSummary().collectAsStateWithLifecycle(initialValue = InvoiceLedgerSummary(0, 0, 0, 0))
    var invoicePage by rememberSaveable { mutableIntStateOf(0) }
    var invoiceHasMore by rememberSaveable { mutableStateOf(true) }
    var invoiceLoading by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        invoiceLoading = true
        runCatching { dao.getInvoicePage(50, 0) }.onSuccess { invoices.addAll(it); invoicePage = 1; invoiceHasMore = it.size == 50 }
        invoiceLoading = false
    }
    val supplierNameSuggestions by dao.observeSupplierNameSuggestions().collectAsStateWithLifecycle(initialValue = emptyList())
    val stockSuggestions by dao.observeStockPriceSuggestions().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    var showForm by rememberSaveable { mutableStateOf(false) }
    var editingId by rememberSaveable { mutableLongStateOf(0L) }
    val editing = invoices.firstOrNull { it.id == editingId }
    var initialLines by rememberSaveable(stateSaver = InvoiceDraftsSaver) { mutableStateOf<List<InvoiceLineDraft>>(emptyList()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var detailsId by rememberSaveable { mutableLongStateOf(0L) }
    var invoiceMenuId by rememberSaveable { mutableLongStateOf(0L) }
    val detailsFor = invoices.firstOrNull { it.id == detailsId }
    var detailLines by remember { mutableStateOf<List<InvoiceItemEntity>>(emptyList()) }
    LaunchedEffect(detailsId) {
        if (detailsId != 0L) detailLines = dao.getInvoiceItems(detailsId)
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("الفواتير", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                Text("تسجيل المشتريات وتحويل قيمتها وتحديث المخزون تلقائيًا", style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { editingId = 0L; initialLines = listOf(InvoiceLineDraft()); showForm = true }) {
                Icon(Icons.Default.Add, null); Text("فاتورة")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE7F8EC))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("🧾 إجمالي الفواتير الآجلة", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text(formatMoney(invoiceSummary.creditTotal), color = Green, fontWeight = FontWeight.ExtraBold)
                    Text("${invoiceSummary.creditCount} فاتورة", style = MaterialTheme.typography.labelSmall)
                }
            }
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3D6))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("💵 إجمالي الفواتير النقدية", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text(formatMoney(invoiceSummary.cashTotal), color = Green, fontWeight = FontWeight.ExtraBold)
                    Text("${invoiceSummary.cashCount} فاتورة", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (invoices.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ReceiptLong, null, tint = Emerald, modifier = Modifier.size(34.dp))
                    Text("لا توجد فواتير مسجلة بعد", fontWeight = FontWeight.Bold)
                    Text("أضف فاتورة لتسجيل الأصناف والكميات في المخزون.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        invoices.forEach { invoice ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.combinedClickable(onClick = { detailsId = invoice.id }, onLongClick = { invoiceMenuId = invoice.id })) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(invoice.supplier, color = Emerald, fontWeight = FontWeight.Bold)
                            Text("فاتورة ${invoice.invoiceNumber} • ${localDate(invoice.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (invoice.paymentStatus == "آجل") "آجل" else "نقدًا", color = if (invoice.paymentStatus == "آجل") Gold else Green, fontWeight = FontWeight.Bold)
                    }
                    Text("الإجمالي: ${formatMoney(invoice.totalYer)}", fontWeight = FontWeight.ExtraBold)
                    Text("${formatNumber(invoice.totalForeign)} ${invoice.currency} • سعر الصرف: ${invoice.exchangeRateScaled / 1000.0}", style = MaterialTheme.typography.bodySmall)
                    DropdownMenu(expanded = invoiceMenuId == invoice.id, onDismissRequest = { invoiceMenuId = 0L }) {
                        DropdownMenuItem(text = { Text("التفاصيل") }, onClick = { detailsId = invoice.id; invoiceMenuId = 0L })
                        DropdownMenuItem(text = { Text("تعديل الفاتورة") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = {
                            invoiceMenuId = 0L
                            scope.launch {
                                val rows = dao.getInvoiceItems(invoice.id).map { item -> InvoiceLineDraft(item.productType, item.productName, item.activeIngredient, item.packageName, item.packageSize.toString(), item.packageCount.toString(), if (item.unit == "مل") "ملي" else item.unit, item.unitPriceForeign.toString(), item.treatmentType) }
                                editingId = invoice.id; initialLines = rows; showForm = true
                            }
                        })
                        DropdownMenuItem(text = { Text("حذف الفاتورة", color = MaterialTheme.colorScheme.error) }, leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }, onClick = {
                            invoiceMenuId = 0L
                            scope.launch { try { val deleted = dao.deleteInvoiceSafely(invoice.id); if (!deleted) error = "لا يمكن حذف الفاتورة لأن جزءًا من كمياتها صُرف في عمليات زراعية. أعد الكميات المستخدمة أولًا." else { invoices.removeAll { it.id == invoice.id }; if (invoices.size < 50) { val next = dao.getInvoicePage(50, (invoicePage - 1).coerceAtLeast(0) * 50); invoices.clear(); invoices.addAll(next); invoicePage = 1; invoiceHasMore = next.size == 50 } } } catch (t: Throwable) { error = t.message ?: "تعذر حذف الفاتورة." } }
                        })
                    }
                }
            }
        }
        if ((invoicePage > 1 || invoiceHasMore) && !invoiceLoading) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (invoicePage > 1) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    invoiceLoading = true
                    scope.launch {
                        val previous = invoicePage - 2
                        runCatching { dao.getInvoicePage(50, previous * 50) }
                            .onSuccess { invoices.clear(); invoices.addAll(it); invoicePage--; invoiceHasMore = true }
                        invoiceLoading = false
                    }
                }) { Text("السابق") }
                if (invoiceHasMore) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    invoiceLoading = true
                    scope.launch {
                        runCatching { dao.getInvoicePage(50, invoicePage * 50) }
                            .onSuccess { invoices.clear(); invoices.addAll(it); invoicePage++; invoiceHasMore = it.size == 50 }
                        invoiceLoading = false
                    }
                }) { Text("التالي — 50 فاتورة") }
            }
        }
        if (invoiceLoading) Text("جارٍ تحميل الفواتير…", color = Green)
    }

    if (showForm) {
        InvoiceFormDialog(
            initial = editing,
            initialLines = initialLines,
            stockSuggestions = stockSuggestions,
            supplierNameSuggestions = supplierNameSuggestions,
            initialSarRate = prefs.getString("sar", "") ?: "",
            initialUsdRate = prefs.getString("usd", "") ?: "",
            onDismiss = { showForm = false; editingId = 0L },
            onSave = { invoice, lines, sarRate, usdRate, complete ->
                scope.launch {
                    try {
                        dao.saveInvoice(invoice, lines)
                        val latest = dao.getInvoicePage(50, 0)
                        invoices.clear(); invoices.addAll(latest); invoicePage = 1; invoiceHasMore = latest.size == 50
                        prefs.edit().putString("sar", sarRate).putString("usd", usdRate).apply()
                        showForm = false; editingId = 0L
                        complete(true)
                    } catch (t: Throwable) {
                        error = t.message ?: "تعذر حفظ الفاتورة."
                        complete(false)
                    }
                }
            }
        )
    }
    if (detailsFor != null) {
        AlertDialog(
            onDismissRequest = { detailsId = 0L },
            title = { Text("تفاصيل فاتورة ${detailsFor!!.invoiceNumber}") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("التاجر: ${detailsFor!!.supplier}")
                    detailLines.forEach { line ->
                        HorizontalDivider()
                        Text(line.productName, fontWeight = FontWeight.Bold)
                        Text("${line.productType} • ${line.treatmentType} • ${line.activeIngredient}")
                        Text("${line.packageCount} × ${line.packageSize} ${line.unit} • ${line.packageName}")
                        Text("${line.lineTotalForeign} ${detailsFor!!.currency} = ${formatMoney(line.lineTotalYer)}")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detailsId = 0L }) { Text("إغلاق") } }
        )
    }
    if (error != null) AlertDialog(onDismissRequest = { error = null }, title = { Text("تنبيه") }, text = { Text(error!!) }, confirmButton = { TextButton(onClick = { error = null }) { Text("حسنًا") } })
}

@Composable
private fun InvoiceDropdownChoice(
    value: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    var expanded by remember(value, options) { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 6.dp)) {
            Text(value, maxLines = 1, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ArrowDropDown, contentDescription = "اختيار")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) }
        }
    }
}

@Composable
private fun InvoiceFormDialog(
    initial: InvoiceEntity?,
    initialLines: List<InvoiceLineDraft>,
    stockSuggestions: List<StockPriceSuggestion>,
    supplierNameSuggestions: List<String>,
    initialSarRate: String,
    initialUsdRate: String,
    onDismiss: () -> Unit,
    onSave: (InvoiceEntity, List<InvoiceItemEntity>, String, String, (Boolean) -> Unit) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val nextFieldAction = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Next) })
    var supplier by rememberSaveable(initial?.id) { mutableStateOf(initial?.supplier ?: "") }
    var invoiceNumber by rememberSaveable(initial?.id) { mutableStateOf(initial?.invoiceNumber ?: "") }
    var dateMillis by rememberSaveable(initial?.id) { mutableLongStateOf(parseDateOrToday(initial?.dateMillis)) }
    var paymentStatus by rememberSaveable(initial?.id) { mutableStateOf(initial?.paymentStatus ?: "نقدًا") }
    var currency by rememberSaveable(initial?.id) { mutableStateOf(initial?.currency ?: "YER") }
    var sarRate by rememberSaveable { mutableStateOf(initialSarRate) }
    var usdRate by rememberSaveable { mutableStateOf(initialUsdRate) }
    var notes by rememberSaveable(initial?.id) { mutableStateOf(initial?.notes ?: "") }
    val lines = rememberSaveable(initial?.id, saver = InvoiceLinesSaver) {
        mutableStateListOf<InvoiceLineDraft>().apply { addAll(initialLines.ifEmpty { listOf(InvoiceLineDraft()) }) }
    }
    val rateText = when (currency) { "SAR" -> sarRate; "USD" -> usdRate; else -> "1" }
    val rate = if (currency == "YER") 1000L else rateScaled(rateText)
    val lineTotals = lines.map { line ->
        runCatching { FinanceCalculations.lineTotal(digits(line.packageCount), moneyToLong(line.unitPrice)) }.getOrNull()
    }
    val quantityBases = lines.map { line ->
        runCatching { FinanceCalculations.quantityToBase(digits(line.packageSize), line.unit, digits(line.packageCount)) }.getOrNull()
    }
    val totalForeignResult = runCatching {
        lineTotals.fold(0L) { total, value -> Math.addExact(total, value ?: error("قيمة أحد الأصناف تتجاوز الحد المسموح.")) }
    }
    val totalForeign = totalForeignResult.getOrDefault(0L)
    val totalYerResult = runCatching {
        lineTotals.fold(0L) { total, value ->
            Math.addExact(total, FinanceCalculations.toYemeniRials(value ?: error("قيمة أحد الأصناف غير صالحة."), rate))
        }
    }
    val totalYer = totalYerResult.getOrDefault(0L)
    var validation by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable(initial?.id) { mutableStateOf(false) }
    var activeSuggestionIndex by rememberSaveable { mutableIntStateOf(-1) }

    Dialog(onDismissRequest = { if (!saving) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Cream, shape = RoundedCornerShape(0.dp)) {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (initial == null) "إضافة فاتورة" else "تعديل الفاتورة", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(enabled = !saving, onClick = onDismiss) { Text("إغلاق") }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(supplier, { supplier = it }, label = { Text("اسم التاجر / المورد") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                val supplierMatches = remember(supplier, supplierNameSuggestions) { if (supplier.isBlank()) emptyList() else supplierNameSuggestions.filter { it.contains(supplier, true) }.take(5) }
                if (supplierMatches.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    supplierMatches.forEach { name -> AssistChip(onClick = { supplier = name }, label = { Text(name) }) }
                }
                OutlinedTextField(invoiceNumber, { invoiceNumber = it }, label = { Text("رقم الفاتورة") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                MiyarDateField("تاريخ الفاتورة", dateMillis) { dateMillis = it }
                Text("حالة الفاتورة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = paymentStatus == "نقدًا", onClick = { paymentStatus = "نقدًا" }, label = { Text("نقدًا") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = androidx.compose.ui.graphics.Color(0xFFDCEFE2)))
                    FilterChip(selected = paymentStatus == "آجل", onClick = { paymentStatus = "آجل" }, label = { Text("آجل") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = androidx.compose.ui.graphics.Color(0xFFFFE8C2)))
                }
                Text("عملة الفاتورة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("YER", "SAR", "USD").forEach { c -> FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = when (c) {
                            "YER" -> androidx.compose.ui.graphics.Color(0xFFDCEFE2)
                            "SAR" -> androidx.compose.ui.graphics.Color(0xFFDCEBFA)
                            else -> androidx.compose.ui.graphics.Color(0xFFEDE0F5)
                        })) }
                }
                if (currency != "YER") {
                    MiyarRateInputField(
                        value = rateText,
                        onValueChange = { if (currency == "SAR") sarRate = it else usdRate = it },
                        label = "سعر صرف 1 $currency مقابل الريال اليمني",
                        imeAction = ImeAction.Next,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                HorizontalDivider()
                var itemCountText by rememberSaveable(initial?.id) { mutableStateOf(lines.size.toString()) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("عدد أصناف الفاتورة", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    OutlinedTextField(itemCountText, { raw ->
                        itemCountText = latinDigitsOnly(raw).take(3)
                        val wanted = itemCountText.toIntOrNull()?.coerceIn(1, 100)
                        if (wanted != null) {
                            while (lines.size < wanted) lines.add(InvoiceLineDraft())
                            while (lines.size > wanted) lines.removeAt(lines.lastIndex)
                        }
                    }, modifier = Modifier.width(100.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done), label = { Text("عدد الصفوف") })
                    TextButton(onClick = { lines.add(InvoiceLineDraft()); itemCountText = lines.size.toString() }) { Icon(Icons.Default.Add, null); Text("صف") }
                }
                Text("جدول الأصناف — اسحب أفقيًا لعرض بقية الأعمدة", color = Emerald, style = MaterialTheme.typography.labelSmall)
                val tableScroll = rememberScrollState()
                Column(Modifier.fillMaxWidth().horizontalScroll(tableScroll)) {
                    Row(
                        Modifier.background(Emerald, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)).padding(vertical = 9.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("القسم", "اسم الصنف", "المادة الفعالة", "حالة الصنف", "العبوة", "حجمها", "الوحدة", "العدد", "سعر العبوة", "الإجمالي باليمني", "تكلفة الوحدة").forEachIndexed { i, heading ->
                            Text(heading, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.width(listOf(100,170,160,120,110,95,120,85,125,135,135)[i].dp).padding(horizontal = 3.dp))
                        }
                    }
                    lines.forEachIndexed { index, line ->
                        val lineTotal = lineTotals.getOrNull(index)
                        val quantityBase = quantityBases.getOrNull(index)
                        val lineYer = lineTotal?.let { runCatching { FinanceCalculations.toYemeniRials(it, rate) }.getOrNull() }
                        val unitYer = if (quantityBase != null && quantityBase > 0 && lineYer != null) runCatching {
                            val factor = if (line.unit == "كجم" || line.unit == "لتر") 1000L else 1L
                            BigDecimal(lineYer).multiply(BigDecimal(factor)).divide(BigDecimal(quantityBase), 3, RoundingMode.HALF_UP)
                        }.getOrNull() else null
                        Row(
                            Modifier.background(if (index % 2 == 0) Cream else androidx.compose.ui.graphics.Color(0xFFFFFDF7)).padding(5.dp),
                            horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            InvoiceDropdownChoice(
                                value = if (line.productType == "الأسمدة") "سماد" else "سموم",
                                options = listOf("سماد", "سموم"),
                                modifier = Modifier.width(100.dp).background(if (line.productType == "الأسمدة") androidx.compose.ui.graphics.Color(0xFFE4F5E8) else androidx.compose.ui.graphics.Color(0xFFFFE8E5), RoundedCornerShape(8.dp)).padding(3.dp),
                                onSelect = { selectedType ->
                                    val type = if (selectedType == "سماد") "الأسمدة" else "السموم"
                                    lines[index] = line.copy(
                                        productType = type,
                                        packageName = if (type == "الأسمدة") "كيس" else "عبوة",
                                        unit = if (type == "الأسمدة") "كجم" else "ملي",
                                        treatmentType = if (type == "الأسمدة") line.treatmentType.takeIf { it in listOf("عام", "نمو", "تجذير", "ورقي") } ?: "عام" else line.treatmentType.takeIf { it in listOf("حشري", "فطري", "ورقي", "جذري") } ?: "حشري"
                                    )
                                }
                            )
                            val productMatches = stockSuggestions.filter { it.productType == line.productType && it.baseUnit == baseUnit(line.unit) && line.productName.isNotBlank() && it.productName.contains(line.productName.trim(), true) }.take(5)
                            Box(Modifier.width(170.dp)) {
                                OutlinedTextField(line.productName, { value ->
                                    activeSuggestionIndex = index
                                    lines[index] = line.copy(productName = value)
                                    stockSuggestions.firstOrNull { it.productType == line.productType && it.baseUnit == baseUnit(line.unit) && it.productName.equals(value.trim(), true) && (line.productType == "الأسمدة" || it.treatmentType == line.treatmentType) }?.let { found ->
                                        lines[index] = lines[index].copy(activeIngredient = found.activeIngredient, treatmentType = found.treatmentType)
                                    }
                                }, label = { Text("اسم الصنف") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                                DropdownMenu(expanded = activeSuggestionIndex == index && productMatches.isNotEmpty(), onDismissRequest = { activeSuggestionIndex = -1 }, properties = PopupProperties(focusable = false)) {
                                    productMatches.forEach { product -> DropdownMenuItem(text = { Column {
                                        Text(product.productName, fontWeight = FontWeight.SemiBold)
                                        Text(product.activeIngredient, style = MaterialTheme.typography.bodySmall)
                                    } }, onClick = {
                                        lines[index] = lines[index].copy(productName = product.productName, activeIngredient = product.activeIngredient, treatmentType = product.treatmentType)
                                        activeSuggestionIndex = -1
                                    }) }
                                }
                            }
                            OutlinedTextField(line.activeIngredient, { lines[index] = line.copy(activeIngredient = it) }, label = { Text("المادة الفعالة / العنصر") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(160.dp))
                            InvoiceDropdownChoice(
                                value = line.treatmentType,
                                options = if (line.productType == "الأسمدة") listOf("عام", "نمو", "تجذير", "ورقي") else listOf("حشري", "فطري", "ورقي", "جذري"),
                                modifier = Modifier.width(120.dp),
                                onSelect = { lines[index] = line.copy(treatmentType = it) }
                            )
                            InvoiceDropdownChoice(
                                value = line.packageName,
                                options = listOf("كيس", "عبوة"),
                                modifier = Modifier.width(110.dp),
                                onSelect = { lines[index] = line.copy(packageName = it) }
                            )
                            OutlinedTextField(line.packageSize, { lines[index] = line.copy(packageSize = latinDigitsOnly(it)) }, label = { Text("الحجم") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(95.dp))
                            InvoiceDropdownChoice(value = if (line.unit == "كجم") "كيلو" else line.unit, options = listOf("كيلو", "جرام", "ملي", "لتر"), modifier = Modifier.width(120.dp), onSelect = { selectedUnit -> lines[index] = line.copy(unit = if (selectedUnit == "كيلو") "كجم" else selectedUnit) })
                            OutlinedTextField(line.packageCount, { lines[index] = line.copy(packageCount = latinDigitsOnly(it)) }, label = { Text("العدد") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(85.dp))
                            MiyarMoneyInputField(line.unitPrice, { lines[index] = line.copy(unitPrice = it) }, label = "السعر ($currency)", imeAction = ImeAction.Next, modifier = Modifier.width(125.dp))
                            Text(lineYer?.let { formatMoney(it) } ?: "—", color = Green, fontWeight = FontWeight.Bold, modifier = Modifier.width(135.dp))
                            Text(unitYer?.let { String.format(Locale.US, "%.3f YER", it) } ?: "—", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.width(135.dp))
                            IconButton(onClick = { if (lines.size > 1) lines.removeAt(index) }) { Icon(Icons.Default.Delete, "حذف الصف", tint = MaterialTheme.colorScheme.error) }
                        }
                        HorizontalDivider(color = Gold.copy(alpha = 0.65f))
                    }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات الفاتورة") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                HorizontalDivider()
                Text("الإجمالي: $totalForeign $currency", fontWeight = FontWeight.Bold)
                Text("ما يعادله: ${formatMoney(totalYer)}", color = Emerald, fontWeight = FontWeight.ExtraBold)
                if (validation.isNotBlank()) Text(validation, color = MaterialTheme.colorScheme.error)
            }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(enabled = !saving, onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                    Button(enabled = !saving, onClick = {
                        when {
                            supplier.isBlank() -> validation = "أدخل اسم التاجر أو المورد."
                            invoiceNumber.isBlank() -> validation = "أدخل رقم الفاتورة."
                            lines.any { it.productName.isBlank() || digits(it.packageCount) <= 0 || digits(it.packageSize) <= 0 || digits(it.unitPrice) <= 0 } -> validation = "أكمل بيانات جميع أصناف الفاتورة."
                            lines.any { if (it.productType == "الأسمدة") it.treatmentType !in listOf("عام", "نمو", "تجذير", "ورقي") else it.treatmentType !in listOf("حشري", "فطري", "ورقي", "جذري") } -> validation = "حدد تصنيف كل صنف: السماد عام أو نمو أو تجذير أو ورقي، والسموم حشري أو فطري أو ورقي أو جذري."
                            quantityBases.any { it == null || it <= 0L } -> validation = "راجع الكميات والوحدات."
                            lineTotals.any { it == null } || totalForeignResult.isFailure -> validation = "راجع أسعار الأصناف."
                            currency != "YER" && rate <= 0 -> validation = "أدخل سعر صرف صحيحًا."
                            totalYerResult.isFailure -> validation = "تعذر تحويل إجمالي الفاتورة."
                            else -> {
                                val invoice = InvoiceEntity(id = initial?.id ?: 0, supplier = supplier.trim(), invoiceNumber = invoiceNumber.trim(), dateMillis = dateMillis, paymentStatus = paymentStatus, currency = currency, exchangeRateScaled = rate, totalForeign = totalForeign, totalYer = totalYer, notes = notes.trim())
                                val invoiceItems = lines.mapIndexed { index, line ->
                                    val foreign = requireNotNull(lineTotals[index]); val qty = requireNotNull(quantityBases[index])
                                    InvoiceItemEntity(invoiceId = invoice.id, stockItemId = 0, productType = line.productType, productName = line.productName.trim(), activeIngredient = line.activeIngredient.trim(), packageName = line.packageName.trim(), packageSize = digits(line.packageSize), packageCount = digits(line.packageCount), unit = line.unit, quantityBase = qty, unitPriceForeign = moneyToLong(line.unitPrice), lineTotalForeign = foreign, lineTotalYer = FinanceCalculations.toYemeniRials(foreign, rate), treatmentType = line.treatmentType)
                                }
                                saving = true
                                onSave(invoice, invoiceItems, sarRate, usdRate) { saving = false }
                            }
                        }
                    }, modifier = Modifier.weight(1f)) { Text(if (saving) "جارٍ الحفظ..." else "حفظ الفاتورة") }
                }
            }
        }
    }
}

@Composable
fun MiyarInventoryScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val stock by dao.observeStockItems().collectAsStateWithLifecycle(initialValue = emptyList())
    val movements by dao.observeStockUsageDetails().collectAsStateWithLifecycle(initialValue = emptyList())
    val issueVouchers by dao.observeStockIssueVouchers().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var selectedType by rememberSaveable { mutableStateOf("الكل") }
    var selectedTreatment by rememberSaveable { mutableStateOf("الكل") }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var showIssue by rememberSaveable { mutableStateOf(false) }
    var editingIssue by remember { mutableStateOf<StockIssueVoucherEntity?>(null) }
    var editingIssueLines by remember { mutableStateOf<List<StockIssueLineEntity>>(emptyList()) }
    var pendingDeleteIssue by remember { mutableStateOf<StockIssueVoucherEntity?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var stockSearch by rememberSaveable { mutableStateOf("") }
    var usageDialogItem by remember { mutableStateOf<StockItemEntity?>(null) }
    var unusedStockDialogName by remember { mutableStateOf<String?>(null) }
    var showIssueHistory by rememberSaveable { mutableStateOf(true) }

    // Sort by last receipt/opening-balance time, never by usage or issue updates.
    val orderedStock = stock.sortedWith(compareByDescending<StockItemEntity> { it.lastReceivedAtMillis }.thenByDescending { it.id })
    val byProductSection = orderedStock.filter { selectedType == "الكل" || it.productType == selectedType }
    val treatmentFiltered = byProductSection.filter { selectedTreatment == "الكل" || it.treatmentType == selectedTreatment }
    val query = stockSearch.trim()
    val filtered = treatmentFiltered.filter {
        query.isBlank() || it.productName.contains(query, ignoreCase = true) || it.activeIngredient.contains(query, ignoreCase = true)
    }
    val receivedGrams = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "g" }.map { it.totalReceivedBase })
    val usedGrams = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "g" }.map { it.totalUsedBase })
    val remainingGrams = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "g" }.map { it.quantityBase })
    val receivedMl = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "ml" }.map { it.totalReceivedBase })
    val usedMl = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "ml" }.map { it.totalUsedBase })
    val remainingMl = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "ml" }.map { it.quantityBase })
    fun mixedQuantity(grams: Long, ml: Long): String = buildList {
        if (grams > 0L) add(stockQuantity(grams, "g"))
        if (ml > 0L) add(stockQuantity(ml, "ml"))
    }.joinToString(" • ").ifBlank { "0" }

    Column(modifier.fillMaxWidth().background(Cream), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("المخزون", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                Text("ترتيب الأصناف حسب آخر توريد أو إضافة رصيد", style = MaterialTheme.typography.bodySmall, color = Green)
            }
            OutlinedButton(onClick = { showIssue = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = androidx.compose.ui.graphics.Color(0xFFB64040)), border = androidx.compose.foundation.BorderStroke(1.dp, androidx.compose.ui.graphics.Color(0xFFDFAAAA)), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 7.dp)) {
                Icon(Icons.Default.Remove, contentDescription = null); Spacer(Modifier.width(3.dp)); Text("صرف")
            }
            Button(onClick = { showAdd = true }, colors = ButtonDefaults.buttonColors(containerColor = Emerald), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 7.dp)) {
                Icon(Icons.Default.Add, contentDescription = null); Spacer(Modifier.width(3.dp)); Text("رصيد")
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            val typeColors = mapOf("الكل" to (androidx.compose.ui.graphics.Color(0xFF176B49) to androidx.compose.ui.graphics.Color.White), "الأسمدة" to (androidx.compose.ui.graphics.Color(0xFFDDF1D9) to androidx.compose.ui.graphics.Color(0xFF285C35)), "السموم" to (androidx.compose.ui.graphics.Color(0xFFE9E0F7) to androidx.compose.ui.graphics.Color(0xFF59427D)))
            listOf("الكل", "الأسمدة", "السموم").forEach { type ->
                val colors = typeColors.getValue(type)
                FilterChip(
                    selected = selectedType == type,
                    onClick = { selectedType = type; selectedTreatment = "الكل" },
                    label = { Text(type, maxLines = 1) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = colors.first, selectedLabelColor = colors.second,
                        containerColor = colors.first.copy(alpha = 0.32f), labelColor = colors.second
                    ),
                    border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selectedType == type, borderColor = colors.first, selectedBorderColor = colors.first)
                )
            }
            OutlinedTextField(
                value = stockSearch, onValueChange = { stockSearch = it }, modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("بحث صنف", maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                shape = RoundedCornerShape(12.dp), textStyle = MaterialTheme.typography.bodySmall,
                colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = androidx.compose.ui.graphics.Color.White, focusedContainerColor = androidx.compose.ui.graphics.Color.White)
            )
        }

        val treatments = when (selectedType) {
            "الأسمدة" -> listOf("الكل", "عام", "نمو", "تجذير", "ورقي")
            "السموم" -> listOf("الكل", "حشري", "فطري", "ورقي", "جذري")
            else -> listOf("الكل", "عام", "نمو", "تجذير", "حشري", "فطري", "ورقي", "جذري")
        }
        val treatmentPalette = mapOf(
            "الكل" to 0xFFE8EDE9, "عام" to 0xFFE3EFE5, "نمو" to 0xFFD9EEDB,
            "تجذير" to 0xFFF4E7CE, "ورقي" to 0xFFDCEAF5, "حشري" to 0xFFF8E1E1,
            "فطري" to 0xFFE9E1F4, "جذري" to 0xFFEDE8D5
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            treatments.forEach { kind ->
                val tint = androidx.compose.ui.graphics.Color(treatmentPalette[kind] ?: 0xFFE8EDE9)
                FilterChip(
                    selected = selectedTreatment == kind,
                    onClick = { selectedTreatment = kind },
                    label = { Text(kind) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = tint, selectedLabelColor = Emerald,
                        containerColor = tint.copy(alpha = 0.52f), labelColor = Green
                    ),
                    border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selectedTreatment == kind, borderColor = tint.copy(alpha = 0.9f), selectedBorderColor = Emerald.copy(alpha = 0.5f))
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            SummaryMiniCard("الأصناف", filtered.size.toString(), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFE4EDF8))
            SummaryMiniCard("المستلم", mixedQuantity(receivedGrams, receivedMl), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFDDF1E8))
            SummaryMiniCard("المستخدم", mixedQuantity(usedGrams, usedMl), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFFFF0D9))
            SummaryMiniCard("المتبقي", mixedQuantity(remainingGrams, remainingMl), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFDCEFE2))
        }

        if (showIssueHistory && issueVouchers.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("سندات الصرف السابقة", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showIssueHistory = false }) { Text("إخفاء") }
            }
            issueVouchers.forEach { voucher ->
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF4F1)), shape = RoundedCornerShape(11.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(voucher.reason, color = androidx.compose.ui.graphics.Color(0xFF994444), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                            Text("${localDate(voucher.dateMillis)} • سند رقم ${voucher.id}", color = Green, style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = {
                            scope.launch {
                                editingIssueLines = dao.getStockIssueLines(voucher.id)
                                editingIssue = voucher
                                showIssue = true
                            }
                        }) { Icon(Icons.Default.Edit, contentDescription = "تعديل سند الصرف", tint = Emerald) }
                        IconButton(onClick = { pendingDeleteIssue = voucher }) { Icon(Icons.Default.Delete, contentDescription = "حذف سند الصرف", tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) }
                    }
                }
            }
        } else if (issueVouchers.isNotEmpty()) {
            TextButton(onClick = { showIssueHistory = true }) { Text("عرض سندات الصرف السابقة (${issueVouchers.size})") }
        }

        if (query.length >= 1 && filtered.isEmpty()) Text("لا توجد أصناف تطابق البحث.", color = Green, modifier = Modifier.padding(8.dp))
        if (filtered.isEmpty() && query.isBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("لا توجد أصناف في المخزون", fontWeight = FontWeight.Bold)
                    Text("أضف رصيدًا افتتاحيًا أو سجّل فاتورة مشتريات.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        filtered.forEach { item ->
            val cardColor = if (item.productType == "الأسمدة") androidx.compose.ui.graphics.Color(0xFFF2F8EF) else androidx.compose.ui.graphics.Color(0xFFF2EFF8)
            Card(colors = CardDefaults.cardColors(containerColor = cardColor), shape = RoundedCornerShape(13.dp), elevation = CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CategoryArtwork(item.productType, Modifier.size(38.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.productName, fontWeight = FontWeight.Bold, color = Emerald)
                            Text("${item.productType} • ${item.treatmentType}", style = MaterialTheme.typography.labelSmall, color = Green)
                        }
                    }
                    if (item.activeIngredient.isNotBlank()) Text("المادة الفعالة / العنصر: ${item.activeIngredient}", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("المستلم", color = androidx.compose.ui.graphics.Color(0xFF286C4D), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Text(stockQuantity(item.totalReceivedBase, item.baseUnit), fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFF286C4D))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("المستخدم / الخارج", color = androidx.compose.ui.graphics.Color(0xFF94601C), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = {
                            if (item.totalUsedBase > 0L) usageDialogItem = item else unusedStockDialogName = item.productName
                        }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                            Text(stockQuantity(item.totalUsedBase, item.baseUnit), color = if (item.totalUsedBase > 0L) androidx.compose.ui.graphics.Color(0xFF94601C) else androidx.compose.ui.graphics.Color.Gray, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, contentDescription = "عرض سجل استخدام الصنف", modifier = Modifier.size(16.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("المتبقي", color = androidx.compose.ui.graphics.Color(0xFF236A40), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Text(stockQuantity(item.quantityBase, item.baseUnit), fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFF236A40))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }

    if (usageDialogItem != null) {
        val item = usageDialogItem!!
        val itemMovements = movements.filter { it.stockItemId == item.id }.sortedWith(compareByDescending<StockMovementDetail> { it.dateMillis }.thenByDescending { it.id })
        AlertDialog(
            onDismissRequest = { usageDialogItem = null },
            title = { Text("سجل حركة ${item.productName}", color = Emerald, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إجمالي الخارج: ${stockQuantity(item.totalUsedBase, item.baseUnit)}", color = Emerald, fontWeight = FontWeight.Bold)
                    if (itemMovements.isEmpty()) {
                        Text("لا توجد حركات خروج تفصيلية مرتبطة بهذا الصنف.")
                    } else itemMovements.forEach { movement ->
                        Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(10.dp)) {
                            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("الكمية: ${stockQuantity(kotlin.math.abs(movement.quantityBase), movement.baseUnit)}", color = Emerald, fontWeight = FontWeight.Bold)
                                Text("نوع الحركة: ${movement.operationCategory ?: movement.referenceType}", style = MaterialTheme.typography.bodySmall)
                                if (!movement.plantationName.isNullOrBlank()) Text("الموضع: ${movement.plantationName}", style = MaterialTheme.typography.bodySmall)
                                if (!movement.operationTitle.isNullOrBlank()) Text("البيان: ${movement.operationTitle}", style = MaterialTheme.typography.bodySmall)
                                Text("التاريخ: ${localDate(movement.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                                if (movement.description.isNotBlank()) Text(movement.description, style = MaterialTheme.typography.labelSmall, color = Green)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { usageDialogItem = null }) { Text("إغلاق") } }
        )
    }
    if (unusedStockDialogName != null) AlertDialog(
        onDismissRequest = { unusedStockDialogName = null },
        title = { Text("لا توجد استخدامات مسجلة", color = Emerald, fontWeight = FontWeight.Bold) },
        text = { Text("الصنف «$unusedStockDialogName» لم يخرج منه أي مقدار حتى الآن.") },
        confirmButton = { TextButton(onClick = { unusedStockDialogName = null }) { Text("حسنًا") } }
    )
    if (showAdd) StockOpeningDialog(if (selectedType == "الكل") "الأسمدة" else selectedType, onDismiss = { showAdd = false }) { entries ->
        scope.launch { try { dao.addOpeningStockBatch(if (selectedType == "الكل") "الأسمدة" else selectedType, entries); showAdd = false } catch (t: Throwable) { error = t.message ?: "تعذر إضافة الرصيد." } }
    }
    if (showIssue) StockIssueDialog(
        stockItems = orderedStock,
        initial = editingIssue,
        initialLines = editingIssueLines,
        onDismiss = { showIssue = false; editingIssue = null; editingIssueLines = emptyList() },
        onSave = { voucher, lines, complete ->
            scope.launch {
                runCatching { dao.saveStockIssue(voucher, lines) }
                    .onSuccess {
                        complete(true, null)
                        showIssue = false; editingIssue = null; editingIssueLines = emptyList()
                    }
                    .onFailure { complete(false, it.message ?: "تعذر حفظ سند الصرف.") }
            }
        }
    )
    if (pendingDeleteIssue != null) {
        val voucher = pendingDeleteIssue!!
        AlertDialog(
            onDismissRequest = { pendingDeleteIssue = null },
            title = { Text("تأكيد حذف سند الصرف") },
            text = { Text("سيُعاد أثر جميع كميات هذا السند إلى المخزون. هل تريد المتابعة؟") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    val deleted = runCatching { dao.deleteStockIssue(voucher.id) }.getOrDefault(false)
                    if (!deleted) error = "تعذر حذف السند لأن بيانات الرصيد غير متسقة. لم يُغيّر النظام أي كمية."
                    pendingDeleteIssue = null
                }
            }) { Text("حذف وإعادة الكميات", color = androidx.compose.ui.graphics.Color(0xFFB3261E)) } },
            dismissButton = { TextButton(onClick = { pendingDeleteIssue = null }) { Text("إلغاء") } }
        )
    }
    if (error != null) AlertDialog(onDismissRequest = { error = null }, title = { Text("تنبيه المخزون") }, text = { Text(error!!) }, confirmButton = { TextButton(onClick = { error = null }) { Text("حسنًا") } })
}

private data class StockIssueRowUi(
    val stockItemId: Long? = null,
    val quantity: String = "",
    val unit: String = ""
)

@Composable
private fun StockIssueDialog(
    stockItems: List<StockItemEntity>,
    initial: StockIssueVoucherEntity?,
    initialLines: List<StockIssueLineEntity>,
    onDismiss: () -> Unit,
    onSave: (StockIssueVoucherEntity, List<StockIssueLineInput>, (Boolean, String?) -> Unit) -> Unit
) {
    var dateMillis by rememberSaveable(initial?.id) { mutableLongStateOf(initial?.dateMillis ?: System.currentTimeMillis()) }
    var reason by rememberSaveable(initial?.id) { mutableStateOf(initial?.reason ?: "صرف سابق قبل استخدام مِعيار") }
    var notes by rememberSaveable(initial?.id) { mutableStateOf(initial?.notes.orEmpty()) }
    var error by rememberSaveable(initial?.id) { mutableStateOf("") }
    var saving by rememberSaveable(initial?.id) { mutableStateOf(false) }
    val rows = remember(initial?.id, stockItems, initialLines) {
        androidx.compose.runtime.mutableStateListOf<StockIssueRowUi>().apply {
            if (initialLines.isNotEmpty()) initialLines.forEach { add(StockIssueRowUi(it.stockItemId, it.enteredQuantity.toString(), it.unit)) }
            else add(StockIssueRowUi(unit = if (stockItems.firstOrNull()?.baseUnit == "g") "كجم" else "لتر"))
        }
    }
    var stockMenuIndex by remember { mutableIntStateOf(-1) }
    var unitMenuIndex by remember { mutableIntStateOf(-1) }
    val inputs = rows.mapNotNull { row ->
        val selected = row.stockItemId?.let { id -> stockItems.firstOrNull { it.id == id } }
        val entered = row.quantity.toLongOrNull() ?: 0L
        if (selected == null || entered <= 0L) null else runCatching {
            StockIssueLineInput(selected.id, row.unit, entered, FinanceCalculations.quantityToBase(entered, row.unit))
        }.getOrNull()
    }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (initial == null) "سند صرف مخزني جديد" else "تعديل سند الصرف رقم ${initial.id}", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                MiyarDateField("تاريخ الصرف", dateMillis) { dateMillis = it }
                OutlinedTextField(reason, { reason = it }, label = { Text("بيان الصرف / سبب الخروج") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات إضافية (اختياري)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text("أصناف السند", color = Emerald, fontWeight = FontWeight.Bold)
                rows.forEachIndexed { index, row ->
                    val selected = row.stockItemId?.let { id -> stockItems.firstOrNull { it.id == id } }
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الصنف ${index + 1}", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (rows.size > 1) IconButton(onClick = { rows.removeAt(index) }) { Icon(Icons.Default.Delete, contentDescription = "حذف السطر", tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) }
                            }
                            Box {
                                OutlinedButton(onClick = { stockMenuIndex = index }, modifier = Modifier.fillMaxWidth()) {
                                    Text(selected?.let { "${it.productName} • ${it.treatmentType}" } ?: "اختر صنفًا من المخزون", modifier = Modifier.weight(1f), maxLines = 1)
                                    Icon(Icons.Default.ArrowDropDown, null)
                                }
                                DropdownMenu(expanded = stockMenuIndex == index, onDismissRequest = { stockMenuIndex = -1 }) {
                                    stockItems.forEach { item ->
                                        DropdownMenuItem(text = { Text("${item.productName} • ${item.treatmentType} (${stockQuantity(item.quantityBase, item.baseUnit)})") }, onClick = {
                                            val defaultUnit = if (item.baseUnit == "g") "كجم" else "لتر"
                                            rows[index] = row.copy(stockItemId = item.id, quantity = "", unit = defaultUnit)
                                            stockMenuIndex = -1
                                        })
                                    }
                                }
                            }
                            if (selected != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(row.quantity, { rows[index] = row.copy(quantity = it.filter(Char::isDigit)) }, label = { Text("الكمية") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    Box {
                                        OutlinedButton(onClick = { unitMenuIndex = index }) { Text(row.unit.ifBlank { if (selected.baseUnit == "g") "كجم" else "لتر" }); Icon(Icons.Default.ArrowDropDown, null) }
                                        DropdownMenu(expanded = unitMenuIndex == index, onDismissRequest = { unitMenuIndex = -1 }) {
                                            (if (selected.baseUnit == "g") listOf("كجم", "جرام") else listOf("لتر", "ملي")).forEach { unit ->
                                                DropdownMenuItem(text = { Text(unit) }, onClick = { rows[index] = row.copy(unit = unit); unitMenuIndex = -1 })
                                            }
                                        }
                                    }
                                }
                                val entered = row.quantity.toLongOrNull() ?: 0L
                                val base = runCatching { FinanceCalculations.quantityToBase(entered, row.unit) }.getOrDefault(0L)
                                val remaining = selected.quantityBase
                                Text("المتاح: ${stockQuantity(remaining, selected.baseUnit)} • المطلوب: ${if (base > 0L) stockQuantity(base, selected.baseUnit) else "—"}", color = if (base > remaining) androidx.compose.ui.graphics.Color(0xFFB3261E) else Green, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                val previewByStock = inputs.groupBy { it.stockItemId }.mapNotNull { (stockId, linesForStock) ->
                    val item = stockItems.firstOrNull { it.id == stockId } ?: return@mapNotNull null
                    val quantity = runCatching { FinanceCalculations.sumExact(linesForStock.map { it.quantityBase }) }.getOrDefault(Long.MAX_VALUE)
                    item to quantity
                }
                if (previewByStock.isNotEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3E8)), shape = RoundedCornerShape(11.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("مراجعة الرصيد بعد الصرف", color = androidx.compose.ui.graphics.Color(0xFF8B5528), fontWeight = FontWeight.Bold)
                            previewByStock.forEach { (item, issueQuantity) ->
                                val enough = item.quantityBase >= issueQuantity
                                val after = if (enough) item.quantityBase - issueQuantity else 0L
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(item.productName, color = Emerald, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                    Text("قبل: ${stockQuantity(item.quantityBase, item.baseUnit)} • صرف: ${stockQuantity(issueQuantity, item.baseUnit)}", style = MaterialTheme.typography.labelSmall)
                                    Text(if (enough) "بعد الصرف: ${stockQuantity(after, item.baseUnit)}" else "غير كافٍ — المتاح ${stockQuantity(item.quantityBase, item.baseUnit)} فقط", color = if (enough) Green else androidx.compose.ui.graphics.Color(0xFFB3261E), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                                if (previewByStock.last().first.id != item.id) HorizontalDivider(color = androidx.compose.ui.graphics.Color(0xFFD9C8B8))
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { rows.add(StockIssueRowUi()) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("إضافة صنف آخر للسند") }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { Button(enabled = !saving, onClick = {
            val valid = rows.size == inputs.size && rows.isNotEmpty() && reason.isNotBlank() && rows.all { it.stockItemId != null && (it.quantity.toLongOrNull() ?: 0L) > 0L }
            if (!valid) error = "أكمل اختيار جميع الأصناف وأدخل كميات صحيحة وسبب الصرف."
            else {
                saving = true
                onSave(StockIssueVoucherEntity(id = initial?.id ?: 0L, dateMillis = dateMillis, reason = reason.trim(), notes = notes.trim(), createdAtMillis = initial?.createdAtMillis ?: System.currentTimeMillis()), inputs) { success, message ->
                    saving = false
                    if (!success) error = message ?: "تعذر حفظ سند الصرف."
                }
            }
        }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ سند الصرف") } },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun SummaryMiniCard(title: String, value: String, modifier: Modifier = Modifier, tint: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = tint)) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Green)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
    }
}

private data class OpeningStockRowUi(
    val name: String = "",
    val ingredient: String = "",
    val unit: String,
    val quantity: String = "",
    val treatment: String,
    val cost: String = ""
)

@Composable
private fun StockOpeningDialog(type: String, onDismiss: () -> Unit, onSave: (List<OpeningStockInput>) -> Unit) {
    val defaultUnit = if (type == "الأسمدة") "كجم" else "لتر"
    val defaultTreatment = if (type == "الأسمدة") "عام" else "حشري"
    val rows = remember(type) { androidx.compose.runtime.mutableStateListOf(OpeningStockRowUi(unit = defaultUnit, treatment = defaultTreatment)) }
    var error by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة رصيد افتتاحي: $type") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("أدخل الكمية وقيمتها الإجمالية للصنف. يمكنك إضافة أكثر من صنف في الحفظ نفسه. إذا لم تعرف قيمة الصنف، اترك القيمة صفرًا وأدخل تكلفة الاستخدام يدويًا عند تسجيل العملية.", style = MaterialTheme.typography.bodySmall)
                rows.forEachIndexed { index, row ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(13.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الصنف ${index + 1}", modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.Bold)
                                if (rows.size > 1) IconButton(onClick = { rows.removeAt(index) }) { Icon(Icons.Default.Delete, contentDescription = "حذف الصنف", tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) }
                            }
                            OutlinedTextField(row.name, { rows[index] = row.copy(name = it) }, label = { Text("اسم الصنف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(row.ingredient, { rows[index] = row.copy(ingredient = it) }, label = { Text("المادة الفعالة / العنصر") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                (if (type == "الأسمدة") listOf("عام", "نمو", "تجذير", "ورقي") else listOf("حشري", "فطري", "ورقي", "جذري")).forEach { item ->
                                    FilterChip(selected = row.treatment == item, onClick = { rows[index] = row.copy(treatment = item) }, label = { Text(item) })
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                listOf("كجم", "لتر", "جرام", "ملي").forEach { item -> FilterChip(selected = row.unit == item, onClick = { rows[index] = row.copy(unit = item) }, label = { Text(item) }) }
                            }
                            OutlinedTextField(row.quantity, { rows[index] = row.copy(quantity = latinDigitsOnly(it)) }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                            MiyarMoneyInputField(row.cost, { rows[index] = row.copy(cost = it) }, label = "القيمة الإجمالية لهذا الرصيد (ر.ي)", modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                OutlinedButton(onClick = { rows.add(OpeningStockRowUi(unit = defaultUnit, treatment = defaultTreatment)); error = "" }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Text("إضافة صنف آخر")
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = {
            val valid = rows.mapNotNull { row ->
                val base = row.quantity.toLongOrNull()?.let { runCatching { FinanceCalculations.quantityToBase(it, row.unit) }.getOrNull() } ?: 0L
                val cost = moneyToLong(row.cost)
                if (row.name.isBlank() || base <= 0L || cost < 0L) null
                else OpeningStockInput(row.name.trim(), row.ingredient.trim(), row.unit, base, row.treatment, cost)
            }
            if (valid.size != rows.size) error = "تحقق من اسم كل صنف وكميته وقيمته قبل الحفظ."
            else onSave(valid)
        }) { Text("حفظ الأرصدة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun MiyarReportsScreen(
    dao: MiyarDao,
    modifier: Modifier = Modifier,
    onExportReport: (type: String, fromMillis: Long, untilMillis: Long, plantationId: Long?) -> Unit = { _, _, _, _ -> }
) {
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val today = remember { System.currentTimeMillis() }
    val cal = remember { java.util.Calendar.getInstance().apply { timeInMillis = today; set(java.util.Calendar.DAY_OF_MONTH, 1); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) } }
    var from by rememberSaveable { mutableLongStateOf(cal.timeInMillis) }
    var to by rememberSaveable { mutableLongStateOf(today) }
    var selectedPlantationId by rememberSaveable { mutableStateOf<Long?>(null) }
    val endExclusive = remember(to) {
        java.util.Calendar.getInstance().apply { timeInMillis = to; add(java.util.Calendar.DAY_OF_YEAR, 1); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
    }
    val summary by dao.observeReportSummary(from, endExclusive, selectedPlantationId).collectAsStateWithLifecycle(
        initialValue = ReportSummary(0, 0, 0, 0, 0, 0, 0, 0)
    )
    val reportRows = remember { androidx.compose.runtime.mutableStateListOf<ExpenseWithPlantation>() }
    val reportScope = rememberCoroutineScope()
    var loadedPage by rememberSaveable { mutableIntStateOf(0) }
    var loadingPage by remember { mutableStateOf(false) }
    var hasMore by remember { mutableStateOf(true) }
    LaunchedEffect(from, endExclusive, selectedPlantationId) {
        reportRows.clear()
        loadedPage = 0
        hasMore = true
        loadingPage = true
        runCatching { dao.getReportExpensePage(from, endExclusive, selectedPlantationId, 50, 0) }
            .onSuccess { reportRows.addAll(it); loadedPage = 1; hasMore = it.size == 50 }
        loadingPage = false
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("التقارير وكشوف الحسابات", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
        Text("اختر الفترة والموضع، ثم صدّر التقرير المطلوب بصيغة PDF بهوية مِعيار.", style = MaterialTheme.typography.bodySmall)
        MiyarDateField("من تاريخ", from) { from = it }
        MiyarDateField("إلى تاريخ", to) { to = it }
        Text("تصفية الموضع", color = Emerald, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = selectedPlantationId == null, onClick = { selectedPlantationId = null }, label = { Text("كل المواضع") })
            plantations.forEach { plot ->
                FilterChip(selected = selectedPlantationId == plot.id, onClick = { selectedPlantationId = plot.id }, label = { Text(plot.name) })
            }
        }
        FinancialCard("💸 إجمالي الخرج", formatMoney(summary.expenseTotal), "${summary.expenseCount} عملية خلال الفترة")
        FinancialCard("💰 إجمالي المردود", formatMoney(summary.harvestTotal), "القطفات المسجلة في دفتر العمليات")
        FinancialCard("🧾 قيمة الفواتير بالريال اليمني", formatMoney(summary.invoiceTotal), "قيمة الفواتير في الفترة")
        FinancialCard("📊 صافي الفرق", formatMoney(summary.harvestTotal - summary.expenseTotal), "المردود المسجل ناقص المصروفات المسجلة")
        Text("ملخص الأنشطة", color = Emerald, fontWeight = FontWeight.Bold)
        listOf(
            "السموم والأسمدة" to summary.chemicalTotal,
            "المياه والري" to summary.waterTotal,
            "الأعمال اليدوية" to summary.laborTotal,
            "أخرى" to summary.otherTotal
        ).forEach { (label, total) ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.SemiBold)
                    Text(formatMoney(total), color = Emerald, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text("تصدير التقارير وكشوف الحساب بصيغة PDF", color = Emerald, fontWeight = FontWeight.Bold)
        val pdfReports = listOf(
            "كشف حساب الموضع الزراعي" to "plantation",
            "تقرير الأنشطة الزراعية بالتفصيل" to "activities",
            "كشف العملاء والمشترين والبائعين" to "buyers",
            "كشف التجار والموردين" to "suppliers",
            "الفواتير وتفاصيل الأصناف" to "invoices",
            "التقرير المالي والإنتاجي" to "financial"
        )
        pdfReports.forEach { (label, type) ->
            OutlinedButton(
                onClick = { onExportReport(type, from, endExclusive, selectedPlantationId) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("📄 $label — PDF") }
        }
        Text("سجل العمليات — عرض تدريجي", color = Emerald, fontWeight = FontWeight.Bold)
        Text("يتم تحميل 50 سجلًا في كل مرة لتقليل استهلاك الذاكرة.", style = MaterialTheme.typography.bodySmall)
        reportRows.forEach { record ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(record.title, fontWeight = FontWeight.SemiBold)
                        Text("${record.plantationName} • ${record.category} • ${localDate(record.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(formatMoney(record.amount), fontWeight = FontWeight.Bold)
                }
            }
        }
        if ((loadedPage > 1 || hasMore) && !loadingPage) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (loadedPage > 1) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    loadingPage = true
                    reportScope.launch {
                        runCatching { dao.getReportExpensePage(from, endExclusive, selectedPlantationId, 50, (loadedPage - 2) * 50) }
                            .onSuccess { reportRows.clear(); reportRows.addAll(it); loadedPage--; hasMore = true }
                        loadingPage = false
                    }
                }) { Text("السابق") }
                if (hasMore) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    loadingPage = true
                    reportScope.launch {
                        runCatching { dao.getReportExpensePage(from, endExclusive, selectedPlantationId, 50, loadedPage * 50) }
                            .onSuccess { reportRows.clear(); reportRows.addAll(it); loadedPage++; hasMore = it.size == 50 }
                        loadingPage = false
                    }
                }) { Text("التالي — 50 عملية") }
            }
        }
        if (loadingPage) Text("جارٍ تحميل السجلات…", color = Green)
        if (reportRows.isEmpty() && !loadingPage) Text("لا توجد عمليات مسجلة في الفترة المحددة.", color = Green)
    }
}


@Composable
fun MiyarRemindersScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val reminders by dao.observeOperationReminders().collectAsStateWithLifecycle(initialValue = emptyList())
    val personalHarvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(initialValue = emptyList())
    val buyerSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(initialValue = emptyList())
    val buyers by dao.observeBuyers().collectAsStateWithLifecycle(initialValue = emptyList())
    val reminderContext = LocalContext.current
    LaunchedEffect(personalHarvests, buyerSales, buyers) {
        personalHarvests.filter { it.actualEndMillis == 0L && it.expectedEndMillis > System.currentTimeMillis() }.forEach { harvest ->
            val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(harvest.expectedEndMillis))
            ReminderScheduler.schedule(reminderContext, harvest.id, "انتهاء القطفة ${harvest.name}", "القطفات", "موضع القطفة", date, "09:00", "PERSONAL_HARVEST")
        }
        buyerSales.filter { it.actualEndMillis == 0L && it.expectedEndMillis > System.currentTimeMillis() }.forEach { sale ->
            val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(sale.expectedEndMillis))
            val buyerName = buyers.firstOrNull { it.id == sale.buyerId }?.name ?: "المشتري"
            ReminderScheduler.schedule(reminderContext, sale.id, "موعد انتهاء قطفة البيع ${sale.harvestName}", "القطفات", buyerName, date, "09:00", "BUYER_HARVEST")
        }
    }
    val now = System.currentTimeMillis()
    val horizon = now + 3L * 24L * 60L * 60L * 1000L
    val soon = reminders.filter { it.scheduledAtMillis >= now && it.scheduledAtMillis <= horizon }
    val overdue = reminders.filter { it.scheduledAtMillis < now }
    val personalHarvestDue = personalHarvests.filter { it.actualEndMillis == 0L && it.expectedEndMillis <= horizon }
    val buyerHarvestDue = buyerSales.filter { it.actualEndMillis == 0L && it.expectedEndMillis <= horizon }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🔔 التنبيهات والمواعيد", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
        Text("المواعيد المحفوظة للعمليات الزراعية والقطفات", style = MaterialTheme.typography.bodySmall)
        FinancialCard("⏰ مواعيد خلال 3 أيام", soon.size.toString(), "تذكيرات قريبة تحتاج الاستعداد لها")
        FinancialCard("⚠️ مواعيد تجاوزت تاريخها", overdue.size.toString(), "راجع هذه العمليات وحدّث مواعيدها")
        Text("اقتراحات مِعيار الذكية", color = Emerald, fontWeight = FontWeight.Bold)
        if (overdue.isNotEmpty()) overdue.take(4).forEach { item ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF0E5))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("⚠️ موعد متجاوز: ${item.category}", color = androidx.compose.ui.graphics.Color(0xFF9B3A18), fontWeight = FontWeight.Bold)
                    Text("${item.title} — ${item.plantationName}")
                    Text("${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(item.scheduledAtMillis))}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (soon.isNotEmpty()) soon.take(6).forEach { item ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE8F8ED))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("🔔 ${item.category} — ${item.title}", color = Emerald, fontWeight = FontWeight.Bold)
                    Text("الموضع: ${item.plantationName}")
                    Text("${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(item.scheduledAtMillis))}", style = MaterialTheme.typography.labelSmall, color = Green)
                }
            }
        }
        Text("متابعة مواعيد القطفات", color = Emerald, fontWeight = FontWeight.Bold)
        val harvestDueCount = personalHarvestDue.size + buyerHarvestDue.size
        FinancialCard("🧺 قطفات اقترب موعد انتهائها أو تجاوزته", harvestDueCount.toString(), "مقارنة بالتاريخ المتوقع المحفوظ في سجل القطفة")
        personalHarvestDue.forEach { harvest ->
            val days = java.util.concurrent.TimeUnit.MILLISECONDS.toDays(harvest.expectedEndMillis - now)
            Card(colors = CardDefaults.cardColors(containerColor = if (days < 0) androidx.compose.ui.graphics.Color(0xFFFFF0E5) else androidx.compose.ui.graphics.Color(0xFFE8F8ED))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("قطفة شخصية: ${harvest.name}", fontWeight = FontWeight.Bold, color = Emerald)
                    Text(if (days < 0) "تجاوزت تاريخ الانتهاء المتوقع" else "الموعد المتوقع خلال ${days + 1} يوم تقريبًا")
                    Text("التاريخ: ${localDate(harvest.expectedEndMillis)}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        buyerHarvestDue.forEach { sale ->
            val buyerName = buyers.firstOrNull { it.id == sale.buyerId }?.name ?: "مشتري"
            val days = java.util.concurrent.TimeUnit.MILLISECONDS.toDays(sale.expectedEndMillis - now)
            Card(colors = CardDefaults.cardColors(containerColor = if (days < 0) androidx.compose.ui.graphics.Color(0xFFFFF0E5) else androidx.compose.ui.graphics.Color(0xFFE8F8ED))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("قطفة بيع لمشتري: ${sale.harvestName}", fontWeight = FontWeight.Bold, color = Emerald)
                    Text("المشتري: $buyerName")
                    Text(if (days < 0) "تجاوزت تاريخ الانتهاء المتوقع" else "الموعد المتوقع خلال ${days + 1} يوم تقريبًا")
                    Text("التاريخ: ${localDate(sale.expectedEndMillis)}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (reminders.isEmpty() && harvestDueCount == 0) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("لا توجد تنبيهات محفوظة بعد", fontWeight = FontWeight.Bold)
                    Text("تظهر مواعيد العمليات المحفوظة هنا، وتُعرض مواعيد نهاية القطفات المتوقعة للمراجعة.", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("اقتراح: حدّد مواعيد متابعة التسميد والرش والري، وراجع تاريخ نهاية القطفة المتوقع.", color = Green)
        }
        Text("جميع المواعيد مرتبة زمنيًا", color = Emerald, fontWeight = FontWeight.Bold)
        reminders.forEach { item ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔔", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, fontWeight = FontWeight.Bold)
                        Text("${item.category} • ${item.plantationName}", style = MaterialTheme.typography.bodySmall)
                        Text(SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(item.scheduledAtMillis)), color = Green, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}


@Composable
fun MiyarCurrencySettingsCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    var sar by remember { mutableStateOf(prefs.getString("sar", "") ?: "") }
    var usd by remember { mutableStateOf(prefs.getString("usd", "") ?: "") }
    var saved by remember { mutableStateOf(false) }
    Card(modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("إعدادات أسعار الصرف", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            Text("تُستخدم الأسعار الجديدة في الفواتير ودفعات الموردين الجديدة فقط. الأسعار السابقة محفوظة داخل كل فاتورة ودفعة.", style = MaterialTheme.typography.bodySmall)
            MiyarRateInputField(sar, { sar = it; saved = false }, label = "سعر 1 ريال سعودي بالريال اليمني", modifier = Modifier.fillMaxWidth())
            MiyarRateInputField(usd, { usd = it; saved = false }, label = "سعر 1 دولار بالريال اليمني", imeAction = ImeAction.Done, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val sarValue = rateScaled(sar)
                val usdValue = rateScaled(usd)
                if (sarValue > 0 && usdValue > 0) {
                    prefs.edit().putString("sar", rateInput(sar)).putString("usd", rateInput(usd)).apply()
                    saved = true
                } else saved = false
            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ أسعار الصرف") }
            if (saved) Text("تم حفظ أسعار الصرف. ستُستخدم في العمليات المالية الجديدة.", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MiyarSuppliersScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val accounts by dao.observeSupplierAccounts().collectAsStateWithLifecycle(initialValue = emptyList())
    val payments by dao.observeRecentSupplierPaymentsWithName().collectAsStateWithLifecycle(initialValue = emptyList())
    val invoices by dao.observeRecentInvoices().collectAsStateWithLifecycle(initialValue = emptyList())
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var selectedSupplier by remember { mutableStateOf<SupplierAccountSummary?>(null) }
    var showPayment by rememberSaveable { mutableStateOf(false) }
    var showSupplier by rememberSaveable { mutableStateOf(false) }
    var supplierName by rememberSaveable { mutableStateOf("") }
    var supplierPhone by rememberSaveable { mutableStateOf("") }
    var supplierNotes by rememberSaveable { mutableStateOf("") }
    var paymentDateMillis by rememberSaveable { mutableLongStateOf(System.currentTimeMillis()) }
    var paymentAmount by rememberSaveable { mutableStateOf("") }
    var paymentCurrency by rememberSaveable { mutableStateOf("YER") }
    var paymentRate by rememberSaveable { mutableStateOf("1") }
    var paymentMethod by rememberSaveable { mutableStateOf("نقدًا") }
    var paymentNotes by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var saving by rememberSaveable { mutableStateOf(false) }

    val outstanding = FinanceCalculations.sumExact(accounts.map { it.balanceYer })
    val creditTotal = FinanceCalculations.sumExact(accounts.map { it.totalCreditYer })
    val paidTotal = FinanceCalculations.sumExact(accounts.map { it.totalPaidYer })
    Column(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("التجار والموردون", color = Emerald, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text("ملفات الموردين وكشوف حساب الفواتير الآجلة والدفعات", style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { supplierName = ""; supplierPhone = ""; supplierNotes = ""; showSupplier = true }) { Icon(Icons.Default.Add, null); Text("مورد") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SummaryMiniCard("إجمالي الآجل", formatMoney(creditTotal), Modifier.weight(1f))
            SummaryMiniCard("المسدد", formatMoney(paidTotal), Modifier.weight(1f))
            SummaryMiniCard("المتبقي", formatMoney(outstanding), Modifier.weight(1f))
        }
        if (accounts.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("لا توجد ملفات موردين بعد", color = Emerald, fontWeight = FontWeight.Bold)
                    Text("تُنشأ الملفات تلقائيًا عند تسجيل فاتورة، ويمكنك إضافة ملف يدويًا.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(accounts, key = { it.id }) { account ->
                val supplierPayments = payments.filter { it.supplierId == account.id }
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(account.name, color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                if (account.phone.isNotBlank()) Text(account.phone, style = MaterialTheme.typography.bodySmall)
                                if (account.notes.isNotBlank()) Text(account.notes, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            Text(if (account.balanceYer > 0) "عليه مستحقات" else "مسدد", color = if (account.balanceYer > 0) androidx.compose.ui.graphics.Color(0xFF9A5700) else Green, fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("فواتير آجلة: ${account.invoiceCount}", style = MaterialTheme.typography.labelSmall)
                            Text("إجمالي الآجل: ${formatMoney(account.totalCreditYer)}", style = MaterialTheme.typography.labelSmall)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المسدد: ${formatMoney(account.totalPaidYer)}", color = Green, style = MaterialTheme.typography.labelSmall)
                            Text("المتبقي: ${formatMoney(account.balanceYer)}", color = Emerald, fontWeight = FontWeight.ExtraBold)
                        }
                        val supplierInvoices = invoices.filter { it.supplier.equals(account.name, true) }
                        Text("الفواتير المعروضة: ${supplierInvoices.size} من أحدث السجلات", style = MaterialTheme.typography.labelSmall)
                        if (supplierPayments.isNotEmpty()) {
                            HorizontalDivider(color = Gold.copy(alpha = .4f))
                            Text("آخر دفعة: ${localDate(supplierPayments.first().dateMillis)} • ${formatNumber(supplierPayments.first().amountForeign)} ${supplierPayments.first().currency} • ${formatMoney(supplierPayments.first().amountYer)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { selectedSupplier = account }) { Text("كشف الحساب (${supplierPayments.size} حديثة)") }
                            Button(enabled = account.balanceYer > 0, onClick = {
                                selectedSupplier = account
                                paymentAmount = ""
                                paymentCurrency = "YER"
                                paymentRate = "1"
                                paymentMethod = "نقدًا"
                                paymentNotes = ""
                                paymentDateMillis = System.currentTimeMillis()
                                showPayment = true
                            }) { Icon(Icons.Default.Add, null); Text("تسجيل دفعة") }
                        }
                    }
                }
            }
        }
    }

    if (showSupplier) {
        AlertDialog(
            onDismissRequest = { if (!saving) showSupplier = false },
            title = { Text("إضافة ملف مورد") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(supplierName, { supplierName = it }, label = { Text("اسم المورد") }, singleLine = true)
                OutlinedTextField(supplierPhone, { supplierPhone = it }, label = { Text("رقم الهاتف (اختياري)") }, singleLine = true)
                OutlinedTextField(supplierNotes, { supplierNotes = it }, label = { Text("ملاحظات المورد") }, minLines = 2)
            } },
            confirmButton = { TextButton(enabled = !saving, onClick = {
                if (supplierName.isBlank()) { message = "أدخل اسم المورد."; return@TextButton }
                saving = true
                scope.launch { try { dao.saveSupplierProfile(supplierName, supplierPhone, supplierNotes); showSupplier = false } catch (t: Throwable) { message = t.message ?: "تعذر حفظ المورد." } finally { saving = false } }
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showSupplier = false }) { Text("إلغاء") } }
        )
    }
    if (showPayment && selectedSupplier != null) {
        val rate = rateScaled(paymentRate)
        val yerAmount = if (paymentCurrency == "YER") moneyToLong(paymentAmount) else runCatching { FinanceCalculations.toYemeniRials(moneyToLong(paymentAmount), rate) }.getOrDefault(0L)
        AlertDialog(
            onDismissRequest = { if (!saving) showPayment = false },
            title = { Text("دفعة للمورد: ${selectedSupplier!!.name}") },
            text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المتبقي عليه: ${formatMoney(selectedSupplier!!.balanceYer)}", color = Emerald, fontWeight = FontWeight.Bold)
                MiyarDateField("تاريخ الدفعة", paymentDateMillis) { paymentDateMillis = it }
                MiyarMoneyInputField(paymentAmount, { paymentAmount = it }, label = "مبلغ الدفعة", imeAction = ImeAction.Done, modifier = Modifier.fillMaxWidth())
                Text("عملة الدفع", color = Emerald, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("YER", "SAR", "USD").forEach { c -> FilterChip(selected = paymentCurrency == c, onClick = {
                        paymentCurrency = c
                        paymentRate = when (c) { "YER" -> "1"; "SAR" -> prefs.getString("sar", "") ?: ""; else -> prefs.getString("usd", "") ?: "" }
                    }, label = { Text(c) }) }
                }
                if (paymentCurrency != "YER") MiyarRateInputField(paymentRate, { paymentRate = it }, label = "سعر صرف 1 $paymentCurrency بالريال اليمني", imeAction = ImeAction.Done, modifier = Modifier.fillMaxWidth())
                Text("المقابل بالريال اليمني: ${formatMoney(yerAmount)}", color = Green, fontWeight = FontWeight.ExtraBold)
                Text("طريقة الدفع", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("نقدًا", "تحويل", "شيك").forEach { method -> FilterChip(selected = paymentMethod == method, onClick = { paymentMethod = method }, label = { Text(method) }) } }
                OutlinedTextField(paymentNotes, { paymentNotes = it }, label = { Text("ملاحظات الدفعة") }, minLines = 2)
            } },
            confirmButton = { TextButton(enabled = !saving, onClick = {
                if (moneyToLong(paymentAmount) <= 0L || (paymentCurrency != "YER" && rate <= 0L)) { message = "أدخل مبلغًا وسعر صرف صحيحين."; return@TextButton }
                saving = true
                scope.launch { try {
                    dao.addSupplierPayment(SupplierPaymentEntity(supplierId = selectedSupplier!!.id, dateMillis = paymentDateMillis, currency = paymentCurrency, amountForeign = moneyToLong(paymentAmount), exchangeRateScaled = if (paymentCurrency == "YER") 1000L else rate, amountYer = yerAmount, paymentMethod = paymentMethod, notes = paymentNotes.trim()))
                    showPayment = false
                    selectedSupplier = null
                    message = "تم تسجيل الدفعة وحفظ سعر صرفها في كشف حساب المورد."
                } catch (t: Throwable) { message = t.message ?: "تعذر تسجيل الدفعة." } finally { saving = false } }
            }) { Text(if (saving) "جارٍ الحفظ" else "حفظ الدفعة") } },
            dismissButton = { TextButton(enabled = !saving, onClick = { showPayment = false }) { Text("إلغاء") } }
        )
    }
    if (selectedSupplier != null && !showPayment && !showSupplier) {
        val supplier = selectedSupplier!!
        val history = payments.filter { it.supplierId == supplier.id }
        val supplierInvoices = invoices.filter { it.supplier.equals(supplier.name, true) }.sortedByDescending { it.dateMillis }
        AlertDialog(onDismissRequest = { selectedSupplier = null }, title = { Text("كشف حساب ${supplier.name}") },
            text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("إجمالي الفواتير الآجلة: ${formatMoney(supplier.totalCreditYer)}")
                Text("إجمالي الدفعات: ${formatMoney(supplier.totalPaidYer)}")
                Text("الرصيد المتبقي: ${formatMoney(supplier.balanceYer)}", color = Emerald, fontWeight = FontWeight.Bold)
                HorizontalDivider()
                Text("الفواتير — أحدث السجلات المعروضة", fontWeight = FontWeight.Bold, color = Emerald)
                if (supplierInvoices.isEmpty()) Text("لا توجد فواتير مسجلة.")
                supplierInvoices.forEach { invoice ->
                    Text("${localDate(invoice.dateMillis)} • ${invoice.invoiceNumber} • ${invoice.paymentStatus} • ${formatMoney(invoice.totalYer)}", fontWeight = FontWeight.SemiBold)
                }
                HorizontalDivider()
                Text("الدفعات — أحدث السجلات المعروضة", fontWeight = FontWeight.Bold, color = Emerald)
                if (history.isEmpty()) Text("لا توجد دفعات مسجلة.")
                history.forEach { pay ->
                    Text("${localDate(pay.dateMillis)} • ${formatNumber(pay.amountForeign)} ${pay.currency} • ${formatMoney(pay.amountYer)}", fontWeight = FontWeight.SemiBold)
                    Text("سعر الصرف: ${pay.exchangeRateScaled / 1000.0} • ${pay.paymentMethod} ${pay.notes}", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                }
            } }, confirmButton = { TextButton(onClick = { selectedSupplier = null }) { Text("إغلاق") } })
    }
    if (message != null) AlertDialog(onDismissRequest = { message = null }, title = { Text("تنبيه") }, text = { Text(message!!) }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } })
}
