# مِعيار | Miyar 1.0.8

Arabic RTL agricultural management app.

- Application ID: `com.miyar.app`
- Version: `1.0.8` (`versionCode = 30`)
- Room database: `14` with additive migrations from Room 12.
- Build workflow: `.github/workflows/blank.yml`

See `CHANGELOG_1.0.8_AR.txt` and `BUILD_NOTES_1.0.8_AR.txt` for update details and release validation instructions. Do not install the APK until GitHub Actions tests, release build, and permanent signing-certificate checks all pass.
