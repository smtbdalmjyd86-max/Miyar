package com.miyar.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class FinanceCalculationsTest {
    @Test fun kilogramPackagesConvertToGrams() {
        assertEquals(25000L, FinanceCalculations.quantityToBase(5, "كجم", 5))
    }

    @Test fun gramPackagesRemainGrams() {
        assertEquals(1500L, FinanceCalculations.quantityToBase(500, "جرام", 3))
    }

    @Test fun litersConvertToMilliliters() {
        assertEquals(12000L, FinanceCalculations.quantityToBase(2, "لتر", 6))
    }

    @Test fun millilitersRemainMilliliters() {
        assertEquals(750L, FinanceCalculations.quantityToBase(250, "مل", 3))
    }

    @Test fun millilitersUseTheNewMiliUnitLabel() {
        assertEquals(750L, FinanceCalculations.quantityToBase(250, "ملي", 3))
    }

    @Test fun invoiceLineTotalUsesPackageCount() {
        assertEquals(3600L, FinanceCalculations.lineTotal(12, 300))
    }

    @Test fun exchangeRateConvertsCurrencyToYER() {
        assertEquals(2505L, FinanceCalculations.toYemeniRials(10, 250500))
    }

    @Test fun weightedAverageUnitCostIsBasedOnYemeniRials() {
        assertEquals(530L, FinanceCalculations.averageCostPerBaseScaled(53000L, 100000L))
    }

    @Test fun usageCostUsesWeightedAverageCost() {
        assertEquals(53L, FinanceCalculations.usageCostYer(100L, 530L))
    }

    @Test fun agreedInvoiceExampleConvertsToYERAndCorrectUnitCost() {
        // 100 USD x 530 YER/USD, for 5 packages x 20 kg = 100 kg.
        val totalYer = FinanceCalculations.toYemeniRials(100L, 530000L)
        val quantityGrams = FinanceCalculations.quantityToBase(20L, "كجم", 5L)
        val averageCostScaled = FinanceCalculations.averageCostPerBaseScaled(totalYer, quantityGrams)
        assertEquals(53000L, totalYer)
        assertEquals(100000L, quantityGrams)
        assertEquals(530L, averageCostScaled) // 0.530 YER per gram = 530 YER per kg.
        assertEquals(1060L, FinanceCalculations.usageCostYer(2000L, averageCostScaled)) // 2 kg.
    }

    @Test fun inventoryLiquidQuantityUsesMajorAndMinorUnits() {
        assertEquals("11 لتر 750 ملي", FinanceCalculations.formatStockQuantity(11_750L, "ml"))
        assertEquals("750 ملي", FinanceCalculations.formatStockQuantity(750L, "ml"))
        assertEquals("2 لتر", FinanceCalculations.formatStockQuantity(2_000L, "ml"))
        assertEquals("0 ملي", FinanceCalculations.formatStockQuantity(0L, "ml"))
    }

    @Test fun inventorySolidQuantityUsesMajorAndMinorUnits() {
        assertEquals("5 كيلو 400 جرام", FinanceCalculations.formatStockQuantity(5_400L, "g"))
        assertEquals("3 كيلو 200 جرام", FinanceCalculations.formatStockQuantity(3_200L, "g"))
        assertEquals("2 كيلو 200 جرام", FinanceCalculations.formatStockQuantity(2_200L, "g"))
        assertEquals("0 جرام", FinanceCalculations.formatStockQuantity(0L, "g"))
    }

    @Test(expected = ArithmeticException::class)
    fun quantityOverflowIsRejected() {
        FinanceCalculations.quantityToBase(Long.MAX_VALUE, "كجم", 2)
    }

    @Test(expected = ArithmeticException::class)
    fun exchangeConversionOverflowIsRejected() {
        FinanceCalculations.toYemeniRials(Long.MAX_VALUE, 2_000L)
    }

    @Test(expected = ArithmeticException::class)
    fun totalAggregationOverflowIsRejected() {
        FinanceCalculations.sumExact(listOf(Long.MAX_VALUE, 1L))
    }

    @Test fun totalAggregationUsesExactLongArithmetic() {
        assertEquals(3_000_000_000L, FinanceCalculations.sumExact(listOf(1_000_000_000L, 2_000_000_000L)))
    }
    @Test fun sellerSaleNetValueSeparatesDiscountAndDistributionCost() {
        assertEquals(92_000L, FinanceCalculations.sellerNetSale(100_000L, 5_000L, 3_000L))
    }

    @Test fun sellerRemainingBalanceUsesNetSaleAndCollectedPayments() {
        assertEquals(40_000L, FinanceCalculations.sellerBalance(92_000L, 52_000L))
    }

    @Test fun sellerDiscountUpdateDoesNotChangeHistoricalPayments() {
        // The payment total remains 52,000; only net entitlement changes from 92,000 to 90,000.
        assertEquals(38_000L, FinanceCalculations.sellerBalance(
            FinanceCalculations.sellerNetSale(100_000L, 7_000L, 3_000L), 52_000L
        ))
    }

    @Test fun sellerOverCollectionIsPreservedAsCredit() {
        assertEquals(-8_000L, FinanceCalculations.sellerBalance(92_000L, 100_000L))
    }

    @Test(expected = IllegalArgumentException::class)
    fun sellerAdjustmentsCannotExceedGrossSale() {
        FinanceCalculations.sellerNetSale(100_000L, 60_000L, 40_001L)
    }

    @Test fun harvestPickerCostAndNetRevenueAreExact() {
        assertEquals(10_000L, FinanceCalculations.harvestPickerWages(5L, 2_000L))
        assertEquals(13_000L, FinanceCalculations.harvestTotalCost(5L, 2_000L, 3_000L))
        assertEquals(87_000L, FinanceCalculations.harvestNetRevenue(100_000L, 13_000L))
    }

    @Test(expected = ArithmeticException::class)
    fun harvestPickerCostOverflowIsRejected() {
        FinanceCalculations.harvestPickerWages(Long.MAX_VALUE, 2L)
    }
    @Test fun stockIssueSubtractsOnlyAvailableQuantity() {
        assertEquals(4_500L, FinanceCalculations.stockAfterIssue(10_000L, 5_500L))
        assertEquals(0L, FinanceCalculations.stockAfterIssue(750L, 750L))
    }

    @Test(expected = IllegalStateException::class)
    fun stockIssueCannotCreateNegativeBalance() {
        FinanceCalculations.stockAfterIssue(749L, 750L)
    }

    @Test fun stockIssueReversalRestoresOriginalBalance() {
        assertEquals(10_000L, FinanceCalculations.stockAfterIssueReversal(4_500L, 5_500L))
    }

}
