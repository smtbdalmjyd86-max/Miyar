package com.miyar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Emerald = androidx.compose.ui.graphics.Color(0xFF103D32)
private val Green = androidx.compose.ui.graphics.Color(0xFF147D64)
private val Cream = androidx.compose.ui.graphics.Color(0xFFF7F3E8)
private val Gold = androidx.compose.ui.graphics.Color(0xFFC7A65A)

class MainActivity : ComponentActivity() {
    private val dao by lazy { MiyarDatabase.get(this).dao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Emerald,
                    secondary = Gold,
                    background = Cream,
                    surface = androidx.compose.ui.graphics.Color.White
                )
            ) {
                MiyarApp(dao)
            }
        }
    }
}

@Composable
private fun MiyarApp(dao: MiyarDao) {
    val scope = rememberCoroutineScope()
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val totalExpenses by dao.observeTotalExpenses().collectAsStateWithLifecycle(initialValue = 0L)
    var selected by remember { mutableStateOf<PlantationEntity?>(null) }
    var showAddPlantation by remember { mutableStateOf(false) }
    var showAddExpense by remember { mutableStateOf(false) }

    BackHandler(enabled = selected != null) { selected = null }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { if (selected == null) showAddPlantation = true else showAddExpense = true },
                    containerColor = Emerald,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Header()
                Spacer(Modifier.height(16.dp))
                if (selected == null) {
                    Text("مواضعي الزراعية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                    Spacer(Modifier.height(8.dp))
                    if (plantations.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("أهلًا بك في مِعيار 🌿", fontWeight = FontWeight.Bold)
                                Text("أضف أول موضع زراعي للبدء.")
                            }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(plantations, key = { it.id }) { p ->
                                Card(
                                    onClick = { selected = p },
                                    colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌱", style = MaterialTheme.typography.headlineSmall)
                                        Spacer(Modifier.width(12.dp))
                                        Text(p.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                        Text("عرض التفاصيل  ←", color = Green, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    FinancialCard("💸 إجمالي الخرج", formatMoney(totalExpenses), "ريال يمني • المصروفات المسجلة")
                    Spacer(Modifier.height(8.dp))
                    FinancialCard("💰 إجمالي المردود", "0", "سيُفعّل مع تنفيذ قسم القطفات")
                    Spacer(Modifier.height(8.dp))
                    FinancialCard("🧾 الديون", "0", "سيُفعّل مع تنفيذ التجار والمشترين")
                    Spacer(Modifier.height(12.dp))
                    Text("الأقسام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                    Text("🌿 الأسمدة   🐛 السموم   💧 المياه   🧑‍🌾 الأعمال اليدوية   📝 أخرى   💰 القطفات", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                        Column {
                            Text(selected!!.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                            Text("سجل المصروفات • النسخة التأسيسية", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val expenses by dao.observeExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = emptyList())
                    val plantationTotal by dao.observePlantationExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    Spacer(Modifier.height(8.dp))
                    FinancialCard("💸 إجمالي خرج الموضع", formatMoney(plantationTotal), "يتحدث تلقائيًا من السجلات")
                    Spacer(Modifier.height(12.dp))
                    Text("المصروفات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (expenses.isEmpty()) Text("لا توجد مصروفات لهذا الموضع بعد.", modifier = Modifier.padding(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(expenses, key = { it.id }) { expense ->
                            ExpenseRow(expense,
                                onUpdate = { updated -> scope.launch { dao.updateExpense(updated) } },
                                onDelete = { item -> scope.launch { dao.deleteExpense(item) } }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddPlantation) {
        TextEntryDialog("إضافة موضع زراعي", "اسم الموضع", onDismiss = { showAddPlantation = false }) { name ->
            scope.launch { dao.insertPlantation(PlantationEntity(name = name.trim())) }
            showAddPlantation = false
        }
    }
    if (showAddExpense && selected != null) {
        ExpenseDialog(onDismiss = { showAddExpense = false }) { title, amount, notes ->
            scope.launch {
                dao.insertExpense(ExpenseEntity(plantationId = selected!!.id, title = title.trim(), amount = amount, notes = notes))
            }
            showAddExpense = false
        }
    }
}

@Composable
private fun Header() {
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🌿", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("مِعيار", style = MaterialTheme.typography.headlineMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                Text("إدارة أدق، ومردود أوضح", color = Gold, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun FinancialCard(title: String, value: String, caption: String) {
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(caption, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpenseRow(item: ExpenseEntity, onUpdate: (ExpenseEntity) -> Unit, onDelete: (ExpenseEntity) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var editDialog by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { }, onLongClick = { menu = true }),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; editDialog = true })
                DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    if (editDialog) {
        ExpenseDialog(initial = item, onDismiss = { editDialog = false }) { title, amount, notes ->
            onUpdate(item.copy(title = title.trim(), amount = amount, notes = notes))
            editDialog = false
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل تريد حذف المصروف «${item.title}»؟ لا يمكن التراجع عن هذه العملية.") },
            confirmButton = { TextButton(onClick = { onDelete(item); confirmDelete = false }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onSave(value) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ExpenseDialog(initial: ExpenseEntity? = null, onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var amountText by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    val parsed = amountText.toLongOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة مصروف" else "تعديل مصروف") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("بيان المصروف") }, singleLine = true)
                OutlinedTextField(amountText, { amountText = it.filter { ch -> ch.isDigit() } }, label = { Text("المبلغ بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات (اختياري)") })
                Text("أدخل المبلغ كعدد صحيح دون فواصل.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank() && parsed != null && parsed >= 0, onClick = { onSave(title, parsed!!, notes) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun formatMoney(amount: Long): String =
    NumberFormat.getIntegerInstance(Locale.US).format(amount) + " ر.ي"
