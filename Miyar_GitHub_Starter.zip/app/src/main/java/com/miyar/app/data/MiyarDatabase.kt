package com.miyar.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MiyarDao {
    @Query("SELECT * FROM plantations ORDER BY name COLLATE NOCASE")
    fun observePlantations(): Flow<List<PlantationEntity>>

    @Insert
    suspend fun insertPlantation(item: PlantationEntity): Long

    @Query("SELECT * FROM expenses WHERE plantationId = :plantationId ORDER BY dateMillis DESC, id DESC")
    fun observeExpenses(plantationId: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency")
    fun observeTotalExpenses(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency")
    fun observePlantationExpenses(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Insert
    suspend fun insertExpense(item: ExpenseEntity): Long

    @Update
    suspend fun updateExpense(item: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(item: ExpenseEntity)
}

@Database(
    entities = [PlantationEntity::class, ExpenseEntity::class],
    version = 1,
    exportSchema = true
)
abstract class MiyarDatabase : RoomDatabase() {
    abstract fun dao(): MiyarDao

    companion object {
        @Volatile private var INSTANCE: MiyarDatabase? = null

        fun get(context: Context): MiyarDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MiyarDatabase::class.java,
                    "miyar.db"
                ).build().also { INSTANCE = it }
            }
    }
}
