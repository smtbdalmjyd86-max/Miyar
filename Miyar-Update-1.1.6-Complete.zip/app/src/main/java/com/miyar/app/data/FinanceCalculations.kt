package com.miyar.app.data

import java.math.BigDecimal
import java.math.RoundingMode

/** Exact whole-number calculations used by invoice and inventory flows. */
object FinanceCalculations {
    /** Inventory cost ledger precision: one YER is stored as one million micro-YER. */
    const val INVENTORY_VALUE_SCALE: Long = 1_000_000L

    fun inventoryValueMicros(amountYer: Long): Long {
        require(amountYer >= 0L) { "قيمة المخزون لا يمكن أن تكون سالبة." }
        return Math.multiplyExact(amountYer, INVENTORY_VALUE_SCALE)
    }

    /** Moving-average cost of an issue, rounded only at micro-YER precision. */
    fun movingAverageIssueCostMicros(valueBeforeMicros: Long, quantityBefore: Long, issueQuantity: Long): Long {
        require(valueBeforeMicros >= 0L && quantityBefore > 0L && issueQuantity > 0L) { "بيانات تقييم الصرف غير صالحة." }
        require(issueQuantity <= quantityBefore) { "كمية الصرف أكبر من الرصيد المتاح." }
        return BigDecimal(valueBeforeMicros).multiply(BigDecimal(issueQuantity))
            .divide(BigDecimal(quantityBefore), 0, RoundingMode.HALF_UP).longValueExact()
    }

    fun movingAverageUnitCostMicros(valueMicros: Long, quantityBase: Long): Long {
        require(valueMicros >= 0L && quantityBase > 0L) { "قيمة أو كمية الرصيد غير صالحة." }
        return BigDecimal(valueMicros).divide(BigDecimal(quantityBase), 0, RoundingMode.HALF_UP).longValueExact()
    }

    /** Canonical, explicitly supported entry units. Unknown strings are never guessed. */
    fun canonicalQuantityUnit(unit: String): String = when (unit.trim()) {
        "كجم" -> "كجم"
        "جرام" -> "جرام"
        "لتر" -> "لتر"
        "ملي", "مل" -> "ملي" // Keep the old Arabic label as a recognized compatibility alias.
        else -> throw IllegalArgumentException("وحدة القياس «$unit» غير معتمدة.")
    }

    /** Canonical storage unit: grams for solids, milliliters for liquids. */
    fun baseUnitForQuantityUnit(unit: String): String = when (canonicalQuantityUnit(unit)) {
        "كجم", "جرام" -> "g"
        "لتر", "ملي" -> "ml"
        else -> error("وحدة القياس غير معتمدة.")
    }

    fun quantityToBase(quantity: Long, unit: String, packageCount: Long = 1L): Long {
        require(quantity >= 0 && packageCount >= 0) { "الكمية لا يمكن أن تكون سالبة." }
        val canonical = canonicalQuantityUnit(unit)
        val multiplier = if (canonical == "كجم" || canonical == "لتر") 1000L else 1L
        return Math.multiplyExact(Math.multiplyExact(quantity, packageCount), multiplier)
    }

    fun lineTotal(packageCount: Long, pricePerPackage: Long): Long {
        require(packageCount >= 0 && pricePerPackage >= 0) { "الكمية والسعر لا يمكن أن يكونا سالبين." }
        return Math.multiplyExact(packageCount, pricePerPackage)
    }

    /** Add totals without silently wrapping on Long overflow. */
    fun sumExact(values: Iterable<Long>): Long = values.fold(0L) { total, value -> Math.addExact(total, value) }

    /** rateScaled is the exchange rate multiplied by 1000. */
    fun toYemeniRials(amountForeign: Long, rateScaled: Long): Long {
        require(amountForeign >= 0 && rateScaled > 0) { "تحقق من المبلغ وسعر الصرف." }
        return BigDecimal(amountForeign)
            .multiply(BigDecimal(rateScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Weighted-average cost per canonical base unit (gram/ml), scaled by 1000. */
    fun averageCostPerBaseScaled(totalYer: Long, totalQuantityBase: Long): Long {
        require(totalYer >= 0 && totalQuantityBase > 0) { "قيمة الشراء أو الكمية غير صالحة." }
        return BigDecimal(totalYer).multiply(BigDecimal(1000))
            .divide(BigDecimal(totalQuantityBase), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Cost of a consumed quantity using the stored weighted-average YER price. */
    fun usageCostYer(quantityBase: Long, averageCostPerBaseScaled: Long): Long {
        require(quantityBase >= 0 && averageCostPerBaseScaled >= 0) { "كمية الاستخدام أو سعر الوحدة غير صالح." }
        return BigDecimal(quantityBase).multiply(BigDecimal(averageCostPerBaseScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Subtract a stock issue safely; callers must validate the balance before recording the movement. */
    fun stockAfterIssue(availableBase: Long, issueBase: Long): Long {
        require(availableBase >= 0L) { "رصيد المخزون الحالي غير صالح." }
        require(issueBase > 0L) { "كمية الصرف يجب أن تكون أكبر من صفر." }
        check(issueBase <= availableBase) { "كمية الصرف أكبر من الرصيد المتاح." }
        return availableBase - issueBase
    }

    /** Restore a previously recorded issue without allowing overflow. */
    fun stockAfterIssueReversal(currentBase: Long, reversedBase: Long): Long {
        require(currentBase >= 0L && reversedBase > 0L) { "بيانات عكس الصرف غير صالحة." }
        return Math.addExact(currentBase, reversedBase)
    }



    /** Net seller transaction value: gross sale less seller discounts and distribution costs. */
    fun sellerNetSale(gross: Long, discounts: Long, distributionCosts: Long): Long {
        require(gross >= 0L && discounts >= 0L && distributionCosts >= 0L) { "قيم البيع والخصومات ومصاريف التوزيع لا يمكن أن تكون سالبة." }
        val deductions = Math.addExact(discounts, distributionCosts)
        require(deductions <= gross) { "إجمالي الخصومات ومصاريف التوزيع يتجاوز قيمة البيع الأصلية." }
        return Math.subtractExact(gross, deductions)
    }

    /** Preserve an over-collection as a negative balance instead of silently clipping it to zero. */
    fun sellerBalance(netSale: Long, collected: Long): Long {
        require(netSale >= 0L && collected >= 0L) { "صافي البيع والتحصيل لا يمكن أن يكونا سالبين." }
        return Math.subtractExact(netSale, collected)
    }

    fun harvestPickerWages(pickerCount: Long, wagePerPicker: Long): Long {
        require(pickerCount >= 0L && wagePerPicker >= 0L) { "عدد القطافين والأجر لا يمكن أن يكونا سالبين." }
        return Math.multiplyExact(pickerCount, wagePerPicker)
    }

    /** Manual override takes precedence without destroying the automatically calculated baseline. */
    fun effectivePickerWages(pickerCount: Long, wagePerPicker: Long, manualOverride: Long?): Long =
        manualOverride ?: harvestPickerWages(pickerCount, wagePerPicker)

    /** Calculates quantity × unit price exactly, unless a recorded manual total is supplied. */
    fun effectiveProductTotal(quantity: Long, unitPrice: Long, manualOverride: Long?): Long {
        require(quantity >= 0L && unitPrice >= 0L) { "كمية المنتج وسعر الوحدة لا يمكن أن يكونا سالبين." }
        val calculated = Math.multiplyExact(quantity, unitPrice)
        return manualOverride ?: calculated
    }

    fun harvestTotalCost(pickerCount: Long, wagePerPicker: Long, otherCost: Long): Long {
        require(otherCost >= 0L) { "خرج القطاف الآخر لا يمكن أن يكون سالبًا." }
        return Math.addExact(harvestPickerWages(pickerCount, wagePerPicker), otherCost)
    }

    fun harvestNetRevenue(grossRevenue: Long, harvestCost: Long): Long {
        require(grossRevenue >= 0L && harvestCost >= 0L) { "الإيراد وتكاليف القطاف لا يمكن أن يكونا سالبين." }
        return Math.subtractExact(grossRevenue, harvestCost)
    }

    /** Format the canonical gram/ml quantity as a major unit plus the exact remainder. */
    fun formatStockQuantity(quantityBase: Long, baseUnit: String): String {
        require(quantityBase >= 0L) { "كمية المخزون لا يمكن أن تكون سالبة." }
        require(baseUnit == "g" || baseUnit == "ml") { "وحدة التخزين الأساسية غير معتمدة." }
        val major = quantityBase / 1000L
        val remainder = quantityBase % 1000L
        val (majorName, minorName) = if (baseUnit == "g") "كيلو" to "جرام" else "لتر" to "ملي"
        return when {
            major > 0L && remainder > 0L -> "$major $majorName $remainder $minorName"
            major > 0L -> "$major $majorName"
            remainder > 0L -> "$remainder $minorName"
            else -> "0 $minorName"
        }
    }
}
