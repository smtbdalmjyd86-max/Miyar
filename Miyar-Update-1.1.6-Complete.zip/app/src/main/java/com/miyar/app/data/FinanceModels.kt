package com.miyar.app.data

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "invoices", indices = [
    Index(value = ["dateMillis", "id"], name = "index_invoices_dateMillis"),
    Index(value = ["supplier", "paymentStatus", "dateMillis"], name = "index_invoices_supplier_paymentStatus_dateMillis")
])
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplier: String,
    val invoiceNumber: String,
    val dateMillis: Long,
    val paymentStatus: String,
    val currency: String,
    /** Exchange rate multiplied by 1000; 1.000 for YER. */
    val exchangeRateScaled: Long,
    val totalForeign: Long,
    val totalYer: Long,
    val notes: String = ""
)

@Entity(
    tableName = "stock_items",
    indices = [
        Index(value = ["productType", "productName", "baseUnit", "treatmentType"]),
        Index(value = ["valuationStatus", "quantityBase"])
    ]
)
data class StockItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productType: String,
    val productName: String,
    val activeIngredient: String = "",
    /** Canonical unit is g for solids and ml for liquids. */
    val baseUnit: String,
    @ColumnInfo(defaultValue = "'عام'") val treatmentType: String = "عام",
    val quantityBase: Long = 0,
    val totalReceivedBase: Long = 0,
    val totalUsedBase: Long = 0,
    @ColumnInfo(defaultValue = "0") val totalOpeningCostYer: Long = 0,
    @ColumnInfo(defaultValue = "0") val currentValueMicros: Long = 0,
    @ColumnInfo(defaultValue = "NULL") val lowStockThresholdBase: Long? = null,
    @ColumnInfo(defaultValue = "'PENDING'") val valuationStatus: String = "PENDING",
    @ColumnInfo(defaultValue = "''") val valuationReviewReason: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val lastReceivedAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_issue_vouchers",
    indices = [Index(value = ["dateMillis", "id"])]
)
data class StockIssueVoucherEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateMillis: Long,
    val reason: String,
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_issue_lines",
    foreignKeys = [
        ForeignKey(entity = StockIssueVoucherEntity::class, parentColumns = ["id"], childColumns = ["voucherId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["voucherId"]), Index(value = ["stockItemId"])]
)
data class StockIssueLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val voucherId: Long,
    val stockItemId: Long,
    val productName: String,
    val productType: String,
    val baseUnit: String,
    val unit: String,
    val enteredQuantity: Long,
    val quantityBase: Long
)

data class StockIssueLineInput(
    val stockItemId: Long,
    val unit: String,
    val enteredQuantity: Long,
    val quantityBase: Long
)

@Entity(
    tableName = "invoice_items",
    foreignKeys = [
        ForeignKey(entity = InvoiceEntity::class, parentColumns = ["id"], childColumns = ["invoiceId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["invoiceId"]), Index(value = ["stockItemId"])]
)
data class InvoiceItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val packageName: String,
    val packageSize: Long,
    val packageCount: Long,
    val unit: String,
    val quantityBase: Long,
    val unitPriceForeign: Long,
    val lineTotalForeign: Long,
    val lineTotalYer: Long,
    @ColumnInfo(defaultValue = "'عام'") val treatmentType: String = "عام"
)

@Entity(
    tableName = "stock_movements",
    foreignKeys = [ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["stockItemId"]), Index(value = ["referenceType", "referenceId"]), Index(value = ["stockItemId", "dateMillis", "id"])]
)
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stockItemId: Long,
    val referenceType: String,
    val referenceId: Long,
    /** Positive for receipts; negative for usage. */
    val quantityBase: Long,
    val dateMillis: Long = System.currentTimeMillis(),
    val description: String = "",
    @ColumnInfo(defaultValue = "0") val sourceLineId: Long = 0L,
    /** Signed inventory value in micro-YER; positive receipt, negative issue. */
    @ColumnInfo(defaultValue = "0") val valueDeltaMicros: Long = 0L,
    /** Moving-average unit cost immediately before an issue, in micro-YER per g/ml. */
    @ColumnInfo(defaultValue = "0") val unitCostMicrosPerBase: Long = 0L,
    @ColumnInfo(defaultValue = "0") val estimatedValue: Boolean = false,
    /** User-entered evidence note for reviewed legacy receipts or count adjustments. */
    @ColumnInfo(defaultValue = "''") val valuationEvidence: String = ""
)



/** Read-only stock ledger projection joining usage movements to their source operation. */
data class StockMovementDetail(
    val id: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val treatmentType: String,
    val baseUnit: String,
    val quantityBase: Long,
    val dateMillis: Long,
    val referenceType: String,
    val referenceId: Long,
    val description: String,
    val operationTitle: String?,
    val operationCategory: String?,
    val plantationName: String?,
    val valueDeltaMicros: Long = 0L,
    val estimatedValue: Boolean = false
)


/** Movement-level evidence shown in the stock review and repair workflow. */
data class StockReviewMovementRow(
    val id: Long,
    val stockItemId: Long,
    val referenceType: String,
    val referenceId: Long,
    val quantityBase: Long,
    val valueDeltaMicros: Long,
    val unitCostMicrosPerBase: Long,
    val estimatedValue: Boolean,
    val dateMillis: Long,
    val description: String,
    val valuationEvidence: String,
    val sourceLineId: Long,
    val supplier: String?,
    val invoiceNumber: String?,
    val lineTotalYer: Long?
)

/** Financial stock totals. All values are micro-YER (1 YER = 1,000,000 units). */
data class StockValueSummary(
    /** Confirmed/estimated totals only; unresolved stock is reported separately. */
    val inboundValueMicros: Long,
    val outboundValueMicros: Long,
    val remainingValueMicros: Long,
    val unverifiedItemCount: Long,
    val unresolvedInboundValueMicros: Long = 0L,
    val unresolvedOutboundValueMicros: Long = 0L,
    val unresolvedRemainingValueMicros: Long = 0L
)

data class StockReviewRow(
    val id: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val baseUnit: String,
    val quantityBase: Long,
    val totalReceivedBase: Long,
    val totalUsedBase: Long,
    val currentValueMicros: Long,
    val valuationStatus: String,
    val valuationReviewReason: String,
    val ledgerQuantityBase: Long,
    val ledgerValueMicros: Long,
    val inboundValueMicros: Long,
    val outboundValueMicros: Long,
    val movementCount: Long,
    val sourceTypes: String
)

data class StockMovementHistoryRow(
    val id: Long,
    val stockItemId: Long,
    val quantityBase: Long,
    val valueDeltaMicros: Long,
    val unitCostMicrosPerBase: Long,
    val estimatedValue: Boolean,
    val dateMillis: Long,
    val referenceType: String,
    val referenceId: Long,
    val description: String,
    val supplier: String?,
    val invoiceNumber: String?,
    val currency: String?,
    val exchangeRateScaled: Long?,
    val unitPriceForeign: Long?,
    val packageName: String?,
    val packageSize: Long?,
    val packageCount: Long?,
    val unit: String?,
    val lineTotalForeign: Long?,
    val lineTotalYer: Long?
)

data class StockOutboundCategoryTotal(
    val category: String,
    val valueMicros: Long,
    val movementCount: Long,
    val estimatedCount: Long,
    val unresolvedValueMicros: Long = 0L,
    val unresolvedCount: Long = 0L
)

/** Product catalogue entry with a weighted-average purchase cost in YER. */
data class StockPriceSuggestion(
    val id: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val baseUnit: String,
    val quantityBase: Long,
    /** Average cost per gram/ml multiplied by 1000 to retain fractional rials. */
    val averageCostPerBaseScaled: Long,
    val treatmentType: String = "عام",
    val currentValueMicros: Long = 0L,
    val valuationStatus: String = "PENDING",
    val lowStockThresholdBase: Long? = null
)


/** One material consumed inside a single fertilizer or pesticide operation. */
@Entity(
    tableName = "chemical_operation_lines",
    foreignKeys = [
        ForeignKey(entity = ExpenseEntity::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["expenseId"]), Index(value = ["stockItemId"])]
)
data class ChemicalOperationLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val treatmentType: String,
    val unit: String,
    val enteredQuantity: Long,
    val quantityBase: Long,
    val costAmountYer: Long
)

data class ChemicalOperationLineInput(
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val treatmentType: String,
    val unit: String,
    val enteredQuantity: Long,
    val quantityBase: Long,
    val costAmountYer: Long,
    val stockItemId: Long = 0L
)

@Entity(
    tableName = "operation_reminders",
    indices = [
        Index(value = ["referenceType", "referenceId"], unique = true),
        Index(value = ["scheduledAtMillis"]),
        Index(value = ["plantationId"], name = "index_operation_reminders_plantationId"),
        Index(value = ["status"], name = "index_operation_reminders_status")
    ]
)
data class OperationReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val referenceType: String,
    val referenceId: Long,
    val title: String,
    val category: String,
    val plantationName: String,
    val scheduledAtMillis: Long,
    val enabled: Boolean = true,
    @ColumnInfo(defaultValue = "0") val plantationId: Long = 0L,
    @ColumnInfo(defaultValue = "'NORMAL'") val priority: String = "NORMAL",
    @ColumnInfo(defaultValue = "''") val suggestedAction: String = "",
    @ColumnInfo(defaultValue = "'NEW'") val status: String = "NEW"
)


data class InvoiceLedgerSummary(val creditCount: Long, val creditTotal: Long, val cashCount: Long, val cashTotal: Long)
