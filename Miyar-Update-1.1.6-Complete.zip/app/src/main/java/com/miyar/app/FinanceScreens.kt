@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.miyar.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.PopupProperties
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

private data class InvoiceLineDraft(
    val productType: String = "الأسمدة",
    val productName: String = "",
    val activeIngredient: String = "",
    val packageName: String = "كيس",
    val packageSize: String = "1",
    val packageCount: String = "1",
    val unit: String = "كجم",
    val unitPrice: String = "",
    val treatmentType: String = "عام",
    /** Stable stock record identity; product text is only a label. */
    val stockItemId: Long? = null
)

private fun InvoiceLineDraft.toSavedValues(): List<String> = listOf(
    productType, productName, activeIngredient, packageName, packageSize, packageCount,
    unit, unitPrice, treatmentType, stockItemId?.toString().orEmpty()
)

private fun invoiceLineDraftFromSaved(v: List<String>): InvoiceLineDraft = InvoiceLineDraft(
    productType = v[0], productName = v[1], activeIngredient = v[2], packageName = v[3],
    packageSize = v[4], packageCount = v[5], unit = v[6], unitPrice = v[7],
    treatmentType = v[8], stockItemId = v.getOrNull(9)?.toLongOrNull()?.takeIf { it > 0L }
)

private val InvoiceLinesSaver = androidx.compose.runtime.saveable.listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<InvoiceLineDraft>, String>(
    save = { rows -> rows.flatMap { it.toSavedValues() } },
    restore = { values -> androidx.compose.runtime.mutableStateListOf<InvoiceLineDraft>().apply {
        values.chunked(10).forEach { v -> if (v.size == 10) add(invoiceLineDraftFromSaved(v)) }
    } }
)

private val InvoiceDraftsSaver = androidx.compose.runtime.saveable.listSaver<List<InvoiceLineDraft>, String>(
    save = { rows -> rows.flatMap { it.toSavedValues() } },
    restore = { values -> values.chunked(10).filter { it.size == 10 }.map(::invoiceLineDraftFromSaved) }
)

private fun localDate(millis: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(millis))
private fun parseDateOrToday(value: Long?): Long = value ?: System.currentTimeMillis()

// Material3 DatePicker uses UTC-midnight milliseconds. The app stores local-day
// timestamps, so convert explicitly to avoid a one-day shift in UTC+3/other zones.
private fun toPickerDateMillis(localMillis: Long): Long =
    Instant.ofEpochMilli(localMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        .atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()

private fun fromPickerDateMillis(pickerMillis: Long): Long =
    Instant.ofEpochMilli(pickerMillis).atZone(ZoneOffset.UTC).toLocalDate()
        .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
private fun digits(value: String): Long = value.filter { it.isDigit() }.toLongOrNull() ?: 0L
private fun rateScaled(value: String): Long = runCatching {
    val normalized = rateInput(value).replace(".", "").replace(',', '.')
    BigDecimal(normalized).multiply(BigDecimal(1000)).setScale(0, RoundingMode.HALF_UP).longValueExact()
}.getOrDefault(0L)
private fun baseMultiplier(unit: String): Long = FinanceCalculations.quantityToBase(1L, unit)
private fun baseUnit(unit: String): String = FinanceCalculations.baseUnitForQuantityUnit(unit)
private fun stockQuantity(value: Long, unit: String): String =
    FinanceCalculations.formatStockQuantity(value.coerceAtLeast(0L), unit)

private fun formatStockValueMicros(valueMicros: Long): String = runCatching {
    BigDecimal(valueMicros).divide(BigDecimal(FinanceCalculations.INVENTORY_VALUE_SCALE), 2, RoundingMode.HALF_UP)
        .stripTrailingZeros().toPlainString() + " ر.ي"
}.getOrDefault("—")

private fun inventoryThresholdKey(item: StockItemEntity): String = when {
    item.productType == "الأسمدة" && item.baseUnit == "ml" -> "fertilizer_liquid"
    item.productType == "الأسمدة" && item.baseUnit == "g" -> "fertilizer_solid"
    item.productType == "السموم" && item.baseUnit == "ml" -> "pesticide_liquid"
    item.productType == "السموم" && item.baseUnit == "g" -> "pesticide_solid"
    else -> ""
}

private fun effectiveStockThreshold(item: StockItemEntity, prefs: android.content.SharedPreferences): Long? =
    item.lowStockThresholdBase ?: inventoryThresholdKey(item).takeIf { it.isNotBlank() }
        ?.let { prefs.getString(it, null)?.toLongOrNull()?.takeIf { value -> value > 0L } }

private fun stockAvailabilityLabel(item: StockItemEntity, threshold: Long? = item.lowStockThresholdBase): String = when {
    item.quantityBase <= 0L -> "أصناف نفدت كمياتها"
    threshold != null && item.quantityBase <= threshold -> "منخفض المخزون"
    else -> "متوفر"
}

@Composable
fun MiyarDateField(label: String, millis: Long, onDate: (Long) -> Unit) {
    var showPicker by rememberSaveable { mutableStateOf(false) }
    OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
        Text("$label: ${localDate(millis)}")
    }
    if (showPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = toPickerDateMillis(millis))
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = { state.selectedDateMillis?.let { onDate(fromPickerDateMillis(it)) }; showPicker = false }) { Text("اختيار") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("إلغاء") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
fun MiyarInvoiceScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val invoices = remember { androidx.compose.runtime.mutableStateListOf<InvoiceEntity>() }
    val invoiceSummary by dao.observeInvoiceLedgerSummary().collectAsStateWithLifecycle(initialValue = InvoiceLedgerSummary(0, 0, 0, 0))
    var invoicePage by rememberSaveable { mutableIntStateOf(0) }
    var invoiceHasMore by rememberSaveable { mutableStateOf(true) }
    var invoiceLoading by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        invoiceLoading = true
        runCatching { dao.getInvoicePage(50, 0) }.onSuccess { invoices.addAll(it); invoicePage = 1; invoiceHasMore = it.size == 50 }
        invoiceLoading = false
    }
    val supplierNameSuggestions by dao.observeSupplierNameSuggestions().collectAsStateWithLifecycle(initialValue = emptyList())
    val stockSuggestions by dao.observeStockPriceSuggestions().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    var showForm by rememberSaveable { mutableStateOf(false) }
    var editingId by rememberSaveable { mutableLongStateOf(0L) }
    val editing = invoices.firstOrNull { it.id == editingId }
    var initialLines by rememberSaveable(stateSaver = InvoiceDraftsSaver) { mutableStateOf<List<InvoiceLineDraft>>(emptyList()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var detailsId by rememberSaveable { mutableLongStateOf(0L) }
    var invoiceMenuId by rememberSaveable { mutableLongStateOf(0L) }
    val detailsFor = invoices.firstOrNull { it.id == detailsId }
    var detailLines by remember { mutableStateOf<List<InvoiceItemEntity>>(emptyList()) }
    LaunchedEffect(detailsId) {
        if (detailsId != 0L) detailLines = dao.getInvoiceItems(detailsId)
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("الفواتير", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
                Text("تسجيل المشتريات وتحويل قيمتها وتحديث المخزون تلقائيًا", style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { editingId = 0L; initialLines = listOf(InvoiceLineDraft()); showForm = true }) {
                Icon(Icons.Default.Add, null); Text("فاتورة")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE7F8EC))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("🧾 إجمالي الفواتير الآجلة", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text(formatMoney(invoiceSummary.creditTotal), color = Green, fontWeight = FontWeight.ExtraBold)
                    Text("${invoiceSummary.creditCount} فاتورة", style = MaterialTheme.typography.labelSmall)
                }
            }
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3D6))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("💵 إجمالي الفواتير النقدية", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text(formatMoney(invoiceSummary.cashTotal), color = Green, fontWeight = FontWeight.ExtraBold)
                    Text("${invoiceSummary.cashCount} فاتورة", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (invoices.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ReceiptLong, null, tint = Emerald, modifier = Modifier.size(34.dp))
                    Text("لا توجد فواتير مسجلة بعد", fontWeight = FontWeight.Bold)
                    Text("أضف فاتورة لتسجيل الأصناف والكميات في المخزون.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        invoices.forEach { invoice ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.combinedClickable(onClick = { detailsId = invoice.id }, onLongClick = { invoiceMenuId = invoice.id })) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(invoice.supplier, color = Emerald, fontWeight = FontWeight.Bold)
                            Text("فاتورة ${invoice.invoiceNumber} • ${localDate(invoice.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (invoice.paymentStatus == "آجل") "آجل" else "نقدًا", color = if (invoice.paymentStatus == "آجل") Gold else Green, fontWeight = FontWeight.Bold)
                    }
                    Text("الإجمالي: ${formatMoney(invoice.totalYer)}", fontWeight = FontWeight.ExtraBold)
                    Text("${formatNumber(invoice.totalForeign)} ${invoice.currency} • سعر الصرف: ${invoice.exchangeRateScaled / 1000.0}", style = MaterialTheme.typography.bodySmall)
                    DropdownMenu(expanded = invoiceMenuId == invoice.id, onDismissRequest = { invoiceMenuId = 0L }) {
                        DropdownMenuItem(text = { Text("التفاصيل") }, onClick = { detailsId = invoice.id; invoiceMenuId = 0L })
                        DropdownMenuItem(text = { Text("تعديل الفاتورة") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = {
                            invoiceMenuId = 0L
                            scope.launch {
                                val rows = dao.getInvoiceItems(invoice.id).map { item ->
                                    val currentStock = dao.getStockItemById(item.stockItemId)
                                    InvoiceLineDraft(
                                        productType = item.productType,
                                        productName = currentStock?.productName ?: item.productName,
                                        activeIngredient = currentStock?.activeIngredient?.takeIf { it.isNotBlank() } ?: item.activeIngredient,
                                        packageName = item.packageName,
                                        packageSize = item.packageSize.toString(),
                                        packageCount = item.packageCount.toString(),
                                        unit = if (item.unit == "مل") "ملي" else item.unit,
                                        unitPrice = item.unitPriceForeign.toString(),
                                        treatmentType = currentStock?.treatmentType ?: item.treatmentType,
                                        stockItemId = item.stockItemId
                                    )
                                }
                                editingId = invoice.id; initialLines = rows; showForm = true
                            }
                        })
                        DropdownMenuItem(text = { Text("حذف الفاتورة", color = MaterialTheme.colorScheme.error) }, leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }, onClick = {
                            invoiceMenuId = 0L
                            scope.launch { try { val deleted = dao.deleteInvoiceSafely(invoice.id); if (!deleted) error = "لا يمكن حذف الفاتورة لأن جزءًا من كمياتها صُرف في عمليات زراعية. أعد الكميات المستخدمة أولًا." else { invoices.removeAll { it.id == invoice.id }; if (invoices.size < 50) { val next = dao.getInvoicePage(50, (invoicePage - 1).coerceAtLeast(0) * 50); invoices.clear(); invoices.addAll(next); invoicePage = 1; invoiceHasMore = next.size == 50 } } } catch (t: Throwable) { error = t.message ?: "تعذر حذف الفاتورة." } }
                        })
                    }
                }
            }
        }
        if ((invoicePage > 1 || invoiceHasMore) && !invoiceLoading) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (invoicePage > 1) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    invoiceLoading = true
                    scope.launch {
                        val previous = invoicePage - 2
                        runCatching { dao.getInvoicePage(50, previous * 50) }
                            .onSuccess { invoices.clear(); invoices.addAll(it); invoicePage--; invoiceHasMore = true }
                        invoiceLoading = false
                    }
                }) { Text("السابق") }
                if (invoiceHasMore) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    invoiceLoading = true
                    scope.launch {
                        runCatching { dao.getInvoicePage(50, invoicePage * 50) }
                            .onSuccess { invoices.clear(); invoices.addAll(it); invoicePage++; invoiceHasMore = it.size == 50 }
                        invoiceLoading = false
                    }
                }) { Text("التالي — 50 فاتورة") }
            }
        }
        if (invoiceLoading) Text("جارٍ تحميل الفواتير…", color = Green)
    }

    if (showForm) {
        InvoiceFormDialog(
            initial = editing,
            initialLines = initialLines,
            stockSuggestions = stockSuggestions,
            supplierNameSuggestions = supplierNameSuggestions,
            initialSarRate = prefs.getString("sar", "") ?: "",
            initialUsdRate = prefs.getString("usd", "") ?: "",
            onDismiss = { showForm = false; editingId = 0L },
            onSave = { invoice, lines, sarRate, usdRate, complete ->
                scope.launch {
                    try {
                        dao.saveInvoice(invoice, lines)
                        val latest = dao.getInvoicePage(50, 0)
                        invoices.clear(); invoices.addAll(latest); invoicePage = 1; invoiceHasMore = latest.size == 50
                        prefs.edit().putString("sar", sarRate).putString("usd", usdRate).apply()
                        showForm = false; editingId = 0L
                        complete(true)
                    } catch (t: Throwable) {
                        error = t.message ?: "تعذر حفظ الفاتورة."
                        complete(false)
                    }
                }
            }
        )
    }
    if (detailsFor != null) {
        AlertDialog(
            onDismissRequest = { detailsId = 0L },
            title = { Text("تفاصيل فاتورة ${detailsFor!!.invoiceNumber}") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("التاجر: ${detailsFor!!.supplier}")
                    detailLines.forEach { line ->
                        HorizontalDivider()
                        Text(line.productName, fontWeight = FontWeight.Bold)
                        Text("${line.productType} • ${line.treatmentType} • ${line.activeIngredient}")
                        Text("${line.packageCount} × ${line.packageSize} ${line.unit} • ${line.packageName}")
                        Text("${line.lineTotalForeign} ${detailsFor!!.currency} = ${formatMoney(line.lineTotalYer)}")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detailsId = 0L }) { Text("إغلاق") } }
        )
    }
    if (error != null) AlertDialog(onDismissRequest = { error = null }, title = { Text("تنبيه") }, text = { Text(error!!) }, confirmButton = { TextButton(onClick = { error = null }) { Text("حسنًا") } })
}

@Composable
private fun InvoiceDropdownChoice(
    value: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    var expanded by remember(value, options) { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 6.dp)) {
            Text(value, maxLines = 1, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ArrowDropDown, contentDescription = "اختيار")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) }
        }
    }
}

@Composable
private fun InvoiceFormDialog(
    initial: InvoiceEntity?,
    initialLines: List<InvoiceLineDraft>,
    stockSuggestions: List<StockPriceSuggestion>,
    supplierNameSuggestions: List<String>,
    initialSarRate: String,
    initialUsdRate: String,
    onDismiss: () -> Unit,
    onSave: (InvoiceEntity, List<InvoiceItemEntity>, String, String, (Boolean) -> Unit) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val nextFieldAction = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Next) })
    var supplier by rememberSaveable(initial?.id) { mutableStateOf(initial?.supplier ?: "") }
    var invoiceNumber by rememberSaveable(initial?.id) { mutableStateOf(initial?.invoiceNumber ?: "") }
    var dateMillis by rememberSaveable(initial?.id) { mutableLongStateOf(parseDateOrToday(initial?.dateMillis)) }
    var paymentStatus by rememberSaveable(initial?.id) { mutableStateOf(initial?.paymentStatus ?: "نقدًا") }
    var currency by rememberSaveable(initial?.id) { mutableStateOf(initial?.currency ?: "YER") }
    var sarRate by rememberSaveable { mutableStateOf(initialSarRate) }
    var usdRate by rememberSaveable { mutableStateOf(initialUsdRate) }
    var notes by rememberSaveable(initial?.id) { mutableStateOf(initial?.notes ?: "") }
    val lines = rememberSaveable(initial?.id, saver = InvoiceLinesSaver) {
        mutableStateListOf<InvoiceLineDraft>().apply { addAll(initialLines.ifEmpty { listOf(InvoiceLineDraft()) }) }
    }
    val rateText = when (currency) { "SAR" -> sarRate; "USD" -> usdRate; else -> "1" }
    val rate = if (currency == "YER") 1000L else rateScaled(rateText)
    val lineTotals = lines.map { line ->
        runCatching { FinanceCalculations.lineTotal(digits(line.packageCount), moneyToLong(line.unitPrice)) }.getOrNull()
    }
    val quantityBases = lines.map { line ->
        runCatching { FinanceCalculations.quantityToBase(digits(line.packageSize), line.unit, digits(line.packageCount)) }.getOrNull()
    }
    val totalForeignResult = runCatching {
        lineTotals.fold(0L) { total, value -> Math.addExact(total, value ?: error("قيمة أحد الأصناف تتجاوز الحد المسموح.")) }
    }
    val totalForeign = totalForeignResult.getOrDefault(0L)
    val totalYerResult = runCatching {
        lineTotals.fold(0L) { total, value ->
            Math.addExact(total, FinanceCalculations.toYemeniRials(value ?: error("قيمة أحد الأصناف غير صالحة."), rate))
        }
    }
    val totalYer = totalYerResult.getOrDefault(0L)
    var validation by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable(initial?.id) { mutableStateOf(false) }
    var activeSuggestionIndex by rememberSaveable { mutableIntStateOf(-1) }

    Dialog(onDismissRequest = { if (!saving) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Cream, shape = RoundedCornerShape(0.dp)) {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (initial == null) "إضافة فاتورة" else "تعديل الفاتورة", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(enabled = !saving, onClick = onDismiss) { Text("إغلاق") }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(supplier, { supplier = it }, label = { Text("اسم التاجر / المورد") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                val supplierMatches = remember(supplier, supplierNameSuggestions) { if (supplier.isBlank()) emptyList() else supplierNameSuggestions.filter { it.contains(supplier, true) }.take(5) }
                if (supplierMatches.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    supplierMatches.forEach { name -> AssistChip(onClick = { supplier = name }, label = { Text(name) }) }
                }
                OutlinedTextField(invoiceNumber, { invoiceNumber = it }, label = { Text("رقم الفاتورة") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                MiyarDateField("تاريخ الفاتورة", dateMillis) { dateMillis = it }
                Text("حالة الفاتورة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = paymentStatus == "نقدًا", onClick = { paymentStatus = "نقدًا" }, label = { Text("نقدًا") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = androidx.compose.ui.graphics.Color(0xFFDCEFE2)))
                    FilterChip(selected = paymentStatus == "آجل", onClick = { paymentStatus = "آجل" }, label = { Text("آجل") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = androidx.compose.ui.graphics.Color(0xFFFFE8C2)))
                }
                Text("عملة الفاتورة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("YER", "SAR", "USD").forEach { c -> FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = when (c) {
                            "YER" -> androidx.compose.ui.graphics.Color(0xFFDCEFE2)
                            "SAR" -> androidx.compose.ui.graphics.Color(0xFFDCEBFA)
                            else -> androidx.compose.ui.graphics.Color(0xFFEDE0F5)
                        })) }
                }
                if (currency != "YER") {
                    MiyarRateInputField(
                        value = rateText,
                        onValueChange = { if (currency == "SAR") sarRate = it else usdRate = it },
                        label = "سعر صرف 1 $currency مقابل الريال اليمني",
                        imeAction = ImeAction.Next,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                HorizontalDivider()
                var itemCountText by rememberSaveable(initial?.id) { mutableStateOf(lines.size.toString()) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("عدد أصناف الفاتورة", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    OutlinedTextField(itemCountText, { raw ->
                        itemCountText = latinDigitsOnly(raw).take(3)
                        val wanted = itemCountText.toIntOrNull()?.coerceIn(1, 100)
                        if (wanted != null) {
                            while (lines.size < wanted) lines.add(InvoiceLineDraft())
                            while (lines.size > wanted) lines.removeAt(lines.lastIndex)
                        }
                    }, modifier = Modifier.width(100.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done), label = { Text("عدد الصفوف") })
                    TextButton(onClick = { lines.add(InvoiceLineDraft()); itemCountText = lines.size.toString() }) { Icon(Icons.Default.Add, null); Text("صف") }
                }
                Text("جدول الأصناف — اسحب أفقيًا لعرض بقية الأعمدة", color = Emerald, style = MaterialTheme.typography.labelSmall)
                val tableScroll = rememberScrollState()
                Column(Modifier.fillMaxWidth().horizontalScroll(tableScroll)) {
                    Row(
                        Modifier.background(Emerald, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)).padding(vertical = 9.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("القسم", "اسم الصنف", "المادة الفعالة", "حالة الصنف", "العبوة", "حجمها", "الوحدة", "العدد", "سعر العبوة", "الإجمالي باليمني", "تكلفة الوحدة").forEachIndexed { i, heading ->
                            Text(heading, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.width(listOf(100,170,160,120,110,95,120,85,125,135,135)[i].dp).padding(horizontal = 3.dp))
                        }
                    }
                    lines.forEachIndexed { index, line ->
                        val lineTotal = lineTotals.getOrNull(index)
                        val quantityBase = quantityBases.getOrNull(index)
                        val lineYer = lineTotal?.let { runCatching { FinanceCalculations.toYemeniRials(it, rate) }.getOrNull() }
                        val unitYer = if (quantityBase != null && quantityBase > 0 && lineYer != null) runCatching {
                            val factor = if (line.unit == "كجم" || line.unit == "لتر") 1000L else 1L
                            BigDecimal(lineYer).multiply(BigDecimal(factor)).divide(BigDecimal(quantityBase), 3, RoundingMode.HALF_UP)
                        }.getOrNull() else null
                        Row(
                            Modifier.background(if (index % 2 == 0) Cream else androidx.compose.ui.graphics.Color(0xFFFFFDF7)).padding(5.dp),
                            horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            InvoiceDropdownChoice(
                                value = if (line.productType == "الأسمدة") "سماد" else "سموم",
                                options = listOf("سماد", "سموم"),
                                modifier = Modifier.width(100.dp).background(if (line.productType == "الأسمدة") androidx.compose.ui.graphics.Color(0xFFE4F5E8) else androidx.compose.ui.graphics.Color(0xFFFFE8E5), RoundedCornerShape(8.dp)).padding(3.dp),
                                onSelect = { selectedType ->
                                    val type = if (selectedType == "سماد") "الأسمدة" else "السموم"
                                    lines[index] = line.copy(
                                        productType = type,
                                        packageName = if (type == "الأسمدة") "كيس" else "عبوة",
                                        unit = if (type == "الأسمدة") "كجم" else "ملي",
                                        // A type-family change requires an explicit new stock selection.
                                        stockItemId = null,
                                        treatmentType = if (type == "الأسمدة") line.treatmentType.takeIf { it in listOf("عام", "نمو", "تجذير", "ورقي") } ?: "عام" else line.treatmentType.takeIf { it in listOf("حشري", "فطري", "ورقي", "جذري") } ?: "حشري"
                                    )
                                }
                            )
                            val productMatches = stockSuggestions.filter { it.productType == line.productType && it.baseUnit == baseUnit(line.unit) && line.productName.isNotBlank() && it.productName.contains(line.productName.trim(), true) }.take(5)
                            Box(Modifier.width(170.dp)) {
                                OutlinedTextField(line.productName, { value ->
                                    activeSuggestionIndex = index
                                    lines[index] = line.copy(productName = value)
                                    stockSuggestions.firstOrNull { it.productType == line.productType && it.baseUnit == baseUnit(line.unit) && it.productName.equals(value.trim(), true) && (line.productType == "الأسمدة" || it.treatmentType == line.treatmentType) }?.let { found ->
                                        // Do not bind an identity by matching text; select a suggestion explicitly.
                                        lines[index] = lines[index].copy(activeIngredient = found.activeIngredient, treatmentType = found.treatmentType)
                                    }
                                }, label = { Text("اسم الصنف") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.fillMaxWidth())
                                DropdownMenu(expanded = activeSuggestionIndex == index && productMatches.isNotEmpty(), onDismissRequest = { activeSuggestionIndex = -1 }, properties = PopupProperties(focusable = false)) {
                                    productMatches.forEach { product -> DropdownMenuItem(text = { Column {
                                        Text(product.productName, fontWeight = FontWeight.SemiBold)
                                        Text(product.activeIngredient, style = MaterialTheme.typography.bodySmall)
                                    } }, onClick = {
                                        lines[index] = lines[index].copy(productName = product.productName, activeIngredient = product.activeIngredient, treatmentType = product.treatmentType, stockItemId = product.id)
                                        activeSuggestionIndex = -1
                                    }) }
                                }
                            }
                            OutlinedTextField(line.activeIngredient, { lines[index] = line.copy(activeIngredient = it) }, label = { Text("المادة الفعالة / العنصر") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(160.dp))
                            InvoiceDropdownChoice(
                                value = line.treatmentType,
                                options = if (line.productType == "الأسمدة") listOf("عام", "نمو", "تجذير", "ورقي") else listOf("حشري", "فطري", "ورقي", "جذري"),
                                modifier = Modifier.width(120.dp),
                                onSelect = { lines[index] = line.copy(treatmentType = it) }
                            )
                            InvoiceDropdownChoice(
                                value = line.packageName,
                                options = listOf("كيس", "عبوة"),
                                modifier = Modifier.width(110.dp),
                                onSelect = { lines[index] = line.copy(packageName = it) }
                            )
                            OutlinedTextField(line.packageSize, { lines[index] = line.copy(packageSize = latinDigitsOnly(it)) }, label = { Text("الحجم") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(95.dp))
                            InvoiceDropdownChoice(value = if (line.unit == "كجم") "كيلو" else line.unit, options = listOf("كيلو", "جرام", "ملي", "لتر"), modifier = Modifier.width(120.dp), onSelect = { selectedUnit ->
                                val normalizedUnit = if (selectedUnit == "كيلو") "كجم" else selectedUnit
                                val oldFamily = runCatching { baseUnit(line.unit) }.getOrNull()
                                val newFamily = runCatching { baseUnit(normalizedUnit) }.getOrNull()
                                lines[index] = line.copy(unit = normalizedUnit, stockItemId = line.stockItemId.takeIf { oldFamily == newFamily })
                            })
                            OutlinedTextField(line.packageCount, { lines[index] = line.copy(packageCount = latinDigitsOnly(it)) }, label = { Text("العدد") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), keyboardActions = nextFieldAction, singleLine = true, modifier = Modifier.width(85.dp))
                            MiyarMoneyInputField(line.unitPrice, { lines[index] = line.copy(unitPrice = it) }, label = "السعر ($currency)", imeAction = ImeAction.Next, modifier = Modifier.width(125.dp))
                            Text(lineYer?.let { formatMoney(it) } ?: "—", color = Green, fontWeight = FontWeight.Bold, modifier = Modifier.width(135.dp))
                            Text(unitYer?.let { String.format(Locale.US, "%.3f YER", it) } ?: "—", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.width(135.dp))
                            IconButton(onClick = { if (lines.size > 1) lines.removeAt(index) }) { Icon(Icons.Default.Delete, "حذف الصف", tint = MaterialTheme.colorScheme.error) }
                        }
                        HorizontalDivider(color = Gold.copy(alpha = 0.65f))
                    }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات الفاتورة") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                HorizontalDivider()
                Text("الإجمالي: $totalForeign $currency", fontWeight = FontWeight.Bold)
                Text("ما يعادله: ${formatMoney(totalYer)}", color = Emerald, fontWeight = FontWeight.ExtraBold)
                if (validation.isNotBlank()) Text(validation, color = MaterialTheme.colorScheme.error)
            }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(enabled = !saving, onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                    Button(enabled = !saving, onClick = {
                        when {
                            supplier.isBlank() -> validation = "أدخل اسم التاجر أو المورد."
                            invoiceNumber.isBlank() -> validation = "أدخل رقم الفاتورة."
                            lines.any { it.productName.isBlank() || digits(it.packageCount) <= 0 || digits(it.packageSize) <= 0 || digits(it.unitPrice) <= 0 } -> validation = "أكمل بيانات جميع أصناف الفاتورة."
                            lines.any { if (it.productType == "الأسمدة") it.treatmentType !in listOf("عام", "نمو", "تجذير", "ورقي") else it.treatmentType !in listOf("حشري", "فطري", "ورقي", "جذري") } -> validation = "حدد تصنيف كل صنف: السماد عام أو نمو أو تجذير أو ورقي، والسموم حشري أو فطري أو ورقي أو جذري."
                            quantityBases.any { it == null || it <= 0L } -> validation = "راجع الكميات والوحدات."
                            lineTotals.any { it == null } || totalForeignResult.isFailure -> validation = "راجع أسعار الأصناف."
                            currency != "YER" && rate <= 0 -> validation = "أدخل سعر صرف صحيحًا."
                            totalYerResult.isFailure -> validation = "تعذر تحويل إجمالي الفاتورة."
                            else -> {
                                val invoice = InvoiceEntity(id = initial?.id ?: 0, supplier = supplier.trim(), invoiceNumber = invoiceNumber.trim(), dateMillis = dateMillis, paymentStatus = paymentStatus, currency = currency, exchangeRateScaled = rate, totalForeign = totalForeign, totalYer = totalYer, notes = notes.trim())
                                val invoiceItems = lines.mapIndexed { index, line ->
                                    val foreign = requireNotNull(lineTotals[index]); val qty = requireNotNull(quantityBases[index])
                                    InvoiceItemEntity(invoiceId = invoice.id, stockItemId = line.stockItemId ?: 0L, productType = line.productType, productName = line.productName.trim(), activeIngredient = line.activeIngredient.trim(), packageName = line.packageName.trim(), packageSize = digits(line.packageSize), packageCount = digits(line.packageCount), unit = line.unit, quantityBase = qty, unitPriceForeign = moneyToLong(line.unitPrice), lineTotalForeign = foreign, lineTotalYer = FinanceCalculations.toYemeniRials(foreign, rate), treatmentType = line.treatmentType)
                                }
                                saving = true
                                onSave(invoice, invoiceItems, sarRate, usdRate) { saving = false }
                            }
                        }
                    }, modifier = Modifier.weight(1f)) { Text(if (saving) "جارٍ الحفظ..." else "حفظ الفاتورة") }
                }
            }
        }
    }
}

@Composable
private fun InventoryThresholdEditorContent(onSaved: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("miyar_inventory_settings", android.content.Context.MODE_PRIVATE) }
    var values by remember { mutableStateOf(listOf("fertilizer_liquid", "fertilizer_solid", "pesticide_liquid", "pesticide_solid").map { prefs.getString(it, "").orEmpty() }) }
    var error by remember { mutableStateOf("") }
    val labels = listOf("الأسمدة السائلة (ml)", "الأسمدة الصلبة (g)", "السموم السائلة (ml)", "السموم الصلبة (g)")
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        labels.forEachIndexed { index, label ->
            OutlinedTextField(values[index], { value -> values = values.toMutableList().also { it[index] = value.filter(Char::isDigit) } }, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
        Button(onClick = {
            if (!values.all { it.isBlank() || it.toLongOrNull()?.let { v -> v > 0L } == true }) error = "يجب إدخال أعداد صحيحة أكبر من صفر أو ترك الحقل فارغاً."
            else {
                val keys = listOf("fertilizer_liquid", "fertilizer_solid", "pesticide_liquid", "pesticide_solid")
                val edit = prefs.edit()
                keys.forEachIndexed { index, key -> edit.putString(key, values[index]) }
                edit.putBoolean("limits_completed", true)
                edit.apply()
                onSaved()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الحدود الافتراضية") }
    }
}

@Composable
fun MiyarInventorySettingsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("miyar_inventory_settings", android.content.Context.MODE_PRIVATE) }
    var fertilizerLiquid by remember { mutableStateOf(prefs.getString("fertilizer_liquid", "").orEmpty()) }
    var fertilizerSolid by remember { mutableStateOf(prefs.getString("fertilizer_solid", "").orEmpty()) }
    var pesticideLiquid by remember { mutableStateOf(prefs.getString("pesticide_liquid", "").orEmpty()) }
    var pesticideSolid by remember { mutableStateOf(prefs.getString("pesticide_solid", "").orEmpty()) }
    var message by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("إعدادات المخزون", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
        Text("حدد حدود التنبيه العامة مرة واحدة. يطبق الحد على الأصناف المطابقة التي لا تملك حداً مخصصاً، ولا يؤثر في الكمية أو التكلفة أو الرصيد المالي.", style = MaterialTheme.typography.bodySmall, color = Green)
        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(fertilizerLiquid, { fertilizerLiquid = it.filter(Char::isDigit); saved = false }, label = { Text("الأسمدة السائلة — ml") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(fertilizerSolid, { fertilizerSolid = it.filter(Char::isDigit); saved = false }, label = { Text("الأسمدة الصلبة — g") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(pesticideLiquid, { pesticideLiquid = it.filter(Char::isDigit); saved = false }, label = { Text("السموم السائلة — ml") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(pesticideSolid, { pesticideSolid = it.filter(Char::isDigit); saved = false }, label = { Text("السموم الصلبة — g") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text("كل حقل اختياري. اتركه فارغاً إذا لم ترغب في حد عام لهذه الفئة. الحد المخصص داخل بطاقة الصنف له الأولوية ولا يتغير عند تعديل الحدود العامة.", style = MaterialTheme.typography.labelSmall, color = Green)
                Button(onClick = {
                    val values = listOf(fertilizerLiquid, fertilizerSolid, pesticideLiquid, pesticideSolid)
                    val valid = values.all { it.isBlank() || (it.toLongOrNull()?.let { n -> n > 0L } == true) }
                    if (!valid) { message = "يجب أن تكون الحدود أعداداً صحيحة أكبر من صفر أو فارغة."; saved = false }
                    else {
                        prefs.edit()
                            .putString("fertilizer_liquid", fertilizerLiquid.trim())
                            .putString("fertilizer_solid", fertilizerSolid.trim())
                            .putString("pesticide_liquid", pesticideLiquid.trim())
                            .putString("pesticide_solid", pesticideSolid.trim())
                            .putBoolean("limits_completed", true)
                            .apply()
                        message = "تم حفظ حدود التنبيه الافتراضية."
                        saved = true
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("حفظ حدود التنبيه") }
                if (message.isNotBlank()) Text(message, color = if (saved) Green else MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun MiyarInventoryScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val inventoryPrefs = remember(context) { context.getSharedPreferences("miyar_inventory_settings", android.content.Context.MODE_PRIVATE) }
    var inventoryPrefsRevision by remember { mutableIntStateOf(0) }
    DisposableEffect(inventoryPrefs) {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> inventoryPrefsRevision++ }
        inventoryPrefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { inventoryPrefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    var stockItems by remember(dao) { mutableStateOf<List<StockItemEntity>?>(null) }
    var stockLoadError by remember(dao) { mutableStateOf<String?>(null) }
    var stockReloadKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(dao, stockReloadKey) {
        stockItems = null
        stockLoadError = null
        dao.observeStockItems()
            .catch { throwable -> stockItems = null; stockLoadError = throwable.message ?: "تعذر تحميل بيانات المخزون." }
            .collect { items -> stockItems = items; stockLoadError = null }
    }
    val stock = stockItems.orEmpty()
    @Suppress("UNUSED_VARIABLE") val prefsRevisionRead = inventoryPrefsRevision
    val lowStockItems = stock.filter { it.quantityBase > 0L && effectiveStockThreshold(it, inventoryPrefs)?.let { limit -> it.quantityBase <= limit } == true }
    val outOfStockItems = stock.filter { it.quantityBase == 0L }
    val issueVouchers by dao.observeStockIssueVouchers().collectAsStateWithLifecycle(initialValue = emptyList())
    val valueSummary by dao.observeStockValueSummary().collectAsStateWithLifecycle(initialValue = StockValueSummary(0, 0, 0, 0))
    val outboundBreakdown by dao.observeStockOutboundCategoryTotals().collectAsStateWithLifecycle(initialValue = emptyList())
    val reviewRows by dao.observeStockReviewRows().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var selectedType by rememberSaveable { mutableStateOf("الكل") }
    var selectedTreatment by rememberSaveable { mutableStateOf("الكل") }
    var typeMenuExpanded by remember { mutableStateOf(false) }
    var treatmentMenuExpanded by remember { mutableStateOf(false) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var showIssue by rememberSaveable { mutableStateOf(false) }
    var editingIssue by remember { mutableStateOf<StockIssueVoucherEntity?>(null) }
    var editingIssueLines by remember { mutableStateOf<List<StockIssueLineEntity>>(emptyList()) }
    var pendingDeleteIssue by remember { mutableStateOf<StockIssueVoucherEntity?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var stockSearch by rememberSaveable { mutableStateOf("") }
    var usageDialogItem by remember { mutableStateOf<StockItemEntity?>(null) }
    var usageMovements by remember { mutableStateOf<List<StockMovementDetail>>(emptyList()) }
    var usagePage by rememberSaveable { mutableIntStateOf(0) }
    var unusedStockDialogName by remember { mutableStateOf<String?>(null) }
    var showIssueHistory by remember { mutableStateOf(false) }
    var expandedIssueVoucherId by remember { mutableStateOf<Long?>(null) }
    var expandedIssueLines by remember { mutableStateOf<List<StockIssueLineEntity>>(emptyList()) }
    var issueActionsMenuId by remember { mutableStateOf<Long?>(null) }
    var showOutboundDetails by remember { mutableStateOf(false) }
    var showInboundDetails by remember { mutableStateOf(false) }
    var showRemainingDetails by remember { mutableStateOf(false) }
    var showLowStockList by remember { mutableStateOf(false) }
    var showOutOfStockList by remember { mutableStateOf(false) }
    var showReviewCenter by remember { mutableStateOf(false) }
    var showLimitReminder by remember { mutableStateOf(false) }
    var showThresholdEditor by remember { mutableStateOf(false) }
    var inboundPage by rememberSaveable { mutableIntStateOf(0) }
    var inboundMovements by remember { mutableStateOf<List<StockMovementHistoryRow>>(emptyList()) }
    var reviewFeedback by remember { mutableStateOf("") }
    var selectedReviewRow by remember { mutableStateOf<StockReviewRow?>(null) }
    var outboundMovements by remember { mutableStateOf<List<StockMovementDetail>>(emptyList()) }
    var outboundPage by rememberSaveable { mutableIntStateOf(0) }
    var detailStockItem by remember { mutableStateOf<StockItemEntity?>(null) }
    var itemHistory by remember { mutableStateOf<List<StockMovementHistoryRow>>(emptyList()) }
    var itemHistoryPage by rememberSaveable { mutableIntStateOf(0) }
    var thresholdInput by remember { mutableStateOf("") }
    var thresholdError by remember { mutableStateOf("") }
    var thresholdMessage by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(usageDialogItem?.id, usagePage) {
        usageMovements = usageDialogItem?.let { selectedItem ->
            runCatching { dao.getStockUsageDetails(selectedItem.id, 50, usagePage * 50) }.getOrDefault(emptyList())
        }.orEmpty()
    }
    LaunchedEffect(showOutboundDetails, outboundPage) {
        if (showOutboundDetails) outboundMovements = runCatching { dao.getStockUsageDetailsPage(100, outboundPage * 100) }.getOrDefault(emptyList())
    }
    LaunchedEffect(showInboundDetails, inboundPage) {
        if (showInboundDetails) inboundMovements = runCatching { dao.getStockInboundHistoryPage(100, inboundPage * 100) }.getOrDefault(emptyList())
    }
    LaunchedEffect(Unit) {
        if (!inventoryPrefs.getBoolean("limits_completed", false)) showLimitReminder = true
    }
    LaunchedEffect(detailStockItem?.id, itemHistoryPage, inventoryPrefsRevision) {
        val selected = detailStockItem
        if (selected != null) {
            itemHistory = runCatching { dao.getStockMovementHistory(selected.id, 50, itemHistoryPage * 50) }.getOrDefault(emptyList())
            thresholdInput = (selected.lowStockThresholdBase ?: effectiveStockThreshold(selected, inventoryPrefs))?.toString().orEmpty()
            thresholdError = ""
            thresholdMessage = ""
        } else itemHistory = emptyList()
    }

    // Sort by last receipt/opening-balance time, never by usage or issue updates.
    val orderedStock = stock.sortedWith(compareByDescending<StockItemEntity> { it.lastReceivedAtMillis }.thenByDescending { it.id })
    val byProductSection = orderedStock.filter { selectedType == "الكل" || it.productType == selectedType }
    val treatmentFiltered = byProductSection.filter { selectedTreatment == "الكل" || it.treatmentType == selectedTreatment }
    val query = stockSearch.trim()
    val filtered = treatmentFiltered.filter {
        query.isBlank() || it.productName.contains(query, ignoreCase = true) || it.activeIngredient.contains(query, ignoreCase = true)
    }
    val receivedGrams = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "g" }.map { it.totalReceivedBase })
    val usedGrams = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "g" }.map { it.totalUsedBase })
    val remainingGrams = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "g" }.map { it.quantityBase })
    val receivedMl = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "ml" }.map { it.totalReceivedBase })
    val usedMl = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "ml" }.map { it.totalUsedBase })
    val remainingMl = FinanceCalculations.sumExact(filtered.filter { it.baseUnit == "ml" }.map { it.quantityBase })
    fun mixedQuantity(grams: Long, ml: Long): String = buildList {
        if (grams > 0L) add(stockQuantity(grams, "g"))
        if (ml > 0L) add(stockQuantity(ml, "ml"))
    }.joinToString(" • ").ifBlank { "0" }

    Column(modifier.fillMaxWidth().background(Cream), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("المخزون", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = { showIssue = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = androidx.compose.ui.graphics.Color(0xFFB64040)), border = androidx.compose.foundation.BorderStroke(1.dp, androidx.compose.ui.graphics.Color(0xFFDFAAAA)), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 7.dp)) {
                Icon(Icons.Default.Remove, contentDescription = null); Spacer(Modifier.width(3.dp)); Text("صرف")
            }
            Button(onClick = { showAdd = true }, colors = ButtonDefaults.buttonColors(containerColor = Emerald), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 7.dp)) {
                Icon(Icons.Default.Add, contentDescription = null); Spacer(Modifier.width(3.dp)); Text("رصيد")
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(0.9f)) {
                OutlinedButton(onClick = { typeMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selectedType == "الكل") androidx.compose.ui.graphics.Color(0xFFE5F0FF) else androidx.compose.ui.graphics.Color.White)) {
                    Text("نوع الصنف: $selectedType", maxLines = 1, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = typeMenuExpanded, onDismissRequest = { typeMenuExpanded = false }) {
                    listOf("الكل", "الأسمدة", "السموم").forEach { type ->
                        DropdownMenuItem(text = { Text(type) }, onClick = { selectedType = type; selectedTreatment = "الكل"; typeMenuExpanded = false })
                    }
                }
            }
            OutlinedTextField(
                value = stockSearch, onValueChange = { stockSearch = it }, modifier = Modifier.weight(1.1f), singleLine = true,
                placeholder = { Text("بحث صنف", maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                shape = RoundedCornerShape(12.dp), textStyle = MaterialTheme.typography.bodySmall,
                colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = androidx.compose.ui.graphics.Color.White, focusedContainerColor = androidx.compose.ui.graphics.Color.White)
            )
        }
        val treatments = when (selectedType) {
            "الأسمدة" -> listOf("الكل", "عام", "نمو", "تجذير", "ورقي")
            "السموم" -> listOf("الكل", "حشري", "فطري", "ورقي", "جذري")
            else -> listOf("الكل", "عام", "نمو", "تجذير", "حشري", "فطري", "ورقي", "جذري")
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                OutlinedButton(onClick = { treatmentMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selectedTreatment == "الكل") androidx.compose.ui.graphics.Color(0xFFFFF0D8) else androidx.compose.ui.graphics.Color.White)) {
                    Text("التصنيف: $selectedTreatment", maxLines = 1, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = treatmentMenuExpanded, onDismissRequest = { treatmentMenuExpanded = false }) {
                    treatments.forEach { kind -> DropdownMenuItem(text = { Text(kind) }, onClick = { selectedTreatment = kind; treatmentMenuExpanded = false }) }
                }
            }
            Text("التصنيفات متوافقة مع نوع الصنف", style = MaterialTheme.typography.labelSmall, color = Green, modifier = Modifier.padding(start = 8.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            val partialLabel = if (valueSummary.unverifiedItemCount > 0L) "محسوب جزئياً" else "موثق/تقديري"
            StockValueCard("قيمة الوارد", formatStockValueMicros(valueSummary.inboundValueMicros), partialLabel + " • اضغط للتفصيل", Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFDDF1E8), onClick = { inboundPage = 0; showInboundDetails = true })
            StockValueCard("قيمة المنصرف", formatStockValueMicros(valueSummary.outboundValueMicros), partialLabel + " • اضغط للتفصيل", Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFFFE9D8), onClick = { outboundPage = 0; showOutboundDetails = true })
            StockValueCard("قيمة المتبقي", formatStockValueMicros(valueSummary.remainingValueMicros), partialLabel + " • اضغط للتفصيل", Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFE4EDF8), onClick = { showRemainingDetails = true })
        }
        if (valueSummary.unverifiedItemCount > 0L) {
            Card(modifier = Modifier.fillMaxWidth().clickable { showReviewCenter = true }, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3D9)), shape = RoundedCornerShape(10.dp)) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("توجد ${valueSummary.unverifiedItemCount} أصناف تحتاج إلى مراجعة — اضغط لفتح مركز المراجعة", color = androidx.compose.ui.graphics.Color(0xFF805719), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Text("القيم الظاهرة في المربعات تخص الأصناف الموثقة أو التقديرية فقط. أثر الأصناف غير المحسومة: وارد ${formatStockValueMicros(valueSummary.unresolvedInboundValueMicros)} • منصرف ${formatStockValueMicros(valueSummary.unresolvedOutboundValueMicros)} • متبقٍ ${formatStockValueMicros(valueSummary.unresolvedRemainingValueMicros)}", color = androidx.compose.ui.graphics.Color(0xFF805719), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SummaryMiniCard("منخفض المخزون", lowStockItems.size.toString(), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFFFE7B8), onClick = { showLowStockList = true })
            SummaryMiniCard("نفد المخزون", outOfStockItems.size.toString(), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFFFDAD6), onClick = { showOutOfStockList = true })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            SummaryMiniCard("الأصناف", filtered.size.toString(), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFE4EDF8))
            SummaryMiniCard("المستلم", mixedQuantity(receivedGrams, receivedMl), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFDDF1E8))
            SummaryMiniCard("المستخدم", mixedQuantity(usedGrams, usedMl), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFFFF0D9))
            SummaryMiniCard("المتبقي", mixedQuantity(remainingGrams, remainingMl), Modifier.weight(1f), androidx.compose.ui.graphics.Color(0xFFDCEFE2))
        }

        if (showIssueHistory && issueVouchers.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("سندات الصرف السابقة", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showIssueHistory = false }) { Text("إخفاء") }
            }
            issueVouchers.forEach { voucher ->
                Box {
                    Card(
                        modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = {
                                if (expandedIssueVoucherId == voucher.id) {
                                    expandedIssueVoucherId = null
                                    expandedIssueLines = emptyList()
                                } else {
                                    expandedIssueVoucherId = voucher.id
                                    scope.launch { expandedIssueLines = dao.getStockIssueLines(voucher.id) }
                                }
                            },
                            onLongClick = { issueActionsMenuId = voucher.id }
                        ),
                        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF4F1)),
                        shape = RoundedCornerShape(11.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(voucher.reason, color = androidx.compose.ui.graphics.Color(0xFF994444), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                            Text("${localDate(voucher.dateMillis)} • سند رقم ${voucher.id}", color = Green, style = MaterialTheme.typography.labelSmall)
                            if (expandedIssueVoucherId == voucher.id) {
                                HorizontalDivider(color = androidx.compose.ui.graphics.Color(0xFFE5D0C8))
                                expandedIssueLines.forEach { line ->
                                    Text("${line.productName} • ${stockQuantity(line.quantityBase, line.baseUnit)}", color = Emerald, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    DropdownMenu(
                        expanded = issueActionsMenuId == voucher.id,
                        onDismissRequest = { issueActionsMenuId = null }
                    ) {
                        DropdownMenuItem(
                            text = { Text("تعديل السند") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                issueActionsMenuId = null
                                scope.launch {
                                    editingIssueLines = dao.getStockIssueLines(voucher.id)
                                    editingIssue = voucher
                                    showIssue = true
                                    showIssueHistory = false
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("حذف السند", color = androidx.compose.ui.graphics.Color(0xFFB3261E)) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) },
                            onClick = { issueActionsMenuId = null; pendingDeleteIssue = voucher }
                        )
                    }
                }
            }
        } else if (issueVouchers.isNotEmpty()) {
            TextButton(onClick = { showIssueHistory = true }) { Text("عرض سندات الصرف السابقة (${issueVouchers.size})") }
        }

        if (stockItems == null && stockLoadError == null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Text("جارٍ تحميل بيانات المخزون...")
                }
            }
        }
        if (stockLoadError != null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تعذر تحميل المخزون", color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                    Text(stockLoadError.orEmpty(), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = { stockReloadKey++ }) { Text("إعادة المحاولة") }
                }
            }
        }
        if (stockItems != null && stockLoadError == null && query.length >= 1 && filtered.isEmpty()) {
            Text("لا توجد أصناف تطابق البحث.", color = Green, modifier = Modifier.padding(8.dp))
        }
        if (stockItems != null && stockLoadError == null && filtered.isEmpty() && query.isBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("لا توجد أصناف في المخزون", fontWeight = FontWeight.Bold)
                    Text("أضف رصيدًا افتتاحيًا أو سجّل فاتورة مشتريات.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        filtered.forEach { item ->
            val cardColor = if (item.productType == "الأسمدة") androidx.compose.ui.graphics.Color(0xFFF2F8EF) else androidx.compose.ui.graphics.Color(0xFFF2EFF8)
            Card(modifier = Modifier.fillMaxWidth().clickable { detailStockItem = item; itemHistoryPage = 0 }, colors = CardDefaults.cardColors(containerColor = cardColor), shape = RoundedCornerShape(13.dp), elevation = CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CategoryArtwork(item.productType, Modifier.size(38.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.productName, fontWeight = FontWeight.Bold, color = Emerald)
                            Text("${item.productType} • ${item.treatmentType}", style = MaterialTheme.typography.labelSmall, color = Green)
                        }
                    }
                    if (item.activeIngredient.isNotBlank()) Text("المادة الفعالة / العنصر: ${item.activeIngredient}", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        val availability = stockAvailabilityLabel(item, effectiveStockThreshold(item, inventoryPrefs))
                        val availabilityColor = when (availability) {
                            "أصناف نفدت كمياتها" -> androidx.compose.ui.graphics.Color(0xFFB3261E)
                            "منخفض المخزون" -> androidx.compose.ui.graphics.Color(0xFF9A641A)
                            else -> Green
                        }
                        Text(availability, color = availabilityColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.width(8.dp))
                        Text(if (item.valuationStatus == "REVIEW_REQUIRED") "• يحتاج مراجعة" else if (item.valuationStatus == "ESTIMATED") "• تقييم تقديري" else "• تقييم موثق", color = if (item.valuationStatus == "REVIEW_REQUIRED") androidx.compose.ui.graphics.Color(0xFFB3261E) else Green, style = MaterialTheme.typography.labelSmall)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("القيمة الحالية", color = Emerald, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Text(if (item.valuationStatus == "REVIEW_REQUIRED") "تحتاج مراجعة" else formatStockValueMicros(item.currentValueMicros), fontWeight = FontWeight.Bold, color = Emerald)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("المستلم", color = androidx.compose.ui.graphics.Color(0xFF286C4D), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Text(stockQuantity(item.totalReceivedBase, item.baseUnit), fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFF286C4D))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("المستخدم / الخارج", color = androidx.compose.ui.graphics.Color(0xFF94601C), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = {
                            if (item.totalUsedBase > 0L) { usagePage = 0; usageDialogItem = item } else unusedStockDialogName = item.productName
                        }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                            Text(stockQuantity(item.totalUsedBase, item.baseUnit), color = if (item.totalUsedBase > 0L) androidx.compose.ui.graphics.Color(0xFF94601C) else androidx.compose.ui.graphics.Color.Gray, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, contentDescription = "عرض سجل استخدام الصنف", modifier = Modifier.size(16.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("المتبقي", color = androidx.compose.ui.graphics.Color(0xFF236A40), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Text(stockQuantity(item.quantityBase, item.baseUnit), fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFF236A40))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }

    if (usageDialogItem != null) {
        val item = usageDialogItem!!
        val itemMovements = usageMovements
        AlertDialog(
            onDismissRequest = { usageDialogItem = null },
            title = { Text("سجل حركة ${item.productName}", color = Emerald, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إجمالي الخارج: ${stockQuantity(item.totalUsedBase, item.baseUnit)}", color = Emerald, fontWeight = FontWeight.Bold)
                    if (itemMovements.isEmpty()) {
                        Text("لا توجد حركات خروج تفصيلية مرتبطة بهذا الصنف.")
                    } else itemMovements.forEach { movement ->
                        Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(10.dp)) {
                            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("الكمية: ${stockQuantity(kotlin.math.abs(movement.quantityBase), movement.baseUnit)}", color = Emerald, fontWeight = FontWeight.Bold)
                                Text("نوع الحركة: ${movement.operationCategory ?: movement.referenceType}", style = MaterialTheme.typography.bodySmall)
                                if (!movement.plantationName.isNullOrBlank()) Text("الموضع: ${movement.plantationName}", style = MaterialTheme.typography.bodySmall)
                                if (!movement.operationTitle.isNullOrBlank()) Text("البيان: ${movement.operationTitle}", style = MaterialTheme.typography.bodySmall)
                                Text("التاريخ: ${localDate(movement.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                                Text("تكلفة الحركة: ${formatStockValueMicros(kotlin.math.abs(movement.valueDeltaMicros))}${if (movement.estimatedValue) " • تقديرية" else ""}", style = MaterialTheme.typography.labelSmall, color = Emerald)
                                if (movement.description.isNotBlank()) Text(movement.description, style = MaterialTheme.typography.labelSmall, color = Green)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(enabled = usagePage > 0, onClick = { usagePage-- }) { Text("السابق") }
                        Text("صفحة ${usagePage + 1}", style = MaterialTheme.typography.labelSmall, color = Green)
                        TextButton(enabled = itemMovements.size == 50, onClick = { usagePage++ }) { Text("التالي") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { usageDialogItem = null }) { Text("إغلاق") } }
        )
    }
    if (showInboundDetails) AlertDialog(
        onDismissRequest = { showInboundDetails = false },
        title = { Text("تفاصيل قيمة الوارد", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("الوارد يشمل الفواتير والأرصدة الافتتاحية. قيمة الحركة تُحسب مرة واحدة من سجل المخزون، ولا يعاد احتساب الفاتورة بشكل منفصل.", style = MaterialTheme.typography.bodySmall)
                if (inboundMovements.isEmpty()) Text("لا توجد حركات وارد مسجلة.")
                inboundMovements.forEach { movement ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(9.dp)) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("${stockItems?.firstOrNull { it.id == movement.stockItemId }?.productName ?: "صنف #${movement.stockItemId}"} • ${stockQuantity(movement.quantityBase, stockItems?.firstOrNull { it.id == movement.stockItemId }?.baseUnit ?: movement.unit ?: "ml")}", color = Emerald, fontWeight = FontWeight.Bold)
                            Text(when (movement.referenceType) { "INVOICE" -> "فاتورة مشتريات • ${movement.supplier.orEmpty()} • ${movement.invoiceNumber.orEmpty()}"; "OPENING" -> "رصيد افتتاحي"; "REVIEW_ADJUSTMENT" -> "تسوية جردية / تصحيح مراجعة"; else -> movement.referenceType }, style = MaterialTheme.typography.bodySmall)
                            if (movement.referenceType == "REVIEW_ADJUSTMENT" && movement.description.isNotBlank()) Text(movement.description, style = MaterialTheme.typography.labelSmall)
                            val valuationStatus = stockItems?.firstOrNull { it.id == movement.stockItemId }?.valuationStatus
                            Text("${localDate(movement.dateMillis)} • ${if (valuationStatus == "REVIEW_REQUIRED" || valuationStatus == "PENDING") "أثر غير محسوم: ${formatStockValueMicros(movement.valueDeltaMicros)}" else formatStockValueMicros(movement.valueDeltaMicros)}${if (movement.estimatedValue) " • تقديري" else ""}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(enabled = inboundPage > 0, onClick = { inboundPage-- }) { Text("السابق") }
                    Text("صفحة ${inboundPage + 1}", style = MaterialTheme.typography.labelSmall)
                    TextButton(enabled = inboundMovements.size == 100, onClick = { inboundPage++ }) { Text("التالي") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showInboundDetails = false }) { Text("إغلاق") } }
    )
    if (showRemainingDetails) AlertDialog(
        onDismissRequest = { showRemainingDetails = false },
        title = { Text("تفاصيل قيمة المتبقي", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("قيمة مؤكدة: ${formatStockValueMicros(valueSummary.remainingValueMicros)} • قيمة الأصناف غير المحسومة: ${formatStockValueMicros(valueSummary.unresolvedRemainingValueMicros)}", color = Emerald, fontWeight = FontWeight.Bold)
                stockItems.orEmpty().filter { it.quantityBase > 0L }.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(9.dp)) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(item.productName, color = Emerald, fontWeight = FontWeight.Bold)
                            Text("الكمية الفعلية: ${stockQuantity(item.quantityBase, item.baseUnit)}", style = MaterialTheme.typography.bodySmall)
                            Text(if (item.valuationStatus == "REVIEW_REQUIRED" || item.valuationStatus == "PENDING") "القيمة: غير محسومة — ${item.valuationReviewReason.ifBlank { "يلزم فحص سجل الحركات" }}" else "القيمة: ${formatStockValueMicros(item.currentValueMicros)} • ${if (item.valuationStatus == "ESTIMATED") "تقديرية" else "موثقة"}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showRemainingDetails = false }) { Text("إغلاق") } }
    )
    if (showLowStockList || showOutOfStockList) {
        val lowMode = showLowStockList
        val target = if (lowMode) lowStockItems else outOfStockItems
        AlertDialog(
            onDismissRequest = { showLowStockList = false; showOutOfStockList = false },
            title = { Text(if (lowMode) "أصناف منخفضة المخزون" else "أصناف نفدت كمياتها", color = Emerald, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (target.isEmpty()) Text(if (lowMode) "لا توجد أصناف منخفضة حالياً." else "لا توجد أصناف نفدت كمياتها.")
                    target.forEach { item ->
                        Card(Modifier.fillMaxWidth().clickable { detailStockItem = item; itemHistoryPage = 0; showLowStockList = false; showOutOfStockList = false }, colors = CardDefaults.cardColors(containerColor = if (lowMode) androidx.compose.ui.graphics.Color(0xFFFFF0D8) else androidx.compose.ui.graphics.Color(0xFFFFE4E1))) {
                            Column(Modifier.padding(9.dp)) {
                                Text(item.productName, color = Emerald, fontWeight = FontWeight.Bold)
                                Text("الكمية: ${stockQuantity(item.quantityBase, item.baseUnit)} • حد التنبيه: ${effectiveStockThreshold(item, inventoryPrefs)?.let { stockQuantity(it, item.baseUnit) } ?: "غير محدد"}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showLowStockList = false; showOutOfStockList = false }) { Text("إغلاق") } }
        )
    }
    if (showReviewCenter) AlertDialog(
        onDismissRequest = { showReviewCenter = false; reviewFeedback = "" },
        title = { Text("مراجعة أصناف المخزون", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("موثق: تكلفة مرتبطة بمصدر محفوظ يمكن تتبعه. تقديري: قيمة محسوبة بتوزيع أو بيانات تاريخية معلن أنها تقديرية. يحتاج مراجعة: نقص أو تعارض يمنع اعتماد النتيجة.", style = MaterialTheme.typography.bodySmall)
                if (reviewFeedback.isNotBlank()) Text(reviewFeedback, color = Green, fontWeight = FontWeight.Bold)
                if (reviewRows.isEmpty()) Text("لا توجد أصناف تحتاج إلى مراجعة حالياً.", color = Green)
                reviewRows.forEach { row ->
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3D9)), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${row.productName} • #${row.id}", color = Emerald, fontWeight = FontWeight.Bold)
                            Text("سبب المراجعة: ${row.valuationReviewReason.ifBlank { "تقييم تاريخي غير مكتمل أو مصدر غير مطابق." }}", style = MaterialTheme.typography.bodySmall)
                            Text("الكمية المسجلة: ${stockQuantity(row.quantityBase, row.baseUnit)} • المستنتجة من الحركات: ${if (row.movementCount > 0L) stockQuantity(row.ledgerQuantityBase, row.baseUnit) else "غير متاحة لعدم وجود حركات"}", style = MaterialTheme.typography.labelSmall)
                            val quantityDifference = runCatching { Math.subtractExact(row.ledgerQuantityBase, row.quantityBase) }.getOrDefault(0L)
                            val valueDifference = runCatching { Math.subtractExact(row.ledgerValueMicros, row.currentValueMicros) }.getOrDefault(0L)
                            Text("فرق الكمية (الحركات − المسجل): ${if (quantityDifference >= 0L) "+" else ""}${stockQuantity(kotlin.math.abs(quantityDifference), row.baseUnit)} • فرق القيمة: ${formatStockValueMicros(valueDifference)}", style = MaterialTheme.typography.labelSmall)
                            Text("القيمة المسجلة: ${formatStockValueMicros(row.currentValueMicros)} • صافي قيمة دفتر الحركات: ${formatStockValueMicros(row.ledgerValueMicros)}", style = MaterialTheme.typography.labelSmall)
                            Text("قيمة الوارد: ${formatStockValueMicros(row.inboundValueMicros)} • قيمة المنصرف: ${formatStockValueMicros(row.outboundValueMicros)}", style = MaterialTheme.typography.labelSmall)
                            Text("مصادر الحركات: ${row.sourceTypes} • عدد الحركات: ${row.movementCount}", style = MaterialTheme.typography.labelSmall)
                            Text("الإجراء المقترح: افتح أدوات الإصلاح لمعرفة الحركة المحددة. يمكنك تصحيح قيمة وارد من مصدره، أو تسوية الكمية بعد عدّ فعلي. كل تغيير يحفظ الحركة الأصلية وتضاف له حركة/مراجعة تدقيقية.", style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color(0xFF805719))
                            OutlinedButton(onClick = { selectedReviewRow = row }, modifier = Modifier.fillMaxWidth()) { Text("تفاصيل الخلل وأدوات الإصلاح") }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    val result = runCatching { dao.recheckStockItemValuation(row.id) }
                                    reviewFeedback = result.fold(
                                        { ok -> if (ok) "أعيد فحص «${row.productName}»؛ حالته الآن موثق أو تقديري حسب مصادره." else "ما زال «${row.productName}» يحتاج مراجعة. افتح أدوات الإصلاح لمعرفة السبب المتبقي." },
                                        { failure -> "تعذر الفحص: ${failure.message ?: "خطأ غير معروف"}" }
                                    )
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("إعادة فحص بعد التصحيح") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showReviewCenter = false; reviewFeedback = "" }) { Text("إغلاق") } }
    )
    selectedReviewRow?.let { reviewRow ->
        StockReviewRepairDialog(
            dao = dao,
            row = reviewRow,
            onDismiss = { selectedReviewRow = null }
        )
    }
    if (showLimitReminder) AlertDialog(
        onDismissRequest = { showLimitReminder = false },
        title = { Text("إعداد حدود تنبيه المخزون", color = Emerald, fontWeight = FontWeight.Bold) },
        text = { Text("لم تكتمل حدود التنبيه الافتراضية للفئات الأربع. يمكنك متابعة استخدام المخزون دون تعطيل الفواتير أو الحركات، لكن حدّد الحدود من الإعدادات عند الحاجة.") },
        confirmButton = { TextButton(onClick = { showLimitReminder = false; showThresholdEditor = true }) { Text("إعداد الحدود") } },
        dismissButton = { TextButton(onClick = { showLimitReminder = false }) { Text("لاحقاً") } }
    )
    if (showThresholdEditor) AlertDialog(
        onDismissRequest = { showThresholdEditor = false },
        title = { Text("حدود التنبيه الافتراضية", color = Emerald, fontWeight = FontWeight.Bold) },
        text = { InventoryThresholdEditorContent(onSaved = { showThresholdEditor = false }) },
        confirmButton = { TextButton(onClick = { showThresholdEditor = false }) { Text("إغلاق") } }
    )

    if (showOutboundDetails) AlertDialog(
        onDismissRequest = { showOutboundDetails = false },
        title = { Text("تفاصيل قيمة المنصرف", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("إجمالي المنصرف يشمل كل حركة خروج من المخزون، لكنه لا يعني أن جميع الحركات مصروف زراعي على موضع.", style = MaterialTheme.typography.bodySmall)
                outboundBreakdown.forEach { category ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(category.category, color = Emerald, fontWeight = FontWeight.Bold)
                            Text(formatStockValueMicros(category.valueMicros), fontWeight = FontWeight.ExtraBold)
                            Text("${category.movementCount} حركة${if (category.estimatedCount > 0) " • ${category.estimatedCount} بتكلفة تاريخية تقديرية" else ""}", style = MaterialTheme.typography.labelSmall, color = Green)
                            if (category.unresolvedCount > 0L) Text("أثر غير محسوم: ${formatStockValueMicros(category.unresolvedValueMicros)} • ${category.unresolvedCount} حركة", style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color(0xFF805719))
                        }
                    }
                }
                HorizontalDivider()
                Text("أحدث حركات الخروج", color = Emerald, fontWeight = FontWeight.Bold)
                outboundMovements.forEach { movement ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${movement.productName} • ${stockQuantity(kotlin.math.abs(movement.quantityBase), movement.baseUnit)}", fontWeight = FontWeight.SemiBold)
                        Text("${movement.operationCategory ?: movement.referenceType} • ${localDate(movement.dateMillis)} • ${formatStockValueMicros(kotlin.math.abs(movement.valueDeltaMicros))}${if (movement.estimatedValue) " (تقديري)" else ""}", style = MaterialTheme.typography.labelSmall)
                        if (!movement.plantationName.isNullOrBlank()) Text("الموضع: ${movement.plantationName}", style = MaterialTheme.typography.labelSmall, color = Green)
                    }
                    HorizontalDivider(color = Gold.copy(alpha = 0.35f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(enabled = outboundPage > 0, onClick = { outboundPage-- }) { Text("السابق") }
                    Text("صفحة ${outboundPage + 1}", style = MaterialTheme.typography.labelSmall, color = Green)
                    TextButton(enabled = outboundMovements.size == 100, onClick = { outboundPage++ }) { Text("التالي") }
                }
                Text("يعرض كل جزء 100 حركة؛ الإجماليات أعلاه محسوبة من دفتر الحركات الكامل.", style = MaterialTheme.typography.labelSmall, color = Green)
            }
        },
        confirmButton = { TextButton(onClick = { showOutboundDetails = false }) { Text("إغلاق") } }
    )

    if (detailStockItem != null) {
        val detailItem = detailStockItem!!
        AlertDialog(
            onDismissRequest = { detailStockItem = null },
            title = { Text("بطاقة الصنف: ${detailItem.productName}", color = Emerald, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(Modifier.heightIn(max = 580.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("هوية الصنف الثابتة: #${detailItem.id}", color = Green, style = MaterialTheme.typography.labelSmall)
                    Text("الكمية الحالية: ${stockQuantity(detailItem.quantityBase, detailItem.baseUnit)} • القيمة الحالية: ${formatStockValueMicros(detailItem.currentValueMicros)}", color = Emerald, fontWeight = FontWeight.Bold)
                    Text("الدفعات الواردة أدناه تعرض الكمية الأصلية لكل توريد، ولا تعني وجود رصيد مستقل متبقٍ لكل فاتورة؛ التقييم المعتمد متوسط مرجح متحرك.", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                    val inheritedThreshold = effectiveStockThreshold(detailItem.copy(lowStockThresholdBase = null), inventoryPrefs)
                    Text("حد تنبيه انخفاض المخزون (${detailItem.baseUnit})", color = Emerald, fontWeight = FontWeight.Bold)
                    Text(if (detailItem.lowStockThresholdBase == null) "الحد الحالي موروث من الإعدادات العامة: ${inheritedThreshold?.let { stockQuantity(it, detailItem.baseUnit) } ?: "غير محدد"}" else "هذا الصنف يستخدم حداً مخصصاً مستقلاً عن الحد العام.", style = MaterialTheme.typography.labelSmall, color = Green)
                    OutlinedTextField(
                        value = thresholdInput,
                        onValueChange = { thresholdInput = it.filter(Char::isDigit); thresholdError = ""; thresholdMessage = "" },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("أدخل الحد الخاص بهذا الصنف") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
                    )
                    if (thresholdError.isNotBlank()) Text(thresholdError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    if (thresholdMessage.isNotBlank()) Text(thresholdMessage, color = Green, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    Button(onClick = {
                        val parsed = thresholdInput.toLongOrNull()
                        if (thresholdInput.isBlank() || parsed == null || parsed <= 0L) thresholdError = "أدخل حداً مخصصاً أكبر من صفر. لإلغاء التخصيص واستخدام الحد العام اضغط الزر أدناه."
                        else scope.launch {
                            runCatching { dao.updateStockLowThreshold(detailItem.id, parsed) }
                                .onSuccess {
                                    detailStockItem = dao.getStockItemById(detailItem.id)
                                    thresholdMessage = "تم حفظ حد التنبيه بنجاح"
                                    thresholdError = ""
                                    keyboardController?.hide()
                                }
                                .onFailure { thresholdError = it.message ?: "تعذر حفظ حد التنبيه."; thresholdMessage = "" }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الحد المخصص") }
                    TextButton(onClick = {
                        scope.launch {
                            runCatching { dao.updateStockLowThreshold(detailItem.id, null) }
                                .onSuccess {
                                    detailStockItem = dao.getStockItemById(detailItem.id)
                                    thresholdInput = inheritedThreshold?.toString().orEmpty()
                                    thresholdMessage = "تم إلغاء الحد المخصص والعودة إلى الحد العام."
                                    thresholdError = ""
                                    keyboardController?.hide()
                                }
                                .onFailure { thresholdError = it.message ?: "تعذر إلغاء الحد المخصص."; thresholdMessage = "" }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("استخدام الحد الافتراضي") }
                    HorizontalDivider()
                    Text("دفعات الإدخال والحركات", color = Emerald, fontWeight = FontWeight.Bold)
                    if (itemHistory.isEmpty()) Text("لا توجد حركات تفصيلية متاحة لهذا الصنف.", style = MaterialTheme.typography.bodySmall)
                    itemHistory.forEach { movement ->
                        Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(9.dp)) {
                            Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                val inbound = movement.quantityBase > 0L
                                Text(if (inbound) "وارد • ${stockQuantity(movement.quantityBase, detailItem.baseUnit)}" else "${movement.referenceType} • ${stockQuantity(kotlin.math.abs(movement.quantityBase), detailItem.baseUnit)}", color = Emerald, fontWeight = FontWeight.Bold)
                                Text(localDate(movement.dateMillis), style = MaterialTheme.typography.labelSmall)
                                if (movement.referenceType == "INVOICE") {
                                    Text("المورد: ${movement.supplier.orEmpty()} • الفاتورة: ${movement.invoiceNumber.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                                    if (movement.unitPriceForeign != null && movement.lineTotalForeign != null) {
                                        Text("سعر الوحدة وقت الشراء: ${movement.unitPriceForeign} ${movement.currency.orEmpty()} لكل ${movement.packageName.orEmpty()} (${movement.packageSize ?: 0} ${movement.unit.orEmpty()}) • العدد: ${movement.packageCount ?: 0}", style = MaterialTheme.typography.labelSmall)
                                        Text("القيمة الأصلية: ${movement.lineTotalForeign} ${movement.currency.orEmpty()} • التحويل التاريخي: ${(movement.exchangeRateScaled ?: 0L) / 1000.0} • القيمة المعتمدة: ${formatStockValueMicros(movement.valueDeltaMicros)}", style = MaterialTheme.typography.labelSmall)
                                    } else {
                                        Text("القيمة المعتمدة للصنف: ${formatStockValueMicros(movement.valueDeltaMicros)} • لا تتوفر مطابقة مؤكدة لسطر الفاتورة القديم لعرض سعر وحدته.", style = MaterialTheme.typography.labelSmall)
                                    }
                                } else if (movement.referenceType == "OPENING") {
                                    Text("رصيد افتتاحي • قيمة الإدخال: ${formatStockValueMicros(movement.valueDeltaMicros)}", style = MaterialTheme.typography.bodySmall)
                                } else {
                                    Text("التكلفة: ${formatStockValueMicros(kotlin.math.abs(movement.valueDeltaMicros))}${if (movement.estimatedValue) " • تقديرية" else ""}", style = MaterialTheme.typography.bodySmall)
                                }
                                if (movement.description.isNotBlank()) Text(movement.description, style = MaterialTheme.typography.labelSmall, color = Green)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(enabled = itemHistoryPage > 0, onClick = { itemHistoryPage-- }) { Text("السابق") }
                        Text("صفحة ${itemHistoryPage + 1}", style = MaterialTheme.typography.labelSmall)
                        TextButton(enabled = itemHistory.size == 50, onClick = { itemHistoryPage++ }) { Text("التالي") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detailStockItem = null }) { Text("إغلاق") } }
        )
    }

    if (unusedStockDialogName != null) AlertDialog(
        onDismissRequest = { unusedStockDialogName = null },
        title = { Text("لا توجد استخدامات مسجلة", color = Emerald, fontWeight = FontWeight.Bold) },
        text = { Text("الصنف «$unusedStockDialogName» لم يخرج منه أي مقدار حتى الآن.") },
        confirmButton = { TextButton(onClick = { unusedStockDialogName = null }) { Text("حسنًا") } }
    )
    if (showAdd) StockOpeningDialog(if (selectedType == "الكل") "الأسمدة" else selectedType, onDismiss = { showAdd = false }) { entries ->
        scope.launch { try { dao.addOpeningStockBatch(if (selectedType == "الكل") "الأسمدة" else selectedType, entries); showAdd = false } catch (t: Throwable) { error = t.message ?: "تعذر إضافة الرصيد." } }
    }
    if (showIssue) StockIssueDialog(
        stockItems = orderedStock,
        initial = editingIssue,
        initialLines = editingIssueLines,
        onDismiss = { showIssue = false; editingIssue = null; editingIssueLines = emptyList() },
        onSave = { voucher, lines, complete ->
            scope.launch {
                runCatching { dao.saveStockIssue(voucher, lines) }
                    .onSuccess {
                        complete(true, null)
                        showIssue = false; editingIssue = null; editingIssueLines = emptyList()
                    }
                    .onFailure { complete(false, it.message ?: "تعذر حفظ سند الصرف.") }
            }
        }
    )
    if (pendingDeleteIssue != null) {
        val voucher = pendingDeleteIssue!!
        AlertDialog(
            onDismissRequest = { pendingDeleteIssue = null },
            title = { Text("تأكيد حذف سند الصرف") },
            text = { Text("سيُعاد أثر جميع كميات هذا السند إلى المخزون. هل تريد المتابعة؟") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    val deleted = runCatching { dao.deleteStockIssue(voucher.id) }.getOrDefault(false)
                    if (!deleted) error = "تعذر حذف السند لأن بيانات الرصيد غير متسقة. لم يُغيّر النظام أي كمية."
                    pendingDeleteIssue = null
                }
            }) { Text("حذف وإعادة الكميات", color = androidx.compose.ui.graphics.Color(0xFFB3261E)) } },
            dismissButton = { TextButton(onClick = { pendingDeleteIssue = null }) { Text("إلغاء") } }
        )
    }
    if (error != null) AlertDialog(onDismissRequest = { error = null }, title = { Text("تنبيه المخزون") }, text = { Text(error!!) }, confirmButton = { TextButton(onClick = { error = null }) { Text("حسنًا") } })
}

@Composable
private fun StockReviewRepairDialog(
    dao: MiyarDao,
    row: StockReviewRow,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var movements by remember(row.id) { mutableStateOf<List<StockReviewMovementRow>>(emptyList()) }
    var totalMovements by remember(row.id) { mutableStateOf(0) }
    var movementPage by remember(row.id) { mutableStateOf(0) }
    var chronologicalDeficit by remember(row.id) { mutableStateOf<Pair<StockReviewMovementRow, Long>?>(null) }
    var loading by remember(row.id) { mutableStateOf(true) }
    var loadError by remember(row.id) { mutableStateOf("") }
    var feedback by remember(row.id) { mutableStateOf("") }
    var receiptMovement by remember { mutableStateOf<StockReviewMovementRow?>(null) }
    var invoiceLines by remember { mutableStateOf<List<InvoiceItemEntity>>(emptyList()) }
    var selectedInvoiceLineId by remember { mutableLongStateOf(0L) }
    var receiptValueInput by rememberSaveable(row.id) { mutableStateOf("") }
    var receiptEvidence by rememberSaveable(row.id) { mutableStateOf("") }
    var receiptVerified by rememberSaveable(row.id) { mutableStateOf(false) }
    var countDialog by remember { mutableStateOf(false) }
    var physicalCountInput by rememberSaveable(row.id) { mutableStateOf("") }
    var addedValueInput by rememberSaveable(row.id) { mutableStateOf("") }
    var countEvidence by rememberSaveable(row.id) { mutableStateOf("") }
    var countVerified by rememberSaveable(row.id) { mutableStateOf(false) }
    var historicalDialog by remember { mutableStateOf(false) }
    var historicalQuantityInput by rememberSaveable(row.id) { mutableStateOf("") }
    var historicalValueInput by rememberSaveable(row.id) { mutableStateOf("") }
    var historicalDateMillis by rememberSaveable(row.id) { mutableLongStateOf(System.currentTimeMillis() - 86400000L) }
    var historicalEvidence by rememberSaveable(row.id) { mutableStateOf("") }
    var historicalVerified by rememberSaveable(row.id) { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    suspend fun reloadMovements(refreshDiagnostics: Boolean = true) {
        loading = true
        loadError = ""
        try {
            totalMovements = dao.countStockReviewMovements(row.id)
            movements = dao.getStockReviewMovements(row.id, 50, movementPage * 50)
            if (refreshDiagnostics) {
                // Diagnose the entire ledger, not only the visible page. The detailed UI stays
                // paginated while this lightweight entity query checks chronological balance.
                val fullLedger = dao.getStockMovementsChronological(row.id)
                var running = 0L
                var deficit: Pair<Long, Long>? = null
                for (movement in fullLedger) {
                    when {
                        movement.quantityBase > 0L -> running = Math.addExact(running, movement.quantityBase)
                        movement.quantityBase < 0L -> {
                            val outgoing = Math.negateExact(movement.quantityBase)
                            if (running < outgoing) {
                                deficit = movement.id to (outgoing - running)
                                break
                            }
                            running -= outgoing
                        }
                    }
                }
                chronologicalDeficit = deficit?.let { (id, shortage) ->
                    dao.getStockReviewMovementById(id)?.let { it to shortage }
                }
            }
        } catch (failure: Throwable) {
            loadError = failure.message ?: "تعذر تحميل حركات الصنف."
        } finally {
            loading = false
        }
    }
    LaunchedEffect(row.id) { reloadMovements(refreshDiagnostics = true) }
    LaunchedEffect(receiptMovement?.id) {
        val current = receiptMovement
        if (current != null && current.referenceType == "INVOICE") {
            val usedLineIds = movements.filter { it.id != current.id && it.referenceType == "INVOICE" }.map { it.sourceLineId }.filter { it > 0L }.toSet()
            invoiceLines = runCatching { dao.getReviewInvoiceLines(current.referenceId, row.id) }.getOrDefault(emptyList()).filter { (it.id !in usedLineIds || it.id == current.sourceLineId) && it.quantityBase == current.quantityBase }
            selectedInvoiceLineId = current.sourceLineId.takeIf { id -> invoiceLines.any { it.id == id } } ?: 0L
        } else {
            invoiceLines = emptyList()
            selectedInvoiceLineId = 0L
        }
    }

    fun movementSourceLabel(type: String): String = when (type) {
        "INVOICE" -> "فاتورة مشتريات"
        "OPENING" -> "رصيد افتتاحي"
        "CHEMICAL_LINE" -> "استخدام زراعي"
        "EXPENSE" -> "إخراج مرتبط بمصروف"
        "MANUAL_ISSUE" -> "صرف مخزني"
        "REVIEW_ADJUSTMENT" -> "تسوية جردية"
        else -> "مصدر آخر: $type"
    }
    AlertDialog(
        onDismissRequest = { if (!saving && receiptMovement == null && !countDialog && !historicalDialog) onDismiss() },
        title = { Text("تشخيص وإصلاح: ${row.productName}", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("معرّف الصنف #${row.id} • ${row.productType} • وحدة الأساس ${row.baseUnit}", fontWeight = FontWeight.SemiBold)
                Text("سبب المراجعة: ${row.valuationReviewReason.ifBlank { "لم يُسجل سبب تفصيلي؛ افحص الحركات والمصادر الظاهرة أدناه." }}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("الكمية المسجلة: ${stockQuantity(row.quantityBase, row.baseUnit)} • كمية دفتر الحركات: ${stockQuantity(row.ledgerQuantityBase, row.baseUnit)}", style = MaterialTheme.typography.bodySmall)
                Text("القيمة المسجلة: ${formatStockValueMicros(row.currentValueMicros)} • صافي الحركات: ${formatStockValueMicros(row.ledgerValueMicros)}", style = MaterialTheme.typography.bodySmall)
                Text("معنى الحالات: موثق = مربوط بمصدر محفوظ/مرجع صريح؛ تقديري = توجد قيمة معلنة لكنها تقديرية؛ يحتاج مراجعة = تعارض يمنع الاعتماد.", style = MaterialTheme.typography.labelSmall)
                HorizontalDivider()
                Text("سجل الحركات لهذا الصنف", color = Emerald, fontWeight = FontWeight.Bold)
                if (loading) Text("جارٍ تحميل الحركات...")
                if (loadError.isNotBlank()) Text(loadError, color = MaterialTheme.colorScheme.error)
                if (!loading && movements.isEmpty()) Text("لا توجد حركات محفوظة لهذا الصنف. راجع مصدر الرصيد الافتتاحي قبل إنشاء أي حركة تصحيحية.")
                movements.forEach { movement ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(9.dp)) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("حركة #${movement.id} • ${movementSourceLabel(movement.referenceType)}", color = Emerald, fontWeight = FontWeight.Bold)
                            Text("مرجع المصدر: #${movement.referenceId}", style = MaterialTheme.typography.labelSmall)
                            Text("${localDate(movement.dateMillis)} • الكمية: ${if (movement.quantityBase > 0) "+" else ""}${stockQuantity(kotlin.math.abs(movement.quantityBase), row.baseUnit)}", style = MaterialTheme.typography.bodySmall)
                            Text("القيمة: ${formatStockValueMicros(movement.valueDeltaMicros)} • ${if (movement.estimatedValue) "تقديرية" else "غير مصنفة كتقديرية"}", style = MaterialTheme.typography.bodySmall)
                            if (movement.supplier != null || movement.invoiceNumber != null) Text("المورد: ${movement.supplier.orEmpty()} • الفاتورة: ${movement.invoiceNumber.orEmpty()}", style = MaterialTheme.typography.labelSmall)
                            if (movement.sourceLineId > 0L) Text("مرتبطة ببند الفاتورة #${movement.sourceLineId}${movement.lineTotalYer?.let { " • قيمته ${formatMoney(it)}" }.orEmpty()}", style = MaterialTheme.typography.labelSmall)
                            if (movement.description.isNotBlank()) Text("الوصف: ${movement.description}", style = MaterialTheme.typography.labelSmall)
                            if (movement.valuationEvidence.isNotBlank()) Text("مرجع التوثيق: ${movement.valuationEvidence}", style = MaterialTheme.typography.labelSmall)
                            val receiptNeedsEvidence = movement.quantityBase > 0L && (
                                movement.valueDeltaMicros <= 0L || movement.estimatedValue ||
                                    (movement.referenceType == "INVOICE" && movement.sourceLineId == 0L) ||
                                    (movement.referenceType !in listOf("INVOICE", "REVIEW_ADJUSTMENT") && movement.valuationEvidence.isBlank())
                            )
                            if (receiptNeedsEvidence) {
                                OutlinedButton(onClick = {
                                    receiptValueInput = ""
                                    receiptEvidence = movement.valuationEvidence
                                    receiptVerified = false
                                    receiptMovement = movement
                                }, modifier = Modifier.fillMaxWidth()) { Text("تصحيح أو توثيق قيمة هذا الوارد") }
                            }
                        }
                    }
                }
                if (totalMovements > 50) {
                    val firstShown = movementPage * 50 + 1
                    val lastShown = minOf((movementPage + 1) * 50, totalMovements)
                    Text("عرض الحركات $firstShown–$lastShown من $totalMovements (مرتبة زمنياً)", style = MaterialTheme.typography.labelSmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(enabled = !loading && movementPage > 0, onClick = {
                            movementPage = (movementPage - 1).coerceAtLeast(0)
                            scope.launch { reloadMovements(refreshDiagnostics = false) }
                        }) { Text("الحركات الأقدم") }
                        TextButton(enabled = !loading && (movementPage + 1) * 50 < totalMovements, onClick = {
                            movementPage += 1
                            scope.launch { reloadMovements(refreshDiagnostics = false) }
                        }) { Text("الحركات الأحدث") }
                    }
                }
                movements.filter { it.quantityBase == 0L }.forEach { invalid ->
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFE8E4)), shape = RoundedCornerShape(9.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("حركة غير صالحة: #${invalid.id} — كمية صفر", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                            Text("المصدر: ${movementSourceLabel(invalid.referenceType)} رقم ${invalid.referenceId} بتاريخ ${localDate(invalid.dateMillis)}. الحركة الصفرية لا يمكن تقييمها كوارد أو صرف.", style = MaterialTheme.typography.bodySmall)
                            val sourceCorrection = when (invalid.referenceType) {
                                "INVOICE" -> "افتح الفاتورة الأصلية وصحح كمية بند الصنف، ثم ارجع إلى مركز المراجعة وأعد الفحص."
                                "MANUAL_ISSUE" -> "افتح سند الصرف المخزني رقم ${invalid.referenceId} وصحح كمية السطر أو احذف السند من شاشة السندات بعد التأكد من صحته."
                                "CHEMICAL_LINE", "EXPENSE" -> "افتح المصروف/عملية الاستخدام المرتبطة بالمرجع رقم ${invalid.referenceId} وصحح كمية الصرف من مصدرها."
                                else -> "راجع مصدر الحركة رقم ${invalid.referenceId} قبل إجراء أي تسوية؛ لا تدخل كمية تخمينية لمجرد إزالة التنبيه."
                            }
                            Text("طريقة المعالجة: $sourceCorrection", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                chronologicalDeficit?.let { (shortageMovement, minimumMissing) ->
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFE8E4)), shape = RoundedCornerShape(9.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("خلل زمني محدد في الحركة #${shortageMovement.id}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                            Text("في ${localDate(shortageMovement.dateMillis)} سُجل صرف ${stockQuantity(kotlin.math.abs(shortageMovement.quantityBase), row.baseUnit)} بينما المتاح قبله لا يكفي. الحد الأدنى للوارد التاريخي الناقص: ${stockQuantity(minimumMissing, row.baseUnit)}.", style = MaterialTheme.typography.bodySmall)
                            Text("إذا كان هناك وارد حقيقي لم يُسجل قبل هذا الصرف، أدخله من مستنده الأصلي وتاريخه. سيضيف التطبيق حركة تاريخية مستقلة قبل حركة الصرف ويعيد تقييم كل الحركات اللاحقة.", style = MaterialTheme.typography.labelSmall)
                            OutlinedButton(onClick = {
                                historicalQuantityInput = minimumMissing.toString()
                                historicalValueInput = ""
                                historicalDateMillis = (shortageMovement.dateMillis - 86400000L).coerceAtLeast(0L)
                                historicalEvidence = ""
                                historicalVerified = false
                                historicalDialog = true
                            }, modifier = Modifier.fillMaxWidth()) { Text("إضافة الوارد التاريخي المفقود") }
                        }
                    }
                }
                HorizontalDivider()
                Text("معالجة اختلاف الكمية", color = Emerald, fontWeight = FontWeight.Bold)
                Text("إذا اختلف دفتر الحركات عن الكمية الموجودة فعلياً، عدّ الصنف بنفسك ثم أدخل الكمية الفعلية بوحدة الأساس (${row.baseUnit}). سيضيف النظام حركة تسوية جديدة ولا يحذف أي حركة قديمة. النقص يقيّم بمتوسط التكلفة الحالي، والزيادة تحتاج قيمة معلنة.", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { physicalCountInput = ""; addedValueInput = ""; countEvidence = ""; countVerified = false; countDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("إدخال الجرد الفعلي وتسوية الفرق")
                }
                if (feedback.isNotBlank()) Text(feedback, color = if (feedback.contains("تم") && !feedback.contains("ما زال") && !feedback.contains("تعذر")) Green else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("لا يتم تغيير الرصيد لمجرد إخفاء التنبيه. كل إصلاح يسجل القيم قبل وبعد، وسببه، ومرجعه في سجل مِعيار.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(enabled = !saving && receiptMovement == null && !countDialog && !historicalDialog, onClick = onDismiss) { Text("إغلاق") } }
    )

    val activeReceipt = receiptMovement
    if (activeReceipt != null) {
        AlertDialog(
            onDismissRequest = { if (!saving) receiptMovement = null },
            title = { Text("تصحيح قيمة الوارد • حركة #${activeReceipt.id}", color = Emerald, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الكمية: ${stockQuantity(activeReceipt.quantityBase, row.baseUnit)} • المصدر: ${movementSourceLabel(activeReceipt.referenceType)}", style = MaterialTheme.typography.bodySmall)
                    if (activeReceipt.referenceType == "INVOICE" && invoiceLines.isNotEmpty()) {
                        Text("اختر بند الفاتورة المطابق لهذه الحركة. يجب أن تتطابق الكمية، وسيأخذ النظام قيمة البند الأصلية ويحفظ الرابط بمعرّفه دون تكرار احتساب البند.", style = MaterialTheme.typography.bodySmall)
                        invoiceLines.forEach { line ->
                            FilterChip(
                                selected = selectedInvoiceLineId == line.id,
                                onClick = {
                                    selectedInvoiceLineId = if (selectedInvoiceLineId == line.id) 0L else line.id
                                    if (selectedInvoiceLineId == line.id) receiptValueInput = line.lineTotalYer.toString()
                                },
                                label = { Text("بند #${line.id} • ${line.packageCount} × ${line.packageSize} ${line.unit} • ${formatMoney(line.lineTotalYer)}") }
                            )
                        }
                    }
                    if (selectedInvoiceLineId == 0L && activeReceipt.referenceType == "INVOICE" && invoiceLines.isEmpty()) {
                        Text("لم يُعثر على بند فاتورة غير مرتبط يطابق كمية الحركة. افتح الفاتورة الأصلية وصحح بند الصنف/الكمية ثم ارجع وأعد الفحص. لا يسمح النظام بإدخال قيمة يدوية قد تفصل الحركة عن مصدر فاتورتها.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    if (selectedInvoiceLineId == 0L && activeReceipt.referenceType != "INVOICE") {
                        OutlinedTextField(
                            value = receiptValueInput,
                            onValueChange = { receiptValueInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("قيمة الوارد الصحيحة بالريال اليمني") },
                            supportingText = { Text("أدخل القيمة من مستند الشراء أو الرصيد الافتتاحي، لا تخمّنها.") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                    if (selectedInvoiceLineId > 0L) {
                        Text("القيمة المعتمدة من بند الفاتورة المحدد: ${formatMoney(invoiceLines.firstOrNull { it.id == selectedInvoiceLineId }?.lineTotalYer ?: 0L)}", color = Green, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(
                        value = receiptEvidence,
                        onValueChange = { receiptEvidence = it },
                        label = { Text("مرجع المستند / سبب التصحيح") },
                        supportingText = { Text("مثال: فاتورة المورد رقم ...، أو مستند الرصيد الافتتاحي بتاريخ ...") },
                        minLines = 2
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = receiptVerified, onCheckedChange = { receiptVerified = it })
                        Text("أؤكد أن المبلغ مستند إلى مرجع محفوظ ويمكن تتبعه")
                    }
                    if (!receiptVerified) Text("سيظل التقييم تقديرياً حتى توثيق المصدر.", color = androidx.compose.ui.graphics.Color(0xFF805719), style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                TextButton(enabled = !saving && receiptEvidence.isNotBlank() && (selectedInvoiceLineId > 0L || (activeReceipt.referenceType != "INVOICE" && receiptValueInput.isNotBlank())), onClick = {
                    saving = true
                    scope.launch {
                        try {
                            val value = digits(receiptValueInput)
                            val ok = dao.repairStockReceiptValuation(
                                stockItemId = row.id,
                                movementId = activeReceipt.id,
                                receiptValueYer = value,
                                evidence = receiptEvidence,
                                markVerified = receiptVerified,
                                invoiceLineId = selectedInvoiceLineId.takeIf { it > 0L }
                            )
                            val current = dao.getStockItemById(row.id)
                            feedback = when {
                                ok && current?.valuationStatus == "VERIFIED" -> "تم التصحيح وأصبح الصنف موثقاً بعد مطابقة سجل الحركات."
                                ok && current?.valuationStatus == "ESTIMATED" -> "تم التصحيح، لكن التقييم بقي تقديرياً لأن بعض مصادره تقديرية."
                                else -> "تم حفظ توثيق الوارد، لكن ما زال خلل آخر يحتاج معالجة: ${current?.valuationReviewReason.orEmpty()}"
                            }
                            receiptMovement = null
                            reloadMovements(refreshDiagnostics = true)
                        } catch (failure: Throwable) {
                            feedback = "تعذر حفظ التصحيح: ${failure.message ?: "خطأ غير معروف"}"
                        } finally { saving = false }
                    }
                }) { Text(if (saving) "جارٍ الحفظ" else "حفظ التصحيح وإعادة التقييم") }
            },
            dismissButton = { TextButton(enabled = !saving, onClick = { receiptMovement = null }) { Text("إلغاء") } }
        )
    }

    if (historicalDialog && chronologicalDeficit != null) {
        val (shortageMovement, minimumMissing) = chronologicalDeficit!!
        AlertDialog(
            onDismissRequest = { if (!saving) historicalDialog = false },
            title = { Text("إضافة وارد تاريخي موثق", color = Emerald, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الحركة التي ظهر عندها العجز: #${shortageMovement.id} بتاريخ ${localDate(shortageMovement.dateMillis)} • العجز الأدنى ${stockQuantity(minimumMissing, row.baseUnit)}.", style = MaterialTheme.typography.bodySmall)
                    MiyarDateField("تاريخ الوارد الحقيقي (يجب أن يسبق حركة الصرف)", historicalDateMillis) { historicalDateMillis = it }
                    OutlinedTextField(historicalQuantityInput, { historicalQuantityInput = it.filter(Char::isDigit) }, label = { Text("كمية الوارد التاريخي (${row.baseUnit})") }, supportingText = { Text("لا تقل عن العجز الأدنى، وأدخل الكمية الحقيقية من المستند.") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(historicalValueInput, { historicalValueInput = it.filter(Char::isDigit) }, label = { Text("قيمة هذا الوارد بالريال اليمني") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(historicalEvidence, { historicalEvidence = it }, label = { Text("مرجع المستند التاريخي") }, minLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = historicalVerified, onCheckedChange = { historicalVerified = it })
                        Text("أؤكد أن الكمية والقيمة والتاريخ مثبتة بمصدر يمكن الرجوع إليه")
                    }
                    if (!historicalVerified) Text("ستضاف الحركة كتقديرية، ولن يصبح التقييم موثقاً حتى يقدم مصدر موثق.", color = androidx.compose.ui.graphics.Color(0xFF805719), style = MaterialTheme.typography.labelSmall)
                    Text("لن تتغير حركة الصرف القديمة أو تُحذف. ستضاف حركة وارد تصحيحية جديدة ويسجل سببها في سجل مِعيار.", style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                TextButton(enabled = !saving && historicalQuantityInput.isNotBlank() && historicalValueInput.isNotBlank() && historicalEvidence.isNotBlank(), onClick = {
                    saving = true
                    scope.launch {
                        try {
                            val ok = dao.addDocumentedHistoricalReceipt(
                                stockItemId = row.id,
                                quantityBase = digits(historicalQuantityInput),
                                valueYer = digits(historicalValueInput),
                                receiptDateMillis = historicalDateMillis,
                                evidence = historicalEvidence,
                                markVerified = historicalVerified
                            )
                            val current = dao.getStockItemById(row.id)
                            feedback = when {
                                ok && current?.valuationStatus == "VERIFIED" -> "تمت إضافة الوارد التاريخي وإعادة تقييم الحركات؛ أصبح الصنف موثقاً."
                                ok && current?.valuationStatus == "ESTIMATED" -> "تمت إضافة الوارد، لكن بقي التقييم تقديرياً حسب مصدر القيمة."
                                else -> "تم حفظ الوارد التاريخي، لكن ما زال تعارض آخر يحتاج معالجة: ${current?.valuationReviewReason.orEmpty()} وقد تحتاج إلى إدخال الجرد الفعلي الحالي بعد تصحيح السبب التاريخي."
                            }
                            historicalDialog = false
                            reloadMovements(refreshDiagnostics = true)
                        } catch (failure: Throwable) {
                            feedback = "تعذر إضافة الوارد التاريخي: ${failure.message ?: "خطأ غير معروف"}"
                        } finally { saving = false }
                    }
                }) { Text(if (saving) "جارٍ الحفظ" else "إضافة الوارد وإعادة التقييم") }
            },
            dismissButton = { TextButton(enabled = !saving, onClick = { historicalDialog = false }) { Text("إلغاء") } }
        )
    }

    if (countDialog) {
        AlertDialog(
            onDismissRequest = { if (!saving) countDialog = false },
            title = { Text("تسوية الجرد الفعلي • ${row.productName}", color = Emerald, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("دفتر الحركات يستنتج ${stockQuantity(row.ledgerQuantityBase, row.baseUnit)} بينما كمية الصنف المسجلة ${stockQuantity(row.quantityBase, row.baseUnit)}. أدخل الكمية التي عددتها فعلياً الآن.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(physicalCountInput, { physicalCountInput = it.filter(Char::isDigit) }, label = { Text("الكمية الفعلية (${row.baseUnit})") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(addedValueInput, { addedValueInput = it.filter(Char::isDigit) }, label = { Text("قيمة الزيادة بالريال اليمني (عند وجود زيادة فقط)") }, supportingText = { Text("إذا كانت الكمية الفعلية أكبر من دفتر الحركات، أدخل قيمة الكمية الزائدة من مستند أو تقدير معلن. النقص يحسب بمتوسط التكلفة المتحرك.") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(countEvidence, { countEvidence = it }, label = { Text("سبب الجرد / مرجع الإثبات") }, minLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = countVerified, onCheckedChange = { countVerified = it })
                        Text("أؤكد أن الجرد والقيمة يستندان إلى بيانات موثوقة")
                    }
                    if (!countVerified) Text("ستكون قيمة التسوية تقديرية، ولن يتحول الصنف إلى موثق إلا بعد استكمال مصدر موثق.", color = androidx.compose.ui.graphics.Color(0xFF805719), style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                TextButton(enabled = !saving && physicalCountInput.isNotBlank() && countEvidence.isNotBlank(), onClick = {
                    saving = true
                    scope.launch {
                        try {
                            val ok = dao.reconcileStockItemPhysicalCount(
                                stockItemId = row.id,
                                physicalCountBase = digits(physicalCountInput),
                                addedValueYer = digits(addedValueInput),
                                evidence = countEvidence,
                                markVerified = countVerified
                            )
                            val current = dao.getStockItemById(row.id)
                            feedback = when {
                                ok && current?.valuationStatus == "VERIFIED" -> "تم تسجيل تسوية الجرد وأصبح الصنف موثقاً؛ الحركات القديمة محفوظة والتسوية مضافة كسجل مستقل."
                                ok && current?.valuationStatus == "ESTIMATED" -> "تم تسجيل التسوية، لكن قيمة الصنف ما زالت تقديرية بسبب وجود مصدر تقديري سابق."
                                else -> "تم حفظ أثر الجرد، لكن بقي تعارض يحتاج معالجة: ${current?.valuationReviewReason.orEmpty()}"
                            }
                            countDialog = false
                            reloadMovements(refreshDiagnostics = true)
                        } catch (failure: Throwable) {
                            feedback = "تعذر اعتماد الجرد: ${failure.message ?: "خطأ غير معروف"}"
                        } finally { saving = false }
                    }
                }) { Text(if (saving) "جارٍ الحفظ" else "اعتماد الجرد وإعادة التقييم") }
            },
            dismissButton = { TextButton(enabled = !saving, onClick = { countDialog = false }) { Text("إلغاء") } }
        )
    }
}

private data class StockIssueRowUi(
    val stockItemId: Long? = null,
    val quantity: String = "",
    val unit: String = ""
)

@Composable
private fun StockIssueDialog(
    stockItems: List<StockItemEntity>,
    initial: StockIssueVoucherEntity?,
    initialLines: List<StockIssueLineEntity>,
    onDismiss: () -> Unit,
    onSave: (StockIssueVoucherEntity, List<StockIssueLineInput>, (Boolean, String?) -> Unit) -> Unit
) {
    var dateMillis by rememberSaveable(initial?.id) { mutableLongStateOf(initial?.dateMillis ?: System.currentTimeMillis()) }
    var reason by rememberSaveable(initial?.id) { mutableStateOf(initial?.reason ?: "صرف سابق قبل استخدام مِعيار") }
    var notes by rememberSaveable(initial?.id) { mutableStateOf(initial?.notes.orEmpty()) }
    var error by rememberSaveable(initial?.id) { mutableStateOf("") }
    var saving by rememberSaveable(initial?.id) { mutableStateOf(false) }
    val rows = remember(initial?.id, stockItems, initialLines) {
        androidx.compose.runtime.mutableStateListOf<StockIssueRowUi>().apply {
            if (initialLines.isNotEmpty()) initialLines.forEach { add(StockIssueRowUi(it.stockItemId, it.enteredQuantity.toString(), it.unit)) }
            else add(StockIssueRowUi())
        }
    }
    var stockMenuIndex by remember { mutableIntStateOf(-1) }
    var unitMenuIndex by remember { mutableIntStateOf(-1) }
    val inputs = rows.mapNotNull { row ->
        val selected = row.stockItemId?.let { id -> stockItems.firstOrNull { it.id == id } }
        val entered = row.quantity.toLongOrNull() ?: 0L
        if (selected == null || entered <= 0L) null else runCatching {
            StockIssueLineInput(selected.id, row.unit, entered, FinanceCalculations.quantityToBase(entered, row.unit))
        }.getOrNull()
    }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(if (initial == null) "سند صرف مخزني جديد" else "تعديل سند الصرف رقم ${initial.id}", color = Emerald, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3D9)), shape = RoundedCornerShape(10.dp)) {
                    Text("توضيح: هذا السند مخصص لكمية سبق إدخالها إلى المخزون ثم خرجت فعليًا ولم تُسجل داخل مِعيار من خلال عملية زراعية أو حركة مخزنية أخرى. سيخصم النظام الكمية وتكلفتها من رصيد المخزون دون تسجيل مصروف على أي موضع.", modifier = Modifier.padding(11.dp), color = androidx.compose.ui.graphics.Color(0xFF805719), style = MaterialTheme.typography.bodySmall)
                }
                MiyarDateField("تاريخ الصرف", dateMillis) { dateMillis = it }
                OutlinedTextField(reason, { reason = it }, label = { Text("بيان الصرف / سبب الخروج") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات إضافية (اختياري)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text("أصناف السند", color = Emerald, fontWeight = FontWeight.Bold)
                rows.forEachIndexed { index, row ->
                    val selected = row.stockItemId?.let { id -> stockItems.firstOrNull { it.id == id } }
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الصنف ${index + 1}", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (rows.size > 1) IconButton(onClick = { rows.removeAt(index) }) { Icon(Icons.Default.Delete, contentDescription = "حذف السطر", tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) }
                            }
                            Box {
                                OutlinedButton(onClick = { stockMenuIndex = index }, modifier = Modifier.fillMaxWidth()) {
                                    Text(selected?.let { "${it.productName} • ${it.treatmentType}" } ?: "اختر صنفًا من المخزون", modifier = Modifier.weight(1f), maxLines = 1)
                                    Icon(Icons.Default.ArrowDropDown, null)
                                }
                                DropdownMenu(expanded = stockMenuIndex == index, onDismissRequest = { stockMenuIndex = -1 }) {
                                    stockItems.filter { it.baseUnit == "g" || it.baseUnit == "ml" }.forEach { item ->
                                        DropdownMenuItem(text = { Text("${item.productName} • ${item.treatmentType} (${stockQuantity(item.quantityBase, item.baseUnit)})") }, onClick = {
                                            val defaultUnit = when (item.baseUnit) { "g" -> "كجم"; "ml" -> "لتر"; else -> "" }
                                            rows[index] = row.copy(stockItemId = item.id, quantity = "", unit = defaultUnit)
                                            stockMenuIndex = -1
                                        })
                                    }
                                }
                            }
                            if (selected != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(row.quantity, { rows[index] = row.copy(quantity = it.filter(Char::isDigit)) }, label = { Text("الكمية") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    Box {
                                        OutlinedButton(onClick = { unitMenuIndex = index }, enabled = selected.baseUnit == "g" || selected.baseUnit == "ml") { Text(row.unit.ifBlank { when (selected.baseUnit) { "g" -> "كجم"; "ml" -> "لتر"; else -> "وحدة غير معتمدة" } }); Icon(Icons.Default.ArrowDropDown, null) }
                                        DropdownMenu(expanded = unitMenuIndex == index, onDismissRequest = { unitMenuIndex = -1 }) {
                                            (when (selected.baseUnit) { "g" -> listOf("كجم", "جرام"); "ml" -> listOf("لتر", "ملي"); else -> emptyList() }).forEach { unit ->
                                                DropdownMenuItem(text = { Text(unit) }, onClick = { rows[index] = row.copy(unit = unit); unitMenuIndex = -1 })
                                            }
                                        }
                                    }
                                }
                                val entered = row.quantity.toLongOrNull() ?: 0L
                                val base = runCatching { FinanceCalculations.quantityToBase(entered, row.unit) }.getOrDefault(0L)
                                val remaining = selected.quantityBase
                                Text("المتاح: ${stockQuantity(remaining, selected.baseUnit)} • المطلوب: ${if (base > 0L) stockQuantity(base, selected.baseUnit) else "—"}", color = if (base > remaining) androidx.compose.ui.graphics.Color(0xFFB3261E) else Green, style = MaterialTheme.typography.labelSmall)
                                val estimatedCost = if (base > 0L && remaining > 0L && selected.valuationStatus != "REVIEW_REQUIRED") runCatching { FinanceCalculations.movingAverageIssueCostMicros(selected.currentValueMicros, remaining, base) }.getOrNull() else null
                                Text("التكلفة المتوقعة وفق المتوسط الحالي: ${estimatedCost?.let(::formatStockValueMicros) ?: if (selected.valuationStatus == "REVIEW_REQUIRED") "تحتاج مراجعة التقييم" else "—"}", style = MaterialTheme.typography.labelSmall, color = Emerald)
                            }
                        }
                    }
                }
                val previewByStock = inputs.groupBy { it.stockItemId }.mapNotNull { (stockId, linesForStock) ->
                    val item = stockItems.firstOrNull { it.id == stockId } ?: return@mapNotNull null
                    val quantity = runCatching { FinanceCalculations.sumExact(linesForStock.map { it.quantityBase }) }.getOrDefault(Long.MAX_VALUE)
                    item to quantity
                }
                if (previewByStock.isNotEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFF3E8)), shape = RoundedCornerShape(11.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("مراجعة الرصيد بعد الصرف", color = androidx.compose.ui.graphics.Color(0xFF8B5528), fontWeight = FontWeight.Bold)
                            previewByStock.forEach { (item, issueQuantity) ->
                                val enough = item.quantityBase >= issueQuantity
                                val after = if (enough) item.quantityBase - issueQuantity else 0L
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(item.productName, color = Emerald, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                    Text("قبل: ${stockQuantity(item.quantityBase, item.baseUnit)} • صرف: ${stockQuantity(issueQuantity, item.baseUnit)}", style = MaterialTheme.typography.labelSmall)
                                    Text(if (enough) "بعد الصرف: ${stockQuantity(after, item.baseUnit)}" else "غير كافٍ — المتاح ${stockQuantity(item.quantityBase, item.baseUnit)} فقط", color = if (enough) Green else androidx.compose.ui.graphics.Color(0xFFB3261E), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                                if (previewByStock.last().first.id != item.id) HorizontalDivider(color = androidx.compose.ui.graphics.Color(0xFFD9C8B8))
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { rows.add(StockIssueRowUi()) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("إضافة صنف آخر للسند") }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { Button(enabled = !saving, onClick = {
            val valid = rows.size == inputs.size && rows.isNotEmpty() && reason.isNotBlank() && rows.all { it.stockItemId != null && (it.quantity.toLongOrNull() ?: 0L) > 0L }
            if (!valid) error = "أكمل اختيار جميع الأصناف وأدخل كميات صحيحة وسبب الصرف."
            else {
                saving = true
                onSave(StockIssueVoucherEntity(id = initial?.id ?: 0L, dateMillis = dateMillis, reason = reason.trim(), notes = notes.trim(), createdAtMillis = initial?.createdAtMillis ?: System.currentTimeMillis()), inputs) { success, message ->
                    saving = false
                    if (!success) error = message ?: "تعذر حفظ سند الصرف."
                }
            }
        }) { Text(if (saving) "جارٍ الحفظ..." else "حفظ سند الصرف") } },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun StockValueCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier, tint: androidx.compose.ui.graphics.Color, onClick: (() -> Unit)? = null) {
    Card(modifier = if (onClick != null) modifier.clickable(onClick = onClick) else modifier, colors = CardDefaults.cardColors(containerColor = tint), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
            Text(value, color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall, maxLines = 2)
            Text(subtitle, color = Green, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SummaryMiniCard(title: String, value: String, modifier: Modifier = Modifier, tint: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White, onClick: (() -> Unit)? = null) {
    Card(if (onClick != null) modifier.clickable(onClick = onClick) else modifier, colors = CardDefaults.cardColors(containerColor = tint)) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Green)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
    }
}

private data class OpeningStockRowUi(
    val name: String = "",
    val ingredient: String = "",
    val unit: String,
    val quantity: String = "",
    val treatment: String,
    val cost: String = ""
)

@Composable
private fun StockOpeningDialog(type: String, onDismiss: () -> Unit, onSave: (List<OpeningStockInput>) -> Unit) {
    val defaultUnit = if (type == "الأسمدة") "كجم" else "لتر"
    val defaultTreatment = if (type == "الأسمدة") "عام" else "حشري"
    val rows = remember(type) { androidx.compose.runtime.mutableStateListOf(OpeningStockRowUi(unit = defaultUnit, treatment = defaultTreatment)) }
    var error by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة رصيد افتتاحي: $type") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("أدخل الكمية وقيمتها الإجمالية للصنف. يمكنك إضافة أكثر من صنف في الحفظ نفسه. إذا لم تعرف قيمة الصنف، اترك القيمة صفرًا وأدخل تكلفة الاستخدام يدويًا عند تسجيل العملية.", style = MaterialTheme.typography.bodySmall)
                rows.forEachIndexed { index, row ->
                    Card(colors = CardDefaults.cardColors(containerColor = Cream), shape = RoundedCornerShape(13.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الصنف ${index + 1}", modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.Bold)
                                if (rows.size > 1) IconButton(onClick = { rows.removeAt(index) }) { Icon(Icons.Default.Delete, contentDescription = "حذف الصنف", tint = androidx.compose.ui.graphics.Color(0xFFB3261E)) }
                            }
                            OutlinedTextField(row.name, { rows[index] = row.copy(name = it) }, label = { Text("اسم الصنف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(row.ingredient, { rows[index] = row.copy(ingredient = it) }, label = { Text("المادة الفعالة / العنصر") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                (if (type == "الأسمدة") listOf("عام", "نمو", "تجذير", "ورقي") else listOf("حشري", "فطري", "ورقي", "جذري")).forEach { item ->
                                    FilterChip(selected = row.treatment == item, onClick = { rows[index] = row.copy(treatment = item) }, label = { Text(item) })
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                listOf("كجم", "لتر", "جرام", "ملي").forEach { item -> FilterChip(selected = row.unit == item, onClick = { rows[index] = row.copy(unit = item) }, label = { Text(item) }) }
                            }
                            OutlinedTextField(row.quantity, { rows[index] = row.copy(quantity = latinDigitsOnly(it)) }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                            MiyarMoneyInputField(row.cost, { rows[index] = row.copy(cost = it) }, label = "القيمة الإجمالية لهذا الرصيد (ر.ي)", modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                OutlinedButton(onClick = { rows.add(OpeningStockRowUi(unit = defaultUnit, treatment = defaultTreatment)); error = "" }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Text("إضافة صنف آخر")
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = {
            val valid = rows.mapNotNull { row ->
                val base = row.quantity.toLongOrNull()?.let { runCatching { FinanceCalculations.quantityToBase(it, row.unit) }.getOrNull() } ?: 0L
                val cost = moneyToLong(row.cost)
                if (row.name.isBlank() || base <= 0L || cost < 0L) null
                else OpeningStockInput(row.name.trim(), row.ingredient.trim(), row.unit, base, row.treatment, cost)
            }
            if (valid.size != rows.size) error = "تحقق من اسم كل صنف وكميته وقيمته قبل الحفظ."
            else onSave(valid)
        }) { Text("حفظ الأرصدة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun MiyarReportsScreen(
    dao: MiyarDao,
    modifier: Modifier = Modifier,
    onExportReport: (type: String, fromMillis: Long, untilMillis: Long, plantationId: Long?) -> Unit = { _, _, _, _ -> }
) {
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val today = remember { System.currentTimeMillis() }
    val cal = remember { java.util.Calendar.getInstance().apply { timeInMillis = today; set(java.util.Calendar.DAY_OF_MONTH, 1); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) } }
    var from by rememberSaveable { mutableLongStateOf(cal.timeInMillis) }
    var to by rememberSaveable { mutableLongStateOf(today) }
    var selectedPlantationId by rememberSaveable { mutableStateOf<Long?>(null) }
    val endExclusive = remember(to) {
        java.util.Calendar.getInstance().apply { timeInMillis = to; add(java.util.Calendar.DAY_OF_YEAR, 1); set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
    }
    val summary by dao.observeReportSummary(from, endExclusive, selectedPlantationId).collectAsStateWithLifecycle(
        initialValue = ReportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0)
    )
    val reportRows = remember { androidx.compose.runtime.mutableStateListOf<ExpenseWithPlantation>() }
    val reportScope = rememberCoroutineScope()
    var loadedPage by rememberSaveable { mutableIntStateOf(0) }
    var loadingPage by remember { mutableStateOf(false) }
    var hasMore by remember { mutableStateOf(true) }
    LaunchedEffect(from, endExclusive, selectedPlantationId) {
        reportRows.clear()
        loadedPage = 0
        hasMore = true
        loadingPage = true
        runCatching { dao.getReportExpensePage(from, endExclusive, selectedPlantationId, 50, 0) }
            .onSuccess { reportRows.addAll(it); loadedPage = 1; hasMore = it.size == 50 }
        loadingPage = false
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("التقارير وكشوف الحسابات", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold)
        Text("اختر الفترة والموضع، ثم صدّر التقرير المطلوب بصيغة PDF بهوية مِعيار.", style = MaterialTheme.typography.bodySmall)
        MiyarDateField("من تاريخ", from) { from = it }
        MiyarDateField("إلى تاريخ", to) { to = it }
        Text("تصفية الموضع", color = Emerald, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = selectedPlantationId == null, onClick = { selectedPlantationId = null }, label = { Text("كل المواضع") })
            plantations.forEach { plot ->
                FilterChip(selected = selectedPlantationId == plot.id, onClick = { selectedPlantationId = plot.id }, label = { Text(plot.name) })
            }
        }
        FinancialCard("💸 إجمالي الخرج", formatMoney(summary.expenseTotal), "${summary.expenseCount} عملية خلال الفترة")
        FinancialCard("💰 إجمالي المردود", formatMoney(summary.harvestTotal), "القطفات المسجلة في دفتر العمليات")
        FinancialCard("🧺 تكاليف القطاف", formatMoney(summary.harvestCostTotal), "أجور ومصاريف القطاف من سجلات الأيام")
        FinancialCard("🧾 قيمة الفواتير بالريال اليمني", formatMoney(summary.invoiceTotal), "قيمة الفواتير في الفترة")
        FinancialCard("📊 صافي الفرق", formatMoney(summary.harvestTotal - summary.expenseTotal), "المردود المسجل ناقص المصروفات المسجلة")
        Text("ملخص الأنشطة", color = Emerald, fontWeight = FontWeight.Bold)
        listOf(
            "السموم والأسمدة" to summary.chemicalTotal,
            "المياه والري" to summary.waterTotal,
            "الأعمال اليدوية" to summary.laborTotal,
            "تكاليف القطاف" to summary.harvestCostTotal,
            "أخرى" to summary.otherTotal
        ).forEach { (label, total) ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.SemiBold)
                    Text(formatMoney(total), color = Emerald, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text("تصدير التقارير وكشوف الحساب بصيغة PDF", color = Emerald, fontWeight = FontWeight.Bold)
        val pdfReports = listOf(
            "كشف حساب الموضع الزراعي" to "plantation",
            "تقرير الأنشطة الزراعية بالتفصيل" to "activities",
            "كشف العملاء والمشترين والبائعين" to "buyers",
            "كشف التجار والموردين" to "suppliers",
            "الفواتير وتفاصيل الأصناف" to "invoices",
            "التقرير المالي والإنتاجي" to "financial"
        )
        pdfReports.forEach { (label, type) ->
            OutlinedButton(
                onClick = { onExportReport(type, from, endExclusive, selectedPlantationId) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("📄 $label — PDF") }
        }
        Text("سجل العمليات — عرض تدريجي", color = Emerald, fontWeight = FontWeight.Bold)
        Text("يتم تحميل 50 سجلًا في كل مرة لتقليل استهلاك الذاكرة.", style = MaterialTheme.typography.bodySmall)
        reportRows.forEach { record ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(record.title, fontWeight = FontWeight.SemiBold)
                        Text("${record.plantationName} • ${record.category} • ${localDate(record.dateMillis)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text(formatMoney(record.amount), fontWeight = FontWeight.Bold)
                }
            }
        }
        if ((loadedPage > 1 || hasMore) && !loadingPage) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (loadedPage > 1) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    loadingPage = true
                    reportScope.launch {
                        runCatching { dao.getReportExpensePage(from, endExclusive, selectedPlantationId, 50, (loadedPage - 2) * 50) }
                            .onSuccess { reportRows.clear(); reportRows.addAll(it); loadedPage--; hasMore = true }
                        loadingPage = false
                    }
                }) { Text("السابق") }
                if (hasMore) OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    loadingPage = true
                    reportScope.launch {
                        runCatching { dao.getReportExpensePage(from, endExclusive, selectedPlantationId, 50, loadedPage * 50) }
                            .onSuccess { reportRows.clear(); reportRows.addAll(it); loadedPage++; hasMore = it.size == 50 }
                        loadingPage = false
                    }
                }) { Text("التالي — 50 عملية") }
            }
        }
        if (loadingPage) Text("جارٍ تحميل السجلات…", color = Green)
        if (reportRows.isEmpty() && !loadingPage) Text("لا توجد عمليات مسجلة في الفترة المحددة.", color = Green)
    }
}


private data class ReminderFeedEntry(
    val key: String,
    val dateMillis: Long,
    val title: String,
    val category: String,
    val place: String,
    val detail: String = ""
)

private data class SmartFollowUpSuggestion(
    val key: String,
    val category: String,
    val title: String,
    val plantationName: String,
    val dateMillis: Long,
    val description: String
)

@Composable
fun MiyarRemindersScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val reminders by dao.observeOperationReminders().collectAsStateWithLifecycle(initialValue = emptyList())
    val allReminderRecords by dao.observeAllOperationReminders().collectAsStateWithLifecycle(initialValue = emptyList())
    val personalHarvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(initialValue = emptyList())
    val buyerSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(initialValue = emptyList())
    val buyers by dao.observeBuyers().collectAsStateWithLifecycle(initialValue = emptyList())
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val expenses by dao.observeAllExpenses().collectAsStateWithLifecycle(initialValue = emptyList())
    val reminderContext = LocalContext.current

    LaunchedEffect(personalHarvests, buyerSales, buyers) {
        val nowAtScheduling = System.currentTimeMillis()
        personalHarvests.filter { it.actualEndMillis == 0L && it.expectedEndMillis > nowAtScheduling }.forEach { harvest ->
            val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(harvest.expectedEndMillis))
            ReminderScheduler.schedule(reminderContext, harvest.id, "انتهاء القطفة ${harvest.name}", "القطفات", "موضع القطفة", date, "09:00", "PERSONAL_HARVEST")
        }
        buyerSales.filter { it.actualEndMillis == 0L && it.expectedEndMillis > nowAtScheduling }.forEach { sale ->
            val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(sale.expectedEndMillis))
            val buyerName = buyers.firstOrNull { it.id == sale.buyerId }?.name ?: "المشتري"
            ReminderScheduler.schedule(reminderContext, sale.id, "موعد انتهاء قطفة البيع ${sale.harvestName}", "القطفات", buyerName, date, "09:00", "BUYER_HARVEST")
        }
    }

    var showSoon by rememberSaveable { mutableStateOf(false) }
    var showOverdue by rememberSaveable { mutableStateOf(false) }
    var showHarvestSoon by rememberSaveable { mutableStateOf(false) }
    var showHarvestOverdue by rememberSaveable { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val threeDays = now + 3L * 24L * 60L * 60L * 1000L
    val allHarvestReminderKeys = allReminderRecords
        .filter { it.referenceType == "PERSONAL_HARVEST" || it.referenceType == "BUYER_HARVEST" }
        .map { "${it.referenceType}:${it.referenceId}" }.toSet()

    val overdueReminderItems = reminders
        .filter { it.scheduledAtMillis < now && it.referenceType != "PERSONAL_HARVEST" && it.referenceType != "BUYER_HARVEST" }
        .sortedByDescending { it.scheduledAtMillis }
    val futureReminderItems = reminders.filter { it.scheduledAtMillis >= now }

    val overduePersonalHarvests = personalHarvests
        .filter { it.actualEndMillis == 0L && it.expectedEndMillis in 1L until now }
        .sortedByDescending { it.expectedEndMillis }
    val overdueBuyerHarvests = buyerSales
        .filter { it.actualEndMillis == 0L && it.expectedEndMillis in 1L until now }
        .sortedByDescending { it.expectedEndMillis }
    val soonPersonalHarvests = personalHarvests
        .filter { it.actualEndMillis == 0L && it.expectedEndMillis in now..threeDays }
        .sortedBy { it.expectedEndMillis }
    val soonBuyerHarvests = buyerSales
        .filter { it.actualEndMillis == 0L && it.expectedEndMillis in now..threeDays }
        .sortedBy { it.expectedEndMillis }

    // One upcoming display row per saved reminder. Harvest rows are added only when there is
    // no reminder entity for that harvest, avoiding duplicate entries in the unified feed.
    val upcomingEntries = buildList {
        futureReminderItems.forEach { item ->
            add(ReminderFeedEntry(
                key = "reminder-${item.referenceType}-${item.referenceId}",
                dateMillis = item.scheduledAtMillis,
                title = item.title,
                category = item.category,
                place = item.plantationName
            ))
        }
        personalHarvests.filter { it.actualEndMillis == 0L && it.expectedEndMillis >= now && "PERSONAL_HARVEST:${it.id}" !in allHarvestReminderKeys }.forEach { harvest ->
            val plotName = plantations.firstOrNull { it.id == harvest.plantationId }?.name ?: "موضع غير محدد"
            add(ReminderFeedEntry("personal-harvest-${harvest.id}", harvest.expectedEndMillis, "انتهاء القطفة ${harvest.name}", "القطفات", plotName, "موعد الانتهاء المتوقع"))
        }
        buyerSales.filter { it.actualEndMillis == 0L && it.expectedEndMillis >= now && "BUYER_HARVEST:${it.id}" !in allHarvestReminderKeys }.forEach { sale ->
            val buyerName = buyers.firstOrNull { it.id == sale.buyerId }?.name ?: "المشتري"
            add(ReminderFeedEntry("buyer-harvest-${sale.id}", sale.expectedEndMillis, "انتهاء قطفة البيع ${sale.harvestName}", "القطفات", buyerName, "موعد الانتهاء المتوقع"))
        }
    }.sortedBy { it.dateMillis }

    val soonEntries = upcomingEntries.filter { it.dateMillis in now..threeDays }
    val overdueCount = overdueReminderItems.size
    val overdueHarvestCount = overduePersonalHarvests.size + overdueBuyerHarvests.size
    val soonHarvestCount = soonPersonalHarvests.size + soonBuyerHarvests.size

    // Smart recommendations come from real agricultural entries that do not have any saved
    // reminder attached. They never repeat upcoming or overdue reminders.
    val savedExpenseReminderIds = allReminderRecords
        .filter { it.referenceType == "EXPENSE" }
        .map { it.referenceId }.toSet()
    val smartSuggestions = expenses
        .filter { it.category in setOf("السموم", "الأسمدة", "المياه", "المياه والري") && it.id !in savedExpenseReminderIds }
        .groupBy { it.plantationId to it.category }
        .values
        .mapNotNull { entries -> entries.maxByOrNull { it.dateMillis } }
        .sortedWith(
            compareBy<ExpenseWithPlantation> {
                when (it.category) { "السموم" -> 0; "الأسمدة" -> 1; else -> 2 }
            }.thenByDescending { it.dateMillis }
        )
        .take(6)
        .map { expense ->
            val description = when (expense.category) {
                "السموم" -> "لم يُحفظ موعد متابعة لهذه المعاملة. راجع توصية المنتج أو المادة الفعالة وحدد موعد المراجعة المناسب."
                "الأسمدة" -> "لا يوجد موعد متابعة مرتبط بهذه المعاملة. يمكنك تحديد موعد لمراجعة استجابة الموضع والتسميد القادم."
                else -> "لم يُحفظ موعد سقي لاحق لهذا الموضع. راجع حالة التربة والطقس وجدول الري وحدد الموعد المناسب."
            }
            SmartFollowUpSuggestion(
                key = "${expense.plantationId}-${expense.category}",
                category = expense.category,
                title = expense.title,
                plantationName = expense.plantationName,
                dateMillis = expense.dateMillis,
                description = description
            )
        }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🔔 التنبيهات والمواعيد", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)

        FinancialCard(
            "⏰ مواعيد خلال 3 أيام",
            soonEntries.size.toString(),
            if (showSoon) "اضغط لإخفاء المواعيد القريبة" else "اضغط لعرض المواعيد القريبة فقط",
            onClick = { showSoon = !showSoon }
        )
        if (showSoon) {
            if (soonEntries.isEmpty()) Text("لا توجد مواعيد خلال الأيام الثلاثة القادمة.", color = Green, style = MaterialTheme.typography.bodySmall)
            soonEntries.forEach { item -> ReminderFeedCard(item) }
        }

        FinancialCard(
            "⚠️ مواعيد تجاوزت تاريخها",
            overdueCount.toString(),
            if (showOverdue) "اضغط لإخفاء المواعيد المتجاوزة" else "اضغط لعرض المواعيد المتجاوزة",
            onClick = { showOverdue = !showOverdue }
        )
        if (showOverdue) {
            if (overdueReminderItems.isEmpty()) Text("لا توجد مواعيد زراعية متجاوزة.", color = Green, style = MaterialTheme.typography.bodySmall)
            overdueReminderItems.forEach { item ->
                ReminderFeedCard(ReminderFeedEntry("overdue-${item.id}", item.scheduledAtMillis, item.title, item.category, item.plantationName, "موعد متجاوز"), overdue = true)
            }
        }

        Text("متابعة مواعيد القطفات", color = Emerald, fontWeight = FontWeight.Bold)
        FinancialCard(
            "🧺 قطفات خلال 3 أيام",
            soonHarvestCount.toString(),
            if (showHarvestSoon) "اضغط لإخفاء المواعيد" else "اضغط لعرض مواعيد القطفات القريبة",
            onClick = { showHarvestSoon = !showHarvestSoon }
        )
        if (showHarvestSoon) {
            soonPersonalHarvests.forEach { harvest ->
                val place = plantations.firstOrNull { it.id == harvest.plantationId }?.name ?: "موضع غير محدد"
                ReminderFeedCard(ReminderFeedEntry("harvest-soon-${harvest.id}", harvest.expectedEndMillis, "قطفة شخصية: ${harvest.name}", "القطفات", place, "موعد الانتهاء المتوقع"))
            }
            soonBuyerHarvests.forEach { sale ->
                val buyerName = buyers.firstOrNull { it.id == sale.buyerId }?.name ?: "مشتري"
                ReminderFeedCard(ReminderFeedEntry("buyer-soon-${sale.id}", sale.expectedEndMillis, "قطفة بيع: ${sale.harvestName}", "القطفات", buyerName, "موعد الانتهاء المتوقع"))
            }
            if (soonHarvestCount == 0) Text("لا توجد قطفات ينتهي موعدها خلال الأيام الثلاثة القادمة.", color = Green, style = MaterialTheme.typography.bodySmall)
        }

        FinancialCard(
            "⚠️ قطفات تجاوزت تاريخ الانتهاء",
            overdueHarvestCount.toString(),
            if (showHarvestOverdue) "اضغط لإخفاء القطفات المتجاوزة" else "اضغط لعرض القطفات المتجاوزة",
            onClick = { showHarvestOverdue = !showHarvestOverdue }
        )
        if (showHarvestOverdue) {
            overduePersonalHarvests.forEach { harvest ->
                val place = plantations.firstOrNull { it.id == harvest.plantationId }?.name ?: "موضع غير محدد"
                ReminderFeedCard(ReminderFeedEntry("harvest-overdue-${harvest.id}", harvest.expectedEndMillis, "قطفة شخصية: ${harvest.name}", "القطفات", place, "تجاوزت تاريخ الانتهاء المتوقع"), overdue = true)
            }
            overdueBuyerHarvests.forEach { sale ->
                val buyerName = buyers.firstOrNull { it.id == sale.buyerId }?.name ?: "مشتري"
                ReminderFeedCard(ReminderFeedEntry("buyer-overdue-${sale.id}", sale.expectedEndMillis, "قطفة بيع: ${sale.harvestName}", "القطفات", buyerName, "تجاوزت تاريخ الانتهاء المتوقع"), overdue = true)
            }
            if (overdueHarvestCount == 0) Text("لا توجد قطفات تجاوزت تاريخ الانتهاء المتوقع.", color = Green, style = MaterialTheme.typography.bodySmall)
        }

        Text("اقتراحات مِعيار الذكية", color = Emerald, fontWeight = FontWeight.Bold)
        if (smartSuggestions.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFEAF4EA))) {
                Text("لا توجد اقتراحات متابعة جديدة حاليًا. ستظهر هنا توصيات مبنية على عملياتك المسجلة التي لم تُربط بمواعيد متابعة.", modifier = Modifier.padding(12.dp), color = Green, style = MaterialTheme.typography.bodySmall)
            }
        } else smartSuggestions.forEach { suggestion ->
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFEAF4EA)), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("اقتراح ${suggestion.category}", color = Emerald, fontWeight = FontWeight.Bold)
                    Text(suggestion.title, color = Emerald, fontWeight = FontWeight.SemiBold)
                    Text("الموضع: ${suggestion.plantationName} • ${localDate(suggestion.dateMillis)}", color = Green, style = MaterialTheme.typography.labelSmall)
                    Text(suggestion.description, color = androidx.compose.ui.graphics.Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text("جميع المواعيد القادمة", color = Emerald, fontWeight = FontWeight.Bold)
        if (upcomingEntries.isEmpty()) {
            Text("لا توجد مواعيد قادمة محفوظة.", color = Green, style = MaterialTheme.typography.bodySmall)
        } else upcomingEntries.forEach { item -> ReminderFeedCard(item) }
    }
}

@Composable
private fun ReminderFeedCard(item: ReminderFeedEntry, overdue: Boolean = false) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (overdue) androidx.compose.ui.graphics.Color(0xFFFFF0E5) else androidx.compose.ui.graphics.Color.White),
        shape = RoundedCornerShape(13.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (overdue) "⚠️" else "🔔", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(item.title, fontWeight = FontWeight.Bold, color = Emerald)
                Text("${item.category} • ${item.place}", color = Green, style = MaterialTheme.typography.bodySmall)
                Text(SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(item.dateMillis)), color = androidx.compose.ui.graphics.Color.DarkGray, style = MaterialTheme.typography.labelSmall)
                if (item.detail.isNotBlank()) Text(item.detail, color = Green, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}


@Composable
fun MiyarCurrencySettingsCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    var sar by remember { mutableStateOf(prefs.getString("sar", "") ?: "") }
    var usd by remember { mutableStateOf(prefs.getString("usd", "") ?: "") }
    var saved by remember { mutableStateOf(false) }
    Card(modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("إعدادات أسعار الصرف", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            Text("تُستخدم الأسعار الجديدة في الفواتير ودفعات الموردين الجديدة فقط. الأسعار السابقة محفوظة داخل كل فاتورة ودفعة.", style = MaterialTheme.typography.bodySmall)
            MiyarRateInputField(sar, { sar = it; saved = false }, label = "سعر 1 ريال سعودي بالريال اليمني", modifier = Modifier.fillMaxWidth())
            MiyarRateInputField(usd, { usd = it; saved = false }, label = "سعر 1 دولار بالريال اليمني", imeAction = ImeAction.Done, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val sarValue = rateScaled(sar)
                val usdValue = rateScaled(usd)
                if (sarValue > 0 && usdValue > 0) {
                    prefs.edit().putString("sar", rateInput(sar)).putString("usd", rateInput(usd)).apply()
                    saved = true
                } else saved = false
            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ أسعار الصرف") }
            if (saved) Text("تم حفظ أسعار الصرف. ستُستخدم في العمليات المالية الجديدة.", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MiyarSuppliersScreen(dao: MiyarDao, modifier: Modifier = Modifier) {
    val accounts by dao.observeSupplierAccounts().collectAsStateWithLifecycle(initialValue = emptyList())
    val payments by dao.observeRecentSupplierPaymentsWithName().collectAsStateWithLifecycle(initialValue = emptyList())
    val invoices by dao.observeRecentInvoices().collectAsStateWithLifecycle(initialValue = emptyList())
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("miyar_currency_rates", android.content.Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var selectedSupplier by remember { mutableStateOf<SupplierAccountSummary?>(null) }
    var showPayment by rememberSaveable { mutableStateOf(false) }
    var showSupplier by rememberSaveable { mutableStateOf(false) }
    var supplierName by rememberSaveable { mutableStateOf("") }
    var supplierPhone by rememberSaveable { mutableStateOf("") }
    var supplierNotes by rememberSaveable { mutableStateOf("") }
    var paymentDateMillis by rememberSaveable { mutableLongStateOf(System.currentTimeMillis()) }
    var paymentAmount by rememberSaveable { mutableStateOf("") }
    var paymentCurrency by rememberSaveable { mutableStateOf("YER") }
    var paymentRate by rememberSaveable { mutableStateOf("1") }
    var paymentMethod by rememberSaveable { mutableStateOf("نقدًا") }
    var paymentNotes by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var saving by rememberSaveable { mutableStateOf(false) }

    val outstanding = FinanceCalculations.sumExact(accounts.map { it.balanceYer })
    val creditTotal = FinanceCalculations.sumExact(accounts.map { it.totalCreditYer })
    val paidTotal = FinanceCalculations.sumExact(accounts.map { it.totalPaidYer })
    Column(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("التجار والموردون", color = Emerald, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text("ملفات الموردين وكشوف حساب الفواتير الآجلة والدفعات", style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { supplierName = ""; supplierPhone = ""; supplierNotes = ""; showSupplier = true }) { Icon(Icons.Default.Add, null); Text("مورد") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SummaryMiniCard("إجمالي الآجل", formatMoney(creditTotal), Modifier.weight(1f))
            SummaryMiniCard("المسدد", formatMoney(paidTotal), Modifier.weight(1f))
            SummaryMiniCard("المتبقي", formatMoney(outstanding), Modifier.weight(1f))
        }
        if (accounts.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("لا توجد ملفات موردين بعد", color = Emerald, fontWeight = FontWeight.Bold)
                    Text("تُنشأ الملفات تلقائيًا عند تسجيل فاتورة، ويمكنك إضافة ملف يدويًا.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(accounts, key = { it.id }) { account ->
                val supplierPayments = payments.filter { it.supplierId == account.id }
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(account.name, color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                if (account.phone.isNotBlank()) Text(account.phone, style = MaterialTheme.typography.bodySmall)
                                if (account.notes.isNotBlank()) Text(account.notes, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            Text(if (account.balanceYer > 0) "عليه مستحقات" else "مسدد", color = if (account.balanceYer > 0) androidx.compose.ui.graphics.Color(0xFF9A5700) else Green, fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("فواتير آجلة: ${account.invoiceCount}", style = MaterialTheme.typography.labelSmall)
                            Text("إجمالي الآجل: ${formatMoney(account.totalCreditYer)}", style = MaterialTheme.typography.labelSmall)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المسدد: ${formatMoney(account.totalPaidYer)}", color = Green, style = MaterialTheme.typography.labelSmall)
                            Text("المتبقي: ${formatMoney(account.balanceYer)}", color = Emerald, fontWeight = FontWeight.ExtraBold)
                        }
                        val supplierInvoices = invoices.filter { it.supplier.equals(account.name, true) }
                        Text("الفواتير المعروضة: ${supplierInvoices.size} من أحدث السجلات", style = MaterialTheme.typography.labelSmall)
                        if (supplierPayments.isNotEmpty()) {
                            HorizontalDivider(color = Gold.copy(alpha = .4f))
                            Text("آخر دفعة: ${localDate(supplierPayments.first().dateMillis)} • ${formatNumber(supplierPayments.first().amountForeign)} ${supplierPayments.first().currency} • ${formatMoney(supplierPayments.first().amountYer)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { selectedSupplier = account }) { Text("كشف الحساب (${supplierPayments.size} حديثة)") }
                            Button(enabled = account.balanceYer > 0, onClick = {
                                selectedSupplier = account
                                paymentAmount = ""
                                paymentCurrency = "YER"
                                paymentRate = "1"
                                paymentMethod = "نقدًا"
                                paymentNotes = ""
                                paymentDateMillis = System.currentTimeMillis()
                                showPayment = true
                            }) { Icon(Icons.Default.Add, null); Text("تسجيل دفعة") }
                        }
                    }
                }
            }
        }
    }

    if (showSupplier) {
        AlertDialog(
            onDismissRequest = { if (!saving) showSupplier = false },
            title = { Text("إضافة ملف مورد") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(supplierName, { supplierName = it }, label = { Text("اسم المورد") }, singleLine = true)
                OutlinedTextField(supplierPhone, { supplierPhone = it }, label = { Text("رقم الهاتف (اختياري)") }, singleLine = true)
                OutlinedTextField(supplierNotes, { supplierNotes = it }, label = { Text("ملاحظات المورد") }, minLines = 2)
            } },
            confirmButton = { TextButton(enabled = !saving, onClick = {
                if (supplierName.isBlank()) { message = "أدخل اسم المورد."; return@TextButton }
                saving = true
                scope.launch { try { dao.saveSupplierProfile(supplierName, supplierPhone, supplierNotes); showSupplier = false } catch (t: Throwable) { message = t.message ?: "تعذر حفظ المورد." } finally { saving = false } }
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showSupplier = false }) { Text("إلغاء") } }
        )
    }
    if (showPayment && selectedSupplier != null) {
        val rate = rateScaled(paymentRate)
        val yerAmount = if (paymentCurrency == "YER") moneyToLong(paymentAmount) else runCatching { FinanceCalculations.toYemeniRials(moneyToLong(paymentAmount), rate) }.getOrDefault(0L)
        AlertDialog(
            onDismissRequest = { if (!saving) showPayment = false },
            title = { Text("دفعة للمورد: ${selectedSupplier!!.name}") },
            text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المتبقي عليه: ${formatMoney(selectedSupplier!!.balanceYer)}", color = Emerald, fontWeight = FontWeight.Bold)
                MiyarDateField("تاريخ الدفعة", paymentDateMillis) { paymentDateMillis = it }
                MiyarMoneyInputField(paymentAmount, { paymentAmount = it }, label = "مبلغ الدفعة", imeAction = ImeAction.Done, modifier = Modifier.fillMaxWidth())
                Text("عملة الدفع", color = Emerald, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("YER", "SAR", "USD").forEach { c -> FilterChip(selected = paymentCurrency == c, onClick = {
                        paymentCurrency = c
                        paymentRate = when (c) { "YER" -> "1"; "SAR" -> prefs.getString("sar", "") ?: ""; else -> prefs.getString("usd", "") ?: "" }
                    }, label = { Text(c) }) }
                }
                if (paymentCurrency != "YER") MiyarRateInputField(paymentRate, { paymentRate = it }, label = "سعر صرف 1 $paymentCurrency بالريال اليمني", imeAction = ImeAction.Done, modifier = Modifier.fillMaxWidth())
                Text("المقابل بالريال اليمني: ${formatMoney(yerAmount)}", color = Green, fontWeight = FontWeight.ExtraBold)
                Text("طريقة الدفع", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("نقدًا", "تحويل", "شيك").forEach { method -> FilterChip(selected = paymentMethod == method, onClick = { paymentMethod = method }, label = { Text(method) }) } }
                OutlinedTextField(paymentNotes, { paymentNotes = it }, label = { Text("ملاحظات الدفعة") }, minLines = 2)
            } },
            confirmButton = { TextButton(enabled = !saving, onClick = {
                if (moneyToLong(paymentAmount) <= 0L || (paymentCurrency != "YER" && rate <= 0L)) { message = "أدخل مبلغًا وسعر صرف صحيحين."; return@TextButton }
                saving = true
                scope.launch { try {
                    dao.addSupplierPayment(SupplierPaymentEntity(supplierId = selectedSupplier!!.id, dateMillis = paymentDateMillis, currency = paymentCurrency, amountForeign = moneyToLong(paymentAmount), exchangeRateScaled = if (paymentCurrency == "YER") 1000L else rate, amountYer = yerAmount, paymentMethod = paymentMethod, notes = paymentNotes.trim()))
                    showPayment = false
                    selectedSupplier = null
                    message = "تم تسجيل الدفعة وحفظ سعر صرفها في كشف حساب المورد."
                } catch (t: Throwable) { message = t.message ?: "تعذر تسجيل الدفعة." } finally { saving = false } }
            }) { Text(if (saving) "جارٍ الحفظ" else "حفظ الدفعة") } },
            dismissButton = { TextButton(enabled = !saving, onClick = { showPayment = false }) { Text("إلغاء") } }
        )
    }
    if (selectedSupplier != null && !showPayment && !showSupplier) {
        val supplier = selectedSupplier!!
        val history = payments.filter { it.supplierId == supplier.id }
        val supplierInvoices = invoices.filter { it.supplier.equals(supplier.name, true) }.sortedByDescending { it.dateMillis }
        AlertDialog(onDismissRequest = { selectedSupplier = null }, title = { Text("كشف حساب ${supplier.name}") },
            text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("إجمالي الفواتير الآجلة: ${formatMoney(supplier.totalCreditYer)}")
                Text("إجمالي الدفعات: ${formatMoney(supplier.totalPaidYer)}")
                Text("الرصيد المتبقي: ${formatMoney(supplier.balanceYer)}", color = Emerald, fontWeight = FontWeight.Bold)
                HorizontalDivider()
                Text("الفواتير — أحدث السجلات المعروضة", fontWeight = FontWeight.Bold, color = Emerald)
                if (supplierInvoices.isEmpty()) Text("لا توجد فواتير مسجلة.")
                supplierInvoices.forEach { invoice ->
                    Text("${localDate(invoice.dateMillis)} • ${invoice.invoiceNumber} • ${invoice.paymentStatus} • ${formatMoney(invoice.totalYer)}", fontWeight = FontWeight.SemiBold)
                }
                HorizontalDivider()
                Text("الدفعات — أحدث السجلات المعروضة", fontWeight = FontWeight.Bold, color = Emerald)
                if (history.isEmpty()) Text("لا توجد دفعات مسجلة.")
                history.forEach { pay ->
                    Text("${localDate(pay.dateMillis)} • ${formatNumber(pay.amountForeign)} ${pay.currency} • ${formatMoney(pay.amountYer)}", fontWeight = FontWeight.SemiBold)
                    Text("سعر الصرف: ${pay.exchangeRateScaled / 1000.0} • ${pay.paymentMethod} ${pay.notes}", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                }
            } }, confirmButton = { TextButton(onClick = { selectedSupplier = null }) { Text("إغلاق") } })
    }
    if (message != null) AlertDialog(onDismissRequest = { message = null }, title = { Text("تنبيه") }, text = { Text(message!!) }, confirmButton = { TextButton(onClick = { message = null }) { Text("حسنًا") } })
}
