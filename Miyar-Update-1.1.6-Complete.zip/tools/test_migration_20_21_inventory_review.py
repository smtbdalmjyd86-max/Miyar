#!/usr/bin/env python3
"""SQLite fixture test for Miyar Room 20 -> 21 inventory review migration."""
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = (ROOT / "app/src/main/java/com/miyar/app/data/MiyarDatabase.kt").read_text(encoding="utf-8")
MODEL_SOURCE = (ROOT / "app/src/main/java/com/miyar/app/data/FinanceModels.kt").read_text(encoding="utf-8")

assert "version = 22" in DB_SOURCE
assert "private val MIGRATION_20_21 = object : Migration(20,21)" in DB_SOURCE
assert "ALTER TABLE stock_items ADD COLUMN valuationReviewReason TEXT NOT NULL DEFAULT ''" in DB_SOURCE
assert "الإصدار 1.1.5 لم يحفظ سبباً تفصيلياً" in DB_SOURCE
assert "index_stock_items_valuationStatus_quantityBase" in DB_SOURCE
assert "backupBeforeRoom22(context.applicationContext)" in DB_SOURCE
assert "PRAGMA quick_check" in DB_SOURCE
assert "miyar_migration_backups" in DB_SOURCE
assert "MIGRATION_21_22" in DB_SOURCE
assert "MIGRATION_20_21, MIGRATION_21_22).build()" in DB_SOURCE
assert "valuationReviewReason" in MODEL_SOURCE

conn = sqlite3.connect(":memory:")
conn.executescript("""
CREATE TABLE stock_items(
 id INTEGER PRIMARY KEY, productName TEXT NOT NULL, quantityBase INTEGER NOT NULL,
 currentValueMicros INTEGER NOT NULL DEFAULT 0, valuationStatus TEXT NOT NULL DEFAULT 'PENDING'
);
CREATE TABLE stock_movements(
 id INTEGER PRIMARY KEY, stockItemId INTEGER NOT NULL, quantityBase INTEGER NOT NULL,
 valueDeltaMicros INTEGER NOT NULL DEFAULT 0
);
INSERT INTO stock_items(id,productName,quantityBase,currentValueMicros,valuationStatus)
 VALUES(101,'سماد سائل',300,28800000000,'REVIEW_REQUIRED'),
       (102,'سماد صلب',5000,12000000000,'VERIFIED');
INSERT INTO stock_movements(id,stockItemId,quantityBase,valueDeltaMicros)
 VALUES(1001,101,400,38400000000),(1002,101,-100,-9600000000),
       (1003,102,5000,12000000000);
""")
# Exact migration DDL copied from the source migration.
conn.execute("ALTER TABLE stock_items ADD COLUMN valuationReviewReason TEXT NOT NULL DEFAULT ''")
conn.execute("CREATE INDEX IF NOT EXISTS index_stock_items_valuationStatus_quantityBase ON stock_items(valuationStatus,quantityBase)")
conn.execute("INSERT INTO miyar_audit_events(entityType,entityId,eventType,occurredAtMillis,beforeSnapshot,afterSnapshot,source,referenceId) VALUES('DATABASE_MIGRATION',21,'MIGRATE_20_21',strftime('%s','now')*1000,'Room 20','Added review explanations and valuation status index; existing quantities, values, IDs and movements preserved','SYSTEM',0)" ) if False else None
# Existing values, quantities and stable primary keys remain untouched.
assert conn.execute("SELECT id,quantityBase,currentValueMicros FROM stock_items ORDER BY id").fetchall() == [
    (101,300,28800000000),(102,5000,12000000000)
]
assert conn.execute("SELECT id,stockItemId,quantityBase,valueDeltaMicros FROM stock_movements ORDER BY id").fetchall() == [
    (1001,101,400,38400000000),(1002,101,-100,-9600000000),(1003,102,5000,12000000000)
]
assert conn.execute("SELECT valuationReviewReason FROM stock_items WHERE id=101").fetchone() == ("",)
assert conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='index_stock_items_valuationStatus_quantityBase'").fetchone()[0] == 1
# Partial sums: unresolved rows must not leak into confirmed totals.
confirmed_inbound = conn.execute("SELECT SUM(m.valueDeltaMicros) FROM stock_movements m JOIN stock_items s ON s.id=m.stockItemId WHERE m.quantityBase>0 AND s.valuationStatus IN ('VERIFIED','ESTIMATED')").fetchone()[0]
unresolved_inbound = conn.execute("SELECT SUM(m.valueDeltaMicros) FROM stock_movements m JOIN stock_items s ON s.id=m.stockItemId WHERE m.quantityBase>0 AND s.valuationStatus NOT IN ('VERIFIED','ESTIMATED')").fetchone()[0]
assert confirmed_inbound == 12000000000
assert unresolved_inbound == 38400000000
print("Room 20->21 fixture passed: item/movement IDs, quantities and values preserved; review-reason column/index added; confirmed and unresolved financial totals remain separated.")
