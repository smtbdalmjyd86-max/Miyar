#!/usr/bin/env python3
"""Room 21 -> 22 migration + audited stock review repair fixture."""
import sqlite3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DB = (ROOT / "app/src/main/java/com/miyar/app/data/MiyarDatabase.kt").read_text(encoding="utf-8")
MODELS = (ROOT / "app/src/main/java/com/miyar/app/data/FinanceModels.kt").read_text(encoding="utf-8")
UI = (ROOT / "app/src/main/java/com/miyar/app/FinanceScreens.kt").read_text(encoding="utf-8")
assert "version = 22" in DB
assert "private val MIGRATION_21_22 = object : Migration(21,22)" in DB
assert "ALTER TABLE stock_movements ADD COLUMN valuationEvidence TEXT NOT NULL DEFAULT ''" in DB
assert "MIGRATION_20_21, MIGRATION_21_22" in DB
assert "Always refresh the snapshot" in DB
assert "backupBeforeRoom22(context.applicationContext)" in DB
assert "valuationEvidence" in MODELS and "StockReviewMovementRow" in MODELS
assert "repairStockReceiptValuation" in DB
assert "reconcileStockItemPhysicalCount" in DB
assert "addDocumentedHistoricalReceipt" in DB
assert "VALUATION_HISTORICAL_RECEIPT_ADDED" in DB
assert "VALUATION_RECEIPT_REPAIRED" in DB
assert "VALUATION_STOCK_COUNT_RECONCILED" in DB
assert "تفاصيل الخلل وأدوات الإصلاح" in UI
assert "تصحيح أو توثيق قيمة هذا الوارد" in UI
assert "إدخال الجرد الفعلي وتسوية الفرق" in UI
assert "إضافة الوارد التاريخي المفقود" in UI
assert "حركة غير صالحة: #${invalid.id} — كمية صفر" in UI
assert "mutableStateOf(false)" in UI[UI.index("var receiptVerified"):UI.index("var countDialog")]
assert "valuationEvidence" in UI
assert "countStockReviewMovements" in DB
assert "getStockReviewMovementById" in DB
assert "getStockReviewMovements(row.id, 50, movementPage * 50)" in UI
assert "getStockMovementsChronological(row.id)" in UI
assert "val issueValueEstimated = estimated" in DB
assert "val issueValueEstimated = movement.estimatedValue" not in DB

# Apply the exact schema addition while preserving historical primary keys and amounts.
con = sqlite3.connect(":memory:")
con.executescript("""
CREATE TABLE stock_movements(id INTEGER PRIMARY KEY, stockItemId INTEGER NOT NULL,
 referenceType TEXT NOT NULL, referenceId INTEGER NOT NULL, quantityBase INTEGER NOT NULL,
 valueDeltaMicros INTEGER NOT NULL DEFAULT 0);
CREATE TABLE stock_items(id INTEGER PRIMARY KEY, quantityBase INTEGER NOT NULL,
 currentValueMicros INTEGER NOT NULL DEFAULT 0);
INSERT INTO stock_items VALUES(9,300,28800000000);
INSERT INTO stock_movements VALUES(90,9,'INVOICE',55,400,38400000000);
INSERT INTO stock_movements VALUES(91,9,'MANUAL_ISSUE',4,-100,-9600000000);
""")
con.execute("ALTER TABLE stock_movements ADD COLUMN valuationEvidence TEXT NOT NULL DEFAULT ''")
assert con.execute("SELECT id,quantityBase,currentValueMicros FROM stock_items").fetchall() == [(9,300,28800000000)]
assert con.execute("SELECT id,quantityBase,valueDeltaMicros,valuationEvidence FROM stock_movements ORDER BY id").fetchall() == [
 (90,400,38400000000,''),(91,-100,-9600000000,'')]
# Demonstrate count reconciliation as a new movement, never rewriting either old movement.
con.execute("INSERT INTO stock_movements(id,stockItemId,referenceType,referenceId,quantityBase,valueDeltaMicros,valuationEvidence) VALUES(92,9,'REVIEW_ADJUSTMENT',9,25,2400000000,'محضر جرد')")
assert con.execute("SELECT id,quantityBase FROM stock_movements ORDER BY id").fetchall() == [(90,400),(91,-100),(92,25)]
# A source line cannot be double-linked by the DAO guard.
con.close()
# The DAO's repair replay must derive an issue's estimate from receipt provenance as it
# stood immediately before that issue, so a stale 1.1.5 issue flag clears after its receipts
# have been fully repaired rather than permanently trapping the item in ESTIMATED.
receipts_verified_before_issue = True
issue_estimated = not receipts_verified_before_issue
assert issue_estimated is False
print("Room 21->22 repair fixture passed: evidence migration is additive; old movement/item IDs, quantities and values stay intact; full-ledger chronological diagnosis, paged history, receipt repair, count reconciliation, and audit events are present.")
