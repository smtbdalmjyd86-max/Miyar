#!/usr/bin/env python3
"""Offline structural acceptance checks for the Room 19 -> 20 inventory migration.

This test mirrors the migration DDL against a representative Room-19 SQLite schema.
Room/KSP schema validation is additionally performed by the Gradle build.
"""
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = (ROOT / "app/src/main/java/com/miyar/app/data/MiyarDatabase.kt").read_text(encoding="utf-8")
MODEL_SOURCE = (ROOT / "app/src/main/java/com/miyar/app/data/FinanceModels.kt").read_text(encoding="utf-8")
CALC_SOURCE = (ROOT / "app/src/main/java/com/miyar/app/data/FinanceCalculations.kt").read_text(encoding="utf-8")

start = DB_SOURCE.index("private val MIGRATION_19_20")
end = DB_SOURCE.index("@Volatile private var INSTANCE", start)
migration = DB_SOURCE[start:end]
assert "ALTER TABLE stock_items ADD COLUMN currentValueMicros" in migration
assert "ALTER TABLE stock_items ADD COLUMN lowStockThresholdBase" in migration
assert "ALTER TABLE stock_movements ADD COLUMN valueDeltaMicros" in migration
assert "ALTER TABLE stock_movements ADD COLUMN sourceLineId" in migration
assert "DROP INDEX IF EXISTS index_stock_items_productType_productName_baseUnit_treatmentType" in migration
assert "CREATE INDEX IF NOT EXISTS index_stock_items_productType_productName_baseUnit_treatmentType" in migration
assert "DROP TABLE" not in migration.upper()
assert "CREATE TABLE" not in migration.upper()
assert 'version = 22' in DB_SOURCE
assert 'MIGRATION_21_22' in DB_SOURCE
assert 'private val MIGRATION_19_20 = object : Migration(19,20)' in DB_SOURCE
assert 'versionCode = 37' in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
assert 'versionName = "1.1.6"' in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
assert 'applicationId = "com.miyar.app"' in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
assert "movingAverageIssueCostMicros" in CALC_SOURCE
assert "currentValueMicros" in MODEL_SOURCE
assert "sourceLineId" in MODEL_SOURCE
assert "findStockItemsByIdentityLabel" in DB_SOURCE
assert "updateStockLowThreshold" in DB_SOURCE
assert "updateMovementSourceLine" in DB_SOURCE
assert "LEFT JOIN invoice_items ii ON ii.id = m.sourceLineId" in DB_SOURCE

conn = sqlite3.connect(":memory:")
cur = conn.cursor()
cur.executescript("""
CREATE TABLE stock_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
 productType TEXT NOT NULL, productName TEXT NOT NULL, activeIngredient TEXT NOT NULL,
 baseUnit TEXT NOT NULL, treatmentType TEXT NOT NULL DEFAULT 'عام',
 quantityBase INTEGER NOT NULL, totalReceivedBase INTEGER NOT NULL, totalUsedBase INTEGER NOT NULL,
 totalOpeningCostYer INTEGER NOT NULL DEFAULT 0, updatedAtMillis INTEGER NOT NULL,
 lastReceivedAtMillis INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX index_stock_items_productType_productName_baseUnit_treatmentType
 ON stock_items(productType,productName,baseUnit,treatmentType);
CREATE TABLE stock_movements (
 id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, stockItemId INTEGER NOT NULL,
 referenceType TEXT NOT NULL, referenceId INTEGER NOT NULL, quantityBase INTEGER NOT NULL,
 dateMillis INTEGER NOT NULL, description TEXT NOT NULL
);
CREATE TABLE miyar_audit_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, entityType TEXT NOT NULL, entityId INTEGER NOT NULL,
 eventType TEXT NOT NULL, occurredAtMillis INTEGER NOT NULL, beforeSnapshot TEXT NOT NULL,
 afterSnapshot TEXT NOT NULL, source TEXT NOT NULL, referenceId INTEGER NOT NULL
);
INSERT INTO stock_items VALUES(17,'السموم','مبيد أ','مادة أ','ml','حشري',700,800,100,0,10,10);
INSERT INTO stock_movements VALUES(44,17,'INVOICE',5,400,100,'فاتورة قديمة');
INSERT INTO stock_movements VALUES(45,17,'MANUAL_ISSUE',8,-100,200,'صرف قديم');
""")
cur.executescript("""
ALTER TABLE stock_items ADD COLUMN currentValueMicros INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stock_items ADD COLUMN lowStockThresholdBase INTEGER DEFAULT NULL;
ALTER TABLE stock_items ADD COLUMN valuationStatus TEXT NOT NULL DEFAULT 'PENDING';
ALTER TABLE stock_movements ADD COLUMN sourceLineId INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stock_movements ADD COLUMN valueDeltaMicros INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stock_movements ADD COLUMN unitCostMicrosPerBase INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stock_movements ADD COLUMN estimatedValue INTEGER NOT NULL DEFAULT 0;
DROP INDEX IF EXISTS index_stock_items_productType_productName_baseUnit_treatmentType;
CREATE INDEX IF NOT EXISTS index_stock_items_productType_productName_baseUnit_treatmentType
 ON stock_items(productType,productName,baseUnit,treatmentType);
CREATE INDEX IF NOT EXISTS index_stock_movements_stockItemId_dateMillis_id
 ON stock_movements(stockItemId,dateMillis,id);
""")
assert cur.execute("SELECT id,quantityBase,totalReceivedBase,totalUsedBase FROM stock_items WHERE id=17").fetchone() == (17,700,800,100)
assert cur.execute("SELECT id,referenceType,quantityBase FROM stock_movements ORDER BY id").fetchall() == [(44,'INVOICE',400),(45,'MANUAL_ISSUE',-100)]
# Text labels are not stock identity: after migration two records may share a label, but have distinct IDs.
cur.execute("INSERT INTO stock_items(productType,productName,activeIngredient,baseUnit,treatmentType,quantityBase,totalReceivedBase,totalUsedBase,totalOpeningCostYer,updatedAtMillis,lastReceivedAtMillis) VALUES('السموم','مبيد أ','مادة مختلفة','ml','حشري',50,50,0,0,11,11)")
assert cur.execute("SELECT COUNT(*) FROM stock_items WHERE productName='مبيد أ'").fetchone()[0] == 2
assert cur.execute("SELECT COUNT(DISTINCT id) FROM stock_items WHERE productName='مبيد أ'").fetchone()[0] == 2
conn.close()

# Required numerical example: all arithmetic in micro-YER avoids cumulative rounding drift.
qty, value = 400, 38_400 * 1_000_000
issue1 = (value * 100 + qty // 2) // qty
qty -= 100; value -= issue1
qty += 400; value += 39_120 * 1_000_000
issue2 = (value * 100 + qty // 2) // qty
qty -= 100; value -= issue2
assert (issue1, issue2, qty, value) == (9_600_000_000, 9_702_857_143, 600, 58_217_142_857)

print("Room 19->20 inventory migration structural checks passed; existing IDs and movements preserved; duplicate labels remain separate; moving-average example passed.")
