package com.miyar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Emerald = androidx.compose.ui.graphics.Color(0xFF103D32)
private val Green = androidx.compose.ui.graphics.Color(0xFF147D64)
private val Cream = androidx.compose.ui.graphics.Color(0xFFF7F3E8)
private val Gold = androidx.compose.ui.graphics.Color(0xFFC7A65A)

class MainActivity : ComponentActivity() {
    private val dao by lazy { MiyarDatabase.get(this).dao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Emerald,
                    secondary = Gold,
                    background = Cream,
                    surface = androidx.compose.ui.graphics.Color.White
                )
            ) {
                MiyarApp(dao)
            }
        }
    }
}

@Composable
private fun MiyarApp(dao: MiyarDao) {
    val scope = rememberCoroutineScope()
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val totalExpenses by dao.observeTotalExpenses().collectAsStateWithLifecycle(initialValue = 0L)
    val totalRevenue by dao.observeTotalRevenue().collectAsStateWithLifecycle(initialValue = 0L)
    var selected by remember { mutableStateOf<PlantationEntity?>(null) }
    var showAddPlantation by remember { mutableStateOf(false) }
    var showAddExpense by remember { mutableStateOf(false) }
    var plantationToDelete by remember { mutableStateOf<PlantationEntity?>(null) }
    var deleteMessage by remember { mutableStateOf<String?>(null) }
    var showAbout by remember { mutableStateOf(false) }
    var currentSection by remember { mutableStateOf("الرئيسية") }
    val sections = listOf("الأسمدة", "السموم", "المياه", "الأعمال اليدوية", "أخرى", "القطفات", "الفواتير والتقارير")
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    BackHandler(enabled = selected != null) { selected = null }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = Cream) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MiyarMark(Modifier.size(54.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("أهلاً بك في معيار", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.ExtraBold)
                                Text("إدارة أدق - مردود أوضح", color = Green, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    HorizontalDivider(color = Gold.copy(alpha = 0.6f))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("الرئيسية") },
                        selected = currentSection == "الرئيسية",
                        onClick = { currentSection = "الرئيسية"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    NavigationDrawerItem(
                        icon = { Text("🌱") },
                        label = { Text("المواضع الزراعية") },
                        selected = currentSection == "المواضع الزراعية",
                        onClick = { currentSection = "المواضع الزراعية"; selected = null; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    sections.forEach { section ->
                        NavigationDrawerItem(
                            icon = { Text(when (section) { "الأسمدة" -> "🌿"; "السموم" -> "🐛"; "المياه" -> "💧"; "الأعمال اليدوية" -> "🧑‍🌾"; "القطفات" -> "🧺"; "الفواتير والتقارير" -> "📊"; else -> "📝" }) },
                            label = { Text(section) },
                            selected = currentSection == section,
                            onClick = { currentSection = section; selected = null; scope.launch { drawerState.close() } },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Info, contentDescription = null) },
                        label = { Text("عن مِعيار") },
                        selected = false,
                        onClick = { showAbout = true; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        ) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { if (selected == null && (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية")) showAddPlantation = true else if (selected != null && currentSection != "الفواتير والتقارير") showAddExpense = true },
                    containerColor = Emerald,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Header(onMenuClick = { scope.launch { drawerState.open() } })
                if (currentSection == "الرئيسية") {
                    Text("أهلاً بك في معيار", modifier = Modifier.padding(top = 10.dp, start = 4.dp), style = MaterialTheme.typography.titleMedium, color = Emerald, fontWeight = FontWeight.ExtraBold)
                    Text("إدارة أدق - مردود أوضح", modifier = Modifier.padding(start = 4.dp), style = MaterialTheme.typography.bodyMedium, color = Green)
                }
                Spacer(Modifier.height(12.dp))
                if (selected == null) {
                    Text(if (currentSection == "الرئيسية") "مواضعي الزراعية" else if (currentSection == "المواضع الزراعية") "المواضع الزراعية" else currentSection,
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                    Spacer(Modifier.height(8.dp))
                    if (plantations.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("أهلًا بك في مِعيار 🌿", fontWeight = FontWeight.Bold)
                                Text("أضف أول موضع زراعي للبدء.")
                            }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(plantations, key = { it.id }) { p ->
                                var menu by remember(p.id) { mutableStateOf(false) }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌱", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 8.dp))
                                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                            Text(p.name, fontWeight = FontWeight.SemiBold)
                                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "عرض تفاصيل الموضع ←" else "اختيار الموضع لهذا القسم ←", color = Green, style = MaterialTheme.typography.labelMedium)
                                        }
                                        TextButton(onClick = { selected = p }) { Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "فتح" else "اختيار") }
                                        Box {
                                            IconButton(onClick = { menu = true }) {
                                                Icon(Icons.Default.MoreVert, contentDescription = "إجراءات الموضع")
                                            }
                                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                                DropdownMenuItem(
                                                    text = { Text("حذف الموضع") },
                                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                                                    onClick = { menu = false; plantationToDelete = p }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (currentSection == "الرئيسية") {
                        Spacer(Modifier.height(12.dp))
                        FinancialCard("💸 إجمالي الخرج", formatMoney(totalExpenses), "ريال يمني • المصروفات المسجلة")
                        Spacer(Modifier.height(8.dp))
                        FinancialCard("💰 إجمالي المردود", formatMoney(totalRevenue), "إجمالي المبالغ المسجلة في قسم القطفات")
                        Spacer(Modifier.height(12.dp))
                        Text("الأقسام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        sections.forEach { section ->
                            TextButton(onClick = { currentSection = section; selected = null }) { Text("${section}  ←") }
                        }
                    } else if (currentSection == "الفواتير والتقارير") {
                        Spacer(Modifier.height(8.dp))
                        Text("اختر موضعًا لعرض ملخص سجلاته وتقرير عملياته.", style = MaterialTheme.typography.bodyMedium)
                    } else if (currentSection != "المواضع الزراعية") {
                        Text("اختر الموضع الزراعي الذي تريد تسجيل بيانات قسم ${currentSection} عليه.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                        Column {
                            Text(selected!!.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                            Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية") "ملخص الموضع" else currentSection, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val allExpenses by dao.observeExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = emptyList())
                    val expenses = if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "الفواتير والتقارير") allExpenses else allExpenses.filter { it.category == currentSection }
                    val plantationTotal by dao.observePlantationExpenses(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    val plantationRevenue by dao.observePlantationRevenue(selected!!.id).collectAsStateWithLifecycle(initialValue = 0L)
                    Spacer(Modifier.height(8.dp))
                    FinancialCard("💸 إجمالي خرج الموضع", formatMoney(plantationTotal), "يتحدث تلقائيًا من سجلات المصروفات")
                    FinancialCard("💰 إجمالي مردود الموضع", formatMoney(plantationRevenue), "إجمالي القطفات المسجلة لهذا الموضع")
                    Spacer(Modifier.height(12.dp))
                    Text(if (currentSection == "الرئيسية" || currentSection == "المواضع الزراعية" || currentSection == "الفواتير والتقارير") "سجل العمليات" else "سجل ${currentSection}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (expenses.isEmpty()) Text(if (currentSection == "الفواتير والتقارير") "لا توجد عمليات مسجلة لعرضها في التقرير." else "لا توجد سجلات في هذا القسم لهذا الموضع بعد.", modifier = Modifier.padding(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(expenses, key = { it.id }) { expense ->
                            ExpenseRow(expense,
                                onUpdate = { updated -> scope.launch { dao.updateExpense(updated) } },
                                onDelete = { item -> scope.launch { dao.deleteExpense(item) } }
                            )
                        }
                    }
                }
            }
        }
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("عن مِعيار") },
            text = { Text("مِعيار يساعدك على تنظيم مواضعك الزراعية ومتابعة المصروفات المسجلة لكل موضع.") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("حسنًا") } }
        )
    }

    if (plantationToDelete != null) {
        val target = plantationToDelete!!
        AlertDialog(
            onDismissRequest = { plantationToDelete = null },
            title = { Text("تأكيد حذف الموضع") },
            text = { Text("هل تريد حذف الموضع «${target.name}»؟ لا يمكن حذف أي موضع يحتوي على مصروفات مسجلة.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val deleted = dao.deletePlantationIfEmpty(target.id)
                        if (!deleted) deleteMessage = "لا يمكن حذف الموضع «${target.name}» لأنه يحتوي على مصروفات مسجلة. احذف المصروفات أو احتفظ بالموضع."
                    }
                    plantationToDelete = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { plantationToDelete = null }) { Text("إلغاء") } }
        )
    }
    if (deleteMessage != null) {
        AlertDialog(
            onDismissRequest = { deleteMessage = null },
            title = { Text("تعذر حذف الموضع") },
            text = { Text(deleteMessage!!) },
            confirmButton = { TextButton(onClick = { deleteMessage = null }) { Text("حسنًا") } }
        )
    }

    if (showAddPlantation) {
        TextEntryDialog("إضافة موضع زراعي", "اسم الموضع", onDismiss = { showAddPlantation = false }) { name ->
            scope.launch { dao.insertPlantation(PlantationEntity(name = name.trim())) }
            showAddPlantation = false
        }
    }
    if (showAddExpense && selected != null) {
        ExpenseDialog(category = currentSection, onDismiss = { showAddExpense = false }) { title, amount, notes ->
            scope.launch {
                dao.insertExpense(ExpenseEntity(plantationId = selected!!.id, category = currentSection, title = title.trim(), amount = amount, notes = notes))
            }
            showAddExpense = false
        }
    }
}

@Composable
private fun Header(onMenuClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, contentDescription = "فتح القائمة الجانبية", tint = androidx.compose.ui.graphics.Color.White)
            }
            MiyarMark(Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("مِعيار", style = MaterialTheme.typography.headlineMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                Text("إدارة أدق - مردود أوضح", color = Gold, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun MiyarMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .padding(2.dp)
            .then(Modifier),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(50),
            color = Emerald,
            border = androidx.compose.foundation.BorderStroke(2.dp, Gold)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("🌿", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}

@Composable
private fun FinancialCard(title: String, value: String, caption: String) {
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(caption, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpenseRow(item: ExpenseEntity, onUpdate: (ExpenseEntity) -> Unit, onDelete: (ExpenseEntity) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var editDialog by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { }, onLongClick = { menu = true }),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; editDialog = true })
                DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    if (editDialog) {
        ExpenseDialog(initial = item, onDismiss = { editDialog = false }) { title, amount, notes ->
            onUpdate(item.copy(title = title.trim(), amount = amount, notes = notes))
            editDialog = false
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل تريد حذف المصروف «${item.title}»؟ لا يمكن التراجع عن هذه العملية.") },
            confirmButton = { TextButton(onClick = { onDelete(item); confirmDelete = false }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onSave(value) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ExpenseDialog(initial: ExpenseEntity? = null, category: String = initial?.category ?: "أخرى", onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var amountText by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    val parsed = amountText.toLongOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة سجل: $category" else "تعديل سجل: $category") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(when (category) { "الأسمدة" -> "اسم السماد / الصنف"; "السموم" -> "اسم السم أو المبيد"; "المياه" -> "بيان المياه / عدد الساعات"; "الأعمال اليدوية" -> "نوع العمل / العامل"; "القطفات" -> "بيان القطفة / المشتري"; else -> "البيان" }) }, singleLine = true)
                OutlinedTextField(amountText, { amountText = it.filter { ch -> ch.isDigit() } }, label = { Text(if (category == "القطفات") "المبلغ المردود بالريال اليمني" else "القيمة الإجمالية بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text(when (category) { "الأسمدة" -> "الكمية، النثريات، التقييم أو التفاصيل"; "السموم" -> "الكمية، طريقة الاستخدام، التفاصيل"; "المياه" -> "المدة، الكمية أو التفاصيل"; "الأعمال اليدوية" -> "عدد العمال، الأيام أو التفاصيل"; "القطفات" -> "تاريخ/رقم القطفة، الكمية، التفاصيل"; else -> "ملاحظات (اختياري)" }) })
                Text("أدخل المبلغ كعدد صحيح دون فواصل.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank() && parsed != null && parsed >= 0, onClick = { onSave(title, parsed!!, notes) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun formatMoney(amount: Long): String =
    NumberFormat.getIntegerInstance(Locale.US).format(amount) + " ر.ي"
