package com.miyar.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "plantations")
data class PlantationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantationId: Long,
    val category: String = "أخرى",
    val title: String,
    // Store money as integer minor units (e.g. whole Yemeni rials) to avoid floating-point errors.
    val amount: Long,
    val currency: String = "YER",
    val dateMillis: Long = System.currentTimeMillis(),
    val notes: String = ""
)
