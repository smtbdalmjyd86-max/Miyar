package com.miyar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Emerald = androidx.compose.ui.graphics.Color(0xFF103D32)
private val Green = androidx.compose.ui.graphics.Color(0xFF147D64)
private val Cream = androidx.compose.ui.graphics.Color(0xFFF7F3E8)
private val Gold = androidx.compose.ui.graphics.Color(0xFFC7A65A)

class MainActivity : ComponentActivity() {
    private val dao by lazy { MiyarDatabase.get(this).dao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Emerald,
                    secondary = Gold,
                    background = Cream,
                    surface = androidx.compose.ui.graphics.Color.White
                )
            ) {
                MiyarApp(dao)
            }
        }
    }
}

@Composable
private fun MiyarApp(dao: MiyarDao) {
    val scope = rememberCoroutineScope()
    val plantations by dao.observePlantations().collectAsStateWithLifecycle(initialValue = emptyList())
    val totalExpenses by dao.observeTotalExpensesOnly().collectAsStateWithLifecycle(initialValue = 0L)
    val totalHarvest by dao.observeTotalHarvest().collectAsStateWithLifecycle(initialValue = 0L)
    var selected by remember { mutableStateOf<PlantationEntity?>(null) }
    var selectedSection by remember { mutableStateOf<String?>(null) }
    var showAddPlantation by remember { mutableStateOf(false) }
    var showAddExpense by remember { mutableStateOf(false) }
    var plantationToDelete by remember { mutableStateOf<PlantationEntity?>(null) }
    var deleteMessage by remember { mutableStateOf<String?>(null) }

    val sections = listOf(
        "الأسمدة" to "🌿", "السموم" to "🐛", "المياه" to "💧",
        "الأعمال اليدوية" to "🧑‍🌾", "أخرى" to "📝", "القطفات" to "🧺",
        "الفواتير والتقارير" to "🧾"
    )

    BackHandler(enabled = selected != null || selectedSection != null) {
        if (selected != null) selected = null else selectedSection = null
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                if (selected != null && selectedSection != "الفواتير والتقارير") {
                    FloatingActionButton(onClick = { showAddExpense = true }, containerColor = Emerald, contentColor = androidx.compose.ui.graphics.Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة سجل")
                    }
                } else if (selected == null && selectedSection == null) {
                    FloatingActionButton(onClick = { showAddPlantation = true }, containerColor = Emerald, contentColor = androidx.compose.ui.graphics.Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة موضع")
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Header()
                Spacer(Modifier.height(12.dp))
                when {
                    selected != null -> {
                        val current = selected!!
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                            Column {
                                Text(current.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                                Text(selectedSection ?: "الأقسام", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (selectedSection == "الفواتير والتقارير") {
                            val all by dao.observeExpenses(current.id).collectAsStateWithLifecycle(initialValue = emptyList())
                            val expensesOnly = all.filter { it.category != "القطفات" }.sumOf { it.amount }
                            val harvestOnly = all.filter { it.category == "القطفات" }.sumOf { it.amount }
                            FinancialCard("💸 إجمالي الخرج", formatMoney(expensesOnly), "مصروفات هذا الموضع")
                            Spacer(Modifier.height(8.dp))
                            FinancialCard("🧺 إجمالي المردود", formatMoney(harvestOnly), "القطفات المسجلة لهذا الموضع")
                            Spacer(Modifier.height(12.dp))
                            Text("ملخص السجلات", fontWeight = FontWeight.Bold, color = Emerald)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(all, key = { it.id }) { item -> ExpenseRow(item,
                                    onUpdate = { updated -> scope.launch { dao.updateExpense(updated) } },
                                    onDelete = { toDelete -> scope.launch { dao.deleteExpense(toDelete) } }) }
                            }
                        } else {
                            val records by dao.observeExpensesByCategory(current.id, selectedSection ?: "أخرى").collectAsStateWithLifecycle(initialValue = emptyList())
                            val total = records.sumOf { it.amount }
                            FinancialCard(if (selectedSection == "القطفات") "🧺 إجمالي المردود" else "💸 إجمالي القسم", formatMoney(total), "${records.size} سجل • ${current.name}")
                            Spacer(Modifier.height(12.dp))
                            Text("سجلات ${selectedSection ?: "القسم"}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                            if (records.isEmpty()) {
                                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                                    Text("لا توجد سجلات في هذا القسم لهذا الموضع. اضغط (+) لإضافة أول سجل.", Modifier.fillMaxWidth().padding(16.dp))
                                }
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(records, key = { it.id }) { item -> ExpenseRow(item,
                                    onUpdate = { updated -> scope.launch { dao.updateExpense(updated) } },
                                    onDelete = { toDelete -> scope.launch { dao.deleteExpense(toDelete) } }) }
                            }
                        }
                    }
                    selectedSection != null -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { selectedSection = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                            Column {
                                Text(selectedSection!!, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                                Text("اختر الموضع لعرض سجلات القسم أو إضافة سجل إليه", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (selectedSection == "الفواتير والتقارير") {
                            Text("اختر الموضع لعرض ملخص الخرج والمردود والفواتير.", Modifier.padding(vertical = 8.dp))
                        }
                        if (plantations.isEmpty()) {
                            Text("أضف موضعًا زراعيًا أولًا من الصفحة الرئيسية.", Modifier.padding(16.dp))
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                items(plantations, key = { it.id }) { p ->
                                    Card(onClick = { selected = p }, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text("🌱", style = MaterialTheme.typography.headlineSmall)
                                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                                Text(p.name, fontWeight = FontWeight.Bold, color = Emerald)
                                                Text("فتح ${selectedSection}", color = Green, style = MaterialTheme.typography.bodySmall)
                                            }
                                            Icon(Icons.Default.ArrowBack, contentDescription = null)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("مواضعي الزراعية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                        if (plantations.isEmpty()) {
                            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                    Text("ابدأ بإضافة موضعك الزراعي الأول.", fontWeight = FontWeight.Bold)
                                    Text("بعدها اختر أي قسم وسجّل بياناته على الموضع الصحيح.")
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 220.dp)) {
                                items(plantations, key = { it.id }) { p ->
                                    var menu by remember(p.id) { mutableStateOf(false) }
                                    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text("🌱", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 8.dp))
                                            Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                                Text("عرض التفاصيل", color = Green, style = MaterialTheme.typography.labelMedium)
                                            }
                                            TextButton(onClick = { selected = p; selectedSection = "الفواتير والتقارير" }) { Text("ملخص") }
                                            Box {
                                                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "إجراءات الموضع") }
                                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                                    DropdownMenuItem(text = { Text("حذف الموضع") }, leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) }, onClick = { menu = false; plantationToDelete = p })
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) { FinancialCard("💸 إجمالي الخرج", formatMoney(totalExpenses), "المصروفات المسجلة") }
                            Box(Modifier.weight(1f)) { FinancialCard("🧺 إجمالي المردود", formatMoney(totalHarvest), "القطفات المسجلة") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("الأقسام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Emerald)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(sections) { (name, emoji) ->
                                Card(onClick = { selectedSection = name }, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(emoji, style = MaterialTheme.typography.titleLarge)
                                        Text(name, Modifier.weight(1f).padding(horizontal = 12.dp), fontWeight = FontWeight.SemiBold)
                                        Icon(Icons.Default.ArrowBack, contentDescription = "فتح القسم", tint = Green)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (plantationToDelete != null) {
        val target = plantationToDelete!!
        AlertDialog(onDismissRequest = { plantationToDelete = null }, title = { Text("تأكيد حذف الموضع") },
            text = { Text("هل تريد حذف الموضع «${target.name}»؟ لا يمكن حذف أي موضع يحتوي مصروفات مسجلة.") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    val deleted = dao.deletePlantationIfEmpty(target.id)
                    if (!deleted) deleteMessage = "لا يمكن حذف الموضع «${target.name}» لأنه يحتوي على سجلات مالية مسجلة."
                }
                plantationToDelete = null
            }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { plantationToDelete = null }) { Text("إلغاء") } })
    }
    if (deleteMessage != null) AlertDialog(onDismissRequest = { deleteMessage = null }, title = { Text("تعذر حذف الموضع") }, text = { Text(deleteMessage!!) }, confirmButton = { TextButton(onClick = { deleteMessage = null }) { Text("حسنًا") } })
    if (showAddPlantation) TextEntryDialog("إضافة موضع زراعي", "اسم الموضع", onDismiss = { showAddPlantation = false }) { name ->
        scope.launch { dao.insertPlantation(PlantationEntity(name = name.trim())) }
        showAddPlantation = false
    }
    if (showAddExpense && selected != null && selectedSection != null) ExpenseDialog(category = selectedSection!!, onDismiss = { showAddExpense = false }) { title, amount, notes ->
        scope.launch { dao.insertExpense(ExpenseEntity(plantationId = selected!!.id, category = selectedSection!!, title = title.trim(), amount = amount, notes = notes)) }
        showAddExpense = false
    }
}

@Composable
private fun Header() {
    Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🌿", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("أهلاً بك في معيار", style = MaterialTheme.typography.titleLarge, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold)
                Text("إدارة أدق - مردود أوضح", color = Gold, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun FinancialCard(title: String, value: String, caption: String) {
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(title, color = Emerald, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(caption, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ExpenseRow(item: ExpenseEntity, onUpdate: (ExpenseEntity) -> Unit, onDelete: (ExpenseEntity) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var editDialog by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { }, onLongClick = { menu = true }),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatMoney(item.amount), color = Emerald, fontWeight = FontWeight.Bold)
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; editDialog = true })
                DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }
    if (editDialog) {
        ExpenseDialog(category = item.category, initial = item, onDismiss = { editDialog = false }) { title, amount, notes ->
            onUpdate(item.copy(title = title.trim(), amount = amount, notes = notes))
            editDialog = false
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل تريد حذف المصروف «${item.title}»؟ لا يمكن التراجع عن هذه العملية.") },
            confirmButton = { TextButton(onClick = { onDelete(item); confirmDelete = false }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onSave(value) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ExpenseDialog(category: String = "أخرى", initial: ExpenseEntity? = null, onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var amountText by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    val parsed = amountText.toLongOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة سجل • $category" else "تعديل سجل • $category") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("بيان المصروف") }, singleLine = true)
                OutlinedTextField(amountText, { amountText = it.filter { ch -> ch.isDigit() } }, label = { Text("المبلغ بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات (اختياري)") })
                Text("أدخل المبلغ كعدد صحيح دون فواصل.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank() && parsed != null && parsed >= 0, onClick = { onSave(title, parsed!!, notes) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun formatMoney(amount: Long): String =
    NumberFormat.getIntegerInstance(Locale.US).format(amount) + " ر.ي"
