مِعيار | Miyar 1.0.9 — حزمة مصدر تحديث Android

Application ID: com.miyar.app
Version: 1.0.9 (versionCode 31)
Room database: 14 (schema unchanged from 1.0.8)

تشمل النسخة تحسينات عرض المخزون وسندات الصرف، تنظيم التنبيهات والمواعيد والاقتراحات الذكية، وإعادة تصميم صفحة الديون والمستحقات بملفات بائعين وعملاء بالآجل وملخصات مالية.

ارفع Miyar-Update-1.0.9-Complete.zip إلى جذر المستودع، واستبدل .github/workflows/blank.yml بمحتوى Miyar-1.0.9-blank.yml. لا تغيّر أسرار التوقيع الدائمة ولا تحذف التطبيق أو بياناته عند التحديث.
