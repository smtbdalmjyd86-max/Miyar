مِعيار | Miyar — حزمة مصدر الإصدار 1.0.7

إدارة أدق، ومردود أوضح.

هذه الحزمة مصدر Android لتحديث التطبيق المثبت 1.0.6. راجع CHANGELOG_1.0.7_AR.txt لمعرفة التعديلات، وBUILD_NOTES_1.0.7_AR.txt لخطوات البناء والتحقق قبل التثبيت.

ثوابت التحديث: applicationId=com.miyar.app، versionCode=29، versionName=1.0.7، Room version=12.
