مِعيار 1.0.6 Complete
الإصدار: 1.0.6 — Build 28
معرّف الحزمة: com.miyar.app
قاعدة البيانات: Room 12 (لا تغيير في المخطط)
مفتاح التوقيع: يستخدم أسرار Android signing الحالية في GitHub Actions.

ارفع Miyar-Update-1.0.6-Complete.zip إلى جذر المستودع، ثم حدّث .github/workflows/blank.yml بمحتوى Miyar-1.0.6-blank.yml. لا تحذف أسرار التوقيع ولا بيانات التطبيق المثبت.
