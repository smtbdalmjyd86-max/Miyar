# مِعيار | Miyar 1.0.9

Android Arabic RTL agricultural management application.

- Application ID: `com.miyar.app`
- Version: `1.0.9` (`versionCode = 31`)
- Room database: `14` (unchanged schema)
- GitHub Actions workflow: `.github/workflows/blank.yml`

See `CHANGELOG_1.0.9_AR.txt` and `BUILD_NOTES_1.0.9_AR.txt`. Install only after unit tests, release build, and permanent signing-certificate verification succeed.
