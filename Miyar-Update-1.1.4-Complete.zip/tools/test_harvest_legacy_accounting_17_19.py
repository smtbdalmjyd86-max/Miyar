#!/usr/bin/env python3
"""Validate the legacy-only harvest dashboard totals on a migrated 1.1.2 fixture.

This is a SQLite regression fixture, not a substitute for an Android Room/device test.
It proves the new 1.1.4 harvest summary queries do not pull amounts from the independent
Commerce ledger and do not double-count linked day rows and their linked ledger records.
"""
from __future__ import annotations
import re
import runpy
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = ROOT / "app/src/main/java/com/miyar/app/data/MiyarDatabase.kt"
source = DB_SOURCE.read_text(encoding="utf-8")

# Reuse the representative 1.1.2 schema and Room 16->17 migration fixture.
ns = runpy.run_path(str(ROOT / "tools/test_migration_16_17.py"))
con: sqlite3.Connection = ns["con"]

def extract_migration(name: str, next_marker: str) -> list[str]:
    block = source.split(f"private val {name}", 1)[1].split(next_marker, 1)[0]
    out = []
    for line in block.splitlines():
        match = re.search(r'db\.execSQL\("(.*)"\)\s*$', line.strip())
        if match:
            out.append(match.group(1).replace(r'\"', '"').replace(r'\\', '\\'))
    return out

for migration, next_marker in (("MIGRATION_17_18", "MIGRATION_18_19"), ("MIGRATION_18_19", "@Volatile private var INSTANCE")):
    for sql in extract_migration(migration, next_marker):
        con.execute(sql)

# Legacy-only summary query text is compiled and executed against the migrated fixture.
query_pattern = re.compile(r'@Query\(\s*(?:"""(.*?)"""|"([^"]*)")\s*\)\s*(?:suspend\s+)?fun\s+(\w+)', re.S)
queries = {}
for match in query_pattern.finditer(source):
    query = (match.group(1) or match.group(2) or "").strip()
    name = match.group(3)
    if name in {
        "observeLegacyHarvestSalesTotal",
        "observeLegacyHarvestCostsTotal",
        "observeLegacyHarvestCollectedTotal",
        "observeLegacyHarvestReceivablesTotal",
        "getActivePersonalHarvestPage",
        "getArchivedPersonalHarvestPage",
        "observeBuyerSalesForPersonalHarvest",
        "observeBuyerPaymentsForPersonalHarvest",
        "observeHarvestDays",
        "observeHarvestDayLinesForHarvest",
    }:
        queries[name] = query

required = {
    "observeLegacyHarvestSalesTotal",
    "observeLegacyHarvestCostsTotal",
    "observeLegacyHarvestCollectedTotal",
    "observeLegacyHarvestReceivablesTotal",
    "getActivePersonalHarvestPage",
    "getArchivedPersonalHarvestPage",
    "observeBuyerSalesForPersonalHarvest",
}
assert required <= queries.keys(), f"Missing DAO queries: {required - queries.keys()}"

bindings = {"limit": 50, "offset": 0, "harvestId": 1, "fromMillis": 0, "untilMillis": 9_999_999_999_999}
for name in required:
    query = queries[name]
    names = set(re.findall(r":([A-Za-z_]\w*)", query))
    params = {key: bindings[key] for key in names}
    con.execute(query, params).fetchall()

# The 1.1.2 fixture has: cash=2,000; seller=5,000; debtor=1,500; buyer net=9,500.
# Linked seller/debtor ledger transactions have sourceDayId>0 and must not be added twice.
sales = con.execute(queries["observeLegacyHarvestSalesTotal"]).fetchone()[0]
costs = con.execute(queries["observeLegacyHarvestCostsTotal"]).fetchone()[0]
collected = con.execute(queries["observeLegacyHarvestCollectedTotal"]).fetchone()[0]
receivables = con.execute(queries["observeLegacyHarvestReceivablesTotal"]).fetchone()[0]
assert sales == 18_000, sales
assert costs == 370, costs
assert collected == 7_000, collected
assert receivables == 10_700, receivables
assert sales - costs == 17_630

# Add unrelated independent-Commerce figures: harvest dashboard totals must remain unchanged.
con.execute("UPDATE commerce_sales SET legacySourceId=123456 WHERE id=(SELECT MIN(id) FROM commerce_sales)")
after = tuple(con.execute(queries[name]).fetchone()[0] for name in (
    "observeLegacyHarvestSalesTotal",
    "observeLegacyHarvestCostsTotal",
    "observeLegacyHarvestCollectedTotal",
    "observeLegacyHarvestReceivablesTotal",
))
assert after == (18_000, 370, 7_000, 10_700), after

# Explicit harvest linking must remain neutral for historical sales unless selected by the user.
linked = con.execute("SELECT COUNT(*) FROM buyer_sales WHERE personalHarvestId=1").fetchone()[0]
assert linked == 0, linked

print("PASS legacy harvest summary DAO SQL executes on the 1.1.2-derived Room 19 fixture")
print(f"PASS sales={sales}, harvest costs={costs}, collected={collected}, receivables owed to us={receivables}")
print("PASS linked seller/debtor daily rows are not double-counted")
print("PASS independent Commerce ledger changes do not affect harvest-section totals")
print("PASS historical buyer sales remain unlinked until explicitly linked")
