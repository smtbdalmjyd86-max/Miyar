#!/usr/bin/env python3
"""Execute Room 16->17 SQLite migration SQL against a representative 1.1.2 fixture.

This validates SQL syntax and selected historical mapping/accounting invariants only.
It is not a replacement for Room migration testing with the actual 1.1.2 database.
"""
from __future__ import annotations

import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = ROOT / "app/src/main/java/com/miyar/app/data/MiyarDatabase.kt"
source = DB_SOURCE.read_text(encoding="utf-8")
block = source.split("private val MIGRATION_16_17", 1)[1].split("private val MIGRATION_17_18", 1)[0]
statements: list[str] = []
for line in block.splitlines():
    match = re.search(r'db\.execSQL\("(.*)"\)\s*$', line.strip())
    if match:
        statements.append(match.group(1).replace(r'\"', '"').replace(r'\\', '\\'))
if not statements:
    raise SystemExit("No migration SQL statements were found.")

con = sqlite3.connect(":memory:")
con.executescript(
    """
    CREATE TABLE plantations(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
    CREATE TABLE personal_harvests(id INTEGER PRIMARY KEY, plantationId INTEGER NOT NULL, name TEXT NOT NULL, startMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, productsText TEXT NOT NULL, cashSalesText TEXT NOT NULL, debtorSalesText TEXT NOT NULL, pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, extraWages INTEGER NOT NULL, bagsAndOther INTEGER NOT NULL, transportAndClearance INTEGER NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL);
    CREATE TABLE harvest_debtors(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL);
    CREATE TABLE qat_buyers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL);
    CREATE TABLE market_distributors(id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL);
    CREATE TABLE buyer_sales(id INTEGER PRIMARY KEY, buyerId INTEGER NOT NULL, harvestName TEXT NOT NULL, agreedAmount INTEGER NOT NULL, initialPaid INTEGER NOT NULL, saleDateMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, discountAmount INTEGER NOT NULL, discountReason TEXT NOT NULL, notes TEXT NOT NULL, plantationId INTEGER NOT NULL);
    CREATE TABLE buyer_payments(id INTEGER PRIMARY KEY, saleId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL);
    CREATE TABLE distributor_transactions(id INTEGER PRIMARY KEY, distributorId INTEGER NOT NULL, harvestId INTEGER NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, received INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL, sourceDayId INTEGER NOT NULL, sourceLineId INTEGER NOT NULL, calculatedTotal INTEGER NOT NULL, isTotalManual INTEGER NOT NULL, isValueComplete INTEGER NOT NULL);
    CREATE TABLE harvest_debtor_transactions(id INTEGER PRIMARY KEY, debtorId INTEGER NOT NULL, harvestId INTEGER NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, paid INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL, sourceDayId INTEGER NOT NULL, sourceLineId INTEGER NOT NULL, calculatedTotal INTEGER NOT NULL, isTotalManual INTEGER NOT NULL, isValueComplete INTEGER NOT NULL);
    CREATE TABLE personal_harvest_days(id INTEGER PRIMARY KEY, harvestId INTEGER NOT NULL, dateMillis INTEGER NOT NULL, pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, otherExpenses INTEGER NOT NULL, notes TEXT NOT NULL, pickerWagesCalculated INTEGER NOT NULL, pickerWagesManual INTEGER, pickerCountEntered INTEGER NOT NULL, pickerWageEntered INTEGER NOT NULL, otherExpensesEntered INTEGER NOT NULL);
    CREATE TABLE personal_harvest_day_lines(id INTEGER PRIMARY KEY, dayId INTEGER NOT NULL, category TEXT NOT NULL, partyName TEXT NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, createdAt INTEGER NOT NULL, accountTransactionId INTEGER NOT NULL, calculatedTotal INTEGER NOT NULL, isTotalManual INTEGER NOT NULL, isValueComplete INTEGER NOT NULL);
    CREATE TABLE harvest_party_payments(id INTEGER PRIMARY KEY, partyType TEXT NOT NULL, partyId INTEGER NOT NULL, transactionId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL, idempotencyKey TEXT NOT NULL);
    CREATE TABLE distributor_transaction_adjustments(id INTEGER PRIMARY KEY, transactionId INTEGER NOT NULL, kind TEXT NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, description TEXT NOT NULL, notes TEXT NOT NULL, idempotencyKey TEXT NOT NULL, createdAtMillis INTEGER NOT NULL);
    CREATE TABLE miyar_audit_events(id INTEGER PRIMARY KEY AUTOINCREMENT, entityType TEXT NOT NULL, entityId INTEGER NOT NULL, eventType TEXT NOT NULL, occurredAtMillis INTEGER NOT NULL, beforeSnapshot TEXT NOT NULL, afterSnapshot TEXT NOT NULL, source TEXT NOT NULL, referenceId INTEGER NOT NULL);

    INSERT INTO plantations VALUES(1,'Plot');
    INSERT INTO personal_harvests VALUES(1,1,'Personal',100,200,0,'','','',2,100,50,30,20,'note',100);
    INSERT INTO personal_harvest_days VALUES(1,1,110,2,100,70,'day',200,NULL,1,1,1);
    INSERT INTO qat_buyers VALUES(1,'Buyer','777','');
    INSERT INTO harvest_debtors VALUES(1,'Debtor','778','');
    INSERT INTO market_distributors VALUES(1,'Distributor','779','');
    INSERT INTO buyer_sales VALUES(1,1,'Sold harvest',10000,2000,120,180,0,500,'discount','',1);
    INSERT INTO buyer_payments VALUES(1,1,1000,130,'cash','later');
    INSERT INTO distributor_transactions VALUES(1,1,1,'عود',10,500,5000,1000,120,'',1,2,5000,0,1);
    INSERT INTO harvest_debtor_transactions VALUES(1,1,1,'مدبوش',5,300,1500,500,120,'',1,3,1500,0,1);
    INSERT INTO personal_harvest_day_lines VALUES(1,1,'cash','cash buyer','عود',5,400,2000,115,0,2000,0,1);
    -- These linked child lines must not be migrated again as separate sales.
    INSERT INTO personal_harvest_day_lines VALUES(2,1,'distributor','Distributor','عود',10,500,5000,116,1,5000,0,1);
    INSERT INTO personal_harvest_day_lines VALUES(3,1,'debt','Debtor','مدبوش',5,300,1500,117,1,1500,0,1);
    INSERT INTO harvest_party_payments VALUES(1,'DISTRIBUTOR',1,1,500,125,'cash','','k1');
    INSERT INTO distributor_transaction_adjustments VALUES(1,1,'SELLER_DISCOUNT',200,122,'discount','', 'a1',122);
    INSERT INTO distributor_transaction_adjustments VALUES(2,1,'DISTRIBUTION_EXPENSE',100,123,'transport','', 'a2',123);
    """
)

for index, sql in enumerate(statements, start=1):
    try:
        con.execute(sql)
    except Exception as exc:  # print the exact failing SQL for the Actions log
        raise RuntimeError(f"Migration SQL #{index} failed:\n{sql}\n{exc}") from exc

# Migration completeness and key relationship checks.
expected_counts = {
    "commerce_parties": 3,
    "commerce_party_roles": 3,
    "commerce_harvests": 2,
    "commerce_harvest_days": 1,
    "commerce_sales": 4,  # whole harvest + distributor + debtor + cash; linked day children excluded
    "commerce_sale_lines": 4,
    "commerce_payments": 5,
    "commerce_payment_allocations": 5,
    "commerce_harvest_cost_items": 3,
    "commerce_settlements": 1,
}
for table, expected in expected_counts.items():
    actual = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    assert actual == expected, f"{table}: expected {expected}, found {actual}"

whole_sale = con.execute(
    "SELECT grossCalculated,discountAmount,netAmount FROM commerce_sales WHERE legacySourceTable='buyer_sales'"
).fetchone()
assert whole_sale == (10_000, 500, 9_500), whole_sale
whole_paid = con.execute(
    "SELECT SUM(a.amount) FROM commerce_payment_allocations a JOIN commerce_sales s ON s.id=a.saleId WHERE s.legacySourceTable='buyer_sales'"
).fetchone()[0]
assert whole_paid == 3_000, whole_paid

# Old day id 1 must map to the generated commerce day id and be referenced consistently.
commerce_day_id = con.execute(
    "SELECT id FROM commerce_harvest_days WHERE legacySourceTable='personal_harvest_days' AND legacySourceId=1"
).fetchone()[0]
for legacy_table in ("distributor_transactions", "harvest_debtor_transactions"):
    mapped_day_id = con.execute(
        "SELECT harvestDayId FROM commerce_sales WHERE legacySourceTable=? AND legacySourceId=1", (legacy_table,)
    ).fetchone()[0]
    assert mapped_day_id == commerce_day_id, (legacy_table, mapped_day_id, commerce_day_id)

# Linked day lines do not create duplicate sales; the cash day line remains a separate sale.
assert con.execute("SELECT COUNT(*) FROM commerce_sales WHERE legacySourceTable='personal_harvest_day_lines'").fetchone()[0] == 1
assert con.execute("SELECT partyRole,netAmount FROM commerce_sales WHERE legacySourceTable='distributor_transactions'").fetchone() == ("DISTRIBUTOR", 4_800)
assert con.execute(
    "SELECT COALESCE(SUM(amount),0) FROM commerce_payment_allocations a JOIN commerce_sales s ON s.id=a.saleId WHERE s.legacySourceTable='distributor_transactions'"
).fetchone()[0] == 1_500
assert con.execute(
    "SELECT COALESCE(SUM(amount),0) FROM commerce_payment_allocations a JOIN commerce_sales s ON s.id=a.saleId WHERE s.legacySourceTable='harvest_debtor_transactions'"
).fetchone()[0] == 500

# Distribution is both a harvest cost and a settlement reducing distributor receivable,
# but there is one source adjustment and it must not be inserted as a second payment.
assert con.execute("SELECT amount FROM commerce_settlements WHERE legacySourceTable='distributor_transaction_adjustments'").fetchone()[0] == 100
assert con.execute("SELECT COUNT(*) FROM commerce_payments WHERE legacySourceTable='distributor_transaction_adjustments'").fetchone()[0] == 0
cost_rows = con.execute("SELECT costType,amount FROM commerce_harvest_cost_items ORDER BY id").fetchall()
assert cost_rows == [("PICKER_WAGES", 200), ("OTHER", 70), ("DISTRIBUTION", 100)], cost_rows

# Preserve historical tables; the migration is additive.
for table in ("personal_harvests", "personal_harvest_days", "personal_harvest_day_lines", "buyer_sales", "buyer_payments", "distributor_transactions", "harvest_debtor_transactions"):
    assert con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone(), table

# Smoke-test every SQL query currently touching commerce_* tables against the migrated schema.
query_pattern = re.compile(r'@Query\(\s*(?:"""(.*?)"""|"([^"]*)")\s*\)\s*(?:suspend\s+)?fun\s+(\w+)', re.S)
query_count = 0
for match in query_pattern.finditer(source):
    query = (match.group(1) or match.group(2) or "").strip()
    method_name = match.group(3)
    if "commerce_" not in query:
        continue
    parameter_names = set(re.findall(r":([A-Za-z_]\w*)", query))
    bindings = {
        name: (100 if name == "limit" else ("" if name == "search" else 0))
        for name in parameter_names
    }
    try:
        con.execute(query, bindings).fetchall()
    except Exception as exc:
        raise RuntimeError(f"Commerce DAO query {method_name} failed against migrated schema:\n{query}\n{exc}") from exc
    query_count += 1
assert query_count >= 30, f"Expected broad commerce DAO SQL coverage, found {query_count} queries"

print(f"PASS: executed {len(statements)} Room 16->17 SQL statements")
print(f"PASS: exercised {query_count} commerce DAO SQL queries against the migrated schema")
for table in expected_counts:
    print(f"  {table}: {con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]}")
print("  buyer sale net / collected: 9500 / 3000 (expected outstanding: 6500)")
print("  distributor sale net / collected / distribution deduction: 4800 / 1500 / 100")
print("  legacy harvest day remapping: correct; linked child lines: no duplicate sale")
print("  legacy tables: preserved")
