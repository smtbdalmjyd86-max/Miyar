#!/usr/bin/env python3
"""Exercise the legacy harvest-only Room 17->18->19 migrations.

The fixture intentionally includes commerce sentinel rows. The two migrations
must preserve them untouched and must not copy or merge commerce data into the
legacy harvest section.
"""
from __future__ import annotations
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = ROOT / "app/src/main/java/com/miyar/app/data/MiyarDatabase.kt"
source = DB_SOURCE.read_text(encoding="utf-8")

def migration_statements(name: str, next_name: str) -> list[str]:
    block = source.split(f"private val {name}", 1)[1].split(f"private val {next_name}", 1)[0]
    statements: list[str] = []
    for line in block.splitlines():
        match = re.search(r'db\.execSQL\("(.*)"\)\s*$', line.strip())
        if match:
            statements.append(match.group(1).replace(r'\"', '"').replace(r'\\', '\\'))
    if not statements:
        raise AssertionError(f"No SQL statements found for {name}")
    return statements

m17_18 = migration_statements("MIGRATION_17_18", "MIGRATION_18_19")
m18_19 = migration_statements("MIGRATION_18_19", "@Volatile private var INSTANCE")

con = sqlite3.connect(":memory:")
con.executescript("""
CREATE TABLE personal_harvests(
 id INTEGER PRIMARY KEY, plantationId INTEGER NOT NULL, name TEXT NOT NULL,
 startMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL,
 productsText TEXT NOT NULL, cashSalesText TEXT NOT NULL, debtorSalesText TEXT NOT NULL,
 pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, extraWages INTEGER NOT NULL,
 bagsAndOther INTEGER NOT NULL, transportAndClearance INTEGER NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL
);
CREATE TABLE personal_harvest_day_lines(
 id INTEGER PRIMARY KEY, dayId INTEGER NOT NULL, category TEXT NOT NULL, partyName TEXT NOT NULL,
 productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL,
 createdAt INTEGER NOT NULL, accountTransactionId INTEGER NOT NULL, calculatedTotal INTEGER NOT NULL,
 isTotalManual INTEGER NOT NULL, isValueComplete INTEGER NOT NULL
);
CREATE TABLE harvest_party_payments(
 id INTEGER PRIMARY KEY, partyType TEXT NOT NULL, partyId INTEGER NOT NULL, transactionId INTEGER NOT NULL,
 amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL,
 idempotencyKey TEXT NOT NULL
);
CREATE TABLE buyer_sales(
 id INTEGER PRIMARY KEY, buyerId INTEGER NOT NULL, harvestName TEXT NOT NULL,
 agreedAmount INTEGER NOT NULL, initialPaid INTEGER NOT NULL, saleDateMillis INTEGER NOT NULL,
 expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, discountAmount INTEGER NOT NULL,
 discountReason TEXT NOT NULL, notes TEXT NOT NULL, plantationId INTEGER NOT NULL
);
CREATE TABLE personal_harvest_days(
 id INTEGER PRIMARY KEY, harvestId INTEGER NOT NULL, dateMillis INTEGER NOT NULL,
 pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, otherExpenses INTEGER NOT NULL,
 notes TEXT NOT NULL, pickerWagesCalculated INTEGER NOT NULL, pickerWagesManual INTEGER,
 pickerCountEntered INTEGER NOT NULL, pickerWageEntered INTEGER NOT NULL, otherExpensesEntered INTEGER NOT NULL
);
CREATE TABLE miyar_audit_events(
 id INTEGER PRIMARY KEY AUTOINCREMENT, entityType TEXT NOT NULL, entityId INTEGER NOT NULL,
 eventType TEXT NOT NULL, occurredAtMillis INTEGER NOT NULL, beforeSnapshot TEXT NOT NULL,
 afterSnapshot TEXT NOT NULL, source TEXT NOT NULL, referenceId INTEGER NOT NULL
);
CREATE TABLE commerce_sales(id INTEGER PRIMARY KEY, legacySourceId INTEGER NOT NULL);
INSERT INTO personal_harvests VALUES(7,2,'قطفة محفوظة',100,200,0,'','','',3,400,20,30,40,'old note',150);
INSERT INTO personal_harvest_day_lines VALUES(9,8,'distributor','بائع قديم','عود',4,250,1000,160,12,1000,0,1);
INSERT INTO harvest_party_payments VALUES(5,'DISTRIBUTOR',3,12,150,170,'نقدًا','دفعة سابقة','old-key');
INSERT INTO buyer_sales VALUES(11,4,'قطفة مشتراة',5000,1000,160,210,0,100,'خصم','',2);
INSERT INTO personal_harvest_days VALUES(8,7,160,3,400,90,'day note',1200,NULL,1,1,1);
INSERT INTO commerce_sales VALUES(55,999);
""")

for name, statements in (("MIGRATION_17_18", m17_18), ("MIGRATION_18_19", m18_19)):
    for i, sql in enumerate(statements, 1):
        try:
            con.execute(sql)
        except Exception as exc:
            raise RuntimeError(f"{name} SQL #{i} failed:\n{sql}\n{exc}") from exc

assert con.execute("SELECT closedAtMillis FROM personal_harvests WHERE id=7").fetchone() == (0,)
assert con.execute("SELECT operationGroupKey FROM personal_harvest_day_lines WHERE id=9").fetchone() == ("",)
assert con.execute("SELECT paymentGroupKey FROM harvest_party_payments WHERE id=5").fetchone() == ("",)
assert con.execute("SELECT personalHarvestId FROM buyer_sales WHERE id=11").fetchone() == (0,)
assert con.execute("SELECT name,total FROM personal_harvests JOIN personal_harvest_day_lines ON personal_harvests.id=7 WHERE personal_harvest_day_lines.id=9").fetchone()[0] == "قطفة محفوظة"
assert con.execute("SELECT amount FROM harvest_party_payments WHERE id=5").fetchone() == (150,)
assert con.execute("SELECT legacySourceId FROM commerce_sales WHERE id=55").fetchone() == (999,)

indexes = {row[1] for row in con.execute("PRAGMA index_list('buyer_sales')")}
assert "index_buyer_sales_personalHarvestId" in indexes
indexes = {row[1] for row in con.execute("PRAGMA index_list('personal_harvest_day_lines')")}
assert "index_personal_harvest_day_lines_operationGroupKey" in indexes
indexes = {row[1] for row in con.execute("PRAGMA index_list('harvest_party_payments')")}
assert "index_harvest_party_payments_paymentGroupKey" in indexes

audit = con.execute("SELECT entityId,eventType FROM miyar_audit_events ORDER BY id").fetchall()
assert audit == [(18, "MIGRATE_17_18"), (19, "MIGRATE_18_19")], audit

print(f"PASS: Room 17->18 executed {len(m17_18)} SQL statements")
print(f"PASS: Room 18->19 executed {len(m18_19)} SQL statements")
print("PASS: existing personal harvest, day-line, payment, and buyer-sale rows remain intact")
print("PASS: old rows receive neutral defaults and are not falsely linked to new group/harvest identities")
print("PASS: required indexes and migration audit events are present")
print("PASS: commerce ledger sentinel remained unchanged and outside the harvest migration")
