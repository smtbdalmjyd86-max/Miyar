package com.miyar.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CommerceCalculationsTest {
    @Test fun saleLinesUseExactIntegerMultiplication() {
        assertEquals(12_500L, CommerceCalculations.lineTotal(5L, 2_500L))
        assertThrows(ArithmeticException::class.java) { CommerceCalculations.lineTotal(Long.MAX_VALUE, 2L) }
    }

    @Test fun saleNetIsGrossLessDiscountOnly() {
        assertEquals(90_000L, CommerceCalculations.netAmount(100_000L, 10_000L))
        assertThrows(IllegalArgumentException::class.java) { CommerceCalculations.netAmount(10L, 11L) }
    }

    @Test fun allocationCannotExceedNetSale() {
        assertEquals(40_000L, CommerceCalculations.remaining(100_000L, 60_000L))
        assertThrows(IllegalArgumentException::class.java) { CommerceCalculations.remaining(100L, 101L) }
    }

    @Test fun productNameNormalizationRemovesSpacingAndArabicMarks() {
        assertEquals("مدبوش", CommerceCalculations.normalizeProductName("  مُدبـوش   "))
    }
}
