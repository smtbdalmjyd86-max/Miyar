@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.miyar.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private data class CommerceLineState(
    val productName: String = "عود",
    val unit: String = "وحدة",
    val quantity: String = "1",
    val unitPrice: String = ""
)

private fun commerceDate(value: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(value))
private fun commerceMoney(value: Long): String = formatMoney(value).replace("ر.ي", "ريال")
private fun parseCommerceLong(value: String): Long? = latinDigitsOnly(value).trim().takeIf { it.isNotEmpty() }?.toLongOrNull()

@Composable
fun MiyarCommerceHubScreen(
    dao: MiyarDao,
    plantations: List<PlantationEntity>,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var page by rememberSaveable { mutableStateOf("home") }
    var selectedPartyId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selectedSaleId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selectedHarvestId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selectedHarvestDayId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showNewHarvest by rememberSaveable { mutableStateOf(false) }
    var showNewHarvestDay by rememberSaveable { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    val sales by dao.observeCommerceSalePage(limit = 250, offset = 0).collectAsStateWithLifecycle(emptyList())
    val deletedSales by dao.observeDeletedCommerceSalePage(limit = 100, offset = 0).collectAsStateWithLifecycle(emptyList())
    val parties by dao.observeCommercePartyPage(limit = 250, offset = 0).collectAsStateWithLifecycle(emptyList())
    val harvests by dao.observeCommerceHarvestPage(limit = 300, offset = 0).collectAsStateWithLifecycle(emptyList())
    val products by dao.observeCommerceProducts(limit = 100).collectAsStateWithLifecycle(emptyList())
    val currencyTotals by dao.observeCommerceCurrencyTotals().collectAsStateWithLifecycle(emptyList())
    val harvestCount by dao.observeCommerceHarvestCount().collectAsStateWithLifecycle(0L)
    val partyCount by dao.observeCommercePartyCount().collectAsStateWithLifecycle(0L)
    val selectedParty by dao.observeCommercePartyById(selectedPartyId ?: -1L).collectAsStateWithLifecycle(null)
    val selectedSale by dao.observeCommerceSaleById(selectedSaleId ?: -1L).collectAsStateWithLifecycle(null)

    fun goBack() {
        page = when (page) {
            "newSale", "sales", "parties", "harvests", "deletedSales" -> "home"
            "partyDetail" -> "parties"
            "harvestDetail" -> "harvests"
            "saleDetail" -> when { selectedPartyId != null -> "partyDetail"; selectedHarvestId != null -> "harvestDetail"; else -> "sales" }
            else -> "home"
        }
        if (page == "home") { selectedPartyId = null; selectedSaleId = null }
    }
    BackHandler(enabled = page != "home") { goBack() }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Emerald).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (page == "home") onBack() else goBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "عودة", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("مِعيار | مركز القطفات والمبيعات", color = Color.White, fontWeight = FontWeight.Bold)
                Text(when (page) {
                    "newSale" -> "عملية بيع جديدة"
                    "sales" -> "سجل عمليات البيع"
                    "parties" -> "ملفات الأطراف"
                    "partyDetail" -> selectedParty?.displayName ?: "ملف الطرف"
                    "saleDetail" -> selectedSale?.saleNumber ?: "تفاصيل البيع"
                    "harvests" -> "سجل القطفات الفعلية"
                    "harvestDetail" -> harvests.firstOrNull { it.id == selectedHarvestId }?.name ?: "تفاصيل القطفة"
                    "deletedSales" -> "المبيعات المحذوفة والاستعادة"
                    else -> "إدارة أدق، ومردود أوضح"
                }, color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelSmall)
            }
            Text("1.1.4", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        when (page) {
            "home" -> Column(
                Modifier.fillMaxSize().background(Color(0xFFF5F8F5)).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("ملخص المبيعات", color = Emerald, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                if (currencyTotals.isEmpty()) {
                    Text("لا توجد مبيعات مسجلة في الدفتر الجديد بعد.", color = Color.Gray)
                } else {
                    currencyTotals.forEach { total ->
                        Text("إجماليات العملة ${total.currency}", color = Emerald, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CommerceMetric("صافي المبيعات", commerceMoney(total.netTotal), Color(0xFFE7F2EC), Modifier.weight(1f))
                            CommerceMetric("المحصل", commerceMoney(total.collectedTotal), Color(0xFFE7F0FC), Modifier.weight(1f))
                            CommerceMetric("المتبقي", commerceMoney(total.outstandingTotal), Color(0xFFFFF1DF), Modifier.weight(1f))
                        }
                    }
                }
                val incompleteCount = currencyTotals.sumOf { it.incompleteCount }
                if (incompleteCount > 0) Text("هناك $incompleteCount عملية بقيم غير مكتملة؛ لا تدخل في إجمالي المبيعات المؤكدة.", color = Color(0xFF9A5A00), style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CommerceMetric("القطفات الفعلية", harvestCount.toString(), Color(0xFFEAE7F8), Modifier.weight(1f))
                    CommerceMetric("ملفات الأطراف", partyCount.toString(), Color(0xFFF1EAF8), Modifier.weight(1f))
                }
                Button(onClick = { selectedHarvestId = null; selectedHarvestDayId = null; page = "newSale" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("عملية بيع جديدة", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = { page = "harvests" }, modifier = Modifier.fillMaxWidth()) { Text("إدخال يوم قطف / سجل القطفات") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CommerceAction("سجل المبيعات", "${sales.size} عملية", Modifier.weight(1f)) { page = "sales" }
                    CommerceAction("العملاء والمشترون", "ملفات محملة: ${parties.size}", Modifier.weight(1f)) { page = "parties" }
                }
                OutlinedButton(onClick = { page = "deletedSales" }, modifier = Modifier.fillMaxWidth()) { Text("المبيعات المحذوفة والاستعادة (${deletedSales.size})") }
                Text("أحدث العمليات", color = Emerald, fontWeight = FontWeight.Bold)
                if (sales.isEmpty()) Text("لا توجد عمليات في سجل المبيعات الجديد بعد. بقيت سجلات الإصدار السابق محفوظة في صفحاتها القديمة.", color = Color.DarkGray)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
                    items(sales.take(8), key = { it.id }) { sale ->
                        CommerceSaleCard(sale, onClick = { selectedSaleId = sale.id; page = "saleDetail" })
                    }
                }
            }

            "newSale" -> NewCommerceSaleScreen(
                dao = dao, plantations = plantations, parties = parties, harvests = harvests, products = products,
                initialHarvestId = selectedHarvestId.takeIf { page == "newSale" && it != null },
                initialHarvestDayId = selectedHarvestDayId.takeIf { page == "newSale" && it != null },
                onSaved = { id -> selectedSaleId = id; selectedPartyId = null; page = "saleDetail"; notice = "تم حفظ عملية البيع والدفعة الأولى ضمن معاملة واحدة." },
                onCancel = { page = if (selectedHarvestId != null) "harvestDetail" else "home" }, onMessage = { notice = it }
            )

            "sales" -> {
                var search by rememberSaveable { mutableStateOf("") }
                var offset by rememberSaveable { mutableStateOf(0) }
                val searchedSales by dao.observeCommerceSaleSearchPage(search.trim(), 100, offset).collectAsStateWithLifecycle(emptyList())
                Column(Modifier.fillMaxSize().padding(12.dp)) {
                    OutlinedTextField(search, { search = it; offset = 0 }, modifier = Modifier.fillMaxWidth(), label = { Text("بحث برقم العملية أو اسم المشتري") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                        items(searchedSales, key = { it.id }) { sale -> CommerceSaleCard(sale, onClick = { selectedSaleId = sale.id; selectedPartyId = sale.partyId; page = "saleDetail" }) }
                        if (searchedSales.isEmpty()) item { Text("لا توجد نتائج مطابقة.", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        OutlinedButton(onClick = { offset = (offset - 100).coerceAtLeast(0) }, enabled = offset > 0) { Text("السابق") }
                        Text("صفحة ${offset / 100 + 1}", modifier = Modifier.align(Alignment.CenterVertically), color = Color.Gray)
                        Button(onClick = { offset += 100 }, enabled = searchedSales.size == 100) { Text("التالي") }
                    }
                }
            }

            "parties" -> {
                var search by rememberSaveable { mutableStateOf("") }
                var offset by rememberSaveable { mutableStateOf(0) }
                val searchedParties by dao.observeCommercePartySearch(search.trim(), 100, offset).collectAsStateWithLifecycle(emptyList())
                Column(Modifier.fillMaxSize().padding(12.dp)) {
                    OutlinedTextField(search, { search = it; offset = 0 }, modifier = Modifier.fillMaxWidth(), label = { Text("ابحث بالاسم أو الهاتف") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                        items(searchedParties, key = { it.id }) { party ->
                            Card(onClick = { selectedPartyId = party.id; page = "partyDetail" }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F6F1))) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(party.displayName, color = Emerald, fontWeight = FontWeight.Bold)
                                        Text(party.phone.ifBlank { "لا يوجد رقم هاتف" }, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                    }
                                    Text("فتح الملف  ›", color = Green, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (searchedParties.isEmpty()) item { Text("لا توجد نتائج مطابقة.", color = Color.Gray) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        OutlinedButton(onClick = { offset = (offset - 100).coerceAtLeast(0) }, enabled = offset > 0) { Text("السابق") }
                        Text("صفحة ${offset / 100 + 1}", modifier = Modifier.align(Alignment.CenterVertically), color = Color.Gray)
                        Button(onClick = { offset += 100 }, enabled = searchedParties.size == 100) { Text("التالي") }
                    }
                }
            }

            "partyDetail" -> selectedParty?.let { party ->
                var selectedRole by remember(party.id) { mutableStateOf("CUSTOMER") }
                var salesOffset by rememberSaveable(party.id) { mutableIntStateOf(0) }
                var paymentsOffset by rememberSaveable(party.id) { mutableIntStateOf(0) }
                var historyTab by rememberSaveable(party.id) { mutableStateOf("SALES") }
                val partyRoles by dao.observeCommercePartyRoles(party.id).collectAsStateWithLifecycle(emptyList())
                LaunchedEffect(party.id, partyRoles) {
                    if (partyRoles.isNotEmpty() && partyRoles.none { it.role == selectedRole }) {
                        selectedRole = partyRoles.first().role
                        salesOffset = 0
                        paymentsOffset = 0
                    }
                }
                val roleTotals by dao.observeCommercePartyRoleTotals(party.id, selectedRole).collectAsStateWithLifecycle(emptyList())
                val partySales by dao.observeCommercePartySales(party.id, selectedRole, 100, salesOffset).collectAsStateWithLifecycle(emptyList())
                val payments by dao.observeCommercePartyPayments(party.id, selectedRole, 100, paymentsOffset).collectAsStateWithLifecycle(emptyList())
                Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(party.displayName, color = Emerald, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${party.phone.ifBlank { "لا يوجد هاتف" }}  •  ملف دائم للطرف", color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        partyRoles.forEach { roleItem ->
                            val label = when (roleItem.role) { "DISTRIBUTOR" -> "حساب الموزع"; "SUPPLIER" -> "حساب المورد"; else -> "حساب المشتري" }
                            FilterChip(selected = selectedRole == roleItem.role, onClick = {
                                selectedRole = roleItem.role; salesOffset = 0; paymentsOffset = 0
                            }, label = { Text(label) })
                        }
                    }
                    roleTotals.forEach { total ->
                        Text("إجمالي الحساب (${total.currency}) • ${total.saleCount} عملية", color = Emerald, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            CommerceMetric("المبيعات المؤكدة", commerceMoney(total.netTotal), Color(0xFFE7F2EC), Modifier.weight(1f))
                            CommerceMetric("المحصل", commerceMoney(total.collectedTotal), Color(0xFFE7F0FC), Modifier.weight(1f))
                            CommerceMetric("المتبقي", commerceMoney(total.outstandingTotal), Color(0xFFFFF1DF), Modifier.weight(1f))
                        }
                        if (total.incompleteCount > 0) Text("${total.incompleteCount} عملية بقيمة غير مكتملة لا تدخل في رصيد المبيعات المؤكد.", color = Color(0xFF9A5A00), style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = historyTab == "SALES", onClick = { historyTab = "SALES" }, label = { Text("المبيعات") })
                        FilterChip(selected = historyTab == "PAYMENTS", onClick = { historyTab = "PAYMENTS" }, label = { Text("الدفعات") })
                    }
                    if (historyTab == "SALES") {
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(partySales, key = { it.id }) { sale -> CommerceSaleCard(sale, onClick = { selectedSaleId = sale.id; selectedPartyId = party.id; page = "saleDetail" }) }
                            if (partySales.isEmpty()) item { Text("لا توجد مبيعات في هذا الحساب بعد.", color = Color.Gray) }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            OutlinedButton(onClick = { salesOffset = (salesOffset - 100).coerceAtLeast(0) }, enabled = salesOffset > 0) { Text("السابق") }
                            Text("صفحة ${salesOffset / 100 + 1}", modifier = Modifier.align(Alignment.CenterVertically), color = Color.Gray)
                            Button(onClick = { salesOffset += 100 }, enabled = partySales.size == 100) { Text("التالي") }
                        }
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(payments, key = { it.id }) { payment ->
                                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) { Text(commerceMoney(payment.amount), fontWeight = FontWeight.Bold); Text("${commerceDate(payment.dateMillis)} • ${payment.method}", style = MaterialTheme.typography.labelSmall) } }
                            }
                            if (payments.isEmpty()) item { Text("لا توجد دفعات مرتبطة بهذا الحساب بعد.", color = Color.Gray) }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            OutlinedButton(onClick = { paymentsOffset = (paymentsOffset - 100).coerceAtLeast(0) }, enabled = paymentsOffset > 0) { Text("السابق") }
                            Text("صفحة ${paymentsOffset / 100 + 1}", modifier = Modifier.align(Alignment.CenterVertically), color = Color.Gray)
                            Button(onClick = { paymentsOffset += 100 }, enabled = payments.size == 100) { Text("التالي") }
                        }
                    }
                }
            } ?: Text("تعذر العثور على ملف الطرف.")

            "saleDetail" -> selectedSaleId?.let { id ->
                val sale = selectedSale
                val lines by dao.observeCommerceSaleLines(id).collectAsStateWithLifecycle(emptyList())
                var saleEntity by remember(id) { mutableStateOf<CommerceSaleEntity?>(null) }
                LaunchedEffect(id) { saleEntity = dao.getCommerceSale(id) }
                var showPayment by remember(id) { mutableStateOf(false) }
                var showEdit by remember(id) { mutableStateOf(false) }
                var showDeleteConfirm by remember(id) { mutableStateOf(false) }
                Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (sale != null) {
                        Text("${sale.saleNumber} • ${sale.partyName ?: "بيع نقدي"}", color = Emerald, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                        Text("${commerceDate(sale.dateMillis)} • ${sale.transactionType} • ${sale.currency}", color = Color.Gray)
                        if (!sale.isValueComplete) Text("قيمة غير مكتملة — لا تدخل في إجمالي المردود المؤكد", color = Color(0xFF9A5A00), fontWeight = FontWeight.Bold)
                        if (sale.settlementDeductions > 0) Text("تسويات وخصومات على الحساب: ${commerceMoney(sale.settlementDeductions)}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            CommerceMetric("صافي البيع", commerceMoney(sale.netAmount), Color(0xFFE7F2EC), Modifier.weight(1f))
                            CommerceMetric("المحصل", commerceMoney(sale.collected), Color(0xFFE7F0FC), Modifier.weight(1f))
                        }
                        CommerceMetric("المتبقي", commerceMoney(sale.remaining), Color(0xFFFFF1DF), Modifier.fillMaxWidth())
                        Text("المنتجات", color = Emerald, fontWeight = FontWeight.Bold)
                        lines.forEach { line ->
                            Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(line.productName, fontWeight = FontWeight.Bold); Text("${line.quantity} ${line.unit} × ${commerceMoney(line.unitPrice)}", style = MaterialTheme.typography.bodySmall) }
                                Text(commerceMoney(line.total), color = Emerald, fontWeight = FontWeight.Bold)
                            } }
                        }
                        OutlinedButton(onClick = { showEdit = true }, modifier = Modifier.fillMaxWidth(), enabled = saleEntity != null) { Text("تعديل بيانات البيع والمنتجات") }
                        Button(onClick = { showPayment = true }, enabled = sale.remaining > 0, modifier = Modifier.fillMaxWidth()) { Text("تسجيل دفعة") }
                        OutlinedButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("حذف العملية حذفاً منطقياً") }
                    } else {
                        Text("هذه العملية لم تعد ضمن النتائج النشطة أو لم يتم تحميلها بعد.", color = Color.Gray)
                    }
                }
                if (showEdit && saleEntity != null) CommerceEditSaleDialog(
                    sale = saleEntity!!,
                    initialLines = lines,
                    onDismiss = { showEdit = false },
                    onSave = { drafts, discount, reason, editNotes ->
                        scope.launch {
                            runCatching { dao.updateCommerceSale(id, drafts, discount, reason, editNotes) }
                                .onSuccess { notice = "تم تعديل عملية البيع مع الاحتفاظ بالدفعات وسجل التعديل."; saleEntity = dao.getCommerceSale(id) }
                                .onFailure { notice = it.message ?: "تعذر تعديل عملية البيع." }
                            showEdit = false
                        }
                    }
                )
                if (showPayment && sale != null) CommercePaymentDialog(
                    sale = sale,
                    onDismiss = { showPayment = false },
                    onSave = { amount, method ->
                        scope.launch {
                            runCatching {
                                dao.addCommercePayment(id, amount, sale.currency, System.currentTimeMillis(), method, "دفعة من ملف العملية", "payment-${UUID.randomUUID()}")
                            }.onSuccess { notice = "تم تسجيل الدفعة وربطها بعملية البيع." }
                             .onFailure { notice = it.message ?: "تعذر تسجيل الدفعة." }
                            showPayment = false
                        }
                    }
                )
                if (showDeleteConfirm && sale != null) AlertDialog(
                    onDismissRequest = { showDeleteConfirm = false },
                    title = { Text("تأكيد حذف العملية") },
                    text = { Text("سيتم إخفاء العملية من السجلات النشطة مع الاحتفاظ بكل الدفعات والربط وسجل مِعيار. يمكنك استعادتها من قسم المحذوفات دون إنشاء دفعات جديدة.") },
                    confirmButton = { TextButton(onClick = {
                        scope.launch {
                            runCatching { dao.softDeleteCommerceSale(id) }
                                .onSuccess { notice = "تم حذف العملية من السجل النشط." }
                                .onFailure { notice = it.message ?: "تعذر حذف العملية." }
                            showDeleteConfirm = false; page = when { selectedPartyId != null -> "partyDetail"; selectedHarvestId != null -> "harvestDetail"; else -> "sales" }
                        }
                    }) { Text("حذف") } },
                    dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("إلغاء") } }
                )
            } ?: Text("اختر عملية بيع.")

            "deletedSales" -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                Text("المبيعات المحذوفة", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("السجلات مخفية من الإجماليات النشطة، لكن تفاصيلها ودفعاتها محفوظة. الاستعادة تعيد السجل إلى الحسابات دون إعادة إدخال أي دفعة.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(deletedSales, key = { it.id }) { deleted ->
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                CommerceSaleCard(deleted, onClick = {})
                                Button(onClick = {
                                    scope.launch {
                                        runCatching { dao.restoreCommerceSale(deleted.id) }
                                            .onSuccess { notice = "تمت استعادة العملية وربطها بالدفعات التاريخية المحفوظة." }
                                            .onFailure { notice = it.message ?: "تعذرت استعادة العملية." }
                                    }
                                }, modifier = Modifier.fillMaxWidth()) { Text("استعادة العملية") }
                            }
                        }
                    }
                    if (deletedSales.isEmpty()) item { Text("لا توجد عمليات محذوفة.", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                }
            }

            "harvests" -> Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("القطفات الفعلية المحفوظة", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("كل ملف قطفة له أيام ومصاريف ومبيعات مرتبطة. عدد الأيام والمبيعات لا يزيد عداد القطفات.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                Button(onClick = { showNewHarvest = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إنشاء ملف قطفة وإدخال أول يوم") }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
                    items(harvests, key = { it.id }) { h ->
                        Card(onClick = { selectedHarvestId = h.id; page = "harvestDetail" }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(h.name, fontWeight = FontWeight.Bold, color = Emerald)
                                Text("${commerceDate(h.dateMillis)} • ${h.harvestType} • ${plantations.firstOrNull { p -> p.id == h.plantationId }?.name ?: "موضع غير محدد"}", style = MaterialTheme.typography.labelSmall)
                                Text("فتح ملف القطفة والتفاصيل  ›", color = Green, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                if (showNewHarvest) CommerceHarvestEntryDialog(
                    title = "ملف قطفة جديد وأول يوم",
                    plantations = plantations,
                    showFileFields = true,
                    onDismiss = { showNewHarvest = false },
                    onSave = { name, plotId, dateMillis, pickerCount, countEntered, unitWage, wageEntered, manualWages, otherCost, notes ->
                        scope.launch {
                            runCatching { dao.createCommerceHarvestWithFirstDay(plotId, name, dateMillis, pickerCount, countEntered, unitWage, wageEntered, manualWages, otherCost, notes) }
                                .onSuccess { id -> selectedHarvestId = id; page = "harvestDetail"; notice = "تم إنشاء ملف القطفة وتسجيل أول يوم وتكاليفه مرة واحدة." }
                                .onFailure { notice = it.message ?: "تعذر إنشاء القطفة." }
                            showNewHarvest = false
                        }
                    }
                )
            }

            "harvestDetail" -> selectedHarvestId?.let { harvestId ->
                val harvest = harvests.firstOrNull { it.id == harvestId }
                val days by dao.observeCommerceHarvestDays(harvestId, 200, 0).collectAsStateWithLifecycle(emptyList())
                val costs by dao.observeCommerceHarvestCosts(harvestId, 300, 0).collectAsStateWithLifecycle(emptyList())
                val harvestSales by dao.observeCommerceHarvestSales(harvestId, 200, 0).collectAsStateWithLifecycle(emptyList())
                val costsTotal by dao.observeCommerceHarvestCostTotal(harvestId).collectAsStateWithLifecycle(0L)
                Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(harvest?.name ?: "ملف القطفة", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("${harvest?.let { commerceDate(it.dateMillis) } ?: ""} • ${plantations.firstOrNull { it.id == harvest?.plantationId }?.name ?: "موضع غير محدد"}", color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CommerceMetric("أيام القطف", days.size.toString(), Color(0xFFE7F0FC), Modifier.weight(1f))
                        CommerceMetric("خرج القطف", commerceMoney(costsTotal), Color(0xFFFFF1DF), Modifier.weight(1f))
                        CommerceMetric("عمليات البيع", harvestSales.size.toString(), Color(0xFFE7F2EC), Modifier.weight(1f))
                    }
                    Button(onClick = { showNewHarvestDay = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة يوم قطف آخر") }
                    Button(onClick = { selectedHarvestDayId = days.firstOrNull()?.id; page = "newSale" }, modifier = Modifier.fillMaxWidth()) { Text("إضافة عملية بيع لهذه القطفة") }
                    Text("أيام القطف", color = Emerald, fontWeight = FontWeight.Bold)
                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(days, key = { it.id }) { day ->
                            val dayCosts = costs.filter { it.harvestDayId == day.id }.sumOf { it.amount }
                            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                                Text(commerceDate(day.dateMillis), color = Emerald, fontWeight = FontWeight.Bold)
                                Text("القطافون: ${if (day.pickerCountEntered) day.pickerCount else "غير محدد"} • خرج اليوم: ${commerceMoney(dayCosts)}", style = MaterialTheme.typography.bodySmall)
                                if (day.notes.isNotBlank()) Text(day.notes, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            } }
                        }
                        item { Text("عمليات البيع المرتبطة", color = Emerald, fontWeight = FontWeight.Bold) }
                        items(harvestSales, key = { it.id }) { sale -> CommerceSaleCard(sale) { selectedSaleId = sale.id; selectedPartyId = sale.partyId; page = "saleDetail" } }
                        item { Text("المصاريف التفصيلية", color = Emerald, fontWeight = FontWeight.Bold) }
                        items(costs, key = { it.id }) { cost -> Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(cost.description); Text(commerceMoney(cost.amount), color = Emerald, fontWeight = FontWeight.Bold) } } }
                    }
                    if (showNewHarvestDay) CommerceHarvestEntryDialog(
                        title = "إضافة يوم قطف",
                        plantations = plantations,
                        showFileFields = false,
                        onDismiss = { showNewHarvestDay = false },
                        onSave = { _, _, dateMillis, pickerCount, countEntered, unitWage, wageEntered, manualWages, otherCost, notes ->
                            scope.launch {
                                runCatching { dao.addCommerceHarvestDay(harvestId, dateMillis, pickerCount, countEntered, unitWage, wageEntered, manualWages, otherCost, notes) }
                                    .onSuccess { notice = "تم تسجيل يوم القطف ومصاريفه دون زيادة عدد القطفات." }
                                    .onFailure { notice = it.message ?: "تعذر إضافة يوم القطف." }
                                showNewHarvestDay = false
                            }
                        }
                    )
                }
            } ?: Text("لم يتم تحديد ملف القطفة.", color = Color.Gray)
        }
    }
    notice?.let { message ->
        AlertDialog(onDismissRequest = { notice = null }, title = { Text("مِعيار") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { notice = null }) { Text("حسناً") } })
    }
}

@Composable
private fun CommerceMetric(title: String, value: String, background: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = background), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Emerald)
            Text(value, style = MaterialTheme.typography.titleMedium, color = Emerald, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun CommerceAction(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) { Text(title, color = Emerald, fontWeight = FontWeight.Bold); Text(subtitle, color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
    }
}

@Composable
private fun CommerceSaleCard(sale: CommerceSaleWithParty, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sale.partyName ?: "بيع نقدي مستقل", modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.Bold)
                Text(if (sale.remaining <= 0) "مكتمل" else "متبقي", color = if (sale.remaining <= 0) Green else Color(0xFFB56A00), style = MaterialTheme.typography.labelSmall)
            }
            Text("${sale.saleNumber} • ${commerceDate(sale.dateMillis)}", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("الصافي ${commerceMoney(sale.netAmount)}", fontWeight = FontWeight.SemiBold)
                Text("المتبقي ${commerceMoney(sale.remaining)}", color = Color(0xFF9A5A00), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun NewCommerceSaleScreen(
    dao: MiyarDao,
    plantations: List<PlantationEntity>,
    parties: List<CommercePartyEntity>,
    harvests: List<CommerceHarvestEntity>,
    products: List<CommerceProductEntity>,
    initialHarvestId: Long? = null,
    initialHarvestDayId: Long? = null,
    onSaved: (Long) -> Unit,
    onCancel: () -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var partyName by rememberSaveable { mutableStateOf("") }
    val matchingParties by dao.observeCommercePartySearch(partyName.trim(), 8, 0).collectAsStateWithLifecycle(emptyList())
    var phone by rememberSaveable { mutableStateOf("") }
    var role by rememberSaveable { mutableStateOf("CUSTOMER") }
    var selectedPartyId by rememberSaveable { mutableStateOf<Long?>(null) }
    val selectedPartyRoles by dao.observeCommercePartyRoles(selectedPartyId ?: -1L).collectAsStateWithLifecycle(emptyList())
    LaunchedEffect(selectedPartyId, selectedPartyRoles) {
        if (selectedPartyId != null && selectedPartyRoles.isNotEmpty() && selectedPartyRoles.none { it.role == role }) {
            role = selectedPartyRoles.first().role
        }
    }
    var selectedPlantationId by rememberSaveable { mutableStateOf(harvests.firstOrNull { it.id == initialHarvestId }?.plantationId) }
    var selectedHarvestId by rememberSaveable { mutableStateOf(initialHarvestId) }
    var selectedHarvestDayId by rememberSaveable { mutableStateOf(initialHarvestDayId) }
    var selectedDateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis)
    val selectedHarvestDays by dao.observeCommerceHarvestDays(selectedHarvestId ?: -1L, 100, 0).collectAsStateWithLifecycle(emptyList())
    var harvestDayExpanded by remember { mutableStateOf(false) }
    var harvestExpanded by remember { mutableStateOf(false) }
    var currency by rememberSaveable { mutableStateOf("YER") }
    var discountText by rememberSaveable { mutableStateOf("0") }
    var discountReason by rememberSaveable { mutableStateOf("") }
    var paidText by rememberSaveable { mutableStateOf("0") }
    var notes by rememberSaveable { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val lines = remember { mutableStateListOf(CommerceLineState()) }
    val lineTotals = lines.map { line ->
        val q = parseCommerceLong(line.quantity)
        val p = parseCommerceLong(line.unitPrice)
        if (q != null && p != null && q > 0) runCatching { CommerceCalculations.lineTotal(q, p) }.getOrNull() else null
    }
    val calculatedGross = lineTotals.filterNotNull().let { values -> runCatching { CommerceCalculations.sumLines(values) }.getOrNull() }
    val discount = parseCommerceLong(discountText) ?: 0L
    val paid = parseCommerceLong(paidText) ?: 0L
    val complete = lineTotals.size == lines.size && lineTotals.all { it != null }
    val net = calculatedGross?.let { runCatching { CommerceCalculations.netAmount(it, discount) }.getOrNull() }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            item { Text("بيانات الطرف", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
            item {
                Column {
                    OutlinedTextField(partyName, { partyName = it; selectedPartyId = null }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المشتري / الطرف (اختياري للبيع النقدي)") }, singleLine = true)
                    if (partyName.isNotBlank() && matchingParties.isNotEmpty()) {
                        matchingParties.forEach { p -> TextButton(onClick = { partyName = p.displayName; phone = p.phone; selectedPartyId = p.id }) { Text("استخدام ملف: ${p.displayName}") } }
                    }
                    OutlinedTextField(phone, { phone = it }, modifier = Modifier.fillMaxWidth(), label = { Text("الهاتف إن وجد") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CUSTOMER" to "مشتري", "DISTRIBUTOR" to "موزع").forEach { (value, label) ->
                            FilterChip(selected = role == value, onClick = { role = value }, label = { Text(label) })
                        }
                    }
                }
            }
            item {
                OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("تاريخ البيع: ${commerceDate(selectedDateMillis)}")
                }
            }
            item { Text("ربط البيع", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
            item {
                Column {
                    var plotExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = plotExpanded, onExpandedChange = { plotExpanded = !plotExpanded }) {
                        OutlinedTextField(value = plantations.firstOrNull { it.id == selectedPlantationId }?.name ?: "بيع غير مرتبط بموضع", onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().menuAnchor(), label = { Text("الموضع (اختياري)") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = plotExpanded) })
                        ExposedDropdownMenu(expanded = plotExpanded, onDismissRequest = { plotExpanded = false }) {
                            DropdownMenuItem(text = { Text("غير مرتبط بموضع") }, onClick = { selectedPlantationId = null; selectedHarvestId = null; plotExpanded = false })
                            plantations.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = { selectedPlantationId = p.id; selectedHarvestId = null; selectedHarvestDayId = null; plotExpanded = false }) }
                        }
                    }
                    ExposedDropdownMenuBox(expanded = harvestExpanded, onExpandedChange = { harvestExpanded = !harvestExpanded }) {
                        OutlinedTextField(value = harvests.firstOrNull { it.id == selectedHarvestId }?.name ?: "بيع مستقل عن القطفة", onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().menuAnchor(), label = { Text("القطفة (اختياري)") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = harvestExpanded) })
                        ExposedDropdownMenu(expanded = harvestExpanded, onDismissRequest = { harvestExpanded = false }) {
                            DropdownMenuItem(text = { Text("بدون قطفة") }, onClick = { selectedHarvestId = null; selectedHarvestDayId = null; harvestExpanded = false })
                            harvests.filter { selectedPlantationId == null || it.plantationId == selectedPlantationId }.forEach { h -> DropdownMenuItem(text = { Text(h.name) }, onClick = { selectedHarvestId = h.id; selectedHarvestDayId = null; selectedPlantationId = h.plantationId; harvestExpanded = false }) }
                        }
                    }
                    ExposedDropdownMenuBox(expanded = harvestDayExpanded, onExpandedChange = { harvestDayExpanded = !harvestDayExpanded }) {
                        OutlinedTextField(
                            value = selectedHarvestDays.firstOrNull { it.id == selectedHarvestDayId }?.let { commerceDate(it.dateMillis) } ?: "بدون تحديد يوم قطف",
                            onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().menuAnchor(),
                            label = { Text("يوم القطف (اختياري)") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = harvestDayExpanded) }
                        )
                        ExposedDropdownMenu(expanded = harvestDayExpanded, onDismissRequest = { harvestDayExpanded = false }) {
                            DropdownMenuItem(text = { Text("بدون يوم محدد") }, onClick = { selectedHarvestDayId = null; harvestDayExpanded = false })
                            selectedHarvestDays.forEach { day -> DropdownMenuItem(text = { Text(commerceDate(day.dateMillis)) }, onClick = { selectedHarvestDayId = day.id; harvestDayExpanded = false }) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("YER", "SAR", "USD").forEach { c -> FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) }) }
                    }
                }
            }
            item { Text("المنتجات", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
            items(lines.size) { index ->
                val line = lines[index]
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F8F5)), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("المنتج ${index + 1}", color = Emerald, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (lines.size > 1) TextButton(onClick = { lines.removeAt(index) }) { Text("إزالة") }
                        }
                        OutlinedTextField(line.productName, { lines[index] = line.copy(productName = it) }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المنتج") }, singleLine = true)
                        if (products.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            products.filter { line.productName.isBlank() || it.displayName.contains(line.productName, true) || it.normalizedName.contains(CommerceCalculations.normalizeProductName(line.productName)) }.take(4).forEach { product -> AssistChip(onClick = { lines[index] = line.copy(productName = product.displayName, unit = product.unit) }, label = { Text(product.displayName) }) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(line.quantity, { lines[index] = line.copy(quantity = it) }, modifier = Modifier.weight(1f), label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                            OutlinedTextField(line.unit, { lines[index] = line.copy(unit = it) }, modifier = Modifier.weight(1f), label = { Text("الوحدة") }, singleLine = true)
                        }
                        OutlinedTextField(line.unitPrice, { lines[index] = line.copy(unitPrice = it) }, modifier = Modifier.fillMaxWidth(), label = { Text("سعر الوحدة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        Text("إجمالي السطر: ${lineTotals.getOrNull(index)?.let(::commerceMoney) ?: "السعر غير مدخل — يحفظ السطر غير مكتمل"}", color = if (lineTotals.getOrNull(index) == null) Color(0xFF9A5A00) else Emerald, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item { OutlinedButton(onClick = { lines.add(CommerceLineState()) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("إضافة منتج آخر للعملية نفسها") } }
            item { Text("المبالغ", color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
            item {
                Column {
                    Text("إجمالي المنتجات: ${calculatedGross?.let(::commerceMoney) ?: "غير مكتمل"}", fontWeight = FontWeight.Bold)
                    OutlinedTextField(discountText, { discountText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("الخصم") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(discountReason, { discountReason = it }, modifier = Modifier.fillMaxWidth(), label = { Text("سبب الخصم (اختياري)") }, singleLine = true)
                    OutlinedTextField(paidText, { paidText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("المبلغ المدفوع الآن") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(notes, { notes = it }, modifier = Modifier.fillMaxWidth(), label = { Text("ملاحظات") }, minLines = 2)
                    Text("المتبقي بعد الدفعة: ${if (net != null && paid <= net) commerceMoney(net - paid) else "راجع الخصم أو المدفوع"}", color = Emerald, fontWeight = FontWeight.Bold)
                    if (!complete) Text("تنبيه: بعض أسعار المنتجات غير مكتملة؛ ستُحفظ العملية بحالة مالية غير مكتملة ولن تعدّ قيمتها مردوداً مؤكداً.", color = Color(0xFF9A5A00), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f), enabled = !saving) { Text("إلغاء") }
            Button(
                onClick = {
                    if (saving) return@Button
                    val qtyPricesValid = lines.all { line ->
                        line.productName.isNotBlank() && line.unit.isNotBlank() &&
                            (parseCommerceLong(line.quantity)?.let { it > 0 } == true) &&
                            (line.unitPrice.isBlank() || parseCommerceLong(line.unitPrice)?.let { it >= 0 } == true)
                    }
                    if (partyName.isNotBlank() && selectedPartyId == null && role !in listOf("CUSTOMER", "DISTRIBUTOR")) { onMessage("حدد نوع الطرف."); return@Button }
                    if (!qtyPricesValid || calculatedGross == null || discount < 0 || discount > calculatedGross || paid < 0 || net == null || paid > net) { onMessage("راجع أسماء المنتجات والكميات والخصم والدفعة. يمكن ترك السعر فارغاً لحفظ العملية كغير مكتملة."); return@Button }
                    saving = true
                    scope.launch {
                        runCatching {
                            val partyId = selectedPartyId ?: if (partyName.isNotBlank()) dao.createCommerceParty(partyName, phone, role) else null
                            val saleNumber = "M113-${UUID.randomUUID().toString().take(12).uppercase(Locale.US)}"
                            val sale = CommerceSaleEntity(
                                saleNumber = saleNumber, partyId = partyId, partyRole = role,
                                transactionType = when { paid >= net -> "CASH"; paid > 0 -> "MIXED"; else -> "CREDIT" },
                                plantationId = selectedPlantationId, harvestId = selectedHarvestId, harvestDayId = selectedHarvestDayId,
                                dateMillis = selectedDateMillis, currency = currency,
                                grossCalculated = calculatedGross, discountAmount = discount,
                                discountReason = discountReason.trim(), netAmount = net,
                                isValueComplete = complete, notes = notes.trim()
                            )
                            val drafts = lines.map { line ->
                                val qty = parseCommerceLong(line.quantity) ?: error("الكمية غير صحيحة.")
                                val enteredPrice = parseCommerceLong(line.unitPrice)
                                val price = enteredPrice ?: 0L
                                val total = CommerceCalculations.lineTotal(qty, price)
                                CommerceProductDraft(line.productName, line.unit, qty, price, total, enteredPrice != null)
                            }
                            dao.saveCommerceSale(sale, drafts, paid)
                        }.onSuccess { onSaved(it) }
                         .onFailure { onMessage(it.message ?: "تعذر حفظ عملية البيع.") }
                        saving = false
                    }
                },
                modifier = Modifier.weight(1f), enabled = !saving
            ) { Text(if (saving) "جارٍ الحفظ..." else "حفظ عملية البيع") }
        }
    }
    if (showDatePicker) DatePickerDialog(
        onDismissRequest = { showDatePicker = false },
        confirmButton = {
            TextButton(onClick = {
                datePickerState.selectedDateMillis?.let { selectedDateMillis = it }
                showDatePicker = false
            }) { Text("اختيار") }
        },
        dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }
    ) { DatePicker(state = datePickerState) }
}

@Composable
private fun CommerceHarvestEntryDialog(
    title: String,
    plantations: List<PlantationEntity>,
    showFileFields: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Long?, Long, Long, Boolean, Long, Boolean, Long?, Long, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedDateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis)
    var selectedPlotId by remember { mutableStateOf<Long?>(null) }
    var plotExpanded by remember { mutableStateOf(false) }
    var pickerCountText by remember { mutableStateOf("") }
    var unitWageText by remember { mutableStateOf("") }
    var manualWagesText by remember { mutableStateOf("") }
    var otherCostText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (showFileFields) {
                    OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم القطفة أو رقمها") }, singleLine = true)
                    ExposedDropdownMenuBox(expanded = plotExpanded, onExpandedChange = { plotExpanded = !plotExpanded }) {
                        OutlinedTextField(
                            value = plantations.firstOrNull { it.id == selectedPlotId }?.name ?: "اختر الموضع (اختياري)",
                            onValueChange = {}, readOnly = true, modifier = Modifier.fillMaxWidth().menuAnchor(),
                            label = { Text("الموضع") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = plotExpanded) }
                        )
                        ExposedDropdownMenu(expanded = plotExpanded, onDismissRequest = { plotExpanded = false }) {
                            DropdownMenuItem(text = { Text("بدون موضع") }, onClick = { selectedPlotId = null; plotExpanded = false })
                            plantations.forEach { plot -> DropdownMenuItem(text = { Text(plot.name) }, onClick = { selectedPlotId = plot.id; plotExpanded = false }) }
                        }
                    }
                }
                OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("تاريخ القطف: ${commerceDate(selectedDateMillis)}")
                }
                Text("تكاليف القطافين", color = Emerald, fontWeight = FontWeight.Bold)
                OutlinedTextField(pickerCountText, { pickerCountText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("عدد القطافين (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(unitWageText, { unitWageText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("أجر القطاف الواحد (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(manualWagesText, { manualWagesText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("إجمالي أجور القطافين يدوياً (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(otherCostText, { otherCostText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("مصاريف أخرى للقطف") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(notes, { notes = it }, modifier = Modifier.fillMaxWidth(), label = { Text("ملاحظات") }, minLines = 2)
                Text("إذا أدخلت إجمالي الأجور يدوياً، فسيكون هو المعتمد بدلاً من حاصل ضرب العدد في الأجر.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                validationError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                runCatching {
                    val pickerCount = pickerCountText.takeIf { it.isNotBlank() }?.let { parseCommerceLong(it)?.takeIf { v -> v >= 0L } ?: error("عدد القطافين غير صحيح.") } ?: 0L
                    val unitWage = unitWageText.takeIf { it.isNotBlank() }?.let { parseCommerceLong(it)?.takeIf { v -> v >= 0L } ?: error("الأجر غير صحيح.") } ?: 0L
                    val manualWages = manualWagesText.takeIf { it.isNotBlank() }?.let { parseCommerceLong(it)?.takeIf { v -> v >= 0L } ?: error("إجمالي الأجور اليدوي غير صحيح.") }
                    val otherCost = otherCostText.takeIf { it.isNotBlank() }?.let { parseCommerceLong(it)?.takeIf { v -> v >= 0L } ?: error("المصاريف الأخرى غير صحيحة.") } ?: 0L
                    if (showFileFields) require(name.isNotBlank()) { "أدخل اسم القطفة أو رقمها." }
                    onSave(name.trim(), selectedPlotId, selectedDateMillis, pickerCount, pickerCountText.isNotBlank(), unitWage, unitWageText.isNotBlank(), manualWages, otherCost, notes.trim())
                }.onFailure { validationError = it.message ?: "راجع البيانات المدخلة." }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
    if (showDatePicker) DatePickerDialog(
        onDismissRequest = { showDatePicker = false },
        confirmButton = {
            TextButton(onClick = {
                datePickerState.selectedDateMillis?.let { selectedDateMillis = it }
                showDatePicker = false
            }) { Text("اختيار") }
        },
        dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") } }
    ) { DatePicker(state = datePickerState) }
}

@Composable
private fun CommerceEditSaleDialog(
    sale: CommerceSaleEntity,
    initialLines: List<CommerceSaleLineEntity>,
    onDismiss: () -> Unit,
    onSave: (List<CommerceProductDraft>, Long, String, String) -> Unit
) {
    val rows = remember(sale.id) {
        mutableStateListOf<CommerceLineState>().also { list ->
            initialLines.forEach { line ->
                list.add(CommerceLineState(
                    productName = line.productName,
                    unit = line.unit,
                    quantity = line.quantity.toString(),
                    unitPrice = if (line.isValueComplete) line.unitPrice.toString() else ""
                ))
            }
        }
    }
    var discountText by remember(sale.id) { mutableStateOf(sale.discountAmount.toString()) }
    var reason by remember(sale.id) { mutableStateOf(sale.discountReason) }
    var notes by remember(sale.id) { mutableStateOf(sale.notes) }
    var validationError by remember(sale.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل عملية البيع ${sale.saleNumber}") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("يتم تعديل نفس العملية ورقمها. تبقى الدفعات السابقة مرتبطة بها، ولا يسمح بخفض الصافي دون إجمالي الدفعات والتسويات.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                rows.forEachIndexed { index, line ->
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F7F4))) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("المنتج ${index + 1}", modifier = Modifier.weight(1f), color = Emerald, fontWeight = FontWeight.Bold)
                                if (rows.size > 1) TextButton(onClick = { rows.removeAt(index) }) { Text("حذف السطر") }
                            }
                            OutlinedTextField(line.productName, { rows[index] = line.copy(productName = it) }, modifier = Modifier.fillMaxWidth(), label = { Text("المنتج") }, singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(line.quantity, { rows[index] = line.copy(quantity = it) }, modifier = Modifier.weight(1f), label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                OutlinedTextField(line.unit, { rows[index] = line.copy(unit = it) }, modifier = Modifier.weight(1f), label = { Text("الوحدة") }, singleLine = true)
                            }
                            OutlinedTextField(line.unitPrice, { rows[index] = line.copy(unitPrice = it) }, modifier = Modifier.fillMaxWidth(), label = { Text("سعر الوحدة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        }
                    }
                }
                OutlinedButton(onClick = { rows.add(CommerceLineState(productName = "")) }, modifier = Modifier.fillMaxWidth()) { Text("إضافة منتج") }
                OutlinedTextField(discountText, { discountText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("الخصم") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(reason, { reason = it }, modifier = Modifier.fillMaxWidth(), label = { Text("سبب الخصم") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, modifier = Modifier.fillMaxWidth(), label = { Text("ملاحظات") }, minLines = 2)
                validationError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                runCatching {
                    require(rows.isNotEmpty()) { "أضف منتجاً واحداً على الأقل." }
                    val drafts = rows.map { line ->
                        val quantity = parseCommerceLong(line.quantity)?.takeIf { it > 0L } ?: error("أدخل كمية صحيحة.")
                        val enteredPrice = parseCommerceLong(line.unitPrice)
                        require(line.unitPrice.isBlank() || enteredPrice != null) { "سعر أحد المنتجات غير صحيح." }
                        require(line.productName.isNotBlank() && line.unit.isNotBlank()) { "أدخل اسم المنتج ووحدته." }
                        val price = enteredPrice ?: 0L
                        val total = CommerceCalculations.lineTotal(quantity, price)
                        CommerceProductDraft(line.productName, line.unit, quantity, price, total, enteredPrice != null)
                    }
                    val gross = CommerceCalculations.sumLines(drafts.map { it.total })
                    val discount = parseCommerceLong(discountText)?.takeIf { it >= 0L } ?: error("أدخل خصماً صحيحاً.")
                    require(discount <= gross) { "الخصم يتجاوز إجمالي المنتجات." }
                    onSave(drafts, discount, reason, notes)
                }.onFailure { validationError = it.message ?: "راجع البيانات المدخلة." }
            }) { Text("حفظ التعديل") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun CommercePaymentDialog(
    sale: CommerceSaleWithParty,
    onDismiss: () -> Unit,
    onSave: (Long, String) -> Unit
) {
    var amount by remember(sale.id) { mutableStateOf("") }
    var method by remember(sale.id) { mutableStateOf("نقدًا") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل دفعة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المتبقي: ${commerceMoney(sale.remaining)} ${sale.currency}")
                OutlinedTextField(amount, { amount = it }, label = { Text("مبلغ الدفعة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("نقدًا", "تحويل", "شيك").forEach { item -> FilterChip(selected = method == item, onClick = { method = item }, label = { Text(item) }) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { parseCommerceLong(amount)?.takeIf { it > 0 && it <= sale.remaining }?.let { onSave(it, method) } }) { Text("حفظ الدفعة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
