package com.miyar.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/** Unified party profile. Legacy identities are intentionally kept separate until an explicit merge is reviewed. */
@Entity(
    tableName = "commerce_parties",
    indices = [
        Index(value = ["displayName", "id"], name = "index_commerce_parties_displayName_id"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_parties_legacySourceTable_legacySourceId")
    ]
)
data class CommercePartyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = "",
    val status: String = "ACTIVE",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val lastInteractionAtMillis: Long = 0,
    val isFavorite: Boolean = false,
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)

@Entity(
    tableName = "commerce_party_roles",
    indices = [
        Index(value = ["partyId", "role"], unique = true, name = "index_commerce_party_roles_partyId_role"),
        Index(value = ["role", "partyId"], name = "index_commerce_party_roles_role_partyId")
    ]
)
data class CommercePartyRoleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val partyId: Long,
    val role: String,
    val isActive: Boolean = true
)

@Entity(
    tableName = "commerce_harvests",
    indices = [
        Index(value = ["plantationId", "dateMillis", "id"], name = "index_commerce_harvests_plantationId_dateMillis_id"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_harvests_legacySourceTable_legacySourceId")
    ]
)
data class CommerceHarvestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantationId: Long?,
    val name: String,
    val dateMillis: Long,
    val harvestType: String = "PERSONAL",
    val notes: String = "",
    val isDeleted: Boolean = false,
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)


@Entity(
    tableName = "commerce_harvest_days",
    indices = [
        Index(value = ["harvestId", "dateMillis", "id"], name = "index_commerce_harvest_days_harvestId_dateMillis_id"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_harvest_days_legacySourceTable_legacySourceId")
    ]
)
data class CommerceHarvestDayEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val harvestId: Long,
    val dateMillis: Long,
    val pickerCount: Long = 0,
    val pickerUnitWage: Long = 0,
    val pickerWagesManual: Long? = null,
    val pickerCountEntered: Boolean = false,
    val pickerUnitWageEntered: Boolean = false,
    val notes: String = "",
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)

@Entity(
    tableName = "commerce_sales",
    indices = [
        Index(value = ["saleNumber"], unique = true, name = "index_commerce_sales_saleNumber"),
        Index(value = ["partyId", "dateMillis", "id"], name = "index_commerce_sales_partyId_dateMillis_id"),
        Index(value = ["plantationId", "dateMillis", "id"], name = "index_commerce_sales_plantationId_dateMillis_id"),
        Index(value = ["harvestId", "dateMillis", "id"], name = "index_commerce_sales_harvestId_dateMillis_id"),
        Index(value = ["dateMillis", "id"], name = "index_commerce_sales_dateMillis_id"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_sales_legacySourceTable_legacySourceId")
    ]
)
data class CommerceSaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleNumber: String,
    val partyId: Long? = null,
    val partyRole: String = "CUSTOMER",
    val transactionType: String = "CASH",
    val plantationId: Long? = null,
    val harvestId: Long? = null,
    val harvestDayId: Long? = null,
    val dateMillis: Long = System.currentTimeMillis(),
    val currency: String = "YER",
    val grossCalculated: Long,
    val grossManual: Long? = null,
    val discountAmount: Long = 0,
    val discountReason: String = "",
    val netAmount: Long,
    val isValueComplete: Boolean = true,
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val deletedAtMillis: Long? = null,
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)

@Entity(
    tableName = "commerce_sale_lines",
    indices = [
        Index(value = ["saleId", "id"], name = "index_commerce_sale_lines_saleId_id"),
        Index(value = ["normalizedProductName", "createdAtMillis"], name = "index_commerce_sale_lines_normalizedProductName_createdAtMillis")
    ]
)
data class CommerceSaleLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productName: String,
    val normalizedProductName: String,
    val unit: String = "وحدة",
    val quantity: Long,
    val unitPrice: Long,
    val calculatedTotal: Long,
    val total: Long,
    val isTotalManual: Boolean = false,
    val isValueComplete: Boolean = true,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "commerce_payments",
    indices = [
        Index(value = ["partyId", "dateMillis", "id"], name = "index_commerce_payments_partyId_dateMillis_id"),
        Index(value = ["dateMillis", "id"], name = "index_commerce_payments_dateMillis_id"),
        Index(value = ["idempotencyKey"], unique = true, name = "index_commerce_payments_idempotencyKey"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_payments_legacySourceTable_legacySourceId")
    ]
)
data class CommercePaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val partyId: Long? = null,
    val amount: Long,
    val currency: String = "YER",
    val dateMillis: Long = System.currentTimeMillis(),
    val method: String = "نقدًا",
    val notes: String = "",
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val deletedAtMillis: Long? = null,
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)

@Entity(
    tableName = "commerce_payment_allocations",
    indices = [
        Index(value = ["paymentId", "saleId"], unique = true, name = "index_commerce_payment_allocations_paymentId_saleId"),
        Index(value = ["saleId", "id"], name = "index_commerce_payment_allocations_saleId_id")
    ]
)
data class CommercePaymentAllocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val paymentId: Long,
    val saleId: Long,
    val amount: Long,
    val createdAtMillis: Long = System.currentTimeMillis()
)


@Entity(
    tableName = "commerce_settlements",
    indices = [
        Index(value = ["saleId", "dateMillis", "id"], name = "index_commerce_settlements_saleId_dateMillis_id"),
        Index(value = ["partyId", "dateMillis", "id"], name = "index_commerce_settlements_partyId_dateMillis_id"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_settlements_legacySourceTable_legacySourceId")
    ]
)
data class CommerceSettlementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val partyId: Long?,
    val settlementType: String,
    val amount: Long,
    val currency: String = "YER",
    val dateMillis: Long = System.currentTimeMillis(),
    val notes: String = "",
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)

@Entity(
    tableName = "commerce_harvest_cost_items",
    indices = [
        Index(value = ["harvestId", "dateMillis", "id"], name = "index_commerce_harvest_cost_items_harvestId_dateMillis_id"),
        Index(value = ["plantationId", "dateMillis", "id"], name = "index_commerce_harvest_cost_items_plantationId_dateMillis_id"),
        Index(value = ["legacySourceTable", "legacySourceId"], unique = true, name = "index_commerce_harvest_cost_items_legacySourceTable_legacySourceId")
    ]
)
data class CommerceHarvestCostEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val harvestId: Long?,
    val harvestDayId: Long? = null,
    val plantationId: Long? = null,
    val costType: String,
    val description: String,
    val amount: Long,
    val currency: String = "YER",
    val dateMillis: Long = System.currentTimeMillis(),
    val notes: String = "",
    val deletedAtMillis: Long? = null,
    val legacySourceTable: String? = null,
    val legacySourceId: Long? = null
)

@Entity(
    tableName = "commerce_products",
    indices = [
        Index(value = ["normalizedName"], unique = true, name = "index_commerce_products_normalizedName"),
        Index(value = ["usageCount", "lastUsedAtMillis"], name = "index_commerce_products_usageCount_lastUsedAtMillis")
    ]
)
data class CommerceProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val normalizedName: String,
    val unit: String = "وحدة",
    val usageCount: Long = 0,
    val lastUsedAtMillis: Long = 0,
    val isActive: Boolean = true
)

data class CommerceSaleWithParty(
    val id: Long,
    val saleNumber: String,
    val partyId: Long?,
    val partyName: String?,
    val dateMillis: Long,
    val plantationId: Long?,
    val harvestId: Long?,
    val currency: String,
    val netAmount: Long,
    val collected: Long,
    val settlementDeductions: Long,
    val remaining: Long,
    val transactionType: String,
    val isValueComplete: Boolean
)

data class CommerceProductDraft(
    val productName: String,
    val unit: String,
    val quantity: Long,
    val unitPrice: Long,
    val total: Long,
    val isValueComplete: Boolean
)


data class CommerceCurrencyTotals(
    val currency: String,
    val saleCount: Long,
    val netTotal: Long,
    val collectedTotal: Long,
    val settlementTotal: Long,
    val outstandingTotal: Long,
    val incompleteCount: Long
)


data class CommercePartyRoleTotals(
    val currency: String,
    val saleCount: Long,
    val netTotal: Long,
    val collectedTotal: Long,
    val settlementTotal: Long,
    val outstandingTotal: Long,
    val incompleteCount: Long
)
