package com.miyar.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import androidx.room.Index
import androidx.room.ForeignKey
import java.util.UUID

@Entity(tableName = "personal_harvests", indices=[Index(value=["closedAtMillis", "startMillis"], name="index_personal_harvests_closedAtMillis_startMillis")])
data class PersonalHarvestEntity(
 @PrimaryKey(autoGenerate=true) val id:Long=0, val plantationId:Long, val name:String,
 val startMillis:Long, val expectedEndMillis:Long, val actualEndMillis:Long=0,
 val productsText:String, val cashSalesText:String, val debtorSalesText:String,
 val pickerCount:Long, val pickerWage:Long, val extraWages:Long, val bagsAndOther:Long,
 val transportAndClearance:Long, val notes:String, val createdAt:Long=System.currentTimeMillis(), @ColumnInfo(defaultValue="0") val closedAtMillis:Long=0
)
@Entity(tableName="harvest_debtors", indices=[Index(value=["name"], unique=true)])
data class HarvestDebtorEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String="",val notes:String="")
@Entity(tableName="harvest_debtor_transactions", indices=[Index("debtorId"), Index("sourceDayId"), Index("sourceLineId"), Index(value=["dateMillis", "id"], name="index_harvest_debtor_transactions_dateMillis")])
data class HarvestDebtorTransactionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val debtorId:Long,val harvestId:Long,val productType:String,val quantity:Long,val unitPrice:Long,val total:Long,val paid:Long=0,val dateMillis:Long=System.currentTimeMillis(),val notes:String="",@ColumnInfo(defaultValue="0") val sourceDayId:Long=0,@ColumnInfo(defaultValue="0") val sourceLineId:Long=0, @ColumnInfo(defaultValue="0") val calculatedTotal:Long=0, @ColumnInfo(defaultValue="0") val isTotalManual:Boolean=false, @ColumnInfo(defaultValue="1") val isValueComplete:Boolean=true)
@Entity(tableName="qat_buyers", indices=[Index(value=["name"], unique=true)])
data class QatBuyerEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String="",val notes:String="")
@Entity(tableName="buyer_sales", indices=[Index("buyerId"), Index(value=["saleDateMillis", "id"], name="index_buyer_sales_saleDateMillis"), Index(value=["personalHarvestId"], name="index_buyer_sales_personalHarvestId")])
data class BuyerSaleEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val buyerId:Long,val harvestName:String,val agreedAmount:Long,val initialPaid:Long,val saleDateMillis:Long,val expectedEndMillis:Long,val actualEndMillis:Long=0,val discountAmount:Long=0,val discountReason:String="",val notes:String="",@ColumnInfo(defaultValue="0") val plantationId:Long=0, @ColumnInfo(defaultValue="0") val personalHarvestId:Long=0)
@Entity(tableName="buyer_payments", indices=[Index("saleId"), Index(value=["dateMillis", "id"], name="index_buyer_payments_dateMillis")])
data class BuyerPaymentEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val saleId:Long,val amount:Long,val dateMillis:Long=System.currentTimeMillis(),val method:String="نقدًا",val notes:String="")
@Entity(tableName="market_distributors", indices=[Index(value=["name"], unique=true)])
data class MarketDistributorEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val phone:String="",val notes:String="")
@Entity(tableName="distributor_transactions", indices=[Index("distributorId"), Index("sourceDayId"), Index("sourceLineId"), Index(value=["dateMillis", "id"], name="index_distributor_transactions_dateMillis")])
data class DistributorTransactionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val distributorId:Long,val harvestId:Long,val productType:String,val quantity:Long,val unitPrice:Long,val total:Long,val received:Long=0,val dateMillis:Long=System.currentTimeMillis(),val notes:String="",@ColumnInfo(defaultValue="0") val sourceDayId:Long=0,@ColumnInfo(defaultValue="0") val sourceLineId:Long=0, @ColumnInfo(defaultValue="0") val calculatedTotal:Long=0, @ColumnInfo(defaultValue="0") val isTotalManual:Boolean=false, @ColumnInfo(defaultValue="1") val isValueComplete:Boolean=true)

@Entity(tableName="personal_harvest_days", indices=[Index("harvestId"), Index(value=["harvestId","dateMillis"]), Index(value=["dateMillis", "id"], name="index_personal_harvest_days_dateMillis")])
data class PersonalHarvestDayEntity(@PrimaryKey(autoGenerate=true) val id:Long=0, val harvestId:Long, val dateMillis:Long, val pickerCount:Long=0, val pickerWage:Long=0, val otherExpenses:Long=0, val notes:String="", val createdAt:Long=System.currentTimeMillis(), @ColumnInfo(defaultValue="0") val pickerWagesCalculated:Long=0, val pickerWagesManual:Long?=null, @ColumnInfo(defaultValue="0") val pickerCountEntered:Boolean=false, @ColumnInfo(defaultValue="0") val pickerWageEntered:Boolean=false, @ColumnInfo(defaultValue="0") val otherExpensesEntered:Boolean=false)
@Entity(tableName="personal_harvest_day_lines", indices=[Index("dayId"), Index("partyName"), Index(value=["dayId","id"], name="index_personal_harvest_day_lines_dayId_id"), Index(value=["operationGroupKey"], name="index_personal_harvest_day_lines_operationGroupKey")])
data class PersonalHarvestDayLineEntity(@PrimaryKey(autoGenerate=true) val id:Long=0, val dayId:Long, val category:String, val partyName:String="", val productType:String, val quantity:Long, val unitPrice:Long, val total:Long, val createdAt:Long=System.currentTimeMillis(), @ColumnInfo(defaultValue="0") val accountTransactionId:Long=0, @ColumnInfo(defaultValue="0") val calculatedTotal:Long=0, @ColumnInfo(defaultValue="0") val isTotalManual:Boolean=false, @ColumnInfo(defaultValue="1") val isValueComplete:Boolean=true, @ColumnInfo(defaultValue="''") val operationGroupKey:String="")


@Entity(tableName="harvest_party_payments", indices=[Index("partyType", "partyId"), Index("transactionId"), Index(value=["idempotencyKey"], unique=true), Index(value=["paymentGroupKey"], name="index_harvest_party_payments_paymentGroupKey")])
data class HarvestPartyPaymentEntity(
 @PrimaryKey(autoGenerate=true) val id:Long=0,
 val partyType:String,
 val partyId:Long,
 val transactionId:Long,
 val amount:Long,
 val dateMillis:Long=System.currentTimeMillis(),
 val method:String="نقدًا",
 val notes:String="",
 @ColumnInfo(defaultValue="''") val idempotencyKey:String=UUID.randomUUID().toString(),
 @ColumnInfo(defaultValue="''") val paymentGroupKey:String=""
)

/** A single adjustment attached to one distributor sale transaction. The original sale total is never overwritten. */
@Entity(
 tableName = "distributor_transaction_adjustments",
 foreignKeys = [ForeignKey(entity = DistributorTransactionEntity::class, parentColumns = ["id"], childColumns = ["transactionId"], onDelete = ForeignKey.RESTRICT)],
 indices = [Index(value = ["transactionId", "dateMillis", "id"]), Index(value = ["kind"]), Index(value = ["idempotencyKey"], unique = true)]
)
data class DistributorTransactionAdjustmentEntity(
 @PrimaryKey(autoGenerate = true) val id: Long = 0,
 val transactionId: Long,
 /** SELLER_DISCOUNT or DISTRIBUTION_EXPENSE */
 val kind: String,
 val amount: Long,
 val dateMillis: Long = System.currentTimeMillis(),
 val description: String,
 val notes: String = "",
 val idempotencyKey: String = UUID.randomUUID().toString(),
 val createdAtMillis: Long = System.currentTimeMillis()
)

/** Actual cash payments against a distribution expense; unpaid balance remains a payable cost. */
@Entity(
 tableName = "distribution_expense_payments",
 foreignKeys = [ForeignKey(entity = DistributorTransactionAdjustmentEntity::class, parentColumns = ["id"], childColumns = ["adjustmentId"], onDelete = ForeignKey.RESTRICT)],
 indices = [Index(value = ["adjustmentId", "dateMillis", "id"]), Index(value = ["idempotencyKey"], unique = true)]
)
data class DistributionExpensePaymentEntity(
 @PrimaryKey(autoGenerate = true) val id: Long = 0,
 val adjustmentId: Long,
 val amount: Long,
 val dateMillis: Long = System.currentTimeMillis(),
 val method: String = "نقدًا",
 val notes: String = "",
 val idempotencyKey: String = UUID.randomUUID().toString()
)

data class DistributorAdjustmentTotals(
 val sellerDiscountTotal: Long,
 val distributionExpenseTotal: Long
)



/** One product line entered in a single multi-product customer/distributor operation. */
data class HarvestPartySaleLineDraft(
    val productType: String,
    val quantity: Long,
    val unitPrice: Long,
    val total: Long,
    val calculatedTotal: Long,
    val isTotalManual: Boolean,
    val isValueComplete: Boolean
)
