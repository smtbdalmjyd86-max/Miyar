package com.miyar.app.data

object CommerceCalculations {
    fun lineTotal(quantity: Long, unitPrice: Long): Long {
        require(quantity > 0L) { "كمية المنتج يجب أن تكون أكبر من صفر." }
        require(unitPrice >= 0L) { "سعر الوحدة لا يمكن أن يكون سالباً." }
        return Math.multiplyExact(quantity, unitPrice)
    }

    fun sumLines(values: Iterable<Long>): Long = values.fold(0L) { total, value ->
        require(value >= 0L) { "لا يمكن أن يكون إجمالي المنتج سالباً." }
        Math.addExact(total, value)
    }

    fun netAmount(gross: Long, discount: Long): Long {
        require(gross >= 0L && discount >= 0L) { "قيمة البيع والخصم لا يمكن أن تكون سالبة." }
        require(discount <= gross) { "الخصم يتجاوز إجمالي البيع." }
        return Math.subtractExact(gross, discount)
    }

    fun remaining(net: Long, allocated: Long): Long {
        require(net >= 0L && allocated >= 0L) { "القيم المالية غير صالحة." }
        require(allocated <= net) { "الدفعات المخصصة تتجاوز صافي البيع." }
        return Math.subtractExact(net, allocated)
    }

    fun normalizeProductName(value: String): String = value
        .trim()
        .replace(Regex("\\s+"), " ")
        .replace("ـ", "")
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .lowercase()
}
