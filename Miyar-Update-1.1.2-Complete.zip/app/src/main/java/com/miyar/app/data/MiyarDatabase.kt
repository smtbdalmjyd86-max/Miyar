package com.miyar.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

data class OpeningStockInput(
    val name: String,
    val ingredient: String,
    val unit: String,
    val quantityBase: Long,
    val treatmentType: String,
    val costYer: Long
)

@Dao
interface MiyarDao {
    @Query("SELECT * FROM plantations ORDER BY name COLLATE NOCASE")
    fun observePlantations(): Flow<List<PlantationEntity>>

    @Query("SELECT * FROM plantations WHERE id = :id LIMIT 1")
    suspend fun getPlantationById(id: Long): PlantationEntity?
    @Query("SELECT * FROM plantations WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun getPlantationByName(name: String): PlantationEntity?

    @Insert
    suspend fun insertPlantation(item: PlantationEntity): Long

    @Update
    suspend fun updatePlantation(item: PlantationEntity)

    @Query("SELECT (SELECT COUNT(*) FROM expenses WHERE plantationId = :plantationId) + (SELECT COUNT(*) FROM plantation_opening_balances WHERE plantationId = :plantationId)")
    suspend fun countExpensesForPlantation(plantationId: Long): Long

    @Query("DELETE FROM plantations WHERE id = :plantationId")
    suspend fun deletePlantationById(plantationId: Long): Int

    @Transaction
    suspend fun deletePlantationIfEmpty(plantationId: Long): Boolean {
        if (countExpensesForPlantation(plantationId) > 0) return false
        return deletePlantationById(plantationId) > 0
    }

    @Query("SELECT * FROM expenses WHERE plantationId = :plantationId ORDER BY dateMillis DESC, id DESC")
    fun observeExpenses(plantationId: Long): Flow<List<ExpenseEntity>>

    /** Stable bounded pagination. Screens should request pages instead of collecting an unbounded ledger. */
    @Query("SELECT * FROM expenses WHERE plantationId = :plantationId ORDER BY dateMillis DESC, id DESC LIMIT :limit OFFSET :offset")
    suspend fun getExpensePage(plantationId: Long, limit: Int, offset: Int): List<ExpenseEntity>

    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id=e.plantationId WHERE e.category != 'القطفات' AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId) ORDER BY e.dateMillis DESC, e.id DESC LIMIT :limit OFFSET :offset")
    suspend fun getReportExpensePage(fromMillis: Long, untilMillis: Long, plantationId: Long?, limit: Int, offset: Int): List<ExpenseWithPlantation>

    @Query("SELECT COUNT(*) FROM expenses WHERE plantationId = :plantationId")
    suspend fun countPlantationOperations(plantationId: Long): Long

    @Query("SELECT * FROM expenses WHERE plantationId=:plantationId AND (:category IS NULL OR category=:category OR (:category='المياه والري' AND category='المياه')) ORDER BY dateMillis DESC,id DESC LIMIT :limit OFFSET :offset")
    suspend fun getPlantationExpensePage(plantationId: Long, category: String?, limit: Int, offset: Int): List<ExpenseEntity>

    @Query("SELECT COUNT(*) FROM expenses WHERE plantationId=:plantationId AND (:category IS NULL OR category=:category OR (:category='المياه والري' AND category='المياه'))")
    fun observePlantationOperationCount(plantationId: Long, category: String?): Flow<Long>

    @Query("SELECT category AS category,COUNT(*) AS count,COALESCE(SUM(amount),0) AS total FROM expenses WHERE plantationId=:plantationId AND category != 'القطفات' GROUP BY category UNION ALL SELECT 'تكاليف القطاف' AS category,COUNT(*) AS count,COALESCE(SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses),0) AS total FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId AND (COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)>0 OR d.pickerCount>0 OR d.pickerWage>0 OR d.otherExpenses>0)")
    fun observePlantationCategoryTotals(plantationId: Long): Flow<List<CategoryTotal>>

    @Query("SELECT category AS category, COUNT(*) AS count, COALESCE(SUM(amount),0) AS total FROM expenses WHERE plantationId = :plantationId AND category != 'القطفات' AND dateMillis >= :fromMillis AND dateMillis < :untilMillis GROUP BY category UNION ALL SELECT 'تكاليف القطاف' AS category,COUNT(*) AS count,COALESCE(SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses),0) AS total FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId AND d.dateMillis>=:fromMillis AND d.dateMillis<:untilMillis AND (COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)>0 OR d.pickerCount>0 OR d.pickerWage>0 OR d.otherExpenses>0)")
    suspend fun getPlantationCategoryTotals(plantationId: Long, fromMillis: Long, untilMillis: Long): List<CategoryTotal>

    @Query("SELECT COALESCE((SELECT COUNT(*) FROM expenses e WHERE e.category != 'القطفات' AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) + COALESCE((SELECT COUNT(*) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE d.dateMillis>=:fromMillis AND d.dateMillis<:untilMillis AND (:plantationId IS NULL OR h.plantationId=:plantationId) AND (COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)>0 OR d.pickerCount>0 OR d.pickerWage>0 OR d.otherExpenses>0)),0) AS expenseCount, COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.category != 'القطفات' AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) + COALESCE((SELECT SUM(o.amount) FROM plantation_opening_balances o WHERE o.dateMillis >= :fromMillis AND o.dateMillis < :untilMillis AND (:plantationId IS NULL OR o.plantationId=:plantationId)),0) + COALESCE((SELECT SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE d.dateMillis>=:fromMillis AND d.dateMillis<:untilMillis AND (:plantationId IS NULL OR h.plantationId=:plantationId)),0) + COALESCE((SELECT SUM(a.amount) FROM distributor_transaction_adjustments a INNER JOIN distributor_transactions t ON t.id=a.transactionId INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE a.kind='DISTRIBUTION_EXPENSE' AND a.dateMillis>=:fromMillis AND a.dateMillis<:untilMillis AND (:plantationId IS NULL OR h.plantationId=:plantationId)),0) AS expenseTotal, COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.category = 'القطفات' AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) AS harvestTotal, COALESCE((SELECT SUM(i.totalYer) FROM invoices i WHERE i.dateMillis >= :fromMillis AND i.dateMillis < :untilMillis),0) AS invoiceTotal, COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.category IN ('السموم','الأسمدة') AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) AS chemicalTotal, COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.category IN ('المياه','المياه والري') AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) AS waterTotal, COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.category='الأعمال اليدوية' AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) AS laborTotal, COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.category='أخرى' AND e.dateMillis >= :fromMillis AND e.dateMillis < :untilMillis AND (:plantationId IS NULL OR e.plantationId=:plantationId)),0) AS otherTotal, COALESCE((SELECT SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE d.dateMillis>=:fromMillis AND d.dateMillis<:untilMillis AND (:plantationId IS NULL OR h.plantationId=:plantationId)),0) AS harvestCostTotal")
    fun observeReportSummary(fromMillis: Long, untilMillis: Long, plantationId: Long?): Flow<ReportSummary>

    @Query("SELECT * FROM plantation_opening_balances WHERE plantationId=:plantationId LIMIT 1")
    suspend fun getOpeningBalance(plantationId: Long): PlantationOpeningBalanceEntity?

    @Query("SELECT COALESCE(SUM(amount),0) FROM plantation_opening_balances WHERE plantationId=:plantationId")
    fun observeOpeningBalance(plantationId: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount),0) FROM plantation_opening_balances")
    fun observeAllOpeningBalancesTotal(): Flow<Long>

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun insertOpeningBalance(item: PlantationOpeningBalanceEntity): Long

    @Update
    suspend fun updateOpeningBalance(item: PlantationOpeningBalanceEntity)

    @Transaction
    suspend fun saveOpeningBalance(plantationId: Long, amount: Long, dateMillis: Long, notes: String) {
        require(amount >= 0L) { "الرصيد الافتتاحي لا يمكن أن يكون سالبًا." }
        require(getPlantationById(plantationId) != null) { "الموضع الزراعي غير موجود." }
        val old = getOpeningBalance(plantationId)
        if (old == null) insertOpeningBalance(PlantationOpeningBalanceEntity(plantationId=plantationId, amount=amount, dateMillis=dateMillis, notes=notes.trim()))
        else updateOpeningBalance(old.copy(amount=amount, dateMillis=dateMillis, notes=notes.trim()))
    }

    @Query("SELECT COALESCE((SELECT SUM(amount) FROM expenses WHERE currency=:currency AND category != 'القطفات'),0) + CASE WHEN :currency='YER' THEN COALESCE((SELECT SUM(amount) FROM plantation_opening_balances),0) + COALESCE((SELECT SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses) FROM personal_harvest_days d),0) + COALESCE((SELECT SUM(a.amount) FROM distributor_transaction_adjustments a WHERE a.kind='DISTRIBUTION_EXPENSE'),0) ELSE 0 END")
    fun observeTotalExpenses(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category = 'القطفات'")
    fun observeTotalRevenue(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE((SELECT SUM(amount) FROM expenses WHERE plantationId=:plantationId AND currency=:currency AND category != 'القطفات'),0) + CASE WHEN :currency='YER' THEN COALESCE((SELECT SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId),0) + COALESCE((SELECT SUM(a.amount) FROM distributor_transaction_adjustments a INNER JOIN distributor_transactions t ON t.id=a.transactionId INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE a.kind='DISTRIBUTION_EXPENSE' AND h.plantationId=:plantationId),0) ELSE 0 END")
    fun observePlantationExpenses(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category = 'القطفات'")
    fun observePlantationRevenue(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id = e.plantationId WHERE e.category != 'القطفات' ORDER BY e.dateMillis DESC, e.id DESC")
    fun observeAllExpenses(): Flow<List<ExpenseWithPlantation>>

    /** Paged ledger query used by the home-screen “show all” action. */
    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id = e.plantationId ORDER BY e.dateMillis DESC, e.id DESC LIMIT :limit OFFSET :offset")
    suspend fun getAllExpensePage(limit: Int, offset: Int): List<ExpenseWithPlantation>

    @Query("SELECT COUNT(*) FROM expenses")
    suspend fun countAllExpenses(): Long

    /** Category-aware global operation paging; unlike financial expense totals, this includes harvest records. */
    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id=e.plantationId WHERE (:category IS NULL OR e.category=:category OR (:category='المياه' AND e.category='المياه والري') OR (:category='المياه والري' AND e.category='المياه')) ORDER BY e.dateMillis DESC,e.id DESC LIMIT :limit OFFSET :offset")
    suspend fun getFilteredOperationPage(category: String?, limit: Int, offset: Int): List<ExpenseWithPlantation>

    @Query("SELECT COUNT(*) FROM expenses WHERE (:category IS NULL OR category=:category OR (:category='المياه' AND category='المياه والري') OR (:category='المياه والري' AND category='المياه'))")
    suspend fun countFilteredOperationRecords(category: String?): Long

    @Query("SELECT e.id AS id,e.plantationId AS plantationId,p.name AS plantationName,e.category AS category,e.title AS title,e.amount AS amount,e.currency AS currency,e.dateMillis AS dateMillis,e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id=e.plantationId ORDER BY e.dateMillis DESC,e.id DESC LIMIT 300")
    fun observeRecentExpenses(): Flow<List<ExpenseWithPlantation>>

    @Query("SELECT category AS category, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total FROM expenses WHERE category != 'القطفات' GROUP BY category UNION ALL SELECT 'تكاليف القطاف' AS category,COUNT(*) AS count,COALESCE(SUM(COALESCE(pickerWagesManual,pickerWagesCalculated)+otherExpenses),0) AS total FROM personal_harvest_days WHERE COALESCE(pickerWagesManual,pickerWagesCalculated)>0 OR pickerCount>0 OR pickerWage>0 OR otherExpenses>0")
    fun observeCategoryTotals(): Flow<List<CategoryTotal>>

    @Query("SELECT COUNT(*) FROM expenses WHERE category = 'القطفات'")
    fun observeHarvestCount(): Flow<Long>

    @Query("SELECT (SELECT COUNT(*) FROM expenses WHERE category != 'القطفات' AND dateMillis >= :startMillis AND dateMillis < :endMillis) + (SELECT COUNT(*) FROM personal_harvest_days WHERE dateMillis >= :startMillis AND dateMillis < :endMillis) + (SELECT COUNT(*) FROM buyer_sales WHERE saleDateMillis >= :startMillis AND saleDateMillis < :endMillis) + (SELECT COUNT(*) FROM invoices WHERE dateMillis >= :startMillis AND dateMillis < :endMillis) + (SELECT COUNT(*) FROM supplier_payments WHERE dateMillis >= :startMillis AND dateMillis < :endMillis)")
    suspend fun countActivityRecordsBetween(startMillis: Long, endMillis: Long): Long

    @Query("SELECT COUNT(*) FROM expenses WHERE category != 'القطفات' AND dateMillis >= :startMillis AND dateMillis < :endMillis")
    suspend fun countExpensesBetween(startMillis: Long, endMillis: Long): Long

    @Insert
    suspend fun insertExpense(item: ExpenseEntity): Long

    @Update
    suspend fun updateExpense(item: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(item: ExpenseEntity)

    // Supplier ledger (separate from qat harvest buyers and market distributors).
    @Query("SELECT * FROM suppliers ORDER BY name COLLATE NOCASE")
    fun observeSuppliers(): Flow<List<SupplierEntity>>
    @Query("SELECT name FROM suppliers ORDER BY name COLLATE NOCASE")
    fun observeSupplierNameSuggestions(): Flow<List<String>>

    @Query("""
        SELECT s.id AS id, s.name AS name, s.phone AS phone, s.notes AS notes,
               (SELECT COUNT(*) FROM invoices i WHERE lower(trim(i.supplier))=lower(trim(s.name)) AND i.paymentStatus='آجل') AS invoiceCount,
               (SELECT COALESCE(SUM(i.totalYer),0) FROM invoices i WHERE lower(trim(i.supplier))=lower(trim(s.name)) AND i.paymentStatus='آجل') AS totalCreditYer,
               (SELECT COALESCE(SUM(p.amountYer),0) FROM supplier_payments p WHERE p.supplierId=s.id) AS totalPaidYer,
               MAX(0,
                   (SELECT COALESCE(SUM(i.totalYer),0) FROM invoices i WHERE lower(trim(i.supplier))=lower(trim(s.name)) AND i.paymentStatus='آجل') -
                   (SELECT COALESCE(SUM(p.amountYer),0) FROM supplier_payments p WHERE p.supplierId=s.id)
               ) AS balanceYer
        FROM suppliers s ORDER BY s.name COLLATE NOCASE
    """)
    fun observeSupplierAccounts(): Flow<List<SupplierAccountSummary>>

    @Query("SELECT * FROM supplier_payments ORDER BY dateMillis DESC, id DESC")
    fun observeSupplierPayments(): Flow<List<SupplierPaymentEntity>>

    @Query("SELECT p.id AS id, p.supplierId AS supplierId, s.name AS supplierName, p.dateMillis AS dateMillis, p.currency AS currency, p.amountForeign AS amountForeign, p.exchangeRateScaled AS exchangeRateScaled, p.amountYer AS amountYer, p.paymentMethod AS paymentMethod, p.notes AS notes FROM supplier_payments p INNER JOIN suppliers s ON s.id=p.supplierId ORDER BY p.dateMillis DESC, p.id DESC")
    fun observeSupplierPaymentsWithName(): Flow<List<SupplierPaymentWithName>>

    @Query("SELECT p.id AS id,p.supplierId AS supplierId,s.name AS supplierName,p.dateMillis AS dateMillis,p.currency AS currency,p.amountForeign AS amountForeign,p.exchangeRateScaled AS exchangeRateScaled,p.amountYer AS amountYer,p.paymentMethod AS paymentMethod,p.notes AS notes FROM supplier_payments p INNER JOIN suppliers s ON s.id=p.supplierId ORDER BY p.dateMillis DESC,p.id DESC LIMIT 300")
    fun observeRecentSupplierPaymentsWithName(): Flow<List<SupplierPaymentWithName>>

    @Query("SELECT * FROM suppliers WHERE id=:id LIMIT 1")
    suspend fun getSupplierById(id: Long): SupplierEntity?

    @Query("SELECT * FROM suppliers WHERE name=:name COLLATE NOCASE LIMIT 1")
    suspend fun getSupplierByName(name: String): SupplierEntity?

    @Insert(onConflict = androidx.room.OnConflictStrategy.IGNORE)
    suspend fun insertSupplierIfNew(supplier: SupplierEntity): Long

    @Update
    suspend fun updateSupplierProfileRow(supplier: SupplierEntity)

    @Transaction
    suspend fun saveSupplierProfile(name: String, phone: String = "", notes: String = ""): Long {
        val clean = name.trim()
        require(clean.isNotBlank()) { "أدخل اسم التاجر أو المورد." }
        val existing = getSupplierByName(clean)
        if (existing != null) {
            updateSupplierProfileRow(existing.copy(name = clean, phone = phone.trim(), notes = notes.trim()))
            return existing.id
        }
        val inserted = insertSupplierIfNew(SupplierEntity(name = clean, phone = phone.trim(), notes = notes.trim()))
        if (inserted > 0L) return inserted
        val raced = getSupplierByName(clean) ?: error("تعذر إنشاء ملف المورد.")
        updateSupplierProfileRow(raced.copy(phone = phone.trim(), notes = notes.trim()))
        return raced.id
    }

    @Insert
    suspend fun insertSupplierPayment(payment: SupplierPaymentEntity): Long

    @Query("SELECT COALESCE(SUM(amountYer),0) FROM supplier_payments WHERE supplierId=:supplierId")
    suspend fun getSupplierPaidTotal(supplierId: Long): Long

    @Transaction
    suspend fun ensureSupplier(name: String): Long {
        val clean = name.trim()
        require(clean.isNotBlank()) { "أدخل اسم التاجر أو المورد." }
        val existing = getSupplierByName(clean)
        return existing?.id ?: insertSupplierIfNew(SupplierEntity(name = clean)).let { inserted ->
            if (inserted > 0L) inserted else getSupplierByName(clean)?.id ?: error("تعذر إنشاء ملف المورد.")
        }
    }

    @Transaction
    suspend fun addSupplierPayment(payment: SupplierPaymentEntity): Long {
        require(payment.supplierId > 0 && payment.amountForeign > 0 && payment.amountYer > 0 && payment.exchangeRateScaled > 0) { "تحقق من مبلغ الدفعة وسعر الصرف." }
        require(FinanceCalculations.toYemeniRials(payment.amountForeign, payment.exchangeRateScaled) == payment.amountYer) {
            "قيمة الدفعة بالريال اليمني لا تطابق المبلغ وسعر الصرف المدخلين."
        }
        val supplier = getSupplierById(payment.supplierId) ?: error("ملف المورد غير موجود.")
        val credit = observeSupplierCreditTotalForValidation(supplier.name)
        val paid = getSupplierPaidTotal(supplier.id)
        require(payment.amountYer <= (credit - paid).coerceAtLeast(0L)) { "قيمة الدفعة أكبر من المبلغ المستحق للمورد." }
        return insertSupplierPayment(payment)
    }

    @Query("SELECT COALESCE(SUM(totalYer),0) FROM invoices WHERE lower(trim(supplier))=lower(trim(:supplierName)) AND paymentStatus='آجل'")
    suspend fun observeSupplierCreditTotalForValidation(supplierName: String): Long

    // Invoice and inventory queries
    @Query("SELECT * FROM invoices ORDER BY dateMillis DESC, id DESC")
    fun observeInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices ORDER BY dateMillis DESC,id DESC LIMIT 300")
    fun observeRecentInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices ORDER BY dateMillis DESC,id DESC LIMIT :limit OFFSET :offset")
    suspend fun getInvoicePage(limit: Int, offset: Int): List<InvoiceEntity>

    @Query("""
        SELECT
            COALESCE(SUM(CASE WHEN paymentStatus = 'آجل' THEN 1 ELSE 0 END), 0) AS creditCount,
            COALESCE(SUM(CASE WHEN paymentStatus = 'آجل' THEN totalYer ELSE 0 END), 0) AS creditTotal,
            COALESCE(SUM(CASE WHEN paymentStatus != 'آجل' THEN 1 ELSE 0 END), 0) AS cashCount,
            COALESCE(SUM(CASE WHEN paymentStatus != 'آجل' THEN totalYer ELSE 0 END), 0) AS cashTotal
        FROM invoices
        """)
    fun observeInvoiceLedgerSummary(): Flow<InvoiceLedgerSummary>

    @Query("SELECT * FROM invoices WHERE id=:id LIMIT 1")
    suspend fun getInvoiceById(id: Long): InvoiceEntity?

    @Query("SELECT COALESCE(SUM(totalYer),0) FROM invoices WHERE lower(trim(supplier))=lower(trim(:supplierName)) AND paymentStatus='آجل' AND id != :excludeInvoiceId")
    suspend fun getSupplierCreditExcludingInvoice(supplierName: String, excludeInvoiceId: Long): Long

    @Query("SELECT * FROM invoice_items ORDER BY id DESC")
    fun observeAllInvoiceItems(): Flow<List<InvoiceItemEntity>>

    @Query("SELECT * FROM invoice_items ORDER BY id DESC LIMIT 500")
    fun observeRecentInvoiceItems(): Flow<List<InvoiceItemEntity>>

    @Query("""
        SELECT m.id AS id, m.stockItemId AS stockItemId, s.productType AS productType,
               s.productName AS productName, s.activeIngredient AS activeIngredient,
               s.treatmentType AS treatmentType, s.baseUnit AS baseUnit,
               m.quantityBase AS quantityBase, m.dateMillis AS dateMillis,
               m.referenceType AS referenceType, m.referenceId AS referenceId,
               COALESCE(NULLIF(v.notes, ''), m.description) AS description,
               CASE WHEN m.referenceType = 'MANUAL_ISSUE' THEN v.reason ELSE e.title END AS operationTitle,
               CASE WHEN m.referenceType = 'MANUAL_ISSUE' THEN 'صرف مخزني' ELSE e.category END AS operationCategory,
               p.name AS plantationName
        FROM stock_movements m
        INNER JOIN stock_items s ON s.id = m.stockItemId
        LEFT JOIN chemical_operation_lines c ON m.referenceType = 'CHEMICAL_LINE' AND c.id = m.referenceId
        LEFT JOIN expenses e ON e.id = CASE WHEN m.referenceType = 'CHEMICAL_LINE' THEN c.expenseId WHEN m.referenceType = 'EXPENSE' THEN m.referenceId ELSE NULL END
        LEFT JOIN plantations p ON p.id = e.plantationId
        LEFT JOIN stock_issue_vouchers v ON m.referenceType = 'MANUAL_ISSUE' AND v.id = m.referenceId
        WHERE m.quantityBase < 0
        ORDER BY m.dateMillis DESC, m.id DESC
    """)
    fun observeStockUsageDetails(): Flow<List<StockMovementDetail>>

    @Query("SELECT m.id AS id,m.stockItemId AS stockItemId,s.productType AS productType,s.productName AS productName,s.activeIngredient AS activeIngredient,s.treatmentType AS treatmentType,s.baseUnit AS baseUnit,m.quantityBase AS quantityBase,m.dateMillis AS dateMillis,m.referenceType AS referenceType,m.referenceId AS referenceId,COALESCE(NULLIF(v.notes,''),m.description) AS description,CASE WHEN m.referenceType='MANUAL_ISSUE' THEN v.reason ELSE e.title END AS operationTitle,CASE WHEN m.referenceType='MANUAL_ISSUE' THEN 'صرف مخزني' ELSE e.category END AS operationCategory,p.name AS plantationName FROM stock_movements m INNER JOIN stock_items s ON s.id=m.stockItemId LEFT JOIN chemical_operation_lines c ON m.referenceType='CHEMICAL_LINE' AND c.id=m.referenceId LEFT JOIN expenses e ON e.id=CASE WHEN m.referenceType='CHEMICAL_LINE' THEN c.expenseId WHEN m.referenceType='EXPENSE' THEN m.referenceId ELSE NULL END LEFT JOIN plantations p ON p.id=e.plantationId LEFT JOIN stock_issue_vouchers v ON m.referenceType='MANUAL_ISSUE' AND v.id=m.referenceId WHERE m.quantityBase<0 AND m.stockItemId=:stockItemId ORDER BY m.dateMillis DESC,m.id DESC")
    suspend fun getStockUsageDetails(stockItemId: Long): List<StockMovementDetail>

    @Query("SELECT * FROM stock_movements ORDER BY dateMillis DESC,id DESC LIMIT 500")
    fun observeRecentStockMovements(): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId ORDER BY id")
    suspend fun getInvoiceItems(invoiceId: Long): List<InvoiceItemEntity>

    @Query("SELECT * FROM stock_items ORDER BY lastReceivedAtMillis DESC, id DESC")
    fun observeStockItems(): Flow<List<StockItemEntity>>

    @Query("SELECT * FROM chemical_operation_lines WHERE expenseId = :expenseId ORDER BY id")
    suspend fun getChemicalOperationLines(expenseId: Long): List<ChemicalOperationLineEntity>

    @Insert suspend fun insertChemicalOperationLine(item: ChemicalOperationLineEntity): Long
    @Query("DELETE FROM chemical_operation_lines WHERE expenseId = :expenseId") suspend fun deleteChemicalOperationLines(expenseId: Long)

    @Query("SELECT * FROM operation_reminders WHERE enabled = 1 ORDER BY scheduledAtMillis")
    fun observeOperationReminders(): Flow<List<OperationReminderEntity>>
    @Query("SELECT * FROM operation_reminders WHERE enabled=1 AND status!='RESOLVED' AND (plantationId=:plantationId OR (plantationId=0 AND plantationName=:plantationName)) ORDER BY scheduledAtMillis,id")
    fun observePlantationOperationReminders(plantationId:Long, plantationName:String):Flow<List<OperationReminderEntity>>
    @Query("UPDATE operation_reminders SET status=:status, enabled=CASE WHEN :status='RESOLVED' THEN 0 ELSE enabled END WHERE id=:id")
    suspend fun updateOperationReminderStatus(id:Long, status:String)

    @Query("SELECT * FROM operation_reminders ORDER BY scheduledAtMillis")
    fun observeAllOperationReminders(): Flow<List<OperationReminderEntity>>

    @Query("SELECT * FROM operation_reminders WHERE enabled=1 ORDER BY scheduledAtMillis LIMIT 300")
    fun observeRecentOperationReminders(): Flow<List<OperationReminderEntity>>
    @Query("SELECT * FROM operation_reminders WHERE enabled = 1 ORDER BY scheduledAtMillis")
    suspend fun getEnabledOperationReminders(): List<OperationReminderEntity>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun upsertOperationReminder(item: OperationReminderEntity)
    @Query("DELETE FROM operation_reminders WHERE referenceType = :type AND referenceId = :id") suspend fun deleteOperationReminder(type: String, id: Long)

    @Query("""
        SELECT s.id AS id, s.productType AS productType, s.productName AS productName,
               s.activeIngredient AS activeIngredient, s.baseUnit AS baseUnit,
               s.quantityBase AS quantityBase, s.treatmentType AS treatmentType,
               CASE WHEN COALESCE(s.totalReceivedBase, 0) > 0
                    THEN CAST(((COALESCE(SUM(ii.lineTotalYer), 0) + s.totalOpeningCostYer) * 1000) / s.totalReceivedBase AS INTEGER)
                    ELSE 0 END AS averageCostPerBaseScaled
        FROM stock_items s
        LEFT JOIN invoice_items ii ON ii.stockItemId = s.id
        GROUP BY s.id
        ORDER BY s.productName COLLATE NOCASE
    """)
    fun observeStockPriceSuggestions(): Flow<List<StockPriceSuggestion>>

    @Query("SELECT * FROM stock_items WHERE id = :id LIMIT 1")
    suspend fun getStockItemById(id: Long): StockItemEntity?

    @Query("SELECT COALESCE(MAX(dateMillis),0) FROM stock_movements WHERE stockItemId=:stockItemId AND quantityBase>0 AND referenceType IN ('INVOICE','OPENING')")
    suspend fun getLastReceiptMillis(stockItemId: Long): Long

    @Query("SELECT * FROM stock_items WHERE productType = :type AND productName COLLATE NOCASE = :name COLLATE NOCASE AND baseUnit = :baseUnit LIMIT 1")
    suspend fun findStockItem(type: String, name: String, baseUnit: String): StockItemEntity?

    @Query("SELECT * FROM stock_items WHERE productType = :type AND productName COLLATE NOCASE = :name COLLATE NOCASE AND baseUnit = :baseUnit AND treatmentType = :treatmentType LIMIT 1")
    suspend fun findStockItemByTreatment(type: String, name: String, baseUnit: String, treatmentType: String): StockItemEntity?

    @Insert
    suspend fun insertInvoice(invoice: InvoiceEntity): Long

    @Update
    suspend fun updateInvoice(invoice: InvoiceEntity)

    @Query("DELETE FROM invoices WHERE id = :id")
    suspend fun deleteInvoiceRow(id: Long)

    @Insert
    suspend fun insertInvoiceItem(item: InvoiceItemEntity): Long

    @Query("DELETE FROM invoice_items WHERE invoiceId = :invoiceId")
    suspend fun deleteInvoiceItems(invoiceId: Long)

    @Insert
    suspend fun insertStockItem(item: StockItemEntity): Long

    @Update
    suspend fun updateStockItem(item: StockItemEntity)

    @Insert
    suspend fun insertStockIssueVoucher(item: StockIssueVoucherEntity): Long

    @Update
    suspend fun updateStockIssueVoucher(item: StockIssueVoucherEntity)

    @Insert
    suspend fun insertStockIssueLine(item: StockIssueLineEntity): Long

    @Query("SELECT * FROM stock_issue_vouchers ORDER BY dateMillis DESC, id DESC")
    fun observeStockIssueVouchers(): Flow<List<StockIssueVoucherEntity>>

    @Query("SELECT * FROM stock_issue_lines WHERE voucherId = :voucherId ORDER BY id")
    suspend fun getStockIssueLines(voucherId: Long): List<StockIssueLineEntity>

    @Query("DELETE FROM stock_issue_lines WHERE voucherId = :voucherId")
    suspend fun deleteStockIssueLines(voucherId: Long)

    @Query("DELETE FROM stock_movements WHERE referenceType = 'MANUAL_ISSUE' AND referenceId = :voucherId")
    suspend fun deleteManualIssueMovements(voucherId: Long)

    @Query("DELETE FROM stock_issue_vouchers WHERE id = :voucherId")
    suspend fun deleteStockIssueVoucherRow(voucherId: Long)

    @Transaction
    suspend fun saveStockIssue(voucher: StockIssueVoucherEntity, lines: List<StockIssueLineInput>): Long {
        require(voucher.reason.isNotBlank()) { "أدخل بيان الصرف قبل الحفظ." }
        require(lines.isNotEmpty()) { "أضف صنفًا واحدًا على الأقل إلى سند الصرف." }
        require(lines.all { it.stockItemId > 0L && it.enteredQuantity > 0L && it.quantityBase > 0L }) { "تحقق من الصنف والكمية في جميع الأسطر." }
        require(lines.all { it.unit in listOf("كجم", "جرام", "لتر", "ملي", "مل") && it.quantityBase == FinanceCalculations.quantityToBase(it.enteredQuantity, it.unit) }) { "وحدة القياس أو تحويل الكمية غير صحيح." }
        lines.forEach { line ->
            val stock = getStockItemById(line.stockItemId) ?: error("أحد الأصناف المحددة لم يعد موجودًا في المخزون.")
            require(stock.baseUnit == "g" || stock.baseUnit == "ml") { "وحدة التخزين الأساسية للصنف «${stock.productName}» غير معتمدة؛ صحح بيانات الصنف قبل الصرف." }
            val unitMatches = if (stock.baseUnit == "g") line.unit in listOf("كجم", "جرام") else line.unit in listOf("لتر", "ملي", "مل")
            require(unitMatches) { "وحدة القياس لا تتوافق مع نوع الصنف «${stock.productName}»." }
        }

        val voucherId = if (voucher.id == 0L) insertStockIssueVoucher(voucher.copy(id = 0)) else voucher.id
        if (voucher.id != 0L) {
            val oldVoucher = getStockIssueVoucher(voucherId) ?: error("سند الصرف المراد تعديله غير موجود.")
            val oldLines = getStockIssueLines(voucherId)
            // Restore every old line first, inside this transaction, before checking the replacement quantities.
            oldLines.forEach { old ->
                val stock = getStockItemById(old.stockItemId) ?: error("تعذر العثور على الصنف المرتبط بسند الصرف القديم.")
                require(stock.totalUsedBase >= old.quantityBase) { "تعذر عكس سند الصرف؛ سجل المستخدم للصنف غير متسق." }
                updateStockItem(stock.copy(
                    quantityBase = FinanceCalculations.stockAfterIssueReversal(stock.quantityBase, old.quantityBase),
                    totalUsedBase = stock.totalUsedBase - old.quantityBase,
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteManualIssueMovements(voucherId)
            deleteStockIssueLines(voucherId)
            updateStockIssueVoucher(voucher.copy(id = voucherId, createdAtMillis = oldVoucher.createdAtMillis))
        }

        // Aggregate repeated lines for the same stock item before checking availability.
        val requestedByStock = lines.groupBy { it.stockItemId }.mapValues { (_, group) ->
            group.fold(0L) { total, line -> Math.addExact(total, line.quantityBase) }
        }
        requestedByStock.forEach { (stockId, requested) ->
            val stock = getStockItemById(stockId) ?: error("أحد الأصناف المحددة لم يعد موجودًا في المخزون.")
            check(stock.quantityBase >= requested) {
                "الرصيد غير كافٍ للصنف «${stock.productName}». المطلوب ${FinanceCalculations.formatStockQuantity(requested, stock.baseUnit)}، والمتاح ${FinanceCalculations.formatStockQuantity(stock.quantityBase, stock.baseUnit)}."
            }
        }
        lines.forEach { line ->
            val stock = getStockItemById(line.stockItemId) ?: error("تعذر العثور على صنف المخزون.")
            updateStockItem(stock.copy(
                quantityBase = FinanceCalculations.stockAfterIssue(stock.quantityBase, line.quantityBase),
                totalUsedBase = Math.addExact(stock.totalUsedBase, line.quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            insertStockIssueLine(StockIssueLineEntity(
                voucherId = voucherId,
                stockItemId = stock.id,
                productName = stock.productName,
                productType = stock.productType,
                baseUnit = stock.baseUnit,
                unit = line.unit,
                enteredQuantity = line.enteredQuantity,
                quantityBase = line.quantityBase
            ))
            insertStockMovement(StockMovementEntity(
                stockItemId = stock.id,
                referenceType = "MANUAL_ISSUE",
                referenceId = voucherId,
                quantityBase = -line.quantityBase,
                dateMillis = voucher.dateMillis,
                description = voucher.notes.ifBlank { voucher.reason }
            ))
        }
        return voucherId
    }

    @Transaction
    suspend fun deleteStockIssue(voucherId: Long): Boolean {
        val voucher = getStockIssueVoucher(voucherId) ?: return false
        val lines = getStockIssueLines(voucherId)
        val totalsByStock = lines.groupBy { it.stockItemId }.mapValues { (_, grouped) ->
            grouped.fold(0L) { total, line -> Math.addExact(total, line.quantityBase) }
        }
        val stocksToRestore = totalsByStock.map { (stockId, quantity) ->
            val stock = getStockItemById(stockId) ?: return false
            if (stock.totalUsedBase < quantity) return false
            Triple(stock, quantity, stockId)
        }
        // Validate the entire voucher before changing any row; grouped rows avoid stale snapshots for repeated items.
        stocksToRestore.forEach { (stock, quantity, _) ->
            updateStockItem(stock.copy(
                quantityBase = FinanceCalculations.stockAfterIssueReversal(stock.quantityBase, quantity),
                totalUsedBase = stock.totalUsedBase - quantity,
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        deleteManualIssueMovements(voucherId)
        deleteStockIssueLines(voucherId)
        deleteStockIssueVoucherRow(voucherId)
        return true
    }

    @Query("SELECT * FROM stock_issue_vouchers WHERE id = :id LIMIT 1")
    suspend fun getStockIssueVoucher(id: Long): StockIssueVoucherEntity?

    @Insert
    suspend fun insertStockMovement(item: StockMovementEntity): Long

    @Query("SELECT * FROM stock_movements WHERE referenceType = :type AND referenceId = :id")
    suspend fun getMovements(type: String, id: Long): List<StockMovementEntity>

    @Query("DELETE FROM stock_movements WHERE referenceType = :type AND referenceId = :id")
    suspend fun deleteMovements(type: String, id: Long)

    @Transaction
    suspend fun saveInvoice(invoice: InvoiceEntity, lines: List<InvoiceItemEntity>): Long {
        require(invoice.supplier.isNotBlank() && invoice.invoiceNumber.isNotBlank()) { "أدخل اسم المورد ورقم الفاتورة." }
        require(invoice.exchangeRateScaled > 0 && invoice.totalForeign >= 0 && invoice.totalYer >= 0) { "قيمة الفاتورة أو سعر الصرف غير صالح." }
        require(lines.isNotEmpty()) { "أضف صنفًا واحدًا على الأقل إلى الفاتورة." }
        require(invoice.currency in listOf("YER", "SAR", "USD")) { "عملة الفاتورة غير معتمدة." }
        require(lines.all { line ->
            line.productName.isNotBlank() && line.productType.isNotBlank() &&
                line.packageName.isNotBlank() && line.packageSize > 0L && line.packageCount > 0L &&
                line.unitPriceForeign >= 0L && line.lineTotalForeign >= 0L && line.lineTotalYer >= 0L &&
                line.unit in listOf("كجم", "جرام", "لتر", "ملي", "مل") &&
                line.quantityBase == FinanceCalculations.quantityToBase(line.packageSize, line.unit, line.packageCount) &&
                line.lineTotalForeign == FinanceCalculations.lineTotal(line.packageCount, line.unitPriceForeign) &&
                line.lineTotalYer == FinanceCalculations.toYemeniRials(line.lineTotalForeign, invoice.exchangeRateScaled)
        }) { "تحقق من وحدة وكمية وسعر وتحويل كل صنف في الفاتورة." }
        ensureSupplier(invoice.supplier)
        val linesForeign = lines.fold(0L) { total, line -> Math.addExact(total, line.lineTotalForeign) }
        val linesYer = lines.fold(0L) { total, line -> Math.addExact(total, line.lineTotalYer) }
        require(linesForeign == invoice.totalForeign && linesYer == invoice.totalYer) { "إجمالي الفاتورة لا يطابق مجموع أصنافها." }
        val invoiceId: Long
        if (invoice.id == 0L) {
            invoiceId = insertInvoice(invoice.copy(id = 0))
        } else {
            invoiceId = invoice.id
            val oldInvoice = getInvoiceById(invoiceId) ?: error("الفاتورة المراد تعديلها غير موجودة.")
            val oldSupplier = getSupplierByName(oldInvoice.supplier)
            if (oldSupplier != null) {
                val alreadyPaid = getSupplierPaidTotal(oldSupplier.id)
                val creditWithoutThis = getSupplierCreditExcludingInvoice(oldSupplier.name, invoiceId)
                val restoredCredit = if (invoice.paymentStatus == "آجل" && oldInvoice.supplier.equals(invoice.supplier, true)) invoice.totalYer else 0L
                require(alreadyPaid <= Math.addExact(creditWithoutThis, restoredCredit)) {
                    "لا يمكن تعديل الفاتورة بهذه الصورة؛ ستصبح دفعات المورد أكبر من إجمالي فواتيره الآجلة."
                }
            }
            val oldLines = getInvoiceItems(invoiceId)
            oldLines.forEach { old ->
                val stock = getStockItemById(old.stockItemId) ?: error("تعذر العثور على صنف المخزون المرتبط بالفاتورة.")
                require(stock.baseUnit == "g" || stock.baseUnit == "ml") { "وحدة التخزين الأساسية لصنف قديم في الفاتورة غير معتمدة؛ راجع بياناته قبل تعديل الفاتورة." }
                check(stock.quantityBase >= old.quantityBase) {
                    "لا يمكن تعديل الفاتورة؛ استُخدمت بعض كمياتها بالفعل. أعد الكميات المستخدمة أولًا."
                }
                updateStockItem(stock.copy(
                    quantityBase = stock.quantityBase - old.quantityBase,
                    totalReceivedBase = (stock.totalReceivedBase - old.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("INVOICE", invoiceId)
            deleteInvoiceItems(invoiceId)
            oldLines.map { it.stockItemId }.distinct().forEach { stockId ->
                val current = getStockItemById(stockId) ?: return@forEach
                updateStockItem(current.copy(lastReceivedAtMillis = getLastReceiptMillis(stockId)))
            }
            updateInvoice(invoice)
        }
        lines.forEach { draft ->
            require(draft.productName.isNotBlank() && draft.productType.isNotBlank() && draft.packageSize > 0 && draft.quantityBase > 0 && draft.packageCount > 0 && draft.unitPriceForeign >= 0 && draft.lineTotalForeign >= 0 && draft.lineTotalYer >= 0) { "تحقق من اسم وكمية وسعر الصنف." }
            val baseUnit = FinanceCalculations.baseUnitForQuantityUnit(draft.unit)
            val treatment = if (draft.productType == "الأسمدة") draft.treatmentType.takeIf { it in listOf("عام", "نمو", "تجذير", "ورقي") } ?: "عام" else draft.treatmentType.takeIf { it in listOf("حشري", "فطري", "ورقي", "جذري") } ?: "حشري"
            val normalizedDraft = draft.copy(treatmentType = treatment)
            val existing = findStockItemByTreatment(draft.productType, draft.productName.trim(), baseUnit, treatment)
            val stockId = if (existing == null) {
                insertStockItem(StockItemEntity(
                    productType = draft.productType,
                    productName = draft.productName.trim(),
                    activeIngredient = draft.activeIngredient.trim(),
                    treatmentType = treatment,
                    baseUnit = baseUnit
                ))
            } else existing.id
            val stock = getStockItemById(stockId) ?: error("تعذر إنشاء صنف المخزون.")
            updateStockItem(stock.copy(
                activeIngredient = draft.activeIngredient.ifBlank { stock.activeIngredient },
                treatmentType = treatment,
                quantityBase = Math.addExact(stock.quantityBase, draft.quantityBase),
                totalReceivedBase = Math.addExact(stock.totalReceivedBase, draft.quantityBase),
                updatedAtMillis = System.currentTimeMillis(),
                lastReceivedAtMillis = System.currentTimeMillis()
            ))
            insertInvoiceItem(normalizedDraft.copy(id = 0, invoiceId = invoiceId, stockItemId = stockId))
            insertStockMovement(StockMovementEntity(
                stockItemId = stockId,
                referenceType = "INVOICE",
                referenceId = invoiceId,
                quantityBase = draft.quantityBase,
                dateMillis = invoice.dateMillis,
                description = "استلام من فاتورة ${invoice.invoiceNumber}"
            ))
        }
        return invoiceId
    }

    @Transaction
    suspend fun deleteInvoiceSafely(invoiceId: Long): Boolean {
        val invoice = getInvoiceById(invoiceId) ?: return false
        if (invoice.paymentStatus == "آجل") {
            val supplier = getSupplierByName(invoice.supplier)
            if (supplier != null) {
                val paid = getSupplierPaidTotal(supplier.id)
                val creditAfterDelete = getSupplierCreditExcludingInvoice(supplier.name, invoiceId)
                if (paid > creditAfterDelete) return false
            }
        }
        val lines = getInvoiceItems(invoiceId)
        val requiredByStock = lines.groupBy { it.stockItemId }.mapValues { (_, rows) ->
            rows.fold(0L) { total, row -> Math.addExact(total, row.quantityBase) }
        }
        for ((stockId, required) in requiredByStock) {
            val stock = getStockItemById(stockId) ?: return false
            if (stock.quantityBase < required) return false
        }
        lines.forEach { line ->
            val stock = getStockItemById(line.stockItemId) ?: return@forEach
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - line.quantityBase,
                totalReceivedBase = (stock.totalReceivedBase - line.quantityBase).coerceAtLeast(0),
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        deleteMovements("INVOICE", invoiceId)
        lines.map { it.stockItemId }.distinct().forEach { stockId ->
            val current = getStockItemById(stockId) ?: return@forEach
            updateStockItem(current.copy(lastReceivedAtMillis = getLastReceiptMillis(stockId)))
        }
        deleteInvoiceRow(invoiceId)
        return true
    }

    @Transaction
    suspend fun addOpeningStock(type: String, name: String, ingredient: String, unit: String, quantityBase: Long, treatmentType: String = "عام", costYer: Long = 0L) {
        require(quantityBase > 0) { "أدخل كمية أكبر من صفر." }
        require(costYer >= 0L) { "قيمة الرصيد الافتتاحي لا يمكن أن تكون سالبة." }
        require(name.isNotBlank()) { "أدخل اسم الصنف." }
        val baseUnit = FinanceCalculations.baseUnitForQuantityUnit(unit)
        val normalizedTreatment = if (type == "الأسمدة") treatmentType.takeIf { it in listOf("عام", "نمو", "تجذير", "ورقي") } ?: "عام" else treatmentType.takeIf { it in listOf("حشري", "فطري", "ورقي", "جذري") } ?: "عام"
        val item = findStockItemByTreatment(type, name.trim(), baseUnit, normalizedTreatment)
        val id = if (item == null) insertStockItem(StockItemEntity(
            productType = type, productName = name.trim(), activeIngredient = ingredient.trim(), treatmentType = normalizedTreatment, baseUnit = baseUnit
        )) else item.id
        val stock = getStockItemById(id) ?: error("تعذر إنشاء صنف المخزون.")
        updateStockItem(stock.copy(
            activeIngredient = ingredient.ifBlank { stock.activeIngredient },
            quantityBase = Math.addExact(stock.quantityBase, quantityBase),
            totalReceivedBase = Math.addExact(stock.totalReceivedBase, quantityBase),
            totalOpeningCostYer = Math.addExact(stock.totalOpeningCostYer, costYer),
            updatedAtMillis = System.currentTimeMillis(),
            lastReceivedAtMillis = System.currentTimeMillis()
        ))
        insertStockMovement(StockMovementEntity(
            stockItemId = id, referenceType = "OPENING", referenceId = id,
            quantityBase = quantityBase, description = "إضافة رصيد يدوي"
        ))
    }

    @Transaction
    suspend fun addOpeningStockBatch(type: String, items: List<OpeningStockInput>): Int {
        require(items.isNotEmpty()) { "أضف صنفًا واحدًا على الأقل." }
        items.forEach { item ->
            addOpeningStock(type, item.name, item.ingredient, item.unit, item.quantityBase, item.treatmentType, item.costYer)
        }
        return items.size
    }

    @Transaction
    suspend fun saveChemicalExpense(
        expense: ExpenseEntity,
        lines: List<ChemicalOperationLineInput>
    ): Long {
        require(expense.category == "السموم" || expense.category == "الأسمدة") { "نوع العملية الكيميائية غير صحيح." }
        require(lines.isNotEmpty()) { "أضف صنفًا واحدًا على الأقل." }
        require(lines.all { it.productName.isNotBlank() && it.enteredQuantity > 0L && it.quantityBase > 0L }) { "تحقق من أسماء الأصناف وكمياتها." }
        require(lines.all { it.productType == expense.category }) { "لا تخلط الأسمدة والسموم في العملية الواحدة." }
        require(lines.all { it.unit in listOf("كجم", "لتر", "جرام", "ملي", "مل") }) { "وحدة قياس غير معتمدة." }
        require(lines.all { it.costAmountYer >= 0L && it.quantityBase == FinanceCalculations.quantityToBase(it.enteredQuantity, it.unit) }) { "قيمة الصنف أو تحويل وحدته غير صحيح." }
        // The operation total includes both the chemical items and the separate
        // "other operation expense" entered by the user. That extra amount is
        // stored in the expense notes and must NOT be deducted from stock.
        val itemTotal = lines.fold(0L) { total, line -> Math.addExact(total, line.costAmountYer) }
        val otherOperationCost = Regex("(?:^|\\n)خرج آخر للعملية:\\s*(\\d+)")
            .find(expense.notes)
            ?.groupValues
            ?.getOrNull(1)
            ?.toLongOrNull() ?: 0L
        val expectedOperationTotal = Math.addExact(itemTotal, otherOperationCost)
        require(expense.amount == expectedOperationTotal) {
            "إجمالي العملية يجب أن يساوي قيمة الأصناف + خرج آخر للعملية."
        }
        require(lines.all { if (it.productType == "الأسمدة") it.treatmentType in listOf("عام", "نمو", "تجذير", "ورقي") else it.treatmentType in listOf("حشري", "فطري", "ورقي", "جذري") }) { "حالة الصنف غير معتمدة." }
        // Revert the previous lines first when editing, then replace them atomically.
        if (expense.id != 0L) {
            // A 0.8.1 chemical entry had one legacy EXPENSE movement and no line table.
            // Reverse it once when migrating that record through its first multi-line edit.
            getMovements("EXPENSE", expense.id).forEach { movement ->
                val stock = getStockItemById(movement.stockItemId) ?: error("تعذر العثور على المخزون المرتبط بالعملية القديمة.")
                updateStockItem(stock.copy(
                    quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                    totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0L),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("EXPENSE", expense.id)
            val oldLines = getChemicalOperationLines(expense.id)
            oldLines.forEach { old ->
                getMovements("CHEMICAL_LINE", old.id).forEach { movement ->
                    val stock = getStockItemById(movement.stockItemId) ?: error("تعذر العثور على صنف مخزون مستخدم سابقًا.")
                    updateStockItem(stock.copy(
                        quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                        totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0L),
                        updatedAtMillis = System.currentTimeMillis()
                    ))
                }
                deleteMovements("CHEMICAL_LINE", old.id)
            }
            deleteChemicalOperationLines(expense.id)
            updateExpense(expense)
        }
        val expenseId = if (expense.id == 0L) insertExpense(expense) else expense.id
        lines.forEach { line ->
            val treatment = line.treatmentType
            val stock = findStockItemByTreatment(line.productType, line.productName.trim(),
                FinanceCalculations.baseUnitForQuantityUnit(line.unit), treatment)
                ?: error("الصنف «${line.productName}» بتصنيف «$treatment» غير موجود في المخزون. تحقق من فاتورته أولًا.")
            check(stock.quantityBase >= line.quantityBase) {
                "الرصيد غير كافٍ للصنف «${line.productName}». الكمية المطلوبة ${FinanceCalculations.formatStockQuantity(line.quantityBase, stock.baseUnit)}، والمتاح ${FinanceCalculations.formatStockQuantity(stock.quantityBase, stock.baseUnit)}."
            }
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - line.quantityBase,
                totalUsedBase = Math.addExact(stock.totalUsedBase, line.quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            val lineId = insertChemicalOperationLine(ChemicalOperationLineEntity(
                expenseId = expenseId, stockItemId = stock.id, productType = line.productType,
                productName = line.productName.trim(), activeIngredient = line.activeIngredient.ifBlank { stock.activeIngredient },
                treatmentType = treatment, unit = line.unit, enteredQuantity = line.enteredQuantity,
                quantityBase = line.quantityBase, costAmountYer = line.costAmountYer
            ))
            insertStockMovement(StockMovementEntity(
                stockItemId = stock.id, referenceType = "CHEMICAL_LINE", referenceId = lineId,
                quantityBase = -line.quantityBase, dateMillis = expense.dateMillis,
                description = "استخدام في ${expense.category} — ${expense.title}"
            ))
        }
        return expenseId
    }

    @Transaction
    suspend fun saveExpenseWithStock(
        expense: ExpenseEntity,
        stockType: String? = null,
        stockBaseUnit: String? = null,
        quantityBase: Long = 0L
    ): Long {
        require(quantityBase >= 0L) { "كمية الاستخدام لا يمكن أن تكون سالبة." }
        if (!stockBaseUnit.isNullOrBlank()) require(stockBaseUnit == "g" || stockBaseUnit == "ml") { "وحدة التخزين الأساسية غير معتمدة." }
        if (quantityBase > 0L) require(!stockType.isNullOrBlank() && !stockBaseUnit.isNullOrBlank()) { "حدد صنف المخزون ووحدته قبل تسجيل الكمية." }
        if (expense.id != 0L) {
            getMovements("EXPENSE", expense.id).forEach { movement ->
                val stock = getStockItemById(movement.stockItemId) ?: error("صنف المخزون غير موجود.")
                updateStockItem(stock.copy(
                    quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                    totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("EXPENSE", expense.id)
            updateExpense(expense)
        }
        val expenseId = if (expense.id == 0L) insertExpense(expense) else expense.id
        if (!stockType.isNullOrBlank() && !stockBaseUnit.isNullOrBlank() && quantityBase > 0) {
            val stock = findStockItem(stockType, expense.title.trim(), stockBaseUnit)
                ?: error("الصنف «${expense.title}» غير مسجل في المخزون. أضف رصيده من الفاتورة أو من شاشة المخزون أولًا.")
            check(stock.quantityBase >= quantityBase) {
                "الرصيد غير كافٍ للصنف «${expense.title}». الكمية المطلوبة ${FinanceCalculations.formatStockQuantity(quantityBase, stock.baseUnit)}، والمتاح ${FinanceCalculations.formatStockQuantity(stock.quantityBase, stock.baseUnit)}."
            }
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - quantityBase,
                totalUsedBase = Math.addExact(stock.totalUsedBase, quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            insertStockMovement(StockMovementEntity(
                stockItemId = stock.id,
                referenceType = "EXPENSE",
                referenceId = expenseId,
                quantityBase = -quantityBase,
                dateMillis = expense.dateMillis,
                description = "استخدام في عملية ${expense.category}"
            ))
        }
        return expenseId
    }

    @Transaction
    suspend fun deleteExpenseAndRestoreStock(expense: ExpenseEntity) {
        getMovements("EXPENSE", expense.id).forEach { movement ->
            val stock = getStockItemById(movement.stockItemId) ?: return@forEach
            updateStockItem(stock.copy(
                quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        getChemicalOperationLines(expense.id).forEach { line ->
            getMovements("CHEMICAL_LINE", line.id).forEach { movement ->
                val stock = getStockItemById(movement.stockItemId) ?: return@forEach
                updateStockItem(stock.copy(
                    quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                    totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("CHEMICAL_LINE", line.id)
        }
        deleteMovements("EXPENSE", expense.id)
        deleteChemicalOperationLines(expense.id)
        deleteOperationReminder("EXPENSE", expense.id)
        deleteExpense(expense)
    }

    @Insert suspend fun insertAuditEvent(item: MiyarAuditEventEntity): Long
    @Query("SELECT * FROM miyar_audit_events ORDER BY occurredAtMillis DESC,id DESC LIMIT 1000") fun observeRecentAuditEvents(): Flow<List<MiyarAuditEventEntity>>

    @Insert suspend fun insertPersonalHarvest(item: PersonalHarvestEntity): Long
    @Update suspend fun updatePersonalHarvest(item: PersonalHarvestEntity)
    @Query("DELETE FROM personal_harvests WHERE id=:id") suspend fun deletePersonalHarvest(id:Long)
    @Query("SELECT id FROM personal_harvest_days WHERE harvestId=:id") suspend fun getHarvestDayIds(id:Long):List<Long>
    @Query("SELECT (SELECT COUNT(*) FROM distributor_transactions WHERE sourceDayId=:dayId AND received>0) + (SELECT COUNT(*) FROM harvest_debtor_transactions WHERE sourceDayId=:dayId AND paid>0) + (SELECT COUNT(*) FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE sourceDayId=:dayId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE sourceDayId=:dayId)))")
    suspend fun countRecordedPaymentsForDay(dayId:Long):Int
    @Query("SELECT (SELECT COUNT(*) FROM distributor_transactions WHERE harvestId=:harvestId AND received>0) + (SELECT COUNT(*) FROM harvest_debtor_transactions WHERE harvestId=:harvestId AND paid>0) + (SELECT COUNT(*) FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE harvestId=:harvestId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE harvestId=:harvestId)))")
    suspend fun countRecordedPaymentsForHarvest(harvestId:Long):Int
    @Transaction suspend fun deletePersonalHarvestSafely(id:Long):Boolean {
        // Never erase the payment trail together with a harvest. Close its balances first.
        if (countRecordedPaymentsForHarvest(id) > 0) return false
        val profile = getPersonalHarvestById(id) ?: return false
        insertAuditEvent(MiyarAuditEventEntity(
            entityType="PERSONAL_HARVEST_PROFILE", entityId=id, eventType="DELETE",
            beforeSnapshot="plantationId=${profile.plantationId};name=${profile.name};startMillis=${profile.startMillis};expectedEndMillis=${profile.expectedEndMillis};actualEndMillis=${profile.actualEndMillis};notes=${profile.notes}"
        ))
        getHarvestDayIds(id).forEach { dayId ->
            deleteHarvestPartyPaymentsForDay(dayId)
            deleteDistributorTransactionsForDay(dayId)
            deleteDebtorTransactionsForDay(dayId)
            deleteHarvestDayLines(dayId)
            deletePersonalHarvestDay(dayId)
        }
        deleteHarvestPartyPaymentsForHarvest(id)
        deleteDistributorTransactionsForHarvest(id)
        deleteDebtorTransactionsForHarvest(id)
        deletePersonalHarvest(id)
        return true
    }
    @Transaction suspend fun deletePersonalHarvestDaySafely(dayId:Long):Boolean {
        if (countRecordedPaymentsForDay(dayId) > 0) return false
        val day = getPersonalHarvestDayById(dayId) ?: return false
        insertAuditEvent(MiyarAuditEventEntity(
            entityType="PERSONAL_HARVEST_DAY", entityId=dayId, eventType="DELETE",
            beforeSnapshot="harvestId=${day.harvestId};dateMillis=${day.dateMillis};pickerCount=${day.pickerCount};pickerWage=${day.pickerWage};otherExpenses=${day.otherExpenses};notes=${day.notes}",
            referenceId=day.harvestId
        ))
        deleteHarvestPartyPaymentsForDay(dayId)
        deleteDistributorTransactionsForDay(dayId)
        deleteDebtorTransactionsForDay(dayId)
        deleteHarvestDayLines(dayId)
        deletePersonalHarvestDay(dayId)
        return true
    }
    @Insert suspend fun insertPersonalHarvestDay(item:PersonalHarvestDayEntity):Long
    @Update suspend fun updatePersonalHarvestDay(item:PersonalHarvestDayEntity)
    @Query("DELETE FROM personal_harvest_days WHERE id=:id") suspend fun deletePersonalHarvestDay(id:Long)
    @Query("SELECT * FROM personal_harvest_days WHERE harvestId=:harvestId ORDER BY dateMillis DESC,id DESC") fun observeHarvestDays(harvestId:Long):Flow<List<PersonalHarvestDayEntity>>
    @Query("SELECT * FROM personal_harvest_days ORDER BY dateMillis DESC,id DESC") fun observeAllHarvestDays():Flow<List<PersonalHarvestDayEntity>>
    @Query("SELECT * FROM personal_harvest_days ORDER BY dateMillis DESC,id DESC LIMIT 300") fun observeRecentHarvestDays():Flow<List<PersonalHarvestDayEntity>>

    /** Read-only activity projection for harvest records that live outside the expenses table. */
    @Query("""
        SELECT -d.id AS id, h.plantationId AS plantationId, p.name AS plantationName,
               'القطفات' AS category, h.name || ' • يوم قطفة' AS title,
               COALESCE(SUM(l.total),0) AS amount, 'YER' AS currency,
               d.dateMillis AS dateMillis, d.notes AS notes
        FROM personal_harvest_days d
        INNER JOIN personal_harvests h ON h.id=d.harvestId
        INNER JOIN plantations p ON p.id=h.plantationId
        LEFT JOIN personal_harvest_day_lines l ON l.dayId=d.id
        GROUP BY d.id
        UNION ALL
        SELECT (-1000000000000 - s.id) AS id, s.plantationId AS plantationId,
               COALESCE(p.name,'غير محدد') AS plantationName, 'القطفات' AS category,
               ('بيع: ' || COALESCE(b.name,'مشتري') || ' • ' || s.harvestName) AS title,
               MAX(s.agreedAmount - s.discountAmount,0) AS amount, 'YER' AS currency,
               s.saleDateMillis AS dateMillis, s.notes AS notes
        FROM buyer_sales s
        LEFT JOIN plantations p ON p.id=s.plantationId
        LEFT JOIN qat_buyers b ON b.id=s.buyerId
        ORDER BY dateMillis DESC, id DESC
        LIMIT 1000
    """)
    fun observeHarvestOperations(): Flow<List<ExpenseWithPlantation>>
    @Insert suspend fun insertPersonalHarvestDayLine(item:PersonalHarvestDayLineEntity):Long
    @Query("SELECT * FROM personal_harvest_day_lines WHERE dayId=:dayId ORDER BY id") fun observeHarvestDayLines(dayId:Long):Flow<List<PersonalHarvestDayLineEntity>>
    @Query("SELECT * FROM personal_harvest_day_lines WHERE dayId=:dayId ORDER BY id") suspend fun getHarvestDayLines(dayId:Long):List<PersonalHarvestDayLineEntity>
    @Update suspend fun updateHarvestDayLine(item:PersonalHarvestDayLineEntity)
    @Query("SELECT * FROM personal_harvest_day_lines ORDER BY createdAt DESC,id DESC") fun observeAllHarvestDayLines():Flow<List<PersonalHarvestDayLineEntity>>
    @Query("SELECT * FROM personal_harvest_day_lines ORDER BY createdAt DESC,id DESC LIMIT 300") fun observeRecentHarvestDayLines():Flow<List<PersonalHarvestDayLineEntity>>
    @Query("DELETE FROM personal_harvest_day_lines WHERE dayId=:dayId") suspend fun deleteHarvestDayLines(dayId:Long)
    @Query("DELETE FROM personal_harvest_day_lines WHERE id=:id") suspend fun deleteHarvestDayLine(id:Long)
    @Query("SELECT * FROM market_distributors WHERE name=:name COLLATE NOCASE LIMIT 1") suspend fun findDistributor(name:String):MarketDistributorEntity?
    @Query("SELECT * FROM harvest_debtors WHERE name=:name COLLATE NOCASE LIMIT 1") suspend fun findDebtor(name:String):HarvestDebtorEntity?
    @Query("SELECT * FROM qat_buyers WHERE name=:name COLLATE NOCASE LIMIT 1") suspend fun findBuyer(name:String):QatBuyerEntity?
    @Query("SELECT * FROM personal_harvests ORDER BY createdAt DESC") fun observePersonalHarvests(): Flow<List<PersonalHarvestEntity>>
    @Query("SELECT * FROM personal_harvests WHERE id=:id LIMIT 1") suspend fun getPersonalHarvestById(id:Long):PersonalHarvestEntity?
    @Query("SELECT * FROM personal_harvest_days WHERE id=:id LIMIT 1") suspend fun getPersonalHarvestDayById(id:Long):PersonalHarvestDayEntity?
    @Insert suspend fun insertDebtor(item: HarvestDebtorEntity): Long
    @Query("SELECT * FROM harvest_debtors ORDER BY name COLLATE NOCASE") fun observeDebtors(): Flow<List<HarvestDebtorEntity>>
    @Query("SELECT * FROM harvest_debtors WHERE id=:id LIMIT 1") suspend fun getDebtorById(id:Long):HarvestDebtorEntity?
    @Query("SELECT p.name FROM harvest_debtors p LEFT JOIN harvest_debtor_transactions t ON t.debtorId=p.id GROUP BY p.id ORDER BY MAX(t.dateMillis) DESC, COUNT(t.id) DESC, p.name COLLATE NOCASE") fun observeDebtorNameSuggestions():Flow<List<String>>
    @Insert suspend fun insertDebtorTransaction(item: HarvestDebtorTransactionEntity): Long
    @Transaction
    suspend fun insertPartySaleLines(
        partyType: String, partyId: Long, harvestId: Long, dateMillis: Long, notes: String,
        lines: List<HarvestPartySaleLineDraft>
    ): List<Long> {
        require(partyType == "DISTRIBUTOR" || partyType == "DEBTOR") { "نوع الحساب غير صحيح." }
        require(partyId > 0L && lines.isNotEmpty()) { "أدخل منتجًا واحدًا على الأقل." }
        val insertedIds = mutableListOf<Long>()
        for (line in lines) {
            require(line.productType in listOf("عود", "مدبوش", "فراد", "قطل", "خوالف")) { "نوع المنتج غير معتمد." }
            require(line.quantity > 0L && line.unitPrice >= 0L && line.total >= 0L && line.calculatedTotal >= 0L) { "راجع كميات وقيم المنتجات." }
            val expectedCalculated = FinanceCalculations.effectiveProductTotal(line.quantity, line.unitPrice, null)
            require(line.calculatedTotal == expectedCalculated) { "الإجمالي الحسابي الأصلي للمنتج غير متطابق." }
            if (!line.isTotalManual && line.isValueComplete) {
                require(line.total == line.calculatedTotal) { "إجمالي المنتج لا يطابق الكمية وسعر الوحدة." }
            }
            val insertedId = if (partyType == "DISTRIBUTOR") {
                insertDistributorTransaction(DistributorTransactionEntity(
                    distributorId = partyId, harvestId = harvestId, productType = line.productType,
                    quantity = line.quantity, unitPrice = line.unitPrice, total = line.total,
                    dateMillis = dateMillis, notes = notes, calculatedTotal = line.calculatedTotal,
                    isTotalManual = line.isTotalManual, isValueComplete = line.isValueComplete
                ))
            } else {
                insertDebtorTransaction(HarvestDebtorTransactionEntity(
                    debtorId = partyId, harvestId = harvestId, productType = line.productType,
                    quantity = line.quantity, unitPrice = line.unitPrice, total = line.total,
                    dateMillis = dateMillis, notes = notes, calculatedTotal = line.calculatedTotal,
                    isTotalManual = line.isTotalManual, isValueComplete = line.isValueComplete
                ))
            }
            insertedIds += insertedId
        }
        return insertedIds
    }
    @Update suspend fun updateDebtorTransaction(item:HarvestDebtorTransactionEntity)
    @Query("SELECT * FROM harvest_debtor_transactions WHERE debtorId=:debtorId ORDER BY dateMillis DESC,id DESC") fun observeDebtorTransactions(debtorId:Long): Flow<List<HarvestDebtorTransactionEntity>>
    @Query("SELECT * FROM harvest_debtor_transactions WHERE id=:id LIMIT 1") suspend fun getDebtorTransaction(id:Long):HarvestDebtorTransactionEntity?

    @Transaction
    suspend fun updateDistributorTransactionSafely(
        transactionId: Long, productType: String, quantity: Long, unitPrice: Long, total: Long,
        calculatedTotal: Long, isTotalManual: Boolean, isValueComplete: Boolean,
        dateMillis: Long, notes: String
    ) {
        require(productType in listOf("عود", "مدبوش", "فراد", "قطل", "خوالف")) { "نوع المنتج غير معتمد." }
        require(quantity > 0L && unitPrice >= 0L && total >= 0L && dateMillis > 0L) { "تحقق من كمية وسعر وتاريخ العملية." }
        val calculated = FinanceCalculations.effectiveProductTotal(quantity, unitPrice, null)
        require(calculatedTotal == calculated) { "الإجمالي الحسابي الأصلي غير صحيح." }
        if (!isTotalManual && isValueComplete) require(total == calculatedTotal) { "الإجمالي لا يطابق العدد وسعر الوحدة." }
        val old = getDistributorTransaction(transactionId) ?: error("عملية الموزع غير موجودة.")
        require(old.sourceDayId == 0L) { "عدّل عملية يوم القطفة من ملف القطفة نفسه حتى تبقى كل التفاصيل مترابطة." }
        val discounts = getDistributorDiscountTotal(transactionId)
        val distribution = getDistributionExpenseTotal(transactionId)
        val net = FinanceCalculations.sellerNetSale(total, discounts, distribution)
        val collected = getAccountCollectedTotal("DISTRIBUTOR", transactionId)
        require(collected <= net) { "القيمة الجديدة أقل من المبالغ التي استلمتها سابقًا من هذا الموزع." }
        val updated = old.copy(
            productType = productType, quantity = quantity, unitPrice = unitPrice, total = total,
            calculatedTotal = calculatedTotal, isTotalManual = isTotalManual,
            isValueComplete = isValueComplete, dateMillis = dateMillis, notes = notes.trim()
        )
        updateDistributorTransaction(updated)
        insertAuditEvent(MiyarAuditEventEntity(
            entityType = "DISTRIBUTOR_TRANSACTION", entityId = transactionId, eventType = "UPDATE",
            beforeSnapshot = "productType=${old.productType};quantity=${old.quantity};unitPrice=${old.unitPrice};total=${old.total};dateMillis=${old.dateMillis}",
            afterSnapshot = "productType=${updated.productType};quantity=${updated.quantity};unitPrice=${updated.unitPrice};total=${updated.total};calculatedTotal=${updated.calculatedTotal};isTotalManual=${updated.isTotalManual};dateMillis=${updated.dateMillis}"
        ))
    }

    @Transaction
    suspend fun updateDebtorTransactionSafely(
        transactionId: Long, productType: String, quantity: Long, unitPrice: Long, total: Long,
        calculatedTotal: Long, isTotalManual: Boolean, isValueComplete: Boolean,
        dateMillis: Long, notes: String
    ) {
        require(productType in listOf("عود", "مدبوش", "فراد", "قطل", "خوالف")) { "نوع المنتج غير معتمد." }
        require(quantity > 0L && unitPrice >= 0L && total >= 0L && dateMillis > 0L) { "تحقق من كمية وسعر وتاريخ العملية." }
        val calculated = FinanceCalculations.effectiveProductTotal(quantity, unitPrice, null)
        require(calculatedTotal == calculated) { "الإجمالي الحسابي الأصلي غير صحيح." }
        if (!isTotalManual && isValueComplete) require(total == calculatedTotal) { "الإجمالي لا يطابق العدد وسعر الوحدة." }
        val old = getDebtorTransaction(transactionId) ?: error("عملية العميل غير موجودة.")
        require(old.sourceDayId == 0L) { "عدّل عملية يوم القطفة من ملف القطفة نفسه حتى تبقى كل التفاصيل مترابطة." }
        val collected = getAccountCollectedTotal("DEBTOR", transactionId)
        require(collected <= total) { "القيمة الجديدة أقل من المبالغ التي دفعها العميل سابقًا." }
        val updated = old.copy(
            productType = productType, quantity = quantity, unitPrice = unitPrice, total = total,
            calculatedTotal = calculatedTotal, isTotalManual = isTotalManual,
            isValueComplete = isValueComplete, dateMillis = dateMillis, notes = notes.trim()
        )
        updateDebtorTransaction(updated)
        insertAuditEvent(MiyarAuditEventEntity(
            entityType = "DEBTOR_TRANSACTION", entityId = transactionId, eventType = "UPDATE",
            beforeSnapshot = "productType=${old.productType};quantity=${old.quantity};unitPrice=${old.unitPrice};total=${old.total};dateMillis=${old.dateMillis}",
            afterSnapshot = "productType=${updated.productType};quantity=${updated.quantity};unitPrice=${updated.unitPrice};total=${updated.total};calculatedTotal=${updated.calculatedTotal};isTotalManual=${updated.isTotalManual};dateMillis=${updated.dateMillis}"
        ))
    }

    @Query("DELETE FROM harvest_debtor_transactions WHERE id=:id") suspend fun deleteDebtorTransaction(id:Long)
    @Query("SELECT * FROM harvest_debtor_transactions ORDER BY dateMillis DESC,id DESC") fun observeAllDebtorTransactions():Flow<List<HarvestDebtorTransactionEntity>>
    @Query("SELECT * FROM harvest_debtor_transactions ORDER BY dateMillis DESC,id DESC LIMIT 300") fun observeRecentDebtorTransactions():Flow<List<HarvestDebtorTransactionEntity>>
    @Query("DELETE FROM harvest_debtor_transactions WHERE sourceDayId=:dayId") suspend fun deleteDebtorTransactionsForDay(dayId:Long)
    @Query("DELETE FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE sourceDayId=:dayId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE sourceDayId=:dayId))") suspend fun deleteHarvestPartyPaymentsForDay(dayId:Long)
    @Query("DELETE FROM harvest_party_payments WHERE (partyType='DISTRIBUTOR' AND transactionId IN (SELECT id FROM distributor_transactions WHERE harvestId=:harvestId)) OR (partyType='DEBTOR' AND transactionId IN (SELECT id FROM harvest_debtor_transactions WHERE harvestId=:harvestId))") suspend fun deleteHarvestPartyPaymentsForHarvest(harvestId:Long)
    @Query("DELETE FROM distributor_transactions WHERE harvestId=:harvestId") suspend fun deleteDistributorTransactionsForHarvest(harvestId:Long)
    @Query("DELETE FROM harvest_debtor_transactions WHERE harvestId=:harvestId") suspend fun deleteDebtorTransactionsForHarvest(harvestId:Long)
    @Insert suspend fun insertBuyer(item: QatBuyerEntity): Long
    @Query("SELECT * FROM qat_buyers ORDER BY name COLLATE NOCASE") fun observeBuyers(): Flow<List<QatBuyerEntity>>
    @Query("SELECT * FROM qat_buyers WHERE id=:id LIMIT 1") suspend fun getBuyerById(id:Long):QatBuyerEntity?
    @Query("SELECT p.name FROM qat_buyers p LEFT JOIN buyer_sales s ON s.buyerId=p.id GROUP BY p.id ORDER BY MAX(s.saleDateMillis) DESC, COUNT(s.id) DESC, p.name COLLATE NOCASE") fun observeBuyerNameSuggestions():Flow<List<String>>
    @Insert suspend fun insertBuyerSale(item: BuyerSaleEntity): Long
    @Update suspend fun updateBuyerSale(item:BuyerSaleEntity)
    @Query("SELECT * FROM buyer_sales WHERE buyerId=:buyerId ORDER BY saleDateMillis DESC") fun observeBuyerSales(buyerId:Long): Flow<List<BuyerSaleEntity>>
    @Query("SELECT * FROM buyer_sales ORDER BY saleDateMillis DESC") fun observeAllBuyerSales(): Flow<List<BuyerSaleEntity>>
    @Query("SELECT * FROM buyer_sales ORDER BY saleDateMillis DESC,id DESC LIMIT 300") fun observeRecentBuyerSales(): Flow<List<BuyerSaleEntity>>
    @Query("SELECT * FROM buyer_sales WHERE id=:id LIMIT 1") suspend fun getBuyerSaleById(id:Long):BuyerSaleEntity?
    @Insert suspend fun insertBuyerPayment(item: BuyerPaymentEntity): Long
    @Query("SELECT * FROM buyer_payments WHERE saleId=:saleId ORDER BY dateMillis DESC") fun observeBuyerPayments(saleId:Long): Flow<List<BuyerPaymentEntity>>
    @Query("SELECT * FROM buyer_payments ORDER BY dateMillis DESC,id DESC") fun observeAllBuyerPayments():Flow<List<BuyerPaymentEntity>>
    @Query("SELECT * FROM buyer_payments ORDER BY dateMillis DESC,id DESC LIMIT 300") fun observeRecentBuyerPayments():Flow<List<BuyerPaymentEntity>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM buyer_payments") fun observeAllBuyerPaymentsTotal(): Flow<Long>
    @Query("SELECT COALESCE(SUM(amount),0) FROM buyer_payments WHERE saleId=:saleId") fun observeBuyerPaymentsTotal(saleId:Long): Flow<Long>
    @Insert suspend fun insertDistributor(item: MarketDistributorEntity): Long
    @Query("SELECT * FROM market_distributors ORDER BY name COLLATE NOCASE") fun observeDistributors(): Flow<List<MarketDistributorEntity>>
    @Query("SELECT * FROM market_distributors WHERE id=:id LIMIT 1") suspend fun getDistributorById(id:Long):MarketDistributorEntity?
    @Query("SELECT p.name FROM market_distributors p LEFT JOIN distributor_transactions t ON t.distributorId=p.id GROUP BY p.id ORDER BY MAX(t.dateMillis) DESC, COUNT(t.id) DESC, p.name COLLATE NOCASE") fun observeDistributorNameSuggestions():Flow<List<String>>
    @Insert suspend fun insertDistributorTransaction(item: DistributorTransactionEntity): Long
    @Update suspend fun updateDistributorTransaction(item:DistributorTransactionEntity)
    @Query("SELECT * FROM distributor_transactions WHERE distributorId=:id ORDER BY dateMillis DESC,id DESC") fun observeDistributorTransactions(id:Long): Flow<List<DistributorTransactionEntity>>
    @Query("SELECT * FROM distributor_transactions WHERE id=:id LIMIT 1") suspend fun getDistributorTransaction(id:Long):DistributorTransactionEntity?
    @Query("DELETE FROM distributor_transactions WHERE id=:id") suspend fun deleteDistributorTransaction(id:Long)
    @Query("SELECT * FROM distributor_transactions ORDER BY dateMillis DESC,id DESC") fun observeAllDistributorTransactions():Flow<List<DistributorTransactionEntity>>
    @Query("SELECT * FROM distributor_transactions ORDER BY dateMillis DESC,id DESC LIMIT 300") fun observeRecentDistributorTransactions():Flow<List<DistributorTransactionEntity>>

    @Insert(onConflict = androidx.room.OnConflictStrategy.IGNORE) suspend fun insertDistributorAdjustmentRow(item: DistributorTransactionAdjustmentEntity): Long
    @Insert(onConflict = androidx.room.OnConflictStrategy.IGNORE) suspend fun insertDistributionExpensePaymentRow(item: DistributionExpensePaymentEntity): Long
    @Query("SELECT * FROM distributor_transaction_adjustments WHERE transactionId=:transactionId ORDER BY dateMillis DESC,id DESC") fun observeDistributorAdjustments(transactionId:Long):Flow<List<DistributorTransactionAdjustmentEntity>>
    @Query("SELECT * FROM distributor_transaction_adjustments ORDER BY dateMillis DESC,id DESC") fun observeAllDistributorAdjustments():Flow<List<DistributorTransactionAdjustmentEntity>>
    @Query("SELECT * FROM distribution_expense_payments WHERE adjustmentId=:adjustmentId ORDER BY dateMillis DESC,id DESC") fun observeDistributionExpensePayments(adjustmentId:Long):Flow<List<DistributionExpensePaymentEntity>>
    @Query("SELECT * FROM distribution_expense_payments ORDER BY dateMillis DESC,id DESC") fun observeAllDistributionExpensePayments():Flow<List<DistributionExpensePaymentEntity>>
    @Query("SELECT * FROM distributor_transaction_adjustments WHERE idempotencyKey=:key LIMIT 1") suspend fun getDistributorAdjustmentByKey(key:String):DistributorTransactionAdjustmentEntity?
    @Query("SELECT * FROM distribution_expense_payments WHERE idempotencyKey=:key LIMIT 1") suspend fun getDistributionExpensePaymentByKey(key:String):DistributionExpensePaymentEntity?
    @Query("SELECT * FROM distributor_transaction_adjustments WHERE id=:id LIMIT 1") suspend fun getDistributorAdjustmentById(id:Long):DistributorTransactionAdjustmentEntity?
    @Query("SELECT COALESCE(SUM(amount),0) FROM distributor_transaction_adjustments WHERE transactionId=:transactionId AND kind='SELLER_DISCOUNT'") suspend fun getDistributorDiscountTotal(transactionId:Long):Long
    @Query("SELECT COALESCE(SUM(amount),0) FROM distributor_transaction_adjustments WHERE transactionId=:transactionId AND kind='DISTRIBUTION_EXPENSE'") suspend fun getDistributionExpenseTotal(transactionId:Long):Long
    @Query("SELECT COALESCE(SUM(p.amount),0) FROM distribution_expense_payments p INNER JOIN distributor_transaction_adjustments a ON a.id=p.adjustmentId WHERE a.transactionId=:transactionId") suspend fun getDistributionExpensePaidTotal(transactionId:Long):Long
    @Query("SELECT COALESCE(SUM(amount),0) FROM distribution_expense_payments WHERE adjustmentId=:adjustmentId") suspend fun getDistributionExpensePaidForAdjustment(adjustmentId:Long):Long

    @Transaction
    suspend fun saveDistributorAdjustment(item:DistributorTransactionAdjustmentEntity):Long {
        require(item.amount>0L) { "يجب أن يكون مبلغ الخصم أو خرج التوزيع أكبر من صفر." }
        require(item.kind=="SELLER_DISCOUNT" || item.kind=="DISTRIBUTION_EXPENSE") { "نوع الحركة غير معروف." }
        require(item.description.isNotBlank()) { "أدخل بيان الخصم أو خرج التوزيع." }
        val existingByKey=getDistributorAdjustmentByKey(item.idempotencyKey)
        if (existingByKey!=null) {
            require(existingByKey.transactionId==item.transactionId && existingByKey.kind==item.kind && existingByKey.amount==item.amount && existingByKey.dateMillis==item.dateMillis && existingByKey.description==item.description.trim()) { "مفتاح العملية مكرر لبيانات مختلفة." }
            return existingByKey.id
        }
        val sale=getDistributorTransaction(item.transactionId) ?: error("عملية البيع المحددة غير موجودة.")
        val discount=Math.addExact(getDistributorDiscountTotal(item.transactionId), if(item.kind=="SELLER_DISCOUNT") item.amount else 0L)
        val distribution=Math.addExact(getDistributionExpenseTotal(item.transactionId), if(item.kind=="DISTRIBUTION_EXPENSE") item.amount else 0L)
        FinanceCalculations.sellerNetSale(sale.total,discount,distribution)
        val id=insertDistributorAdjustmentRow(item)
        if(id<=0L) return getDistributorAdjustmentByKey(item.idempotencyKey)?.id ?: error("تعذر تسجيل الحركة.")
        insertAuditEvent(MiyarAuditEventEntity(entityType="DISTRIBUTOR_TRANSACTION_ADJUSTMENT",entityId=id,eventType="CREATE",afterSnapshot="transactionId=${item.transactionId};kind=${item.kind};amount=${item.amount};dateMillis=${item.dateMillis};description=${item.description}",referenceId=item.transactionId))
        return id
    }

    @Transaction
    suspend fun saveDistributionExpensePayment(item:DistributionExpensePaymentEntity):Long {
        require(item.amount>0L) { "مبلغ السداد يجب أن يكون أكبر من صفر." }
        val existingByKey=getDistributionExpensePaymentByKey(item.idempotencyKey)
        if(existingByKey!=null) {
            require(existingByKey.adjustmentId==item.adjustmentId && existingByKey.amount==item.amount && existingByKey.dateMillis==item.dateMillis && existingByKey.method==item.method && existingByKey.notes==item.notes) { "مفتاح السداد مكرر لبيانات مختلفة." }
            return existingByKey.id
        }
        val adjustment=getDistributorAdjustmentById(item.adjustmentId) ?: error("خرج التوزيع المحدد غير موجود.")
        require(adjustment.kind=="DISTRIBUTION_EXPENSE") { "لا يمكن سداد حركة ليست مصروف توزيع." }
        val paid=Math.addExact(getDistributionExpensePaidForAdjustment(item.adjustmentId),item.amount)
        require(paid<=adjustment.amount) { "مبلغ السداد يتجاوز قيمة خرج التوزيع المتبقية." }
        val id=insertDistributionExpensePaymentRow(item)
        if(id<=0L) return getDistributionExpensePaymentByKey(item.idempotencyKey)?.id ?: error("تعذر تسجيل السداد.")
        insertAuditEvent(MiyarAuditEventEntity(entityType="DISTRIBUTION_EXPENSE_PAYMENT",entityId=id,eventType="CREATE",afterSnapshot="adjustmentId=${item.adjustmentId};amount=${item.amount};dateMillis=${item.dateMillis};method=${item.method}",referenceId=adjustment.transactionId))
        return id
    }
    @Query("DELETE FROM distributor_transactions WHERE sourceDayId=:dayId") suspend fun deleteDistributorTransactionsForDay(dayId:Long)
    @Insert(onConflict = androidx.room.OnConflictStrategy.IGNORE) suspend fun insertHarvestPartyPaymentRow(item:HarvestPartyPaymentEntity):Long
    @Query("SELECT * FROM harvest_party_payments WHERE idempotencyKey=:key LIMIT 1") suspend fun getHarvestPartyPaymentByKey(key:String):HarvestPartyPaymentEntity?
    @Transaction
    suspend fun saveHarvestPartyPayment(item:HarvestPartyPaymentEntity):Long {
        require(item.amount>0L) { "مبلغ الدفعة يجب أن يكون أكبر من صفر." }
        require(item.partyType=="DISTRIBUTOR" || item.partyType=="DEBTOR") { "نوع الحساب غير صحيح." }
        val prior=getHarvestPartyPaymentByKey(item.idempotencyKey)
        if(prior!=null) {
            require(prior.partyType==item.partyType && prior.partyId==item.partyId && prior.transactionId==item.transactionId && prior.amount==item.amount && prior.dateMillis==item.dateMillis && prior.method==item.method && prior.notes==item.notes) { "مفتاح الدفعة مكرر لبيانات مختلفة." }
            return prior.id
        }
        val transactionExists=if(item.partyType=="DISTRIBUTOR") getDistributorTransaction(item.transactionId)!=null else getDebtorTransaction(item.transactionId)!=null
        require(transactionExists) { "عملية الحساب المحددة غير موجودة." }
        val collected=getAccountCollectedTotal(item.partyType,item.transactionId)
        val remaining=if(item.partyType=="DISTRIBUTOR") {
            val sale=getDistributorTransaction(item.transactionId) ?: error("عملية البيع غير موجودة.")
            val discount=getDistributorDiscountTotal(item.transactionId)
            val distribution=getDistributionExpenseTotal(item.transactionId)
            FinanceCalculations.sellerNetSale(sale.total,discount,distribution)-collected
        } else {
            val sale=getDebtorTransaction(item.transactionId) ?: error("عملية العميل غير موجودة.")
            sale.total-collected
        }
        require(item.amount<=remaining) { "مبلغ الدفعة يتجاوز المتبقي المستحق." }
        val id=insertHarvestPartyPaymentRow(item)
        if(id<=0L) return getHarvestPartyPaymentByKey(item.idempotencyKey)?.id ?: error("تعذر تسجيل الدفعة.")
        insertAuditEvent(MiyarAuditEventEntity(entityType="HARVEST_PARTY_PAYMENT",entityId=id,eventType="CREATE",afterSnapshot="partyType=${item.partyType};partyId=${item.partyId};transactionId=${item.transactionId};amount=${item.amount};dateMillis=${item.dateMillis};method=${item.method}",referenceId=item.transactionId))
        return id
    }
    @Query("SELECT * FROM harvest_party_payments WHERE partyType=:partyType AND partyId=:partyId ORDER BY dateMillis DESC,id DESC") fun observeHarvestPartyPayments(partyType:String,partyId:Long):Flow<List<HarvestPartyPaymentEntity>>
    @Query("SELECT * FROM harvest_party_payments ORDER BY dateMillis DESC,id DESC") fun observeAllHarvestPartyPayments():Flow<List<HarvestPartyPaymentEntity>>
    @Query("SELECT * FROM harvest_party_payments ORDER BY dateMillis DESC,id DESC LIMIT 300") fun observeRecentHarvestPartyPayments():Flow<List<HarvestPartyPaymentEntity>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM harvest_party_payments WHERE partyType=:partyType AND transactionId=:transactionId") fun observeHarvestPartyPaymentTotal(partyType:String,transactionId:Long):Flow<Long>
    @Query("SELECT (CASE WHEN :partyType='DISTRIBUTOR' THEN COALESCE((SELECT received FROM distributor_transactions WHERE id=:transactionId),0) ELSE COALESCE((SELECT paid FROM harvest_debtor_transactions WHERE id=:transactionId),0) END) + COALESCE((SELECT SUM(amount) FROM harvest_party_payments WHERE partyType=:partyType AND transactionId=:transactionId),0)") suspend fun getAccountCollectedTotal(partyType:String,transactionId:Long):Long
    @Query("DELETE FROM harvest_party_payments WHERE partyType=:partyType AND transactionId=:transactionId") suspend fun deleteHarvestPartyPaymentsForTransaction(partyType:String,transactionId:Long)
    @Query("UPDATE harvest_party_payments SET partyId=:newPartyId WHERE partyType=:partyType AND transactionId=:transactionId") suspend fun moveHarvestPartyPayments(transactionId:Long,partyType:String,newPartyId:Long)
    @Query("SELECT productType FROM personal_harvest_day_lines GROUP BY productType ORDER BY COUNT(*) DESC, MAX(createdAt) DESC, productType COLLATE NOCASE") fun observeHarvestProductSuggestions():Flow<List<String>>

    @Query("SELECT COALESCE(SUM(total),0) FROM personal_harvest_day_lines WHERE category IN ('distributor','cash','debt')") fun observePersonalHarvestRevenue():Flow<Long>
    // Transactions created directly from seller/customer files are also income. Daily rows are
    // already represented by personal_harvest_day_lines and are excluded here to prevent double counting.
    @Query("SELECT (SELECT COALESCE(SUM(total),0) FROM distributor_transactions WHERE sourceDayId=0) + (SELECT COALESCE(SUM(total),0) FROM harvest_debtor_transactions WHERE sourceDayId=0)") fun observeManualPartyRevenue():Flow<Long>
    @Query("SELECT (SELECT COALESCE(SUM(t.total),0) FROM distributor_transactions t INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE t.sourceDayId=0 AND h.plantationId=:plantationId) + (SELECT COALESCE(SUM(t.total),0) FROM harvest_debtor_transactions t INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE t.sourceDayId=0 AND h.plantationId=:plantationId)") fun observePlantationManualPartyRevenue(plantationId:Long):Flow<Long>
    // Include legacy costs captured by 0.7.0 as well as all later daily costs. New harvest
    // records created by 0.8.x leave the legacy fields at zero, so this does not double count.
    @Query("SELECT COALESCE(SUM(MAX(agreedAmount-discountAmount,0)),0) FROM buyer_sales") fun observeBuyerNetRevenue():Flow<Long>
    @Query("SELECT COUNT(*) FROM personal_harvest_days") fun observePersonalHarvestDayCount():Flow<Long>
    @Query("SELECT COUNT(*) FROM buyer_sales") fun observeBuyerSaleCount():Flow<Long>
    /** One profile row represents one personal harvest file; each sale row represents one sold harvest. Day records never affect this count. */
    @Query("SELECT (SELECT COUNT(DISTINCT id) FROM personal_harvests WHERE plantationId=:plantationId) + (SELECT COUNT(DISTINCT id) FROM buyer_sales WHERE plantationId=:plantationId)") fun observePlantationActualHarvestCount(plantationId:Long):Flow<Long>
    @Query("SELECT (SELECT COUNT(*) FROM personal_harvests) + (SELECT COUNT(*) FROM buyer_sales)") fun observeGlobalActualHarvestCount():Flow<Long>
    /** Counts primary operations only: expense records, personal-harvest files and sold-harvest records. Child days, product lines and payments are excluded. */
    @Query("SELECT (SELECT COUNT(*) FROM expenses WHERE plantationId=:plantationId AND category!='القطفات') + (SELECT COUNT(*) FROM personal_harvests WHERE plantationId=:plantationId) + (SELECT COUNT(*) FROM buyer_sales WHERE plantationId=:plantationId)") fun observePlantationPrimaryOperationCount(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(COALESCE(pickerWagesManual,pickerWagesCalculated)+otherExpenses),0) FROM personal_harvest_days") fun observeTotalHarvestCosts():Flow<Long>
    @Query("SELECT COALESCE(SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)+d.otherExpenses),0) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId") fun observePlantationHarvestCosts(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(COALESCE(d.pickerWagesManual,d.pickerWagesCalculated)),0) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId") fun observePlantationPickerWagesTotal(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(d.otherExpenses),0) FROM personal_harvest_days d INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId") fun observePlantationPickerOtherExpensesTotal(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(a.amount),0) FROM distributor_transaction_adjustments a INNER JOIN distributor_transactions t ON t.id=a.transactionId INNER JOIN personal_harvests h ON h.id=t.harvestId WHERE a.kind='DISTRIBUTION_EXPENSE' AND h.plantationId=:plantationId") fun observePlantationDistributionExpenseTotal(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(amount),0) FROM distributor_transaction_adjustments WHERE kind='DISTRIBUTION_EXPENSE'") fun observeGlobalDistributionExpenseTotal():Flow<Long>
    @Query("SELECT COALESCE(SUM(l.total),0) FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE h.plantationId=:plantationId") fun observePlantationHarvestRevenue(plantationId:Long):Flow<Long>
    @Query("SELECT COALESCE(SUM(MAX(agreedAmount-discountAmount,0)),0) FROM buyer_sales WHERE plantationId=:plantationId") fun observePlantationBuyerRevenue(plantationId:Long):Flow<Long>
}

@Database(
    entities = [PlantationEntity::class, PlantationOpeningBalanceEntity::class, ExpenseEntity::class, InvoiceEntity::class, StockItemEntity::class, InvoiceItemEntity::class, StockMovementEntity::class, PersonalHarvestEntity::class, HarvestDebtorEntity::class, HarvestDebtorTransactionEntity::class, QatBuyerEntity::class, BuyerSaleEntity::class, BuyerPaymentEntity::class, MarketDistributorEntity::class, DistributorTransactionEntity::class, PersonalHarvestDayEntity::class, PersonalHarvestDayLineEntity::class, HarvestPartyPaymentEntity::class, DistributorTransactionAdjustmentEntity::class, DistributionExpensePaymentEntity::class, MiyarAuditEventEntity::class, ChemicalOperationLineEntity::class, OperationReminderEntity::class, SupplierEntity::class, SupplierPaymentEntity::class, StockIssueVoucherEntity::class, StockIssueLineEntity::class],
    version = 16,
    exportSchema = true
)
abstract class MiyarDatabase : RoomDatabase() {
    abstract fun dao(): MiyarDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `invoices` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `supplier` TEXT NOT NULL, `invoiceNumber` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `paymentStatus` TEXT NOT NULL, `currency` TEXT NOT NULL, `exchangeRateScaled` INTEGER NOT NULL, `totalForeign` INTEGER NOT NULL, `totalYer` INTEGER NOT NULL, `notes` TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `productType` TEXT NOT NULL, `productName` TEXT NOT NULL, `activeIngredient` TEXT NOT NULL, `baseUnit` TEXT NOT NULL, `quantityBase` INTEGER NOT NULL, `totalReceivedBase` INTEGER NOT NULL, `totalUsedBase` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_stock_items_productType_productName_baseUnit` ON `stock_items` (`productType`, `productName`, `baseUnit`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `invoice_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `invoiceId` INTEGER NOT NULL, `stockItemId` INTEGER NOT NULL, `productType` TEXT NOT NULL, `productName` TEXT NOT NULL, `activeIngredient` TEXT NOT NULL, `packageName` TEXT NOT NULL, `packageSize` INTEGER NOT NULL, `packageCount` INTEGER NOT NULL, `unit` TEXT NOT NULL, `quantityBase` INTEGER NOT NULL, `unitPriceForeign` INTEGER NOT NULL, `lineTotalForeign` INTEGER NOT NULL, `lineTotalYer` INTEGER NOT NULL, FOREIGN KEY(`invoiceId`) REFERENCES `invoices`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_items_invoiceId` ON `invoice_items` (`invoiceId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_items_stockItemId` ON `invoice_items` (`stockItemId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_movements` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `stockItemId` INTEGER NOT NULL, `referenceType` TEXT NOT NULL, `referenceId` INTEGER NOT NULL, `quantityBase` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `description` TEXT NOT NULL, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_stockItemId` ON `stock_movements` (`stockItemId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_referenceType_referenceId` ON `stock_movements` (`referenceType`, `referenceId`)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE stock_items ADD COLUMN treatmentType TEXT NOT NULL DEFAULT 'عام'")
                db.execSQL("ALTER TABLE invoice_items ADD COLUMN treatmentType TEXT NOT NULL DEFAULT 'عام'")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS personal_harvests (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, plantationId INTEGER NOT NULL, name TEXT NOT NULL, startMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, productsText TEXT NOT NULL, cashSalesText TEXT NOT NULL, debtorSalesText TEXT NOT NULL, pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, extraWages INTEGER NOT NULL, bagsAndOther INTEGER NOT NULL, transportAndClearance INTEGER NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS harvest_debtors (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_harvest_debtors_name ON harvest_debtors(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS harvest_debtor_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, debtorId INTEGER NOT NULL, harvestId INTEGER NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, paid INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_debtorId ON harvest_debtor_transactions(debtorId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS qat_buyers (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_qat_buyers_name ON qat_buyers(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS buyer_sales (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, buyerId INTEGER NOT NULL, harvestName TEXT NOT NULL, agreedAmount INTEGER NOT NULL, initialPaid INTEGER NOT NULL, saleDateMillis INTEGER NOT NULL, expectedEndMillis INTEGER NOT NULL, actualEndMillis INTEGER NOT NULL, discountAmount INTEGER NOT NULL, discountReason TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_buyer_sales_buyerId ON buyer_sales(buyerId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS buyer_payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, saleId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_buyer_payments_saleId ON buyer_payments(saleId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS market_distributors (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_market_distributors_name ON market_distributors(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS distributor_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, distributorId INTEGER NOT NULL, harvestId INTEGER NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, received INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_distributorId ON distributor_transactions(distributorId)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4,5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS personal_harvest_days (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, harvestId INTEGER NOT NULL, dateMillis INTEGER NOT NULL, pickerCount INTEGER NOT NULL, pickerWage INTEGER NOT NULL, otherExpenses INTEGER NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_days_harvestId ON personal_harvest_days(harvestId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_days_harvestId_dateMillis ON personal_harvest_days(harvestId,dateMillis)")
                db.execSQL("CREATE TABLE IF NOT EXISTS personal_harvest_day_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, dayId INTEGER NOT NULL, category TEXT NOT NULL, partyName TEXT NOT NULL, productType TEXT NOT NULL, quantity INTEGER NOT NULL, unitPrice INTEGER NOT NULL, total INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_day_lines_dayId ON personal_harvest_day_lines(dayId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_day_lines_partyName ON personal_harvest_day_lines(partyName)")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5,6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE buyer_sales ADD COLUMN plantationId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN sourceDayId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN sourceLineId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN sourceDayId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN sourceLineId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_day_lines ADD COLUMN accountTransactionId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_sourceDayId ON distributor_transactions(sourceDayId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_sourceLineId ON distributor_transactions(sourceLineId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_sourceDayId ON harvest_debtor_transactions(sourceDayId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_sourceLineId ON harvest_debtor_transactions(sourceLineId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS harvest_party_payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, partyType TEXT NOT NULL, partyId INTEGER NOT NULL, transactionId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, method TEXT NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_party_payments_partyType_partyId ON harvest_party_payments(partyType,partyId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_party_payments_transactionId ON harvest_party_payments(transactionId)")
                // Rebuild party profiles from historic daily lines before linking those lines to ledgers.
                db.execSQL("INSERT OR IGNORE INTO market_distributors(name,phone,notes) SELECT DISTINCT TRIM(partyName),'','' FROM personal_harvest_day_lines WHERE category='distributor' AND TRIM(partyName)!=''")
                db.execSQL("INSERT OR IGNORE INTO harvest_debtors(name,phone,notes) SELECT DISTINCT TRIM(partyName),'','' FROM personal_harvest_day_lines WHERE category='debt' AND TRIM(partyName)!=''")
                db.execSQL("INSERT INTO distributor_transactions(distributorId,harvestId,productType,quantity,unitPrice,total,received,dateMillis,notes,sourceDayId,sourceLineId) SELECT p.id,h.id,l.productType,l.quantity,l.unitPrice,l.total,0,d.dateMillis,'ترحيل من سجل يوم القطفة',d.id,l.id FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId INNER JOIN market_distributors p ON p.name=TRIM(l.partyName) WHERE l.category='distributor'")
                db.execSQL("INSERT INTO harvest_debtor_transactions(debtorId,harvestId,productType,quantity,unitPrice,total,paid,dateMillis,notes,sourceDayId,sourceLineId) SELECT p.id,h.id,l.productType,l.quantity,l.unitPrice,l.total,0,d.dateMillis,'ترحيل من سجل يوم القطفة',d.id,l.id FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId INNER JOIN harvest_debtors p ON p.name=TRIM(l.partyName) WHERE l.category='debt'")
                db.execSQL("UPDATE personal_harvest_day_lines SET accountTransactionId=COALESCE((SELECT id FROM distributor_transactions WHERE sourceLineId=personal_harvest_day_lines.id LIMIT 1),(SELECT id FROM harvest_debtor_transactions WHERE sourceLineId=personal_harvest_day_lines.id LIMIT 1),0)")
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Normalize fertilizers to a single catalogue status. Keep pesticide status.
                db.execSQL("UPDATE stock_items SET treatmentType='عام' WHERE productType='الأسمدة'")
                db.execSQL("UPDATE invoice_items SET treatmentType='عام' WHERE productType='الأسمدة'")
                db.execSQL("DROP INDEX IF EXISTS index_stock_items_productType_productName_baseUnit")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_items_productType_productName_baseUnit_treatmentType ON stock_items(productType, productName, baseUnit, treatmentType)")
                db.execSQL("CREATE TABLE IF NOT EXISTS chemical_operation_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, expenseId INTEGER NOT NULL, stockItemId INTEGER NOT NULL, productType TEXT NOT NULL, productName TEXT NOT NULL, activeIngredient TEXT NOT NULL, treatmentType TEXT NOT NULL, unit TEXT NOT NULL, enteredQuantity INTEGER NOT NULL, quantityBase INTEGER NOT NULL, costAmountYer INTEGER NOT NULL, FOREIGN KEY(expenseId) REFERENCES expenses(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(stockItemId) REFERENCES stock_items(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chemical_operation_lines_expenseId ON chemical_operation_lines(expenseId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chemical_operation_lines_stockItemId ON chemical_operation_lines(stockItemId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS operation_reminders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, referenceType TEXT NOT NULL, referenceId INTEGER NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, plantationName TEXT NOT NULL, scheduledAtMillis INTEGER NOT NULL, enabled INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_operation_reminders_referenceType_referenceId ON operation_reminders(referenceType, referenceId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_operation_reminders_scheduledAtMillis ON operation_reminders(scheduledAtMillis)")
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT NOT NULL, createdAtMillis INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_suppliers_name ON suppliers(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS supplier_payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, supplierId INTEGER NOT NULL, dateMillis INTEGER NOT NULL, currency TEXT NOT NULL, amountForeign INTEGER NOT NULL, exchangeRateScaled INTEGER NOT NULL, amountYer INTEGER NOT NULL, paymentMethod TEXT NOT NULL, notes TEXT NOT NULL, FOREIGN KEY(supplierId) REFERENCES suppliers(id) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_supplier_payments_supplierId ON supplier_payments(supplierId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_supplier_payments_dateMillis ON supplier_payments(dateMillis)")
                db.execSQL("INSERT OR IGNORE INTO suppliers(name,phone,notes,createdAtMillis) SELECT DISTINCT TRIM(supplier),'','',CAST(strftime('%s','now') AS INTEGER)*1000 FROM invoices WHERE TRIM(supplier)!=''")
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE plantations ADD COLUMN icon TEXT NOT NULL DEFAULT '🌱'")
                db.execSQL("ALTER TABLE plantations ADD COLUMN colorArgb INTEGER NOT NULL DEFAULT -16749764")
            }
        }

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS plantation_opening_balances (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, plantationId INTEGER NOT NULL, amount INTEGER NOT NULL, dateMillis INTEGER NOT NULL, notes TEXT NOT NULL, FOREIGN KEY(plantationId) REFERENCES plantations(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_plantation_opening_balances_plantationId ON plantation_opening_balances(plantationId)")
                // Composite indexes match the most common ledger, filtering and reporting paths.
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_plantationId_dateMillis ON expenses(plantationId, dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_category_dateMillis ON expenses(category, dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_plantationId_category_dateMillis ON expenses(plantationId, category, dateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_expenses_dateMillis ON expenses(dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_invoices_dateMillis ON invoices(dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_invoices_supplier_paymentStatus_dateMillis ON invoices(supplier, paymentStatus, dateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_supplier_payments_dateMillis_id ON supplier_payments(dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_buyer_sales_saleDateMillis ON buyer_sales(saleDateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_buyer_payments_dateMillis ON buyer_payments(dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_harvest_debtor_transactions_dateMillis ON harvest_debtor_transactions(dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_distributor_transactions_dateMillis ON distributor_transactions(dateMillis, id)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_days_dateMillis ON personal_harvest_days(dateMillis, id)")
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE stock_items ADD COLUMN totalOpeningCostYer INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Add an optional user-selected image to each plot without rebuilding or clearing data.
                db.execSQL("ALTER TABLE plantations ADD COLUMN photoUri TEXT DEFAULT NULL")
            }
        }

        private val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_issue_vouchers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `dateMillis` INTEGER NOT NULL, `reason` TEXT NOT NULL, `notes` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_issue_vouchers_dateMillis_id` ON `stock_issue_vouchers` (`dateMillis`, `id`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_issue_lines` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `voucherId` INTEGER NOT NULL, `stockItemId` INTEGER NOT NULL, `productName` TEXT NOT NULL, `productType` TEXT NOT NULL, `baseUnit` TEXT NOT NULL, `unit` TEXT NOT NULL, `enteredQuantity` INTEGER NOT NULL, `quantityBase` INTEGER NOT NULL, FOREIGN KEY(`voucherId`) REFERENCES `stock_issue_vouchers`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_issue_lines_voucherId` ON `stock_issue_lines` (`voucherId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_issue_lines_stockItemId` ON `stock_issue_lines` (`stockItemId`)")
            }
        }

        private val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE stock_items ADD COLUMN lastReceivedAtMillis INTEGER NOT NULL DEFAULT 0")
                // For existing installations, updatedAtMillis is the best available legacy approximation.
                db.execSQL("UPDATE stock_items SET lastReceivedAtMillis = updatedAtMillis WHERE lastReceivedAtMillis = 0")
            }
        }

        private val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `harvest_party_payments` ADD COLUMN `idempotencyKey` TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE `harvest_party_payments` SET `idempotencyKey`='legacy-' || `id` WHERE `idempotencyKey`=''")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_harvest_party_payments_idempotencyKey` ON `harvest_party_payments` (`idempotencyKey`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `distributor_transaction_adjustments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `transactionId` INTEGER NOT NULL, `kind` TEXT NOT NULL, `amount` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `description` TEXT NOT NULL, `notes` TEXT NOT NULL, `idempotencyKey` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, FOREIGN KEY(`transactionId`) REFERENCES `distributor_transactions`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_distributor_transaction_adjustments_transactionId_dateMillis_id` ON `distributor_transaction_adjustments` (`transactionId`, `dateMillis`, `id`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_distributor_transaction_adjustments_kind` ON `distributor_transaction_adjustments` (`kind`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_distributor_transaction_adjustments_idempotencyKey` ON `distributor_transaction_adjustments` (`idempotencyKey`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `distribution_expense_payments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `adjustmentId` INTEGER NOT NULL, `amount` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `method` TEXT NOT NULL, `notes` TEXT NOT NULL, `idempotencyKey` TEXT NOT NULL, FOREIGN KEY(`adjustmentId`) REFERENCES `distributor_transaction_adjustments`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_distribution_expense_payments_adjustmentId_dateMillis_id` ON `distribution_expense_payments` (`adjustmentId`, `dateMillis`, `id`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_distribution_expense_payments_idempotencyKey` ON `distribution_expense_payments` (`idempotencyKey`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `miyar_audit_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `entityType` TEXT NOT NULL, `entityId` INTEGER NOT NULL, `eventType` TEXT NOT NULL, `occurredAtMillis` INTEGER NOT NULL, `beforeSnapshot` TEXT NOT NULL, `afterSnapshot` TEXT NOT NULL, `source` TEXT NOT NULL, `referenceId` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_miyar_audit_events_entityType_entityId_occurredAtMillis` ON `miyar_audit_events` (`entityType`, `entityId`, `occurredAtMillis`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_miyar_audit_events_occurredAtMillis_id` ON `miyar_audit_events` (`occurredAtMillis`, `id`)")
            }
        }

        private val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Keep existing totals and expose their calculated baseline for later manual overrides.
                db.execSQL("ALTER TABLE personal_harvest_days ADD COLUMN pickerWagesCalculated INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_days ADD COLUMN pickerWagesManual INTEGER")
                db.execSQL("UPDATE personal_harvest_days SET pickerWagesCalculated=CASE WHEN pickerCount>0 AND pickerWage>9223372036854775807/pickerCount THEN 9223372036854775807 ELSE pickerCount*pickerWage END")
                db.execSQL("ALTER TABLE personal_harvest_days ADD COLUMN pickerCountEntered INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_days ADD COLUMN pickerWageEntered INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_days ADD COLUMN otherExpensesEntered INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE personal_harvest_days SET pickerCountEntered=CASE WHEN pickerCount>0 THEN 1 ELSE 0 END, pickerWageEntered=CASE WHEN pickerWage>0 THEN 1 ELSE 0 END, otherExpensesEntered=CASE WHEN otherExpenses>0 THEN 1 ELSE 0 END")

                db.execSQL("ALTER TABLE personal_harvest_day_lines ADD COLUMN calculatedTotal INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_day_lines ADD COLUMN isTotalManual INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE personal_harvest_day_lines ADD COLUMN isValueComplete INTEGER NOT NULL DEFAULT 1")
                db.execSQL("UPDATE personal_harvest_day_lines SET calculatedTotal=CASE WHEN quantity>0 AND unitPrice>9223372036854775807/quantity THEN 9223372036854775807 ELSE quantity*unitPrice END")
                db.execSQL("UPDATE personal_harvest_day_lines SET isTotalManual=CASE WHEN total!=calculatedTotal THEN 1 ELSE 0 END, isValueComplete=CASE WHEN unitPrice>0 OR total>0 THEN 1 ELSE 0 END")

                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN calculatedTotal INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN isTotalManual INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE distributor_transactions ADD COLUMN isValueComplete INTEGER NOT NULL DEFAULT 1")
                db.execSQL("UPDATE distributor_transactions SET calculatedTotal=CASE WHEN quantity>0 AND unitPrice>9223372036854775807/quantity THEN 9223372036854775807 ELSE quantity*unitPrice END")
                db.execSQL("UPDATE distributor_transactions SET isTotalManual=CASE WHEN total!=calculatedTotal THEN 1 ELSE 0 END, isValueComplete=CASE WHEN unitPrice>0 OR total>0 THEN 1 ELSE 0 END")

                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN calculatedTotal INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN isTotalManual INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE harvest_debtor_transactions ADD COLUMN isValueComplete INTEGER NOT NULL DEFAULT 1")
                db.execSQL("UPDATE harvest_debtor_transactions SET calculatedTotal=CASE WHEN quantity>0 AND unitPrice>9223372036854775807/quantity THEN 9223372036854775807 ELSE quantity*unitPrice END")
                db.execSQL("UPDATE harvest_debtor_transactions SET isTotalManual=CASE WHEN total!=calculatedTotal THEN 1 ELSE 0 END, isValueComplete=CASE WHEN unitPrice>0 OR total>0 THEN 1 ELSE 0 END")

                db.execSQL("CREATE INDEX IF NOT EXISTS index_personal_harvest_day_lines_dayId_id ON personal_harvest_day_lines(dayId,id)")

                db.execSQL("ALTER TABLE operation_reminders ADD COLUMN plantationId INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE operation_reminders ADD COLUMN priority TEXT NOT NULL DEFAULT 'NORMAL'")
                db.execSQL("ALTER TABLE operation_reminders ADD COLUMN suggestedAction TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE operation_reminders ADD COLUMN status TEXT NOT NULL DEFAULT 'NEW'")
                db.execSQL("UPDATE operation_reminders SET plantationId=COALESCE((SELECT p.id FROM plantations p WHERE p.name=operation_reminders.plantationName COLLATE NOCASE LIMIT 1),0)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_operation_reminders_plantationId ON operation_reminders(plantationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_operation_reminders_status ON operation_reminders(status)")
            }
        }

        @Volatile private var INSTANCE: MiyarDatabase? = null

        fun closeInstance() { synchronized(this) { INSTANCE?.close(); INSTANCE = null } }

        fun get(context: Context): MiyarDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MiyarDatabase::class.java,
                    "miyar.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16).build().also { INSTANCE = it }
            }
    }
}
