package com.miyar.app

import org.junit.Assert.assertEquals
import org.junit.Test

class FinancialInputFormattingTest {
    @Test fun groupsMillionsWithDots() {
        assertEquals("2.000.000", moneyInput("2000000"))
    }

    @Test fun groupsThousandsWithDots() {
        assertEquals("500.000", moneyInput("500000"))
    }

    @Test fun acceptsArabicAndPersianDigits() {
        assertEquals("1.234.567", moneyInput("١٢٣٤٥٦٧"))
        assertEquals("1.234.567", moneyInput("۱۲۳۴۵۶۷"))
    }

    @Test fun parsesGroupedAndUngroupedAmountsWithoutLosingDigits() {
        assertEquals(2_000_000L, moneyToLong("2.000.000"))
        assertEquals(500_000L, moneyToLong("500000"))
        assertEquals(2_000_000L, moneyToLong("٢٠٠٠٠٠٠"))
    }

    @Test fun formatsExchangeRatesWithoutLosingFractionalPrecision() {
        assertEquals("500.000", rateInput("500000"))
        assertEquals("530,5", rateInput("530.5"))
        assertEquals("1.234,56", rateInput("1234,56"))
    }

    @Test fun emptyMoneyInputStaysEmpty() {
        assertEquals("", moneyInput(""))
        assertEquals(0L, moneyToLong(""))
    }
}
