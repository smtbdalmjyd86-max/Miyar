package com.miyar.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextDirectionHeuristics
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.miyar.app.data.MiyarDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import android.database.Cursor
import android.graphics.Color
import android.graphics.RectF
import java.io.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Full local backup: Room database plus all app preference XML files. */
object MiyarTransfer {
    fun createBackup(context: Context, destination: Uri) {
        val db = context.getDatabasePath("miyar.db")
        require(db.exists() && db.length() > 0) { "قاعدة بيانات مِعيار غير موجودة." }
        MiyarDatabase.get(context).openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        context.contentResolver.openOutputStream(destination, "w")?.use { raw ->
            ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                zip.putNextEntry(ZipEntry("backup_info.txt"))
                zip.write(("MIYAR_BACKUP\nversion=1\ncreated=${System.currentTimeMillis()}\n").toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("database/miyar.db")); db.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                val prefs = File(context.applicationInfo.dataDir, "shared_prefs")
                prefs.listFiles()?.filter { it.isFile && it.extension == "xml" }?.forEach { file ->
                    zip.putNextEntry(ZipEntry("preferences/${file.name}")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                }
            }
        } ?: error("تعذر فتح مكان حفظ النسخة.")
    }

    fun restoreBackup(context: Context, source: Uri) {
        val temp = File(context.cacheDir, "miyar_restore_${System.currentTimeMillis()}").apply { mkdirs() }
        var databaseFound = false
        try {
            context.contentResolver.openInputStream(source)?.use { input ->
                ZipInputStream(BufferedInputStream(input)).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        val out = when {
                            entry.name == "database/miyar.db" -> File(temp, "miyar.db").also { databaseFound = true }
                            entry.name.startsWith("preferences/") && entry.name.substringAfterLast('/').matches(Regex("[A-Za-z0-9_.-]+\\.xml")) -> File(temp, entry.name.substringAfterLast('/'))
                            entry.name == "backup_info.txt" -> File(temp, "backup_info.txt")
                            else -> null
                        }
                        if (out != null) { out.parentFile?.mkdirs(); FileOutputStream(out).use { zip.copyTo(it) } }
                        zip.closeEntry()
                    }
                }
            } ?: error("تعذر قراءة ملف النسخة الاحتياطية.")
            val restoredDb = File(temp, "miyar.db")
            require(databaseFound && restoredDb.length() > 100 && restoredDb.inputStream().use { byteArrayOf(it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte(), it.read().toByte()).toString(Charsets.US_ASCII) } == "SQLite ") { "الملف ليس نسخة مِعيار سليمة." }
            require(File(temp, "backup_info.txt").readText().contains("MIYAR_BACKUP")) { "صيغة النسخة غير معروفة." }
            // Validate SQLite integrity before replacing current data.
            android.database.sqlite.SQLiteDatabase.openDatabase(restoredDb.absolutePath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY).use { sql ->
                sql.rawQuery("PRAGMA quick_check", null).use { cursor -> require(cursor.moveToFirst() && cursor.getString(0) == "ok") { "قاعدة البيانات داخل النسخة تالفة." } }
            }
            MiyarDatabase.closeInstance()
            val target = context.getDatabasePath("miyar.db")
            target.parentFile?.mkdirs()
            File(target.parentFile, "miyar.db-wal").delete(); File(target.parentFile, "miyar.db-shm").delete()
            restoredDb.copyTo(target, overwrite = true)
            val prefsTarget = File(context.applicationInfo.dataDir, "shared_prefs").apply { mkdirs() }
            temp.listFiles()?.filter { it.extension == "xml" }?.forEach { it.copyTo(File(prefsTarget, it.name), overwrite = true) }
        } finally { temp.deleteRecursively() }
    }


    fun exportAllTablesCsv(context: Context, destination: Uri) {
        val db = MiyarDatabase.get(context).openHelper.readableDatabase
        context.contentResolver.openOutputStream(destination, "w")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
            writer.write("\uFEFFمِعيار - تصدير شامل لبيانات التطبيق\r\n")
            val tables = db.query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name != 'room_master_table' ORDER BY name")
            val names = mutableListOf<String>()
            while (tables.moveToNext()) names += tables.getString(0)
            tables.close()
            names.forEach { table ->
                writer.write("\r\nجدول: ${csv(table)}\r\n")
                val cursor = db.query("SELECT * FROM `${table.replace("`", "``")}`")
                val columns = (0 until cursor.columnCount).map { cursor.getColumnName(it) }
                writer.write(columns.joinToString(",") { csv(it) } + "\r\n")
                while (cursor.moveToNext()) {
                    writer.write(columns.indices.joinToString(",") { index ->
                        when (cursor.getType(index)) {
                            android.database.Cursor.FIELD_TYPE_NULL -> ""
                            android.database.Cursor.FIELD_TYPE_BLOB -> csv("[BLOB ${cursor.getBlob(index).size} bytes]")
                            android.database.Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(index).toString()
                            android.database.Cursor.FIELD_TYPE_FLOAT -> cursor.getDouble(index).toString()
                            else -> csv(cursor.getString(index) ?: "")
                        }
                    } + "\r\n")
                }
                cursor.close()
            }
        } ?: error("تعذر فتح مكان حفظ ملف التصدير.")
    }


    /** Export a complete, date-filtered PDF report. The queries stream cursor rows and do not
     * collect the full ledger into application memory. */
    fun writeReportPdf(
        context: Context,
        destination: Uri,
        reportType: String,
        fromMillis: Long,
        untilMillis: Long,
        plantationId: Long?
    ) {
        require(untilMillis > fromMillis) { "نطاق التاريخ غير صحيح." }
        val db = MiyarDatabase.get(context).openHelper.readableDatabase
        val pdf = PdfDocument()
        val writer = ReportPdfWriter(context, pdf)
        val dateFrom = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(fromMillis))
        val dateTo = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(untilMillis - 1L))
        val plotName = if (plantationId == null) "كل المواضع" else db.query(
            "SELECT name FROM plantations WHERE id=?", arrayOf(plantationId)
        ).use { if (it.moveToFirst()) it.getString(0) else "موضع محذوف" }
        writer.paragraph("${reportTitle(reportType)}", true, 19f)
        writer.paragraph("الموضع: $plotName", true)
        writer.paragraph("الفترة: من $dateFrom إلى $dateTo")
        writer.paragraph("تاريخ الاستخراج: ${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date())}")
        writer.separator()
        val fromTo = arrayOf(fromMillis, untilMillis)
        val plotArgs = arrayOf(fromMillis, untilMillis, plantationId ?: 0L, plantationId ?: 0L)
        val expensesSql = "SELECT e.dateMillis,e.category,e.title,e.amount,e.notes,p.name,COALESCE((SELECT group_concat(c.productName || ' — ' || c.enteredQuantity || ' ' || c.unit || ' — ' || c.costAmountYer) FROM chemical_operation_lines c WHERE c.expenseId=e.id),'') AS chemicalDetails FROM expenses e LEFT JOIN plantations p ON p.id=e.plantationId WHERE e.category!='القطفات' AND e.dateMillis>=? AND e.dateMillis<? AND (?=0 OR e.plantationId=?) ORDER BY e.dateMillis,e.id"
        when (reportType) {
            "plantation", "activities" -> {
                if (reportType == "plantation" && plantationId != null) {
                    db.query("SELECT amount,dateMillis,notes FROM plantation_opening_balances WHERE plantationId=?", arrayOf(plantationId)).use { c ->
                        if (c.moveToFirst()) {
                            writer.section("الرصيد الافتتاحي")
                            writer.paragraph("المبلغ: ${formatMoney(c.getLong(0))} ر.ي")
                            writer.paragraph("تاريخ الرصيد: ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(1)))}")
                            if (c.getString(2).isNotBlank()) writer.paragraph("ملاحظات: ${c.getString(2)}")
                        }
                    }
                }
                writer.section(if (reportType == "activities") "تفاصيل الأنشطة الزراعية" else "كشف حساب الموضع")
                appendCursorRows(db, writer, expensesSql, plotArgs) { c ->
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(0)))
                    val detail = buildString {
                        append("$date • ${c.getString(1)} • ${c.getString(2)}")
                        append("\nالموضع: ${c.getString(5) ?: "غير محدد"} • القيمة: ${formatMoney(c.getLong(3))} ر.ي")
                        if (c.getString(6).isNotBlank()) append("\nتفاصيل الأصناف: ${c.getString(6)}")
                        if (c.getString(4).isNotBlank()) append("\nملاحظات: ${c.getString(4)}")
                    }
                    detail
                }
                writer.section("إجماليات الأنشطة حسب النوع")
                appendCursorRows(db, writer,
                    "SELECT category,COUNT(*),COALESCE(SUM(amount),0) FROM expenses WHERE category!='القطفات' AND dateMillis>=? AND dateMillis<? AND (?=0 OR plantationId=?) GROUP BY category ORDER BY category", plotArgs) { c ->
                    "${c.getString(0)} • عدد العمليات: ${c.getLong(1)} • الإجمالي: ${formatMoney(c.getLong(2))} ر.ي"
                }
                if (reportType == "plantation") {
                    writer.section("الإنتاج والمبيعات المرتبطة بالموضع")
                    appendCursorRows(db, writer,
                        "SELECT h.name,d.dateMillis,l.partyName,l.productType,l.quantity,l.unitPrice,l.total,l.category FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE d.dateMillis>=? AND d.dateMillis<? AND (?=0 OR h.plantationId=?) ORDER BY d.dateMillis,l.id", plotArgs) { c ->
                        "القطفة: ${c.getString(0)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(1)))}\nالطرف: ${c.getString(2)} • الصنف: ${c.getString(3)} • التصنيف: ${c.getString(7)}\nالكمية: ${c.getLong(4)} × ${formatMoney(c.getLong(5))} • الإجمالي: ${formatMoney(c.getLong(6))} ر.ي"
                    }
                }
                if (reportType == "plantation") {
                    writer.section("مردود القطفات والمبيعات")
                    appendCursorRows(db, writer,
                        "SELECT h.name,d.dateMillis,l.partyName,l.productType,l.quantity,l.unitPrice,l.total,l.category,p.name FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId LEFT JOIN plantations p ON p.id=h.plantationId WHERE d.dateMillis>=? AND d.dateMillis<? AND (?=0 OR h.plantationId=?) ORDER BY d.dateMillis,l.id", plotArgs) { c ->
                        "القطفة: ${c.getString(0)} • الموضع: ${c.getString(8)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(1)))}\nالطرف: ${c.getString(2)} • الصنف: ${c.getString(3)} • النوع: ${c.getString(7)}\nالكمية: ${c.getLong(4)} × ${formatMoney(c.getLong(5))} • الإجمالي: ${formatMoney(c.getLong(6))} ر.ي"
                    }
                    appendCursorRows(db, writer,
                        "SELECT b.name,s.harvestName,s.saleDateMillis,s.agreedAmount,s.discountAmount,s.initialPaid,COALESCE((SELECT SUM(p.amount) FROM buyer_payments p WHERE p.saleId=s.id),0),s.notes FROM buyer_sales s LEFT JOIN qat_buyers b ON b.id=s.buyerId WHERE s.saleDateMillis>=? AND s.saleDateMillis<? AND (?=0 OR s.plantationId=?) ORDER BY s.saleDateMillis,s.id", plotArgs) { c ->
                        val net = (c.getLong(3) - c.getLong(4)).coerceAtLeast(0L)
                        val paid = Math.addExact(c.getLong(5), c.getLong(6))
                        "المشتري: ${c.getString(0)} • القطفة: ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nالاتفاق بعد الخصم: ${formatMoney(net)} • المدفوع: ${formatMoney(paid)} • المتبقي: ${formatMoney((net-paid).coerceAtLeast(0))}\n${c.getString(7)}"
                    }
                }
                if (reportType == "plantation" && plantationId != null) {
                    writer.section("ملخص الحساب")
                    val totals = db.query("SELECT COUNT(CASE WHEN category!='القطفات' THEN 1 END),COALESCE(SUM(CASE WHEN category!='القطفات' THEN amount ELSE 0 END),0),COALESCE(SUM(CASE WHEN category='القطفات' THEN amount ELSE 0 END),0) FROM expenses WHERE plantationId=? AND dateMillis>=? AND dateMillis<?", arrayOf(plantationId, fromMillis, untilMillis))
                    totals.use { if (it.moveToFirst()) {
                        writer.paragraph("عدد العمليات المسجلة: ${it.getLong(0)}")
                        val opening = db.query("SELECT COALESCE(SUM(amount),0) FROM plantation_opening_balances WHERE plantationId=?", arrayOf(plantationId)).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
                        val outlay = Math.addExact(it.getLong(1), opening)
                        writer.paragraph("الرصيد الافتتاحي: ${formatMoney(opening)} ر.ي")
                        writer.paragraph("مصروفات الأنشطة: ${formatMoney(it.getLong(1))} ر.ي")
                        writer.paragraph("إجمالي الخرج شاملاً الرصيد الافتتاحي: ${formatMoney(outlay)} ر.ي")
                        writer.paragraph("مردود القطفات المسجل في دفتر العمليات: ${formatMoney(it.getLong(2))} ر.ي")
                    } }
                } else if (reportType == "plantation") {
                    writer.section("الأرصدة الافتتاحية وملخص كل موضع")
                    appendCursorRows(db, writer,
                        "SELECT p.name,COALESCE((SELECT SUM(o.amount) FROM plantation_opening_balances o WHERE o.plantationId=p.id),0),COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.plantationId=p.id AND e.category!='القطفات' AND e.dateMillis>=? AND e.dateMillis<?),0),COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.plantationId=p.id AND e.category='القطفات' AND e.dateMillis>=? AND e.dateMillis<?),0) FROM plantations p ORDER BY p.name COLLATE NOCASE", arrayOf(fromMillis, untilMillis, fromMillis, untilMillis)) { c ->
                        "الموضع: ${c.getString(0)}\nالرصيد الافتتاحي: ${formatMoney(c.getLong(1))} • خرج الأنشطة للفترة: ${formatMoney(c.getLong(2))} • المردود المسجل: ${formatMoney(c.getLong(3))} ر.ي"
                    }
                }
            }
            "buyers" -> {
                writer.section("ملخص حساب كل مشترٍ خلال الفترة")
                appendCursorRows(db, writer,
                    "SELECT b.name,COUNT(*),COALESCE(SUM(MAX(s.agreedAmount-s.discountAmount,0)),0),COALESCE(SUM(s.initialPaid+(SELECT COALESCE(SUM(p.amount),0) FROM buyer_payments p WHERE p.saleId=s.id)),0) FROM buyer_sales s LEFT JOIN qat_buyers b ON b.id=s.buyerId WHERE s.saleDateMillis>=? AND s.saleDateMillis<? AND (?=0 OR s.plantationId=?) GROUP BY s.buyerId ORDER BY b.name COLLATE NOCASE", plotArgs) { c ->
                    "المشتري: ${c.getString(0)} • عدد القطفات/الاتفاقات: ${c.getLong(1)}\nإجمالي الاتفاقات: ${formatMoney(c.getLong(2))} • المحصل: ${formatMoney(c.getLong(3))} • المتبقي: ${formatMoney((c.getLong(2)-c.getLong(3)).coerceAtLeast(0))} ر.ي"
                }
                writer.section("مبيعات المشترين والدفعات")
                appendCursorRows(db, writer,
                    "SELECT b.name,s.harvestName,s.saleDateMillis,s.agreedAmount,s.discountAmount,s.initialPaid,COALESCE((SELECT SUM(p.amount) FROM buyer_payments p WHERE p.saleId=s.id),0),s.notes FROM buyer_sales s LEFT JOIN qat_buyers b ON b.id=s.buyerId WHERE s.saleDateMillis>=? AND s.saleDateMillis<? AND (?=0 OR s.plantationId=?) ORDER BY s.saleDateMillis,s.id",
                    plotArgs) { c ->
                    val net = (c.getLong(3) - c.getLong(4)).coerceAtLeast(0L)
                    val paid = c.getLong(5) + c.getLong(6)
                    "المشتري: ${c.getString(0)} • القطفة: ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nالاتفاق: ${formatMoney(net)} • المدفوع: ${formatMoney(paid)} • المتبقي: ${formatMoney((net-paid).coerceAtLeast(0))}\n${c.getString(7)}"
                }
                writer.section("حسابات العملاء الآجلة")
                appendCursorRows(db, writer,
                    "SELECT d.name,t.productType,t.dateMillis,t.total,t.paid,t.quantity,t.unitPrice,t.notes FROM harvest_debtor_transactions t LEFT JOIN harvest_debtors d ON d.id=t.debtorId LEFT JOIN personal_harvests h ON h.id=t.harvestId WHERE t.dateMillis>=? AND t.dateMillis<? AND (?=0 OR h.plantationId=?) ORDER BY t.dateMillis,t.id",
                    plotArgs) { c ->
                    "العميل: ${c.getString(0)} • ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nقيمة البيع: ${formatMoney(c.getLong(3))} • المدفوع: ${formatMoney(c.getLong(4))} • المتبقي: ${formatMoney((c.getLong(3)-c.getLong(4)).coerceAtLeast(0))}\nالكمية: ${c.getLong(5)} × ${formatMoney(c.getLong(6))} • ${c.getString(7)}"
                }
                writer.section("حسابات الموزعين والبائعين")
                appendCursorRows(db, writer,
                    "SELECT d.name,t.productType,t.dateMillis,t.total,t.received,t.quantity,t.unitPrice,t.notes FROM distributor_transactions t LEFT JOIN market_distributors d ON d.id=t.distributorId LEFT JOIN personal_harvests h ON h.id=t.harvestId WHERE t.dateMillis>=? AND t.dateMillis<? AND (?=0 OR h.plantationId=?) ORDER BY t.dateMillis,t.id",
                    plotArgs) { c ->
                    "البائع/الموزع: ${c.getString(0)} • ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nالإجمالي: ${formatMoney(c.getLong(3))} • المستلم: ${formatMoney(c.getLong(4))} • المتبقي: ${formatMoney((c.getLong(3)-c.getLong(4)).coerceAtLeast(0))}\nالكمية: ${c.getLong(5)} × ${formatMoney(c.getLong(6))} • ${c.getString(7)}"
                }
                writer.section("دفعات المشترين حسب تاريخ السداد")
                appendCursorRows(db, writer,
                    "SELECT b.name,s.harvestName,p.dateMillis,p.amount,p.method,p.notes FROM buyer_payments p INNER JOIN buyer_sales s ON s.id=p.saleId LEFT JOIN qat_buyers b ON b.id=s.buyerId WHERE p.dateMillis>=? AND p.dateMillis<? AND (?=0 OR s.plantationId=?) ORDER BY p.dateMillis,p.id", plotArgs) { c ->
                    "المشتري: ${c.getString(0)} • القطفة: ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nالدفعة: ${formatMoney(c.getLong(3))} ر.ي • ${c.getString(4)}\n${c.getString(5)}"
                }
                writer.section("حركات الدفعات الإضافية")
                appendCursorRows(db, writer,
                    "SELECT partyType,partyId,transactionId,dateMillis,amount,method,notes FROM harvest_party_payments WHERE dateMillis>=? AND dateMillis<? ORDER BY dateMillis,id", fromTo) { c ->
                    "النوع: ${c.getString(0)} • الحساب: ${c.getLong(1)} • الحركة: ${c.getLong(2)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(3)))}\nدفعة: ${formatMoney(c.getLong(4))} • ${c.getString(5)} • ${c.getString(6)}"
                }
            }
            "suppliers" -> {
                writer.section("فواتير التجار والموردين")
                appendCursorRows(db, writer,
                    "SELECT s.name,i.invoiceNumber,i.dateMillis,i.paymentStatus,i.totalYer,i.currency,i.totalForeign FROM invoices i LEFT JOIN suppliers s ON lower(trim(s.name))=lower(trim(i.supplier)) WHERE i.dateMillis>=? AND i.dateMillis<? ORDER BY i.dateMillis,i.id", fromTo) { c ->
                    "المورد: ${c.getString(0)} • فاتورة رقم ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nالحالة: ${c.getString(3)} • الإجمالي: ${formatMoney(c.getLong(4))} ر.ي • العملة: ${c.getString(5)} ${c.getLong(6)}"
                }
                writer.section("دفعات الموردين")
                appendCursorRows(db, writer,
                    "SELECT s.name,p.dateMillis,p.currency,p.amountForeign,p.exchangeRateScaled,p.amountYer,p.paymentMethod,p.notes FROM supplier_payments p LEFT JOIN suppliers s ON s.id=p.supplierId WHERE p.dateMillis>=? AND p.dateMillis<? ORDER BY p.dateMillis,p.id", fromTo) { c ->
                    "المورد: ${c.getString(0)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(1)))}\nالدفعة: ${c.getLong(3)} ${c.getString(2)} • سعر الصرف ×1000: ${c.getLong(4)} • المقابل: ${formatMoney(c.getLong(5))} ر.ي • ${c.getString(6)}\n${c.getString(7)}"
                }
                writer.section("أرصدة الموردين الحالية")
                appendCursorRows(db, writer,
                    "SELECT s.name,COALESCE((SELECT SUM(i.totalYer) FROM invoices i WHERE lower(trim(i.supplier))=lower(trim(s.name)) AND i.paymentStatus='آجل'),0),COALESCE((SELECT SUM(p.amountYer) FROM supplier_payments p WHERE p.supplierId=s.id),0) FROM suppliers s ORDER BY s.name COLLATE NOCASE", emptyArray()) { c ->
                    "المورد: ${c.getString(0)} • إجمالي الآجل: ${formatMoney(c.getLong(1))} • المدفوع: ${formatMoney(c.getLong(2))} • الرصيد: ${formatMoney((c.getLong(1)-c.getLong(2)).coerceAtLeast(0))} ر.ي"
                }
            }
            "invoices" -> {
                writer.section("ملخص إجمالي الفواتير")
                appendCursorRows(db, writer,
                    "SELECT COUNT(*),COALESCE(SUM(totalYer),0),COALESCE(SUM(CASE WHEN paymentStatus='آجل' THEN totalYer ELSE 0 END),0),COALESCE(SUM(CASE WHEN paymentStatus!='آجل' THEN totalYer ELSE 0 END),0) FROM invoices WHERE dateMillis>=? AND dateMillis<?", fromTo) { c ->
                    "عدد الفواتير: ${c.getLong(0)} • الإجمالي: ${formatMoney(c.getLong(1))} ر.ي\nالآجل: ${formatMoney(c.getLong(2))} • النقدي: ${formatMoney(c.getLong(3))} ر.ي"
                }
                writer.section("الفواتير وتفاصيل الأصناف")
                appendCursorRows(db, writer,
                    "SELECT i.supplier,i.invoiceNumber,i.dateMillis,i.paymentStatus,i.currency,i.totalForeign,i.totalYer,i.notes,COALESCE((SELECT group_concat(x.productName || ' — ' || x.treatmentType || ' — ' || x.packageCount || ' × ' || x.packageSize || ' ' || x.unit || ' — ' || x.lineTotalYer || ' ر.ي') FROM invoice_items x WHERE x.invoiceId=i.id),'') FROM invoices i WHERE i.dateMillis>=? AND i.dateMillis<? ORDER BY i.dateMillis,i.id", fromTo) { c ->
                    "المورد: ${c.getString(0)} • رقم الفاتورة: ${c.getString(1)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\nالحالة: ${c.getString(3)} • الإجمالي: ${formatMoney(c.getLong(6))} ر.ي • المدفوع/العملة: ${c.getLong(5)} ${c.getString(4)}\nالأصناف: ${c.getString(8)}\nملاحظات: ${c.getString(7)}"
                }
            }
            "financial" -> {
                writer.section("إجماليات المصروفات حسب النشاط")
                appendCursorRows(db, writer,
                    "SELECT e.category,COUNT(*),COALESCE(SUM(e.amount),0) FROM expenses e WHERE e.category!='القطفات' AND e.dateMillis>=? AND e.dateMillis<? AND (?=0 OR e.plantationId=?) GROUP BY e.category ORDER BY e.category", plotArgs) { c ->
                    "${c.getString(0)} • عدد العمليات: ${c.getLong(1)} • الإجمالي: ${formatMoney(c.getLong(2))} ر.ي"
                }
                writer.section("إجمالي الفواتير")
                appendCursorRows(db, writer,
                    "SELECT COUNT(*),COALESCE(SUM(totalYer),0),COALESCE(SUM(CASE WHEN paymentStatus='آجل' THEN totalYer ELSE 0 END),0) FROM invoices WHERE dateMillis>=? AND dateMillis<?", fromTo) { c ->
                    "عدد الفواتير: ${c.getLong(0)} • الإجمالي: ${formatMoney(c.getLong(1))} ر.ي • الآجل: ${formatMoney(c.getLong(2))} ر.ي"
                }
                writer.section("تفاصيل الإنتاج المسجل")
                appendCursorRows(db, writer,
                    "SELECT h.name,d.dateMillis,l.partyName,l.productType,l.quantity,l.unitPrice,l.total,l.category FROM personal_harvest_day_lines l INNER JOIN personal_harvest_days d ON d.id=l.dayId INNER JOIN personal_harvests h ON h.id=d.harvestId WHERE d.dateMillis>=? AND d.dateMillis<? AND (?=0 OR h.plantationId=?) ORDER BY d.dateMillis,l.id", plotArgs) { c ->
                    "القطفة: ${c.getString(0)} • ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(1)))}\nالطرف: ${c.getString(2)} • الصنف: ${c.getString(3)} • النوع: ${c.getString(7)} • الكمية: ${c.getLong(4)} × ${formatMoney(c.getLong(5))} • الإجمالي: ${formatMoney(c.getLong(6))} ر.ي"
                }
                if (plantationId == null) {
                    writer.section("الأرصدة الافتتاحية لكل المواضع")
                    appendCursorRows(db, writer,
                        "SELECT p.name,o.amount,o.dateMillis,o.notes FROM plantation_opening_balances o INNER JOIN plantations p ON p.id=o.plantationId ORDER BY p.name COLLATE NOCASE", emptyArray()) { c ->
                        "الموضع: ${c.getString(0)} • الرصيد الافتتاحي: ${formatMoney(c.getLong(1))} ر.ي • التاريخ: ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(c.getLong(2)))}\n${c.getString(3)}"
                    }
                }
                writer.section("ملخص الحسابات")
                appendCursorRows(db, writer,
                    "SELECT COALESCE(SUM(CASE WHEN category='القطفات' THEN amount ELSE 0 END),0),COALESCE(SUM(CASE WHEN category!='القطفات' THEN amount ELSE 0 END),0),COUNT(CASE WHEN category!='القطفات' THEN 1 END) FROM expenses WHERE dateMillis>=? AND dateMillis<? AND (?=0 OR plantationId=?)", plotArgs) { c ->
                    val opening = db.query("SELECT COALESCE(SUM(amount),0) FROM plantation_opening_balances WHERE (?=0 OR plantationId=?)", arrayOf(plantationId ?: 0L, plantationId ?: 0L)).use { row -> if (row.moveToFirst()) row.getLong(0) else 0L }
                    val outlay = Math.addExact(c.getLong(1), opening)
                    "الرصيد الافتتاحي: ${formatMoney(opening)} • المردود المسجل: ${formatMoney(c.getLong(0))} • المصروفات: ${formatMoney(outlay)} • الصافي: ${formatMoney(c.getLong(0)-outlay)} ر.ي • عدد السجلات: ${c.getLong(2)}"
                }
            }
            else -> error("نوع التقرير غير مدعوم.")
        }
        writer.finish()
        try {
            context.contentResolver.openOutputStream(destination, "w")?.use { pdf.writeTo(it) }
                ?: error("تعذر فتح مكان حفظ تقرير PDF.")
        } finally { pdf.close() }
    }

    private fun reportTitle(type: String): String = when (type) {
        "plantation" -> "كشف حساب الموضع الزراعي"
        "activities" -> "تقرير الأنشطة الزراعية بالتفصيل"
        "buyers" -> "كشف حساب العملاء والمشترين والبائعين"
        "suppliers" -> "كشف حساب التجار والموردين"
        "invoices" -> "تقرير الفواتير وتفاصيل الأصناف"
        "financial" -> "التقرير المالي والإنتاجي"
        else -> "تقرير مِعيار"
    }

    private fun appendCursorRows(
        db: SupportSQLiteDatabase,
        writer: ReportPdfWriter,
        sql: String,
        args: Array<out Any?>,
        render: (Cursor) -> String
    ) {
        var count = 0L
        db.query(sql, args).use { cursor ->
            while (cursor.moveToNext()) {
                writer.paragraph(render(cursor), false, 11f)
                writer.separator(light = true)
                count++
            }
        }
        if (count == 0L) writer.paragraph("لا توجد سجلات ضمن الفترة المحددة.", false, 11f)
    }

    private class ReportPdfWriter(context: Context, private val pdf: PdfDocument) {
        private val pageWidth = 595
        private val pageHeight = 842
        private val margin = 40f
        private val contentWidth = (pageWidth - margin * 2).toInt()
        private var pageNumber = 0
        private var page: PdfDocument.Page? = null
        private var y = 0f
        private val darkGreen = Color.rgb(0, 74, 48)
        private val gold = Color.rgb(199, 166, 90)
        private val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        private val context = context

        private fun openPage() {
            pageNumber++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            val canvas = page!!.canvas
            canvas.drawColor(Color.WHITE)
            val header = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = darkGreen }
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 96f, header)
            val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold }
            canvas.drawRect(0f, 94f, pageWidth.toFloat(), 98f, accent)
            context.getDrawable(R.drawable.ic_miyar_launcher)?.let { icon ->
                icon.setBounds(48, 18, 105, 75)
                icon.draw(canvas)
            }
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE; textSize = 23f; typeface = Typeface.create("sans-serif", Typeface.BOLD)
            }
            canvas.drawText("MIYAR  |  مِعيار", 125f, 52f, titlePaint)
            val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold; textSize = 10.5f }
            canvas.drawText("إدارة زراعية ومالية أكثر وضوحًا", 125f, 73f, sub)
            y = 116f
        }

        fun paragraph(text: String, bold: Boolean = false, size: Float = 12f) {
            if (page == null) openPage()
            bodyPaint.textSize = size
            bodyPaint.color = darkGreen
            bodyPaint.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            val layout = StaticLayout.Builder.obtain(text.ifBlank { " " }, 0, text.ifBlank { " " }.length, bodyPaint, contentWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(true)
                .setLineSpacing(1f, 1f)
                .build()
            if (y + layout.height + 16f > 792f) {
                closePage()
                openPage()
            }
            val canvas = page!!.canvas
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + 7f
        }

        fun section(text: String) {
            if (page == null) openPage()
            if (y > 744f) { closePage(); openPage() }
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = darkGreen }
            page!!.canvas.drawRoundRect(RectF(margin, y, pageWidth - margin, y + 27f), 6f, 6f, paint)
            val label = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 13f; typeface = Typeface.DEFAULT_BOLD }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, label, contentWidth - 18)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.RTL).build()
            page!!.canvas.save(); page!!.canvas.translate(margin + 9f, y + 4f); layout.draw(page!!.canvas); page!!.canvas.restore()
            y += 39f
        }

        fun separator(light: Boolean = false) {
            if (page == null) openPage()
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (light) 0xFFE2E9E3.toInt() else gold; strokeWidth = if (light) 0.7f else 1.5f }
            page!!.canvas.drawLine(margin, y, pageWidth - margin, y, paint)
            y += 7f
        }

        private fun closePage() {
            val active = page ?: return
            val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = darkGreen; textSize = 9f }
            active.canvas.drawText("مِعيار • تقرير مستخرج من التطبيق", margin, 822f, footer)
            active.canvas.drawText("$pageNumber", pageWidth - margin - 10f, 822f, footer)
            pdf.finishPage(active)
            page = null
        }

        fun finish() {
            if (page == null) openPage()
            closePage()
        }
    }

    private fun csv(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    fun shareOperationPdf(context: Context, title: String, plantation: String, category: String, dateMillis: Long, amount: Long, notes: String, chemicalLines: List<String>) {
        val pdf = PdfDocument()
        val writer = ReportPdfWriter(context, pdf)
        writer.paragraph("تفاصيل العملية الزراعية", true, 19f)
        writer.paragraph("اسم العملية: $title", true)
        writer.paragraph("الموضع الزراعي: $plantation")
        writer.paragraph("القسم: $category")
        writer.paragraph("التاريخ: ${SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(dateMillis))}")
        writer.paragraph("إجمالي قيمة العملية: ${formatMoney(amount)} ر.ي", true, 14f)
        if (chemicalLines.isNotEmpty()) {
            writer.section("تفاصيل الأصناف والمواد")
            chemicalLines.forEach { writer.paragraph(it) }
        }
        if (notes.isNotBlank()) {
            writer.section("ملاحظات العملية")
            writer.paragraph(notes)
        }
        writer.finish()
        val file = File(context.cacheDir, "miyar_operation_${System.currentTimeMillis()}.pdf")
        try {
            FileOutputStream(file).use { pdf.writeTo(it) }
        } finally { pdf.close() }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "مشاركة تفاصيل عملية مِعيار بصيغة PDF"))
    }
}
