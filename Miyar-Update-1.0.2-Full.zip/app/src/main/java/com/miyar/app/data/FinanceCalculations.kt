package com.miyar.app.data

import java.math.BigDecimal
import java.math.RoundingMode

/** Exact whole-number calculations used by invoice and inventory flows. */
object FinanceCalculations {
    fun quantityToBase(quantity: Long, unit: String, packageCount: Long = 1L): Long {
        require(quantity >= 0 && packageCount >= 0) { "الكمية لا يمكن أن تكون سالبة." }
        val multiplier = if (unit == "كجم" || unit == "لتر") 1000L else 1L
        return Math.multiplyExact(Math.multiplyExact(quantity, packageCount), multiplier)
    }

    fun lineTotal(packageCount: Long, pricePerPackage: Long): Long {
        require(packageCount >= 0 && pricePerPackage >= 0) { "الكمية والسعر لا يمكن أن يكونا سالبين." }
        return Math.multiplyExact(packageCount, pricePerPackage)
    }

    /** Add totals without silently wrapping on Long overflow. */
    fun sumExact(values: Iterable<Long>): Long = values.fold(0L) { total, value -> Math.addExact(total, value) }

    /** rateScaled is the exchange rate multiplied by 1000. */
    fun toYemeniRials(amountForeign: Long, rateScaled: Long): Long {
        require(amountForeign >= 0 && rateScaled > 0) { "تحقق من المبلغ وسعر الصرف." }
        return BigDecimal(amountForeign)
            .multiply(BigDecimal(rateScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Weighted-average cost per canonical base unit (gram/ml), scaled by 1000. */
    fun averageCostPerBaseScaled(totalYer: Long, totalQuantityBase: Long): Long {
        require(totalYer >= 0 && totalQuantityBase > 0) { "قيمة الشراء أو الكمية غير صالحة." }
        return BigDecimal(totalYer).multiply(BigDecimal(1000))
            .divide(BigDecimal(totalQuantityBase), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Cost of a consumed quantity using the stored weighted-average YER price. */
    fun usageCostYer(quantityBase: Long, averageCostPerBaseScaled: Long): Long {
        require(quantityBase >= 0 && averageCostPerBaseScaled >= 0) { "كمية الاستخدام أو سعر الوحدة غير صالح." }
        return BigDecimal(quantityBase).multiply(BigDecimal(averageCostPerBaseScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }
}
