package com.miyar.app.data

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(tableName = "plantations")
data class PlantationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'🌱'") val icon: String = "🌱",
    @ColumnInfo(defaultValue = "-16749764") val colorArgb: Long = -16749764L
)

@Entity(tableName = "expenses", indices = [
    Index(value = ["plantationId", "dateMillis", "id"], name = "index_expenses_plantationId_dateMillis"),
    Index(value = ["category", "dateMillis", "id"], name = "index_expenses_category_dateMillis"),
    Index(value = ["plantationId", "category", "dateMillis"], name = "index_expenses_plantationId_category_dateMillis"),
    Index(value = ["dateMillis", "id"], name = "index_expenses_dateMillis")
])
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantationId: Long,
    val category: String = "أخرى",
    val title: String,
    // Store money as integer minor units (e.g. whole Yemeni rials) to avoid floating-point errors.
    val amount: Long,
    val currency: String = "YER",
    val dateMillis: Long = System.currentTimeMillis(),
    val notes: String = ""
)


data class CategoryTotal(
    val category: String,
    val count: Long,
    val total: Long
)

data class ExpenseWithPlantation(
    val id: Long,
    val plantationId: Long,
    val plantationName: String,
    val category: String,
    val title: String,
    val amount: Long,
    val currency: String,
    val dateMillis: Long,
    val notes: String
)


/** One controlled opening-balance figure per plantation; kept separate from dated expenses. */
@Entity(
    tableName = "plantation_opening_balances",
    foreignKeys = [ForeignKey(entity = PlantationEntity::class, parentColumns = ["id"], childColumns = ["plantationId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["plantationId"], unique = true)]
)
data class PlantationOpeningBalanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantationId: Long,
    val amount: Long,
    val dateMillis: Long = System.currentTimeMillis(),
    val notes: String = "رصيد سابق قبل استخدام مِعيار"
)

data class ReportSummary(
    val expenseCount: Long,
    val expenseTotal: Long,
    val harvestTotal: Long,
    val invoiceTotal: Long,
    val chemicalTotal: Long,
    val waterTotal: Long,
    val laborTotal: Long,
    val otherTotal: Long
)
