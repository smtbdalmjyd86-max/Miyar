package com.miyar.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Supplier profiles are independent from the harvest-market seller profiles. */
@Entity(tableName = "suppliers", indices = [Index(value = ["name"], unique = true)])
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

/** A payment against an invoice supplier's credit balance. Historical exchange rates are immutable. */
@Entity(
    tableName = "supplier_payments",
    foreignKeys = [ForeignKey(entity = SupplierEntity::class, parentColumns = ["id"], childColumns = ["supplierId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["supplierId"]), Index(value = ["dateMillis"]), Index(value = ["dateMillis", "id"], name = "index_supplier_payments_dateMillis_id")]
)
data class SupplierPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long,
    val dateMillis: Long,
    val currency: String,
    val amountForeign: Long,
    /** Exchange rate x 1000; stored per payment so later rate edits do not rewrite history. */
    val exchangeRateScaled: Long,
    val amountYer: Long,
    val paymentMethod: String = "نقدًا",
    val notes: String = ""
)

data class SupplierAccountSummary(
    val id: Long,
    val name: String,
    val phone: String,
    val invoiceCount: Long,
    val totalCreditYer: Long,
    val totalPaidYer: Long,
    val balanceYer: Long,
    val notes: String = ""
)

data class SupplierPaymentWithName(
    val id: Long,
    val supplierId: Long,
    val supplierName: String,
    val dateMillis: Long,
    val currency: String,
    val amountForeign: Long,
    val exchangeRateScaled: Long,
    val amountYer: Long,
    val paymentMethod: String,
    val notes: String
)
