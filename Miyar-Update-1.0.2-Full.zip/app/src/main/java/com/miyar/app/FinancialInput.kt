package com.miyar.app

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange

/** Numeric money input: groups thousands with dots while the stored value remains digits only. */
@Composable
internal fun MiyarMoneyInputField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Next,
    enabled: Boolean = true
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val initialText = remember(value) { moneyInput(value) }
    var fieldValue by remember { mutableStateOf(TextFieldValue(initialText, TextRange(initialText.length))) }

    LaunchedEffect(value) {
        val normalized = moneyInput(value)
        if (normalized != fieldValue.text) {
            fieldValue = TextFieldValue(normalized, TextRange(normalized.length))
        }
    }

    OutlinedTextField(
        value = fieldValue,
        onValueChange = { edited ->
            val digitsBeforeCursor = edited.text.take(edited.selection.start).count(Char::isDigit)
            val grouped = moneyInput(edited.text)
            var seenDigits = 0
            var cursor = 0
            if (digitsBeforeCursor > 0) {
                for (index in grouped.indices) {
                    if (grouped[index].isDigit()) seenDigits++
                    cursor = index + 1
                    if (seenDigits >= digitsBeforeCursor) break
                }
            }
            cursor = cursor.coerceIn(0, grouped.length)
            fieldValue = TextFieldValue(grouped, TextRange(cursor))
            onValueChange(grouped)
        },
        label = { Text(label) },
        modifier = modifier,
        enabled = enabled,
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = imeAction
        ),
        keyboardActions = KeyboardActions(
            onNext = {
                if (!focusManager.moveFocus(FocusDirection.Next)) keyboardController?.hide()
            },
            onDone = {
                keyboardController?.hide()
                focusManager.clearFocus()
            }
        )
    )
}


/** Exchange-rate input retains up to three fractional digits while grouping thousands. */
@Composable
internal fun MiyarRateInputField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Next,
    enabled: Boolean = true
) {
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val initialText = remember(value) { rateInput(value) }
    var fieldValue by remember { mutableStateOf(TextFieldValue(initialText, TextRange(initialText.length))) }

    LaunchedEffect(value) {
        val normalized = rateInput(value)
        if (normalized != fieldValue.text) fieldValue = TextFieldValue(normalized, TextRange(normalized.length))
    }

    OutlinedTextField(
        value = fieldValue,
        onValueChange = { edited ->
            val prefix = edited.text.take(edited.selection.start)
            val explicitDecimalIndex = maxOf(prefix.lastIndexOf(','), prefix.lastIndexOf('٫'))
            val oneDotDecimal = explicitDecimalIndex < 0 && edited.text.count { it == '.' } == 1 &&
                edited.text.substringAfterLast('.').count(Char::isDigit) < 3
            val decimalWasBeforeCursor = explicitDecimalIndex >= 0 || oneDotDecimal
            val fractionDigitsBefore = when {
                explicitDecimalIndex >= 0 -> prefix.substring(explicitDecimalIndex + 1).count(Char::isDigit)
                oneDotDecimal -> prefix.substringAfterLast('.').count(Char::isDigit)
                else -> 0
            }
            val integerPrefix = when {
                explicitDecimalIndex >= 0 -> prefix.substring(0, explicitDecimalIndex)
                oneDotDecimal -> prefix.substringBeforeLast('.')
                else -> prefix
            }
            val integerDigitsBefore = integerPrefix.count(Char::isDigit)
            val grouped = rateInput(edited.text)
            val comma = grouped.indexOf(',')
            var seenDigits = 0
            var cursor = 0
            if (decimalWasBeforeCursor && comma >= 0) {
                cursor = (comma + 1 + fractionDigitsBefore).coerceAtMost(grouped.length)
            } else if (integerDigitsBefore > 0) {
                for (index in grouped.indices) {
                    if (grouped[index].isDigit()) seenDigits++
                    cursor = index + 1
                    if (seenDigits >= integerDigitsBefore) break
                }
            }
            fieldValue = TextFieldValue(grouped, TextRange(cursor.coerceIn(0, grouped.length)))
            onValueChange(grouped)
        },
        label = { Text(label) },
        modifier = modifier,
        enabled = enabled,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = imeAction),
        keyboardActions = KeyboardActions(
            onNext = { if (!focusManager.moveFocus(FocusDirection.Next)) keyboardController?.hide() },
            onDone = { keyboardController?.hide(); focusManager.clearFocus() }
        )
    )
}
