package com.miyar.app.data

import java.math.BigDecimal
import java.math.RoundingMode

/** Exact whole-number calculations used by invoice and inventory flows. */
object FinanceCalculations {
    fun quantityToBase(quantity: Long, unit: String, packageCount: Long = 1L): Long {
        require(quantity >= 0 && packageCount >= 0) { "الكمية لا يمكن أن تكون سالبة." }
        val multiplier = if (unit == "كجم" || unit == "لتر") 1000L else 1L
        return Math.multiplyExact(Math.multiplyExact(quantity, packageCount), multiplier)
    }

    fun lineTotal(packageCount: Long, pricePerPackage: Long): Long {
        require(packageCount >= 0 && pricePerPackage >= 0) { "الكمية والسعر لا يمكن أن يكونا سالبين." }
        return Math.multiplyExact(packageCount, pricePerPackage)
    }

    /** Add totals without silently wrapping on Long overflow. */
    fun sumExact(values: Iterable<Long>): Long = values.fold(0L) { total, value -> Math.addExact(total, value) }

    /** rateScaled is the exchange rate multiplied by 1000. */
    fun toYemeniRials(amountForeign: Long, rateScaled: Long): Long {
        require(amountForeign >= 0 && rateScaled > 0) { "تحقق من المبلغ وسعر الصرف." }
        return BigDecimal(amountForeign)
            .multiply(BigDecimal(rateScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Weighted-average cost per canonical base unit (gram/ml), scaled by 1000. */
    fun averageCostPerBaseScaled(totalYer: Long, totalQuantityBase: Long): Long {
        require(totalYer >= 0 && totalQuantityBase > 0) { "قيمة الشراء أو الكمية غير صالحة." }
        return BigDecimal(totalYer).multiply(BigDecimal(1000))
            .divide(BigDecimal(totalQuantityBase), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Cost of a consumed quantity using the stored weighted-average YER price. */
    fun usageCostYer(quantityBase: Long, averageCostPerBaseScaled: Long): Long {
        require(quantityBase >= 0 && averageCostPerBaseScaled >= 0) { "كمية الاستخدام أو سعر الوحدة غير صالح." }
        return BigDecimal(quantityBase).multiply(BigDecimal(averageCostPerBaseScaled))
            .divide(BigDecimal(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /** Subtract a stock issue safely; callers must validate the balance before recording the movement. */
    fun stockAfterIssue(availableBase: Long, issueBase: Long): Long {
        require(availableBase >= 0L) { "رصيد المخزون الحالي غير صالح." }
        require(issueBase > 0L) { "كمية الصرف يجب أن تكون أكبر من صفر." }
        check(issueBase <= availableBase) { "كمية الصرف أكبر من الرصيد المتاح." }
        return availableBase - issueBase
    }

    /** Restore a previously recorded issue without allowing overflow. */
    fun stockAfterIssueReversal(currentBase: Long, reversedBase: Long): Long {
        require(currentBase >= 0L && reversedBase > 0L) { "بيانات عكس الصرف غير صالحة." }
        return Math.addExact(currentBase, reversedBase)
    }

    /** Format the canonical gram/ml quantity as a major unit plus the exact remainder. */
    fun formatStockQuantity(quantityBase: Long, baseUnit: String): String {
        require(quantityBase >= 0L) { "كمية المخزون لا يمكن أن تكون سالبة." }
        val major = quantityBase / 1000L
        val remainder = quantityBase % 1000L
        val (majorName, minorName) = if (baseUnit.equals("g", true)) "كيلو" to "جرام" else "لتر" to "ملي"
        return when {
            major > 0L && remainder > 0L -> "$major $majorName $remainder $minorName"
            major > 0L -> "$major $majorName"
            remainder > 0L -> "$remainder $minorName"
            else -> "0 $minorName"
        }
    }
}
