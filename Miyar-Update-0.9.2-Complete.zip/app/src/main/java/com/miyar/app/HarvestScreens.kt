@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)
package com.miyar.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.miyar.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private fun hDate(value: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(value))
private fun money(value: Long): String = "$value ريال"
private fun safeProduct(a: Long, b: Long): Long = try { Math.multiplyExact(a, b) } catch (_: ArithmeticException) { Long.MAX_VALUE }

@Composable
private fun DateField(label: String, value: Long, onChange: (Long) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) {
        Text("$label: ${hDate(value)}")
    }
    if (show) {
        val state = rememberDatePickerState(initialSelectedDateMillis = value.takeIf { it > 0 } ?: System.currentTimeMillis())
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = { state.selectedDateMillis?.let(onChange); show = false }) { Text("اختيار") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } }
        ) { DatePicker(state) }
    }
}

@Composable
private fun NumField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(latinDigitsOnly(it)) },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
private fun SuggestedTextField(
    label: String,
    value: String,
    onValue: (String) -> Unit,
    suggestions: List<String>,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    Column(modifier) {
        OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        val matches = remember(value, suggestions) {
            if (value.isBlank()) emptyList() else suggestions.distinct().filter { it.contains(value, ignoreCase = true) }.take(5)
        }
        if (matches.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                matches.forEach { suggestion ->
                    TextButton(onClick = { onValue(suggestion) }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)) {
                        Text(suggestion, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun HarvestMetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) { Text(label, color = Emerald, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold); Text(value, color = Green, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
fun MiyarHarvestScreen(
    dao: MiyarDao,
    plantations: List<PlantationEntity>,
    searchTarget: String? = null,
    onSearchTargetConsumed: () -> Unit = {},
    initialPage: String = "home",
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var page by remember(initialPage) { mutableStateOf(initialPage) }
    var selectedHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }
    var selectedDay by remember { mutableStateOf<PersonalHarvestDayEntity?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var newPlotId by remember { mutableLongStateOf(0L) }
    var editingHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }
    var longPressedHarvest by remember { mutableStateOf<PersonalHarvestEntity?>(null) }
    var longPressedDay by remember { mutableStateOf<PersonalHarvestDayEntity?>(null) }
    var dataProtectionMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedSale by remember { mutableStateOf<BuyerSaleEntity?>(null) }
    var selectedBuyer by remember { mutableStateOf<QatBuyerEntity?>(null) }
    var selectedDistributor by remember { mutableStateOf<MarketDistributorEntity?>(null) }
    var selectedDebtor by remember { mutableStateOf<HarvestDebtorEntity?>(null) }

    val harvests by dao.observePersonalHarvests().collectAsStateWithLifecycle(emptyList())
    val buyers by dao.observeBuyers().collectAsStateWithLifecycle(emptyList())
    val allSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(emptyList())
    val distributors by dao.observeDistributors().collectAsStateWithLifecycle(emptyList())
    val debtors by dao.observeDebtors().collectAsStateWithLifecycle(emptyList())
    val distributorSuggestions by dao.observeDistributorNameSuggestions().collectAsStateWithLifecycle(emptyList())
    val debtorSuggestions by dao.observeDebtorNameSuggestions().collectAsStateWithLifecycle(emptyList())
    val buyerSuggestions by dao.observeBuyerNameSuggestions().collectAsStateWithLifecycle(emptyList())
    val productSuggestions by dao.observeHarvestProductSuggestions().collectAsStateWithLifecycle(emptyList())

    LaunchedEffect(searchTarget) {
        val route = searchTarget?.split(":", limit = 2)
        val id = route?.getOrNull(1)?.toLongOrNull()
        if (route != null && id != null) {
            when (route[0]) {
                "harvest" -> dao.getPersonalHarvestById(id)?.let { selectedHarvest = it; selectedDay = null; page = "harvest" }
                "day" -> dao.getPersonalHarvestDayById(id)?.let { day ->
                    dao.getPersonalHarvestById(day.harvestId)?.let { harvest -> selectedHarvest = harvest; selectedDay = day; page = "day" }
                }
                "buyer" -> dao.getBuyerById(id)?.let { selectedBuyer = it; page = "buyerDetail" }
                "sale" -> dao.getBuyerSaleById(id)?.let { sale ->
                    selectedSale = sale
                    selectedBuyer = dao.getBuyerById(sale.buyerId)
                    page = if (selectedBuyer == null) "buyerFiles" else "saleDetail"
                }
                "distributor" -> dao.getDistributorById(id)?.let { selectedDistributor = it; page = "distributorDetail" }
                "debtor" -> dao.getDebtorById(id)?.let { selectedDebtor = it; page = "debtorDetail" }
            }
        }
        if (!searchTarget.isNullOrBlank()) onSearchTargetConsumed()
    }

    fun navigateBack() {
        when (page) {
            "day", "newDay", "editDay", "harvestEdit" -> page = "harvest"
            "harvest" -> page = "personal"
            "personal", "parties", "buyer", "buyerFiles", "salesList" -> page = if (initialPage == "revenue") "revenue" else "home"
            "distributorDetail", "debtorDetail" -> page = "parties"
            "buyerDetail" -> page = "buyerFiles"
            "buyerNewSale" -> page = "buyerDetail"
            "saleDetail" -> page = "buyerDetail"
            else -> page = if (initialPage == "revenue") "revenue" else "home"
        }
        selectedDay = null
    }

    BackHandler(enabled = page != "home" || showNew || editingHarvest != null || longPressedDay != null || longPressedHarvest != null) {
        when {
            longPressedDay != null -> longPressedDay = null
            longPressedHarvest != null -> longPressedHarvest = null
            editingHarvest != null -> editingHarvest = null
            showNew -> showNew = false
            else -> navigateBack()
        }
    }

    Column(modifier.fillMaxSize()) {
        if (page != "home") {
            TextButton(onClick = { navigateBack() }, modifier = Modifier.align(Alignment.Start)) { Text("← رجوع") }
        }
        when (page) {
            "revenue" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("الإيرادات والمبيعات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Emerald)
                val agreed = allSales.sumOf { it.agreedAmount }
                val discounts = allSales.sumOf { it.discountAmount }
                val totalPayments by dao.observeAllBuyerPaymentsTotal().collectAsStateWithLifecycle(0L)
                val remaining = (agreed - discounts - totalPayments).coerceAtLeast(0L)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HarvestMetricCard("إجمالي الاتفاقات", money(agreed - discounts), Modifier.weight(1f))
                    HarvestMetricCard("المبالغ المحصلة", money(totalPayments), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HarvestMetricCard("المتبقي", money(remaining), Modifier.weight(1f))
                    HarvestMetricCard("عدد المبيعات", allSales.size.toString(), Modifier.weight(1f))
                }
                HarvestChoice("🧾", "سجل المبيعات", "عرض كل عمليات البيع والتحصيل") { page = "salesList" }
                HarvestChoice("👥", "ملفات المشترين", "كشف حساب كل مشترٍ والدفعات والمبالغ المتبقية") { page = "buyerFiles" }
                HarvestChoice("🌿", "القطف الشخصي والإنتاج", "متابعة القطفات الشخصية وأيام الحصاد") { page = "personal" }
                Text("أحدث المبيعات", fontWeight = FontWeight.Bold)
                allSales.take(12).forEach { sale -> val buyer = buyers.firstOrNull { it.id == sale.buyerId }; Card(onClick = { selectedSale = sale; selectedBuyer = buyer; page = "saleDetail" }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(buyer?.name ?: "مشتري", fontWeight = FontWeight.Bold); Text("${sale.harvestName} • ${money(sale.agreedAmount - sale.discountAmount)}"); Text(hDate(sale.saleDateMillis), style = MaterialTheme.typography.bodySmall) } } }
            }

            "salesList" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سجل المبيعات والتحصيلات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
                allSales.forEach { sale -> val buyer = buyers.firstOrNull { it.id == sale.buyerId }; Card(onClick = { selectedSale = sale; selectedBuyer = buyer; page = "saleDetail" }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(buyer?.name ?: "مشتري", fontWeight = FontWeight.Bold); Text("${sale.harvestName} • ${money(sale.agreedAmount - sale.discountAmount)}"); Text("${hDate(sale.saleDateMillis)} • افتح التفاصيل") } } }
                if (allSales.isEmpty()) Text("لا توجد مبيعات مسجلة بعد.")
            }

            "home" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("قسم القطفات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Emerald)
                HarvestChoice("🌿", "قطفة شخصية", "إدارة المواضع وأيام القطف والإنتاج والمبيعات") { page = "personal" }
                HarvestChoice("📁", "ملفات البائعين والعملاء", "${distributors.size} بائع • ${debtors.size} عميل آجل") { page = "parties" }
                HarvestChoice("🤝", "البيع لمشتري", "تسجيل الموضع والاتفاق والمدة والخصم والواصلات") { page = "buyer" }
                HarvestChoice("📂", "ملفات المشترين", "سجلات المشترين والقطفات وكشوف الحساب") { page = "buyerFiles" }
                Text("أحدث عمليات البيع لمشترٍ", fontWeight = FontWeight.Bold)
                allSales.take(8).forEach { sale ->
                    val buyer = buyers.firstOrNull { it.id == sale.buyerId }
                    Card(onClick = { selectedSale = sale; selectedBuyer = buyer; page = "saleDetail" }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(buyer?.name ?: "مشتري", fontWeight = FontWeight.Bold)
                            Text("${sale.harvestName} • ${money(sale.agreedAmount - sale.discountAmount)}")
                            Text("تاريخ البيع: ${hDate(sale.saleDateMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            "personal" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("اختر الموضع الذي سيتم القطف منه", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                plantations.forEach { plot ->
                    Card(onClick = { showNew = true; selectedHarvest = null; newPlotId = plot.id }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(plot.colorArgb).copy(alpha = 0.10f))) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(plot.icon, style = MaterialTheme.typography.titleLarge); Text(plot.name, Modifier.padding(start = 10.dp), fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(plot.colorArgb)) }
                    }
                }
                if (plantations.isEmpty()) Text("لا توجد مواضع مسجلة. أضف موضعًا أولًا.")
                HorizontalDivider()
                Text("القطفات الشخصية المسجلة", fontWeight = FontWeight.Bold)
                harvests.forEach { harvest ->
                    Card(
                        modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = { selectedHarvest = harvest; page = "harvest" },
                            onLongClick = { longPressedHarvest = harvest }
                        )
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(harvest.name, fontWeight = FontWeight.Bold)
                            Text("${plantations.firstOrNull { it.id == harvest.plantationId }?.name ?: "موضع"} • ${hDate(harvest.startMillis)}")
                            Text("اضغط للفتح، واضغط مطولًا للتعديل أو الحذف", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            "harvest" -> {
                val harvest = selectedHarvest
                if (harvest != null) HarvestDetailScreen(dao, harvest, plantations, onAddDay = { selectedDay = null; page = "newDay" }, onOpenDay = { selectedDay = it; page = "day" }, onLongPressDay = { longPressedDay = it })
            }

            "newDay" -> selectedHarvest?.let { harvest ->
                DayEditor(dao, harvest, plantations, null, distributorSuggestions, debtorSuggestions, productSuggestions, onSaved = { page = "harvest" })
            }

            "editDay" -> if (selectedHarvest != null && selectedDay != null) {
                DayEditor(dao, selectedHarvest!!, plantations, selectedDay!!, distributorSuggestions, debtorSuggestions, productSuggestions, onSaved = { page = "harvest" })
            }

            "day" -> if (selectedHarvest != null && selectedDay != null) DayDetails(dao, selectedHarvest!!, selectedDay!!, plantations)

            "parties" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("ملفات الأطراف والمستحقات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = Emerald)
                Text("ملفات البائعين والعملاء المرتبطة بعمليات القطف الشخصية", style = MaterialTheme.typography.bodySmall)
                HarvestChoice("📂", "ملفات المشترين", "سجلات البيع والدفعات والمبالغ المتبقية") { page = "buyerFiles" }
                HorizontalDivider()
                Text("ملفات البائعين", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                if (distributors.isEmpty()) Text("لا توجد ملفات بائعين بعد.")
                distributors.forEach { seller ->
                    Card(onClick = { selectedDistributor = seller; page = "distributorDetail" }, modifier = Modifier.fillMaxWidth()) {
                        Text("🧑 ${seller.name}  ›", Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
                    }
                }
                HorizontalDivider()
                Text("ملفات العملاء بالأجل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                if (debtors.isEmpty()) Text("لا توجد ملفات عملاء آجل بعد.")
                debtors.forEach { debtor ->
                    Card(onClick = { selectedDebtor = debtor; page = "debtorDetail" }, modifier = Modifier.fillMaxWidth()) {
                        Text("👤 ${debtor.name}  ›", Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
                    }
                }
            }

            "distributorDetail" -> selectedDistributor?.let { DistributorFileScreen(dao, it, harvests, plantations) }
            "debtorDetail" -> selectedDebtor?.let { DebtorFileScreen(dao, it, harvests, plantations) }

            "buyer" -> BuyerSaleForm(
                dao = dao,
                plantations = plantations,
                buyers = buyers,
                buyerSuggestions = buyerSuggestions,
                initialBuyer = null,
                onSaved = { page = if (initialPage == "revenue") "revenue" else "home" }
            )

            "buyerFiles" -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("ملفات المشترين", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                buyers.forEach { buyer ->
                    val salesForBuyer = allSales.filter { it.buyerId == buyer.id }
                    Card(onClick = { selectedBuyer = buyer; page = "buyerDetail" }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(buyer.name, fontWeight = FontWeight.Bold)
                            Text("عدد القطفات: ${salesForBuyer.size} • إجمالي الاتفاقات: ${money(salesForBuyer.sumOf { it.agreedAmount })}")
                        }
                    }
                }
                if (buyers.isEmpty()) Text("سيظهر المشترون هنا تلقائيًا بعد تسجيل أول عملية بيع.")
            }

            "buyerDetail" -> selectedBuyer?.let { buyer ->
                BuyerFileScreen(dao, buyer, plantations, onNewSale = { page = "buyerNewSale" }, onOpenSale = { sale -> selectedSale = sale; page = "saleDetail" })
            }

            "buyerNewSale" -> BuyerSaleForm(dao, plantations, buyers, buyerSuggestions, selectedBuyer) { page = "buyerDetail" }

            "saleDetail" -> if (selectedSale != null && selectedBuyer != null) {
                BuyerSaleDetailScreen(dao, selectedSale!!, selectedBuyer!!, plantations)
            }
        }
    }

    if (showNew) {
        NewHarvestDialog(
            dao = dao,
            plots = plantations,
            plotId = newPlotId,
            onSaved = { harvest -> showNew = false; selectedHarvest = harvest; page = "harvest" },
            onCancel = { showNew = false }
        )
    }

    longPressedHarvest?.let { harvest ->
        AlertDialog(
            onDismissRequest = { longPressedHarvest = null },
            title = { Text(harvest.name) },
            text = { Text("اختر الإجراء المطلوب للقطفة") },
            confirmButton = { TextButton(onClick = { longPressedHarvest = null; editingHarvest = harvest }) { Text("تعديل") } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        scope.launch {
                            val deleted = dao.deletePersonalHarvestSafely(harvest.id)
                            longPressedHarvest = null
                            if (deleted) {
                                ReminderScheduler.cancel(context, harvest.id, "HARVEST")
                                dao.deleteOperationReminder("HARVEST", harvest.id)
                                if (selectedHarvest?.id == harvest.id) { selectedHarvest = null; page = "personal" }
                            } else {
                                dataProtectionMessage = "لا يمكن حذف هذه القطفة الآن؛ توجد دفعات مالية مرتبطة بحسابات البائعين أو العملاء. راجع الملفات وسوِّ الدفعات أولًا حتى لا تضيع السجلات المالية."
                            }
                        }
                    }) { Text("حذف") }
                    TextButton(onClick = { longPressedHarvest = null; selectedHarvest = harvest; page = "harvest" }) { Text("فتح") }
                }
            }
        )
    }

    if (editingHarvest != null) {
        EditHarvestDialog(
            dao = dao,
            harvest = editingHarvest!!,
            onDone = { updated -> editingHarvest = null; selectedHarvest = updated; page = "harvest" },
            onCancel = { editingHarvest = null }
        )
    }

    dataProtectionMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { dataProtectionMessage = null },
            title = { Text("حماية السجلات المالية") },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { dataProtectionMessage = null }) { Text("حسنًا") } }
        )
    }

    longPressedDay?.let { day ->
        AlertDialog(
            onDismissRequest = { longPressedDay = null },
            title = { Text("يوم ${hDate(day.dateMillis)}") },
            text = { Text("هل تريد تعديل بيانات اليوم أم حذفه؟") },
            confirmButton = { TextButton(onClick = { longPressedDay = null; selectedDay = day; page = "editDay" }) { Text("تعديل") } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        scope.launch {
                            val deleted = dao.deletePersonalHarvestDaySafely(day.id)
                            longPressedDay = null
                            if (!deleted) dataProtectionMessage = "لا يمكن حذف يوم القطفة؛ توجد دفعة مالية مسجلة لأحد البائعين أو العملاء في هذا اليوم. راجع الحسابات أولًا حتى لا نفقد سجل الدفع."
                        }
                    }) { Text("حذف") }
                    TextButton(onClick = { longPressedDay = null }) { Text("إلغاء") }
                }
            }
        )
    }
}

@Composable
private fun HarvestChoice(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, style = MaterialTheme.typography.headlineLarge)
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun NewHarvestDialog(dao: MiyarDao, plots: List<PlantationEntity>, plotId: Long, onSaved: (PersonalHarvestEntity) -> Unit, onCancel: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var start by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var expected by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val plot = plots.firstOrNull { it.id == plotId }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("بيانات القطفة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الموضع: ${plot?.name ?: ""}", fontWeight = FontWeight.Bold)
                OutlinedTextField(name, { name = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                DateField("تاريخ بداية القطفة", start) { start = it }
                DateField("التاريخ المتوقع للانتهاء", expected) { expected = it }
                Text("يمكن إدخال تاريخ الانتهاء الفعلي لاحقًا من تعديل بيانات القطفة.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && plot != null && expected >= start) scope.launch {
                    val entity = PersonalHarvestEntity(
                        plantationId = plot.id, name = name.trim(), startMillis = start,
                        expectedEndMillis = expected, actualEndMillis = 0,
                        productsText = "", cashSalesText = "", debtorSalesText = "",
                        pickerCount = 0, pickerWage = 0, extraWages = 0,
                        bagsAndOther = 0, transportAndClearance = 0, notes = ""
                    )
                    val id = dao.insertPersonalHarvest(entity)
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(expected))
                    val reminderAt = java.util.Calendar.getInstance().apply { timeInMillis = expected; set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
                    ReminderScheduler.schedule(context, id, name.trim(), "نهاية القطفة المتوقعة", plot.name, date, "09:00", "HARVEST")
                    dao.upsertOperationReminder(OperationReminderEntity(referenceType = "HARVEST", referenceId = id, title = name.trim(), category = "نهاية القطفة المتوقعة", plantationName = plot.name, scheduledAtMillis = reminderAt))
                    onSaved(entity.copy(id = id))
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("إلغاء") } }
    )
}

@Composable
private fun EditHarvestDialog(dao: MiyarDao, harvest: PersonalHarvestEntity, onDone: (PersonalHarvestEntity) -> Unit, onCancel: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var name by remember { mutableStateOf(harvest.name) }
    var start by remember { mutableLongStateOf(harvest.startMillis) }
    var expected by remember { mutableLongStateOf(harvest.expectedEndMillis) }
    var actual by remember { mutableLongStateOf(harvest.actualEndMillis) }
    var showActual by remember { mutableStateOf(harvest.actualEndMillis > 0) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("تعديل بيانات القطفة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth())
                DateField("بداية القطفة", start) { start = it }
                DateField("الانتهاء المتوقع", expected) { expected = it }
                TextButton(onClick = { showActual = !showActual; if (!showActual) actual = 0L }) { Text(if (showActual) "إخفاء تاريخ الانتهاء الفعلي" else "إدخال تاريخ الانتهاء الفعلي") }
                if (showActual) DateField("الانتهاء الفعلي", actual.takeIf { it > 0 } ?: System.currentTimeMillis()) { actual = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && expected >= start) scope.launch {
                    val updated = harvest.copy(name = name.trim(), startMillis = start, expectedEndMillis = expected, actualEndMillis = if (showActual) actual else 0L)
                    dao.updatePersonalHarvest(updated)
                    val plotName = dao.getPlantationById(updated.plantationId)?.name ?: "الموضع الزراعي"
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(expected))
                    val reminderAt = java.util.Calendar.getInstance().apply { timeInMillis = expected; set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
                    if (updated.actualEndMillis == 0L) {
                        ReminderScheduler.schedule(context, updated.id, updated.name, "نهاية القطفة المتوقعة", plotName, date, "09:00", "HARVEST")
                        dao.upsertOperationReminder(OperationReminderEntity(referenceType = "HARVEST", referenceId = updated.id, title = updated.name, category = "نهاية القطفة المتوقعة", plantationName = plotName, scheduledAtMillis = reminderAt))
                    } else {
                        ReminderScheduler.cancel(context, updated.id, "HARVEST")
                        dao.deleteOperationReminder("HARVEST", updated.id)
                    }
                    onDone(updated)
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("إلغاء") } }
    )
}

@Composable
private fun HarvestDetailScreen(
    dao: MiyarDao,
    harvest: PersonalHarvestEntity,
    plots: List<PlantationEntity>,
    onAddDay: () -> Unit,
    onOpenDay: (PersonalHarvestDayEntity) -> Unit,
    onLongPressDay: (PersonalHarvestDayEntity) -> Unit
) {
    val days by dao.observeHarvestDays(harvest.id).collectAsStateWithLifecycle(emptyList())
    val lines by dao.observeAllHarvestDayLines().collectAsStateWithLifecycle(emptyList())
    val manualDistributorTransactions by dao.observeAllDistributorTransactions().collectAsStateWithLifecycle(emptyList())
    val manualDebtorTransactions by dao.observeAllDebtorTransactions().collectAsStateWithLifecycle(emptyList())
    val distributorProfiles by dao.observeDistributors().collectAsStateWithLifecycle(emptyList())
    val debtorProfiles by dao.observeDebtors().collectAsStateWithLifecycle(emptyList())
    val plotName = plots.firstOrNull { it.id == harvest.plantationId }?.name ?: "موضع غير معروف"
    val dayIds = days.map { it.id }.toSet()
    val harvestLines = lines.filter { it.dayId in dayIds }
    val linkedManualDistributor = manualDistributorTransactions.filter { it.harvestId == harvest.id && it.sourceDayId == 0L }
    val linkedManualDebtors = manualDebtorTransactions.filter { it.harvestId == harvest.id && it.sourceDayId == 0L }
    val distributorTotal = harvestLines.filter { it.category == "distributor" }.sumOf { it.total } + linkedManualDistributor.sumOf { it.total }
    val cashTotal = harvestLines.filter { it.category == "cash" }.sumOf { it.total }
    val debtTotal = harvestLines.filter { it.category == "debt" }.sumOf { it.total } + linkedManualDebtors.sumOf { it.total }
    val pickerCosts = days.sumOf { safeProduct(it.pickerCount, it.pickerWage) }
    val otherCosts = days.sumOf { it.otherExpenses }
    val legacyCosts = safeProduct(harvest.pickerCount, harvest.pickerWage) + harvest.extraWages + harvest.bagsAndOther + harvest.transportAndClearance
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("${harvest.name} — $plotName", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
        Text("بداية القطفة: ${hDate(harvest.startMillis)} • المتوقع: ${hDate(harvest.expectedEndMillis)}")
        if (harvest.actualEndMillis > 0) Text("الانتهاء الفعلي: ${hDate(harvest.actualEndMillis)}")
        SummaryLine("إجمالي الموزعين", distributorTotal)
        linkedManualDistributor.forEach { transaction ->
            val sellerName = distributorProfiles.firstOrNull { it.id == transaction.distributorId }?.name ?: "بائع"
            Text("عملية ملف البائع: $sellerName • ${transaction.productType} • ${money(transaction.total)}", style = MaterialTheme.typography.bodySmall)
        }
        SummaryLine("إجمالي المبيعات النقدية", cashTotal)
        SummaryLine("إجمالي المبيعات بالأجل", debtTotal)
        linkedManualDebtors.forEach { transaction ->
            val debtorName = debtorProfiles.firstOrNull { it.id == transaction.debtorId }?.name ?: "عميل"
            Text("عملية ملف العميل: $debtorName • ${transaction.productType} • ${money(transaction.total)}", style = MaterialTheme.typography.bodySmall)
        }
        SummaryLine("إجمالي المبيعات", distributorTotal + cashTotal + debtTotal, strong = true)
        SummaryLine("تكاليف الأيام المسجلة", pickerCosts + otherCosts)
        if (legacyCosts > 0 || harvest.productsText.isNotBlank() || harvest.cashSalesText.isNotBlank() || harvest.debtorSalesText.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("بيانات محفوظة من إصدار سابق", fontWeight = FontWeight.Bold)
                    if (harvest.productsText.isNotBlank()) {
                        Text("تفاصيل الإنتاج القديم:", fontWeight = FontWeight.SemiBold)
                        harvest.productsText.split(';').filter { it.isNotBlank() }.forEach { Text("• ${it.replace("|", " • ")}", style = MaterialTheme.typography.bodySmall) }
                    }
                    if (harvest.cashSalesText.isNotBlank()) Text("المبيعات النقدية القديمة: ${harvest.cashSalesText}", style = MaterialTheme.typography.bodySmall)
                    if (harvest.debtorSalesText.isNotBlank()) Text("المبيعات الآجلة القديمة: ${harvest.debtorSalesText}", style = MaterialTheme.typography.bodySmall)
                    if (legacyCosts > 0) SummaryLine("مصروفات محفوظة من الإصدار السابق", legacyCosts, true)
                    Text("تم إظهار النصوص القديمة كما حُفظت؛ لم تُحوّل تلقائيًا إلى مبيعات رقمية حتى لا تُحسب مبالغ غير مؤكدة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        SummaryLine("إجمالي تكاليف القطفة", pickerCosts + otherCosts + legacyCosts)
        SummaryLine("صافي المردود بعد خصم المصاريف", distributorTotal + cashTotal + debtTotal - pickerCosts - otherCosts - legacyCosts, strong = true)
        Button(onClick = onAddDay, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة يوم جديد") }
        Text("أيام القطفة", fontWeight = FontWeight.Bold)
        days.forEach { day ->
            val dailyLines = harvestLines.filter { it.dayId == day.id }
            Card(
                modifier = Modifier.fillMaxWidth().combinedClickable(
                    onClick = { onOpenDay(day) },
                    onLongClick = { onLongPressDay(day) }
                )
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("$plotName • ${harvest.name}", fontWeight = FontWeight.Bold)
                    Text("يوم القطفة • ${hDate(day.dateMillis)}")
                    Text("الموزع: ${money(dailyLines.filter { it.category == "distributor" }.sumOf { it.total })} • النقدي: ${money(dailyLines.filter { it.category == "cash" }.sumOf { it.total })}", style = MaterialTheme.typography.bodySmall)
                    Text("الآجل: ${money(dailyLines.filter { it.category == "debt" }.sumOf { it.total })} • أجور ومصاريف: ${money(safeProduct(day.pickerCount, day.pickerWage) + day.otherExpenses)}", style = MaterialTheme.typography.bodySmall)
                    Text("اضغط مرة لعرض التفاصيل، واضغط مطولًا للتعديل أو الحذف", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        if (days.isEmpty()) Text("لم تسجل أيام لهذه القطفة بعد.")
    }
}

@Composable
private fun SummaryLine(label: String, amount: Long, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal)
        Text(money(amount), fontWeight = if (strong) FontWeight.ExtraBold else FontWeight.SemiBold, color = if (strong) Green else MaterialTheme.colorScheme.onSurface)
    }
}

private data class HarvestRowState(val category: String, val party: String, val type: String, val quantity: String, val price: String, val lineId: Long = 0L, val accountTransactionId: Long = 0L)

@Composable
private fun DayEditor(
    dao: MiyarDao,
    harvest: PersonalHarvestEntity,
    plots: List<PlantationEntity>,
    editing: PersonalHarvestDayEntity?,
    distributorNames: List<String>,
    debtorNames: List<String>,
    historicalProductNames: List<String>,
    onSaved: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val allDays by dao.observeAllHarvestDays().collectAsStateWithLifecycle(emptyList())
    var date by remember(editing?.id) { mutableLongStateOf(editing?.dateMillis ?: System.currentTimeMillis()) }
    var workers by remember(editing?.id) { mutableStateOf(editing?.pickerCount?.toString() ?: allDays.firstOrNull()?.pickerCount?.takeIf { it > 0 }?.toString().orEmpty()) }
    var wage by remember(editing?.id) { mutableStateOf(editing?.pickerWage?.toString() ?: allDays.firstOrNull()?.pickerWage?.takeIf { it > 0 }?.toString().orEmpty()) }
    var other by remember(editing?.id) { mutableStateOf(editing?.otherExpenses?.toString() ?: "") }
    var notes by remember(editing?.id) { mutableStateOf(editing?.notes ?: "") }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var rows by remember(editing?.id) { mutableStateOf(listOf(HarvestRowState("distributor", "", "عود", "", ""))) }
    var editingLinesReady by remember(editing?.id) { mutableStateOf(editing == null) }
    LaunchedEffect(editing?.id) {
        if (editing != null) {
            editingLinesReady = false
            val loadedLines = dao.getHarvestDayLines(editing.id)
            rows = if (loadedLines.isEmpty()) listOf(HarvestRowState("distributor", "", "عود", "", "")) else loadedLines.map {
                HarvestRowState(it.category, it.partyName, it.productType, it.quantity.toString(), it.unitPrice.toString(), it.id, it.accountTransactionId)
            }
            editingLinesReady = true
        }
    }
    val productSuggestions = remember(historicalProductNames) { (listOf("عود", "قطل", "مدبوش") + historicalProductNames).distinct() }
    val pickerCost = safeProduct(workers.toLongOrNull() ?: 0, wage.toLongOrNull() ?: 0)
    val distributorTotal = rows.filter { it.category == "distributor" }.sumOf { safeProduct(it.quantity.toLongOrNull() ?: 0, it.price.toLongOrNull() ?: 0) }
    val cashTotal = rows.filter { it.category == "cash" }.sumOf { safeProduct(it.quantity.toLongOrNull() ?: 0, it.price.toLongOrNull() ?: 0) }
    val debtTotal = rows.filter { it.category == "debt" }.sumOf { safeProduct(it.quantity.toLongOrNull() ?: 0, it.price.toLongOrNull() ?: 0) }
    val gross = distributorTotal + cashTotal + debtTotal
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (editing == null) "إضافة يوم جديد" else "تعديل يوم القطفة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
        Text("اسم الموضع: ${plots.firstOrNull { it.id == harvest.plantationId }?.name ?: ""}")
        Text("اسم / رقم القطفة: ${harvest.name}", fontWeight = FontWeight.Bold)
        DateField("تاريخ يوم القطفة", date) { date = it }

        Text("الموزع للسوق", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        rows.mapIndexedNotNull { index, row -> if (row.category == "distributor") index to row else null }.forEach { (index, row) ->
            HarvestDayLineEditor(row, distributorNames, productSuggestions, onChange = { changed -> rows = rows.toMutableList().also { it[index] = changed } }, onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } })
        }
        OutlinedButton(onClick = { rows = rows + HarvestRowState("distributor", "", "عود", "", "") }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة بائع آخر") }
        SummaryLine("إجمالي الموزع", distributorTotal)

        HorizontalDivider()
        Text("المبيعات النقدية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        rows.mapIndexedNotNull { index, row -> if (row.category == "cash") index to row else null }.forEach { (index, row) ->
            HarvestDayLineEditor(row, emptyList(), productSuggestions, onChange = { changed -> rows = rows.toMutableList().also { it[index] = changed } }, onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } })
        }
        OutlinedButton(onClick = { rows = rows + HarvestRowState("cash", "", "عود", "", "") }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة صنف نقدي") }
        SummaryLine("إجمالي المبيعات النقدية", cashTotal)

        HorizontalDivider()
        Text("المبيعات بالأجل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        rows.mapIndexedNotNull { index, row -> if (row.category == "debt") index to row else null }.forEach { (index, row) ->
            HarvestDayLineEditor(row, debtorNames, productSuggestions, onChange = { changed -> rows = rows.toMutableList().also { it[index] = changed } }, onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } })
        }
        OutlinedButton(onClick = { rows = rows + HarvestRowState("debt", "", "عود", "", "") }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة عميل آخر") }
        SummaryLine("إجمالي المبيعات بالأجل", debtTotal)
        SummaryLine("إجمالي المبيعات في هذا اليوم", gross, strong = true)

        HorizontalDivider()
        Text("أجور ومصاريف", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        NumField("عدد القطافين", workers, { workers = it })
        NumField("أجر القطاف الواحد", wage, { wage = it })
        SummaryLine("إجمالي أجور القطافين", pickerCost)
        NumField("خرج آخر: أكياس وتوصيل ومصاريف أخرى", other, { other = it })
        SummaryLine("إجمالي مصاريف اليوم", pickerCost + (other.toLongOrNull() ?: 0))
        SummaryLine("صافي مردود اليوم بعد المصاريف", gross - pickerCost - (other.toLongOrNull() ?: 0), strong = true)
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات أخرى") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)

        Button(
            enabled = !saving && date > 0 && editingLinesReady,
            onClick = {
                val touchedRows = rows.filter { it.party.isNotBlank() || it.quantity.isNotBlank() || it.price.isNotBlank() }
                val validRows = touchedRows.filter {
                    it.quantity.toLongOrNull()?.let { q -> q > 0 } == true &&
                        it.price.toLongOrNull()?.let { p -> p > 0 } == true &&
                        it.type.isNotBlank() && (it.category == "cash" || it.party.isNotBlank())
                }
                if (validRows.size != touchedRows.size) {
                    error = "راجع الأصناف: يلزم إدخال اسم البائع أو العميل عند الحاجة، ونوع المنتج والعدد والسعر بصورة صحيحة."
                } else {
                    saving = true
                    error = ""
                    scope.launch {
                        try {
                            val oldLines = if (editing == null) emptyList() else dao.getHarvestDayLines(editing.id)
                            // Do not silently discard a payment history when a row is removed or its category changes.
                            oldLines.filter { old ->
                                val matching = validRows.firstOrNull { it.lineId == old.id }
                                val identityChanged = matching != null && old.category == matching.category &&
                                    old.partyName.trim() != matching.party.trim()
                                matching == null || matching.category != old.category || identityChanged
                            }.forEach { old ->
                                val partyType = when (old.category) { "distributor" -> "DISTRIBUTOR"; "debt" -> "DEBTOR"; else -> "" }
                                if (partyType.isNotBlank() && old.accountTransactionId > 0) {
                                    check(dao.getAccountCollectedTotal(partyType, old.accountTransactionId) == 0L) {
                                        "لا يمكن حذف السطر أو تغيير نوعه أو اسم صاحبه بعد تسجيل دفعة مالية مرتبطة به. عالج الحساب أولًا حتى لا تنتقل الدفعة إلى ملف شخص آخر."
                                    }
                                }
                            }
                            val dayId = if (editing == null) {
                                dao.insertPersonalHarvestDay(PersonalHarvestDayEntity(
                                    harvestId = harvest.id, dateMillis = date,
                                    pickerCount = workers.toLongOrNull() ?: 0,
                                    pickerWage = wage.toLongOrNull() ?: 0,
                                    otherExpenses = other.toLongOrNull() ?: 0,
                                    notes = notes.trim()
                                ))
                            } else {
                                dao.updatePersonalHarvestDay(editing.copy(
                                    dateMillis = date, pickerCount = workers.toLongOrNull() ?: 0,
                                    pickerWage = wage.toLongOrNull() ?: 0,
                                    otherExpenses = other.toLongOrNull() ?: 0,
                                    notes = notes.trim()
                                ))
                                editing.id
                            }
                            val retainedIds = validRows.mapNotNull { it.lineId.takeIf { id -> id > 0 } }.toSet()
                            oldLines.filter { it.id !in retainedIds }.forEach { oldLine ->
                                if (oldLine.accountTransactionId > 0) {
                                    when (oldLine.category) {
                                        "distributor" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DISTRIBUTOR", oldLine.accountTransactionId)
                                            dao.deleteDistributorTransaction(oldLine.accountTransactionId)
                                        }
                                        "debt" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DEBTOR", oldLine.accountTransactionId)
                                            dao.deleteDebtorTransaction(oldLine.accountTransactionId)
                                        }
                                    }
                                }
                                dao.deleteHarvestDayLine(oldLine.id)
                            }
                            validRows.forEach { row ->
                                val party = row.party.trim()
                                val quantity = row.quantity.toLong()
                                val unitPrice = row.price.toLong()
                                val total = safeProduct(quantity, unitPrice)
                                var line = if (row.lineId > 0) {
                                    val prior = oldLines.firstOrNull { it.id == row.lineId }
                                    (prior ?: PersonalHarvestDayLineEntity(dayId = dayId, category = row.category, productType = row.type, quantity = quantity, unitPrice = unitPrice, total = total)).copy(
                                        category = row.category, partyName = party, productType = row.type.trim(),
                                        quantity = quantity, unitPrice = unitPrice, total = total
                                    )
                                } else PersonalHarvestDayLineEntity(
                                    dayId = dayId, category = row.category, partyName = party,
                                    productType = row.type.trim(), quantity = quantity,
                                    unitPrice = unitPrice, total = total
                                )
                                val lineId = if (line.id > 0) {
                                    dao.updateHarvestDayLine(line)
                                    line.id
                                } else dao.insertPersonalHarvestDayLine(line)
                                val priorLine = if (row.lineId > 0) oldLines.firstOrNull { it.id == row.lineId } else null
                                var transactionId = row.accountTransactionId
                                // Changing a row from distributor to cash/debt (or the reverse) must
                                // remove its old ledger entry and linked payments before creating a new one.
                                if (priorLine != null && priorLine.category != row.category && transactionId > 0) {
                                    when (priorLine.category) {
                                        "distributor" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DISTRIBUTOR", transactionId)
                                            dao.deleteDistributorTransaction(transactionId)
                                        }
                                        "debt" -> {
                                            dao.deleteHarvestPartyPaymentsForTransaction("DEBTOR", transactionId)
                                            dao.deleteDebtorTransaction(transactionId)
                                        }
                                    }
                                    transactionId = 0L
                                }
                                if (row.category == "distributor") {
                                    val seller = dao.findDistributor(party) ?: MarketDistributorEntity(name = party).let { dao.insertDistributor(it); dao.findDistributor(party) }
                                    if (seller != null) {
                                        val existing = transactionId.takeIf { it > 0 }?.let { dao.getDistributorTransaction(it) }
                                        if (existing != null) {
                                            check(dao.getAccountCollectedTotal("DISTRIBUTOR", existing.id) <= total) { "قيمة العملية الجديدة أقل من المبلغ المحصل سابقًا من هذا البائع." }
                                            dao.updateDistributorTransaction(existing.copy(
                                                distributorId = seller.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId
                                            ))
                                            dao.moveHarvestPartyPayments(existing.id, "DISTRIBUTOR", seller.id)
                                        } else {
                                            transactionId = dao.insertDistributorTransaction(DistributorTransactionEntity(
                                                distributorId = seller.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId
                                            ))
                                        }
                                    }
                                } else if (row.category == "debt") {
                                    val debtor = dao.findDebtor(party) ?: HarvestDebtorEntity(name = party).let { dao.insertDebtor(it); dao.findDebtor(party) }
                                    if (debtor != null) {
                                        val existing = transactionId.takeIf { it > 0 }?.let { dao.getDebtorTransaction(it) }
                                        if (existing != null) {
                                            check(dao.getAccountCollectedTotal("DEBTOR", existing.id) <= total) { "قيمة العملية الجديدة أقل من المبلغ المسدد سابقًا من هذا العميل." }
                                            dao.updateDebtorTransaction(existing.copy(
                                                debtorId = debtor.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId
                                            ))
                                            dao.moveHarvestPartyPayments(existing.id, "DEBTOR", debtor.id)
                                        } else {
                                            transactionId = dao.insertDebtorTransaction(HarvestDebtorTransactionEntity(
                                                debtorId = debtor.id, harvestId = harvest.id, productType = row.type.trim(),
                                                quantity = quantity, unitPrice = unitPrice, total = total,
                                                dateMillis = date, notes = "عملية قطفة ${harvest.name}", sourceDayId = dayId, sourceLineId = lineId
                                            ))
                                        }
                                    }
                                }
                                dao.updateHarvestDayLine(line.copy(id = lineId, accountTransactionId = transactionId))
                            }
                            saving = false
                            onSaved()
                        } catch (t: Throwable) {
                            saving = false
                            error = t.message ?: "تعذر حفظ يوم القطفة."
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (saving) "جارٍ الحفظ..." else "حفظ اليوم") }
    }
}

@Composable
private fun HarvestDayLineEditor(
    row: HarvestRowState,
    partySuggestions: List<String>,
    productSuggestions: List<String>,
    onChange: (HarvestRowState) -> Unit,
    onRemove: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(when (row.category) { "distributor" -> "بيانات البائع"; "cash" -> "صنف نقدي"; else -> "بيانات العميل" }, fontWeight = FontWeight.Bold)
            if (row.category != "cash") {
                SuggestedTextField(if (row.category == "debt") "اسم العميل" else "اسم البائع", row.party, { onChange(row.copy(party = it)) }, partySuggestions)
            }
            SuggestedTextField("نوع المنتج", row.type, { onChange(row.copy(type = it)) }, productSuggestions)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("عدد المنتج", row.quantity, { onChange(row.copy(quantity = it)) }, Modifier.weight(1f))
                NumField("سعر الوحدة", row.price, { onChange(row.copy(price = it)) }, Modifier.weight(1f))
            }
            SummaryLine("إجمالي الصنف", safeProduct(row.quantity.toLongOrNull() ?: 0, row.price.toLongOrNull() ?: 0))
            TextButton(onClick = onRemove, modifier = Modifier.align(Alignment.End)) { Text("إزالة الصنف") }
        }
    }
}

@Composable
private fun DayDetails(dao: MiyarDao, harvest: PersonalHarvestEntity, day: PersonalHarvestDayEntity, plots: List<PlantationEntity>) {
    val lines by dao.observeHarvestDayLines(day.id).collectAsStateWithLifecycle(emptyList())
    val plotName = plots.firstOrNull { it.id == harvest.plantationId }?.name ?: ""
    val distributor = lines.filter { it.category == "distributor" }
    val cash = lines.filter { it.category == "cash" }
    val debt = lines.filter { it.category == "debt" }
    val wages = safeProduct(day.pickerCount, day.pickerWage)
    val other = day.otherExpenses
    val gross = lines.sumOf { it.total }
    val costs = wages + other
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("تفاصيل يوم القطفة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Emerald)
        Text("اسم الموضع: $plotName")
        Text("اسم / رقم القطفة: ${harvest.name}", fontWeight = FontWeight.Bold)
        Text("التاريخ: ${hDate(day.dateMillis)}")
        DayLinesSection("الموزع للسوق", distributor)
        SummaryLine("إجمالي الموزع والقيمة", distributor.sumOf { it.total }, true)
        DayLinesSection("المبيعات النقدية", cash)
        SummaryLine("إجمالي المباع نقدًا والقيمة", cash.sumOf { it.total }, true)
        DayLinesSection("المبيعات بالأجل", debt)
        SummaryLine("إجمالي الآجل والقيمة", debt.sumOf { it.total }, true)
        HorizontalDivider()
        Text("أجور ومصاريف", fontWeight = FontWeight.Bold)
        SummaryLine("عدد القطافين", day.pickerCount)
        SummaryLine("أجر القطاف الواحد", day.pickerWage)
        SummaryLine("إجمالي أجور القطافين", wages)
        SummaryLine("الخرج الآخر", other)
        SummaryLine("إجمالي المبيعات", gross, true)
        SummaryLine("إجمالي الخرج (أجور + خرج آخر)", costs, true)
        SummaryLine("صافي المردود بعد خصم الخرج", gross - costs, true)
        Text("الملاحظات: ${day.notes.ifBlank { "لا توجد ملاحظات" }}")
    }
}

@Composable
private fun DayLinesSection(title: String, lines: List<PersonalHarvestDayLineEntity>) {
    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    if (lines.isEmpty()) Text("لا توجد عمليات مسجلة.", style = MaterialTheme.typography.bodySmall)
    lines.forEach { line ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (line.partyName.isNotBlank()) Text(line.partyName, fontWeight = FontWeight.Bold)
                Text("${line.productType} • العدد ${line.quantity} × ${line.unitPrice} ريال")
                Text("الإجمالي: ${money(line.total)}", color = Green, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun BuyerSaleForm(
    dao: MiyarDao,
    plantations: List<PlantationEntity>,
    buyers: List<QatBuyerEntity>,
    buyerSuggestions: List<String>,
    initialBuyer: QatBuyerEntity?,
    onSaved: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var buyerName by remember { mutableStateOf(initialBuyer?.name ?: "") }
    var harvestName by remember { mutableStateOf("") }
    var plotId by remember { mutableLongStateOf(0L) }
    var agreed by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var saleDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var expected by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var actual by remember { mutableLongStateOf(0L) }
    var showActual by remember { mutableStateOf(false) }
    var discount by remember { mutableStateOf("0") }
    var discountReason by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var plotMenu by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val selectedPlot = plantations.firstOrNull { it.id == plotId }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("البيع لمشتري", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Box {
            OutlinedButton(onClick = { plotMenu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedPlot?.name ?: "اختر الموضع الزراعي")
            }
            DropdownMenu(expanded = plotMenu, onDismissRequest = { plotMenu = false }) {
                plantations.forEach { plot -> DropdownMenuItem(text = { Text(plot.name) }, onClick = { plotId = plot.id; plotMenu = false }) }
            }
        }
        SuggestedTextField("اسم المشتري", buyerName, { buyerName = it }, (buyerSuggestions + buyers.map { it.name }).distinct())
        OutlinedTextField(harvestName, { harvestName = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth())
        NumField("السعر المتفق عليه", agreed, { agreed = it })
        NumField("الواصل عند البيع", paid, { paid = it })
        DateField("تاريخ البيع", saleDate) { saleDate = it }
        DateField("التاريخ المتوقع للانتهاء", expected) { expected = it }
        TextButton(onClick = { showActual = !showActual; if (!showActual) actual = 0L }) { Text(if (showActual) "إخفاء تاريخ الانتهاء الفعلي" else "إدخال تاريخ الانتهاء الفعلي") }
        if (showActual) DateField("التاريخ الفعلي لانتهاء القطفة", actual.takeIf { it > 0 } ?: System.currentTimeMillis()) { actual = it }
        HorizontalDivider()
        Text("الخصم من السعر المتفق عليه", fontWeight = FontWeight.Bold)
        NumField("قيمة الخصم إن وجد", discount, { discount = it })
        OutlinedTextField(discountReason, { discountReason = it }, label = { Text("سبب الخصم") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        SummaryLine("صافي المبلغ بعد الخصم", ((agreed.toLongOrNull() ?: 0) - (discount.toLongOrNull() ?: 0)).coerceAtLeast(0), true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(
            enabled = !saving,
            onClick = {
                val agreement = agreed.toLongOrNull() ?: 0
                val firstPaid = paid.toLongOrNull() ?: 0
                val discountValue = discount.toLongOrNull() ?: 0
                when {
                    selectedPlot == null -> error = "اختر الموضع الزراعي أولًا."
                    buyerName.isBlank() || harvestName.isBlank() -> error = "أدخل اسم المشتري واسم القطفة."
                    agreement <= 0 || discountValue > agreement || firstPaid > agreement - discountValue -> error = "راجع السعر والخصم والواصل؛ القيم غير متوافقة."
                    expected < saleDate -> error = "تاريخ الانتهاء المتوقع لا يمكن أن يسبق تاريخ البيع."
                    showActual && actual < saleDate -> error = "تاريخ الانتهاء الفعلي لا يمكن أن يسبق تاريخ البيع."
                    discountValue > 0 && discountReason.isBlank() -> error = "اكتب سبب الخصم حتى يظهر التقييم بصورة صحيحة."
                    else -> {
                        error = ""
                        saving = true
                        scope.launch {
                            try {
                                val buyer = dao.findBuyer(buyerName.trim()) ?: QatBuyerEntity(name = buyerName.trim()).let { dao.insertBuyer(it); dao.findBuyer(buyerName.trim()) }
                                if (buyer == null) error = "تعذر إنشاء ملف المشتري."
                                else dao.insertBuyerSale(BuyerSaleEntity(
                                    buyerId = buyer.id, plantationId = selectedPlot.id,
                                    harvestName = harvestName.trim(), agreedAmount = agreement,
                                    initialPaid = firstPaid, saleDateMillis = saleDate,
                                    expectedEndMillis = expected, actualEndMillis = if (showActual) actual else 0L,
                                    discountAmount = discountValue, discountReason = discountReason.trim(), notes = notes.trim()
                                ))
                                if (error.isBlank()) onSaved()
                            } catch (t: Throwable) {
                                error = t.message ?: "تعذر حفظ عملية البيع."
                            } finally { saving = false }
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (saving) "جارٍ الحفظ..." else "حفظ عملية البيع") }
    }
}

@Composable
private fun BuyerFileScreen(
    dao: MiyarDao,
    buyer: QatBuyerEntity,
    plantations: List<PlantationEntity>,
    onNewSale: () -> Unit,
    onOpenSale: (BuyerSaleEntity) -> Unit
) {
    val sales by dao.observeBuyerSales(buyer.id).collectAsStateWithLifecycle(emptyList())
    val allPayments by dao.observeAllBuyerPayments().collectAsStateWithLifecycle(emptyList())
    val saleIds = remember(sales) { sales.map { it.id }.toSet() }
    val total = sales.sumOf { (it.agreedAmount - it.discountAmount).coerceAtLeast(0) }
    val collected = sales.sumOf { it.initialPaid } + allPayments.filter { it.saleId in saleIds }.sumOf { it.amount }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف المشتري: ${buyer.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryLine("إجمالي المستحق بعد الخصومات", total, true)
        SummaryLine("إجمالي الواصل", collected)
        SummaryLine("إجمالي المتبقي", (total - collected).coerceAtLeast(0), true)
        Button(onClick = onNewSale, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة قطفة جديدة لهذا المشتري") }
        Text("سجل القطفات", fontWeight = FontWeight.Bold)
        sales.forEach { sale ->
            val plot = plantations.firstOrNull { it.id == sale.plantationId }?.name ?: "موضع غير محدد"
            Card(onClick = { onOpenSale(sale) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(sale.harvestName, fontWeight = FontWeight.Bold)
                    Text(plot)
                    Text("الاتفاق: ${money(sale.agreedAmount)} • الخصم: ${money(sale.discountAmount)}")
                    Text("من ${hDate(sale.saleDateMillis)} إلى ${if (sale.actualEndMillis > 0) hDate(sale.actualEndMillis) else "لم تنتهِ بعد"}")
                    Text("اضغط لعرض كشف الحساب والدفعات", style = MaterialTheme.typography.bodySmall, color = Green)
                }
            }
        }
    }
}

// Collect a Flow's first value without blocking the UI thread; this helper is used only inside a launched coroutine.

@Composable
private fun BuyerSaleDetailScreen(dao: MiyarDao, sale: BuyerSaleEntity, buyer: QatBuyerEntity, plantations: List<PlantationEntity>) {
    val allSales by dao.observeAllBuyerSales().collectAsStateWithLifecycle(emptyList())
    val details = allSales.firstOrNull { it.id == sale.id } ?: sale
    val payments by dao.observeBuyerPayments(details.id).collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    var paymentDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showEdit by remember { mutableStateOf(false) }
    val paid = details.initialPaid + payments.sumOf { it.amount }
    val netAgreed = (details.agreedAmount - details.discountAmount).coerceAtLeast(0)
    val remaining = (netAgreed - paid).coerceAtLeast(0)
    val expectedDuration = TimeUnit.MILLISECONDS.toDays((details.expectedEndMillis - details.saleDateMillis).coerceAtLeast(0)).toInt()
    val actualDuration = if (details.actualEndMillis > 0) TimeUnit.MILLISECONDS.toDays((details.actualEndMillis - details.saleDateMillis).coerceAtLeast(0)).toInt() else null
    val expectedDeadline = details.expectedEndMillis + TimeUnit.DAYS.toMillis(1) - 1L
    val actualLate = (details.actualEndMillis > 0 && details.actualEndMillis > expectedDeadline) ||
        (details.actualEndMillis == 0L && System.currentTimeMillis() > expectedDeadline)
    val status = when {
        details.discountAmount > 0 || actualLate -> "أحمر — يوجد خصم أو تأخير عن الموعد المتوقع"
        details.actualEndMillis == 0L || remaining > 0 -> "أصفر — القطفة جارية أو توجد مستحقات"
        else -> "أخضر — اكتمل السداد دون خصم أو تأخير"
    }
    val statusColor = when {
        details.discountAmount > 0 || actualLate -> androidx.compose.ui.graphics.Color(0xFFB3261E)
        details.actualEndMillis == 0L || remaining > 0 -> androidx.compose.ui.graphics.Color(0xFFB7791F)
        else -> androidx.compose.ui.graphics.Color(0xFF237A49)
    }
    val plot = plantations.firstOrNull { it.id == details.plantationId }?.name ?: "موضع غير محدد"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف ${buyer.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("الموضع: $plot")
        Text("القطفة: ${details.harvestName}", fontWeight = FontWeight.Bold)
        TextButton(onClick = { showEdit = true }, modifier = Modifier.align(Alignment.End)) { Text("تعديل بيانات البيع") }
        SummaryLine("السعر المتفق عليه", details.agreedAmount)
        SummaryLine("الخصم", details.discountAmount)
        if (details.discountAmount > 0) Text("سبب الخصم: ${details.discountReason}")
        SummaryLine("صافي الاتفاق بعد الخصم", netAgreed, true)
        SummaryLine("الواصل", paid)
        if (details.initialPaid > 0) Text("الدفعة الأولى: ${money(details.initialPaid)} بتاريخ ${hDate(details.saleDateMillis)}")
        SummaryLine("المتبقي", remaining, true)
        Text("تاريخ البيع: ${hDate(details.saleDateMillis)}")
        Text("الانتهاء المتوقع: ${hDate(details.expectedEndMillis)}")
        Text("مدة القطف المتوقعة: $expectedDuration يومًا")
        Text("الانتهاء الفعلي: ${if (details.actualEndMillis > 0) hDate(details.actualEndMillis) else "لم يُسجل بعد"}")
        if (actualDuration != null) Text("مدة القطف الفعلية: $actualDuration يومًا")
        Text("التقييم: $status", color = statusColor, fontWeight = FontWeight.Bold)
        if (details.notes.isNotBlank()) Text("ملاحظات: ${details.notes}")
        HorizontalDivider()
        Text("إضافة دفعة جديدة", fontWeight = FontWeight.Bold)
        NumField("مبلغ الدفعة", amount, { amount = it })
        DateField("تاريخ الدفع", paymentDate) { paymentDate = it }
        OutlinedTextField(method, { method = it }, label = { Text("طريقة الدفع") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(notes, { notes = it }, label = { Text("تفاصيل الدفع / ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Button(
            onClick = {
                val value = amount.toLongOrNull() ?: 0L
                if (value > 0 && value <= remaining) scope.launch {
                    dao.insertBuyerPayment(BuyerPaymentEntity(saleId = details.id, amount = value, dateMillis = paymentDate, method = method.trim().ifBlank { "نقدًا" }, notes = notes.trim()))
                    amount = ""
                    notes = ""
                }
            },
            enabled = (amount.toLongOrNull() ?: 0) in 1..remaining,
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ الدفعة") }
        Text("سجل الواصلات", fontWeight = FontWeight.Bold)
        if (details.initialPaid > 0) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("${money(details.initialPaid)} • ${hDate(details.saleDateMillis)}", fontWeight = FontWeight.Bold)
                    Text("طريقة الدفع: واصل عند البيع")
                    Text("دفعة أولى عند تسجيل الاتفاق", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        SummaryLine("الواصلات الإضافية", payments.sumOf { it.amount })
        if (payments.isEmpty()) Text("لا توجد دفعات إضافية مسجلة.")
        payments.forEach { payment ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("${money(payment.amount)} • ${hDate(payment.dateMillis)}", fontWeight = FontWeight.Bold)
                    Text("طريقة الدفع: ${payment.method}")
                    if (payment.notes.isNotBlank()) Text("التفاصيل: ${payment.notes}")
                }
            }
        }
    }
    if (showEdit) EditBuyerSaleDialog(dao, details, plantations, paid) { showEdit = false }
}

@Composable
private fun EditBuyerSaleDialog(dao: MiyarDao, sale: BuyerSaleEntity, plantations: List<PlantationEntity>, paid: Long, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var plotId by remember(sale.id) { mutableLongStateOf(sale.plantationId) }
    var harvestName by remember(sale.id) { mutableStateOf(sale.harvestName) }
    var agreed by remember(sale.id) { mutableStateOf(sale.agreedAmount.toString()) }
    var expected by remember(sale.id) { mutableLongStateOf(sale.expectedEndMillis) }
    var actual by remember(sale.id) { mutableLongStateOf(sale.actualEndMillis) }
    var showActual by remember(sale.id) { mutableStateOf(sale.actualEndMillis > 0) }
    var discount by remember(sale.id) { mutableStateOf(sale.discountAmount.toString()) }
    var reason by remember(sale.id) { mutableStateOf(sale.discountReason) }
    var notes by remember(sale.id) { mutableStateOf(sale.notes) }
    var plotMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات البيع") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box {
                    OutlinedButton(onClick = { plotMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(plantations.firstOrNull { it.id == plotId }?.name ?: "اختر الموضع الزراعي")
                    }
                    DropdownMenu(expanded = plotMenu, onDismissRequest = { plotMenu = false }) {
                        plantations.forEach { plot -> DropdownMenuItem(text = { Text(plot.name) }, onClick = { plotId = plot.id; plotMenu = false }) }
                    }
                }
                OutlinedTextField(harvestName, { harvestName = it }, label = { Text("اسم / رقم القطفة") }, modifier = Modifier.fillMaxWidth())
                NumField("السعر المتفق عليه", agreed, { agreed = it })
                DateField("الانتهاء المتوقع", expected) { expected = it }
                TextButton(onClick = { showActual = !showActual; if (!showActual) actual = 0L }) { Text(if (showActual) "إخفاء الانتهاء الفعلي" else "إدخال الانتهاء الفعلي") }
                if (showActual) DateField("الانتهاء الفعلي", actual.takeIf { it > 0 } ?: System.currentTimeMillis()) { actual = it }
                NumField("قيمة الخصم", discount, { discount = it })
                OutlinedTextField(reason, { reason = it }, label = { Text("سبب الخصم") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("الملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = agreed.toLongOrNull() ?: 0
                val d = discount.toLongOrNull() ?: 0
                when {
                    plotId <= 0 || plantations.none { it.id == plotId } -> error = "اختر الموضع الزراعي."
                    harvestName.isBlank() || a <= 0 || d > a -> error = "راجع اسم القطفة والسعر والخصم."
                    expected < sale.saleDateMillis -> error = "تاريخ الانتهاء المتوقع لا يمكن أن يسبق تاريخ البيع."
                    showActual && actual < sale.saleDateMillis -> error = "تاريخ الانتهاء الفعلي لا يمكن أن يسبق تاريخ البيع."
                    d > 0 && reason.isBlank() -> error = "أدخل سبب الخصم."
                    paid > a - d -> error = "لا يمكن تخفيض السعر إلى أقل من المبلغ الواصل."
                    else -> scope.launch {
                        dao.updateBuyerSale(sale.copy(
                            plantationId = plotId, harvestName = harvestName.trim(), agreedAmount = a,
                            expectedEndMillis = expected, actualEndMillis = if (showActual) actual else 0L,
                            discountAmount = d, discountReason = reason.trim(), notes = notes.trim()
                        ))
                        onDismiss()
                    }
                }
            }) { Text("حفظ التعديل") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}


@Composable
private fun DistributorFileScreen(dao: MiyarDao, seller: MarketDistributorEntity, harvests: List<PersonalHarvestEntity>, plantations: List<PlantationEntity>) {
    val transactions by dao.observeDistributorTransactions(seller.id).collectAsStateWithLifecycle(emptyList())
    val payments by dao.observeHarvestPartyPayments("DISTRIBUTOR", seller.id).collectAsStateWithLifecycle(emptyList())
    var showNewTransaction by remember { mutableStateOf(false) }
    var paymentTransaction by remember { mutableStateOf<DistributorTransactionEntity?>(null) }
    val total = transactions.sumOf { it.total }
    val received = payments.sumOf { it.amount } + transactions.sumOf { it.received }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف البائع: ${seller.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryLine("إجمالي العمليات", total, true)
        SummaryLine("إجمالي ما وصلنا من البائع", received)
        SummaryLine("المتبقي لنا عند البائع", (total - received).coerceAtLeast(0), true)
        Button(onClick = { showNewTransaction = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة عملية جديدة") }
        Text("تفاصيل العمليات", fontWeight = FontWeight.Bold)
        transactions.forEach { transaction ->
            val paidFor = transaction.received + payments.filter { it.transactionId == transaction.id }.sumOf { it.amount }
            val linkedHarvest = harvests.firstOrNull { it.id == transaction.harvestId }
            val linkedPlot = plantations.firstOrNull { it.id == linkedHarvest?.plantationId }?.name
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(transaction.productType, fontWeight = FontWeight.Bold)
                    Text("${hDate(transaction.dateMillis)} • العدد ${transaction.quantity} × ${transaction.unitPrice}")
                    Text("القطفة: ${linkedHarvest?.name ?: "عملية مستقلة"} • الموضع: ${linkedPlot ?: "غير محدد"}", style = MaterialTheme.typography.bodySmall)
                    SummaryLine("قيمة العملية", transaction.total)
                    SummaryLine("الواصل", paidFor)
                    SummaryLine("الباقي", (transaction.total - paidFor).coerceAtLeast(0), true)
                    TextButton(onClick = { paymentTransaction = transaction }) { Text("＋ تسجيل دفعة لهذه العملية") }
                    if (transaction.notes.isNotBlank()) Text(transaction.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("سجل الدفعات", fontWeight = FontWeight.Bold)
        payments.forEach { payment -> Text("${hDate(payment.dateMillis)} • ${money(payment.amount)} • ${payment.method}${if (payment.notes.isNotBlank()) " • ${payment.notes}" else ""}") }
    }
    if (showNewTransaction) NewPartyTransactionDialog("DISTRIBUTOR", seller.id, dao, harvests, { showNewTransaction = false })
    paymentTransaction?.let { transaction ->
        val alreadyPaid = transaction.received + payments.filter { it.transactionId == transaction.id }.sumOf { it.amount }
        PartyPaymentDialog("DISTRIBUTOR", seller.id, transaction.id, (transaction.total - alreadyPaid).coerceAtLeast(0), dao, { paymentTransaction = null })
    }
}

@Composable
private fun DebtorFileScreen(dao: MiyarDao, debtor: HarvestDebtorEntity, harvests: List<PersonalHarvestEntity>, plantations: List<PlantationEntity>) {
    val transactions by dao.observeDebtorTransactions(debtor.id).collectAsStateWithLifecycle(emptyList())
    val payments by dao.observeHarvestPartyPayments("DEBTOR", debtor.id).collectAsStateWithLifecycle(emptyList())
    var showNewTransaction by remember { mutableStateOf(false) }
    var paymentTransaction by remember { mutableStateOf<HarvestDebtorTransactionEntity?>(null) }
    val total = transactions.sumOf { it.total }
    val paid = payments.sumOf { it.amount } + transactions.sumOf { it.paid }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ملف العميل: ${debtor.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryLine("إجمالي ما عليه", total, true)
        SummaryLine("إجمالي ما دفعه العميل", paid)
        SummaryLine("المتبقي عليه لنا", (total - paid).coerceAtLeast(0), true)
        Button(onClick = { showNewTransaction = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ إضافة عملية جديدة") }
        Text("تفاصيل العمليات", fontWeight = FontWeight.Bold)
        transactions.forEach { transaction ->
            val paidFor = transaction.paid + payments.filter { it.transactionId == transaction.id }.sumOf { it.amount }
            val linkedHarvest = harvests.firstOrNull { it.id == transaction.harvestId }
            val linkedPlot = plantations.firstOrNull { it.id == linkedHarvest?.plantationId }?.name
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(transaction.productType, fontWeight = FontWeight.Bold)
                    Text("${hDate(transaction.dateMillis)} • العدد ${transaction.quantity} × ${transaction.unitPrice}")
                    Text("القطفة: ${linkedHarvest?.name ?: "عملية مستقلة"} • الموضع: ${linkedPlot ?: "غير محدد"}", style = MaterialTheme.typography.bodySmall)
                    SummaryLine("قيمة العملية", transaction.total)
                    SummaryLine("الواصل", paidFor)
                    SummaryLine("المتبقي", (transaction.total - paidFor).coerceAtLeast(0), true)
                    TextButton(onClick = { paymentTransaction = transaction }) { Text("＋ تسجيل دفعة لهذه العملية") }
                    if (transaction.notes.isNotBlank()) Text(transaction.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("سجل الدفعات", fontWeight = FontWeight.Bold)
        payments.forEach { payment -> Text("${hDate(payment.dateMillis)} • ${money(payment.amount)} • ${payment.method}${if (payment.notes.isNotBlank()) " • ${payment.notes}" else ""}") }
    }
    if (showNewTransaction) NewPartyTransactionDialog("DEBTOR", debtor.id, dao, harvests, { showNewTransaction = false })
    paymentTransaction?.let { transaction ->
        val alreadyPaid = transaction.paid + payments.filter { it.transactionId == transaction.id }.sumOf { it.amount }
        PartyPaymentDialog("DEBTOR", debtor.id, transaction.id, (transaction.total - alreadyPaid).coerceAtLeast(0), dao, { paymentTransaction = null })
    }
}

@Composable
private fun NewPartyTransactionDialog(partyType: String, partyId: Long, dao: MiyarDao, harvests: List<PersonalHarvestEntity>, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val productSuggestions by dao.observeHarvestProductSuggestions().collectAsStateWithLifecycle(emptyList())
    var product by remember { mutableStateOf("عود") }
    var quantity by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var notes by remember { mutableStateOf("") }
    var harvestId by remember { mutableLongStateOf(0L) }
    var harvestMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val total = safeProduct(quantity.toLongOrNull() ?: 0, price.toLongOrNull() ?: 0)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة عملية جديدة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SuggestedTextField("نوع المنتج", product, { product = it }, (listOf("عود", "قطل", "مدبوش") + productSuggestions).distinct())
                Box {
                    OutlinedButton(onClick = { harvestMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(harvests.firstOrNull { it.id == harvestId }?.name ?: "ربط العملية بقطفة (اختياري)")
                    }
                    DropdownMenu(expanded = harvestMenu, onDismissRequest = { harvestMenu = false }) {
                        DropdownMenuItem(text = { Text("عملية مستقلة") }, onClick = { harvestId = 0L; harvestMenu = false })
                        harvests.forEach { harvest -> DropdownMenuItem(text = { Text(harvest.name) }, onClick = { harvestId = harvest.id; harvestMenu = false }) }
                    }
                }
                NumField("العدد", quantity, { quantity = it })
                NumField("سعر الوحدة", price, { price = it })
                SummaryLine("إجمالي العملية", total, true)
                DateField("تاريخ العملية", date) { date = it }
                OutlinedTextField(notes, { notes = it }, label = { Text("التفاصيل والملاحظات") }, modifier = Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val q = quantity.toLongOrNull() ?: 0
                val p = price.toLongOrNull() ?: 0
                if (product.isBlank() || q <= 0 || p <= 0) error = "أدخل نوع المنتج والعدد والسعر بصورة صحيحة."
                else scope.launch {
                    if (partyType == "DISTRIBUTOR") dao.insertDistributorTransaction(DistributorTransactionEntity(distributorId = partyId, harvestId = harvestId, productType = product.trim(), quantity = q, unitPrice = p, total = safeProduct(q, p), dateMillis = date, notes = notes.trim()))
                    else dao.insertDebtorTransaction(HarvestDebtorTransactionEntity(debtorId = partyId, harvestId = harvestId, productType = product.trim(), quantity = q, unitPrice = p, total = safeProduct(q, p), dateMillis = date, notes = notes.trim()))
                    onDismiss()
                }
            }) { Text("حفظ العملية") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun PartyPaymentDialog(partyType: String, partyId: Long, transactionId: Long, remaining: Long, dao: MiyarDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (partyType == "DISTRIBUTOR") "تسجيل مبلغ وصل من البائع" else "تسجيل دفعة من العميل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("مبلغ الدفعة", amount, { amount = it })
                DateField("تاريخ الدفع", date) { date = it }
                OutlinedTextField(method, { method = it }, label = { Text("طريقة الدفع") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("تفاصيل الدفع") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val value = amount.toLongOrNull() ?: 0
                if (value > 0 && value <= remaining) scope.launch {
                    dao.insertHarvestPartyPayment(HarvestPartyPaymentEntity(partyType = partyType, partyId = partyId, transactionId = transactionId, amount = value, dateMillis = date, method = method.trim().ifBlank { "نقدًا" }, notes = notes.trim()))
                    onDismiss()
                }
            }, enabled = (amount.toLongOrNull() ?: 0L) in 1..remaining) { Text("حفظ الدفعة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
