package com.miyar.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.launch

object ReminderScheduler {
    private const val CHANNEL_ID = "miyar_agriculture_reminders"

    fun schedule(context: Context, id: Long, title: String, category: String, plantation: String, date: String, reminderTime: String = "09:00", referenceType: String = "EXPENSE") {
        val parsed = runCatching { SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(date) }.getOrNull() ?: return
        val parts = reminderTime.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 9
        val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 0
        val calendar = Calendar.getInstance().apply {
            time = parsed
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            calendar.timeInMillis = System.currentTimeMillis() + 5_000L
        }
        val requestCode = (31 * referenceType.hashCode() + id.hashCode()).and(0x7fffffff)
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("id", id.toInt())
            putExtra("notificationId", requestCode)
            putExtra("referenceType", referenceType)
            putExtra("title", title)
            putExtra("category", category)
            putExtra("plantation", plantation)
            putExtra("date", date)
            putExtra("time", String.format(Locale.US, "%02d:%02d", hour, minute))
        }
        val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
    }

    fun cancel(context: Context, id: Long, referenceType: String = "EXPENSE") {
        val requestCode = (31 * referenceType.hashCode() + id.hashCode()).and(0x7fffffff)
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
        pending.cancel()
    }

    internal fun show(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "تنبيهات مِعيار الزراعية", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val title = intent.getStringExtra("title") ?: "عملية زراعية"
        val category = intent.getStringExtra("category") ?: "عملية"
        val plantation = intent.getStringExtra("plantation") ?: "موضع زراعي"
        val date = intent.getStringExtra("date") ?: ""
        val time = intent.getStringExtra("time") ?: "09:00"
        val openApp = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير من مِعيار: $category")
            .setContentText("تذكير بموعد العملية: $title — $plantation — $time")
            .setStyle(NotificationCompat.BigTextStyle().bigText("حان موعد العملية المجدولة ($category) «$title» في الموضع «$plantation». التاريخ: $date، الساعة: $time."))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        manager.notify(intent.getIntExtra("notificationId", intent.getIntExtra("id", System.currentTimeMillis().toInt())), notification)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.show(context, intent)
    }
}


class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val reminders = com.miyar.app.data.MiyarDatabase.get(context).dao().getEnabledOperationReminders()
                reminders.filter { it.scheduledAtMillis > System.currentTimeMillis() }.forEach { item ->
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(java.util.Date(item.scheduledAtMillis))
                    val time = SimpleDateFormat("HH:mm", Locale.US).format(java.util.Date(item.scheduledAtMillis))
                    ReminderScheduler.schedule(context, item.referenceId, item.title, item.category, item.plantationName, date, time, item.referenceType)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
