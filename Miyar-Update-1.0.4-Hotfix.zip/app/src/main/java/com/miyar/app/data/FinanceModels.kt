package com.miyar.app.data

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "invoices", indices = [
    Index(value = ["dateMillis", "id"], name = "index_invoices_dateMillis"),
    Index(value = ["supplier", "paymentStatus", "dateMillis"], name = "index_invoices_supplier_paymentStatus_dateMillis")
])
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplier: String,
    val invoiceNumber: String,
    val dateMillis: Long,
    val paymentStatus: String,
    val currency: String,
    /** Exchange rate multiplied by 1000; 1.000 for YER. */
    val exchangeRateScaled: Long,
    val totalForeign: Long,
    val totalYer: Long,
    val notes: String = ""
)

@Entity(
    tableName = "stock_items",
    indices = [Index(value = ["productType", "productName", "baseUnit", "treatmentType"], unique = true)]
)
data class StockItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productType: String,
    val productName: String,
    val activeIngredient: String = "",
    /** Canonical unit is g for solids and ml for liquids. */
    val baseUnit: String,
    @ColumnInfo(defaultValue = "'عام'") val treatmentType: String = "عام",
    val quantityBase: Long = 0,
    val totalReceivedBase: Long = 0,
    val totalUsedBase: Long = 0,
    @ColumnInfo(defaultValue = "0") val totalOpeningCostYer: Long = 0,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "invoice_items",
    foreignKeys = [
        ForeignKey(entity = InvoiceEntity::class, parentColumns = ["id"], childColumns = ["invoiceId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["invoiceId"]), Index(value = ["stockItemId"])]
)
data class InvoiceItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val packageName: String,
    val packageSize: Long,
    val packageCount: Long,
    val unit: String,
    val quantityBase: Long,
    val unitPriceForeign: Long,
    val lineTotalForeign: Long,
    val lineTotalYer: Long,
    @ColumnInfo(defaultValue = "'عام'") val treatmentType: String = "عام"
)

@Entity(
    tableName = "stock_movements",
    foreignKeys = [ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["stockItemId"]), Index(value = ["referenceType", "referenceId"])]
)
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stockItemId: Long,
    val referenceType: String,
    val referenceId: Long,
    /** Positive for receipts; negative for usage. */
    val quantityBase: Long,
    val dateMillis: Long = System.currentTimeMillis(),
    val description: String = ""
)



/** Read-only stock ledger projection joining usage movements to their source operation. */
data class StockMovementDetail(
    val id: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val treatmentType: String,
    val baseUnit: String,
    val quantityBase: Long,
    val dateMillis: Long,
    val referenceType: String,
    val referenceId: Long,
    val description: String,
    val operationTitle: String?,
    val operationCategory: String?,
    val plantationName: String?
)

/** Product catalogue entry with a weighted-average purchase cost in YER. */
data class StockPriceSuggestion(
    val id: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val baseUnit: String,
    val quantityBase: Long,
    /** Average cost per gram/ml multiplied by 1000 to retain fractional rials. */
    val averageCostPerBaseScaled: Long,
    val treatmentType: String = "عام"
)


/** One material consumed inside a single fertilizer or pesticide operation. */
@Entity(
    tableName = "chemical_operation_lines",
    foreignKeys = [
        ForeignKey(entity = ExpenseEntity::class, parentColumns = ["id"], childColumns = ["expenseId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = StockItemEntity::class, parentColumns = ["id"], childColumns = ["stockItemId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["expenseId"]), Index(value = ["stockItemId"])]
)
data class ChemicalOperationLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseId: Long,
    val stockItemId: Long,
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val treatmentType: String,
    val unit: String,
    val enteredQuantity: Long,
    val quantityBase: Long,
    val costAmountYer: Long
)

data class ChemicalOperationLineInput(
    val productType: String,
    val productName: String,
    val activeIngredient: String,
    val treatmentType: String,
    val unit: String,
    val enteredQuantity: Long,
    val quantityBase: Long,
    val costAmountYer: Long
)

@Entity(
    tableName = "operation_reminders",
    indices = [Index(value = ["referenceType", "referenceId"], unique = true), Index(value = ["scheduledAtMillis"])]
)
data class OperationReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val referenceType: String,
    val referenceId: Long,
    val title: String,
    val category: String,
    val plantationName: String,
    val scheduledAtMillis: Long,
    val enabled: Boolean = true
)


data class InvoiceLedgerSummary(val creditCount: Long, val creditTotal: Long, val cashCount: Long, val cashTotal: Long)
