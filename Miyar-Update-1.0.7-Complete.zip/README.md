# مِعيار | Miyar — الإصدار 1.0.7

تطبيق Android عربي RTL لإدارة المواضع الزراعية والعمليات والقطفات والفواتير والمخزون.

- Application ID: `com.miyar.app`
- Version: `1.0.7` (`versionCode = 29`)
- Room database: `12`، مطابق للإصدار 1.0.6 ولا يتطلب migration جديدًا.
- Build: Gradle 8.9، Java 17، Android SDK 35.

## ما الجديد في 1.0.7

راجع `CHANGELOG_1.0.7_AR.txt` و`BUILD_NOTES_1.0.7_AR.txt` للتفاصيل. تشمل هذه النسخة إصلاح تصفية القطفات، فصل حقلي حالة الصنف ووحدته، اعتماد «سقي» في اقتراح المياه، وضبط عرض الكميات المزدوجة في المخزون مثل «11 لتر 750 ملي» و«5 كيلو 400 جرام»، مع سجل استخدام مستقل لكل صنف.

## البناء والتوقيع

يوجد GitHub Actions workflow في `.github/workflows/blank.yml`. يعتمد على أسرار التوقيع الدائمة نفسها:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

يشغّل workflow اختبارات الوحدة وبناء release APK، ثم يتحقق من معرّف الحزمة والإصدار وبصمة شهادة APK قبل رفع artifact.

**لا تحذف الإصدار السابق ولا تمسح بيانات التطبيق عند التحديث.** ثبّت APK فقط بعد نجاح GitHub Actions وتطابق شهادة التوقيع مع المفتاح الدائم.
