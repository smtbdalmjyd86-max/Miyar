package com.miyar.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MiyarDao {
    @Query("SELECT * FROM plantations ORDER BY name COLLATE NOCASE")
    fun observePlantations(): Flow<List<PlantationEntity>>

    @Insert
    suspend fun insertPlantation(item: PlantationEntity): Long

    @Query("SELECT COUNT(*) FROM expenses WHERE plantationId = :plantationId")
    suspend fun countExpensesForPlantation(plantationId: Long): Int

    @Query("DELETE FROM plantations WHERE id = :plantationId")
    suspend fun deletePlantationById(plantationId: Long): Int

    @Transaction
    suspend fun deletePlantationIfEmpty(plantationId: Long): Boolean {
        if (countExpensesForPlantation(plantationId) > 0) return false
        return deletePlantationById(plantationId) > 0
    }

    @Query("SELECT * FROM expenses WHERE plantationId = :plantationId ORDER BY dateMillis DESC, id DESC")
    fun observeExpenses(plantationId: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category != 'القطفات'")
    fun observeTotalExpenses(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE currency = :currency AND category = 'القطفات'")
    fun observeTotalRevenue(currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category != 'القطفات'")
    fun observePlantationExpenses(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE plantationId = :plantationId AND currency = :currency AND category = 'القطفات'")
    fun observePlantationRevenue(plantationId: Long, currency: String = "YER"): Flow<Long>

    @Query("SELECT e.id AS id, e.plantationId AS plantationId, p.name AS plantationName, e.category AS category, e.title AS title, e.amount AS amount, e.currency AS currency, e.dateMillis AS dateMillis, e.notes AS notes FROM expenses e INNER JOIN plantations p ON p.id = e.plantationId ORDER BY e.dateMillis DESC, e.id DESC")
    fun observeAllExpenses(): Flow<List<ExpenseWithPlantation>>

    @Query("SELECT category AS category, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total FROM expenses GROUP BY category")
    fun observeCategoryTotals(): Flow<List<CategoryTotal>>

    @Query("SELECT COUNT(*) FROM expenses WHERE category = 'القطفات'")
    fun observeHarvestCount(): Flow<Long>

    @Insert
    suspend fun insertExpense(item: ExpenseEntity): Long

    @Update
    suspend fun updateExpense(item: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(item: ExpenseEntity)

    // Invoice and inventory queries
    @Query("SELECT * FROM invoices ORDER BY dateMillis DESC, id DESC")
    fun observeInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId ORDER BY id")
    suspend fun getInvoiceItems(invoiceId: Long): List<InvoiceItemEntity>

    @Query("SELECT * FROM stock_items ORDER BY productType, productName COLLATE NOCASE")
    fun observeStockItems(): Flow<List<StockItemEntity>>

    @Query("""
        SELECT s.id AS id, s.productType AS productType, s.productName AS productName,
               s.activeIngredient AS activeIngredient, s.baseUnit AS baseUnit,
               s.quantityBase AS quantityBase,
               CASE WHEN COALESCE(SUM(ii.quantityBase), 0) > 0
                    THEN CAST((SUM(CAST(ii.lineTotalYer AS REAL)) * 1000.0) / SUM(ii.quantityBase) AS INTEGER)
                    ELSE 0 END AS averageCostPerBaseScaled
        FROM stock_items s
        LEFT JOIN invoice_items ii ON ii.stockItemId = s.id
        GROUP BY s.id
        ORDER BY s.productName COLLATE NOCASE
    """)
    fun observeStockPriceSuggestions(): Flow<List<StockPriceSuggestion>>

    @Query("SELECT * FROM stock_items WHERE id = :id LIMIT 1")
    suspend fun getStockItemById(id: Long): StockItemEntity?

    @Query("SELECT * FROM stock_items WHERE productType = :type AND productName COLLATE NOCASE = :name COLLATE NOCASE AND baseUnit = :baseUnit LIMIT 1")
    suspend fun findStockItem(type: String, name: String, baseUnit: String): StockItemEntity?

    @Insert
    suspend fun insertInvoice(invoice: InvoiceEntity): Long

    @Update
    suspend fun updateInvoice(invoice: InvoiceEntity)

    @Query("DELETE FROM invoices WHERE id = :id")
    suspend fun deleteInvoiceRow(id: Long)

    @Insert
    suspend fun insertInvoiceItem(item: InvoiceItemEntity): Long

    @Query("DELETE FROM invoice_items WHERE invoiceId = :invoiceId")
    suspend fun deleteInvoiceItems(invoiceId: Long)

    @Insert
    suspend fun insertStockItem(item: StockItemEntity): Long

    @Update
    suspend fun updateStockItem(item: StockItemEntity)

    @Insert
    suspend fun insertStockMovement(item: StockMovementEntity): Long

    @Query("SELECT * FROM stock_movements WHERE referenceType = :type AND referenceId = :id")
    suspend fun getMovements(type: String, id: Long): List<StockMovementEntity>

    @Query("DELETE FROM stock_movements WHERE referenceType = :type AND referenceId = :id")
    suspend fun deleteMovements(type: String, id: Long)

    @Transaction
    suspend fun saveInvoice(invoice: InvoiceEntity, lines: List<InvoiceItemEntity>): Long {
        require(invoice.supplier.isNotBlank() && invoice.invoiceNumber.isNotBlank()) { "أدخل اسم المورد ورقم الفاتورة." }
        require(invoice.exchangeRateScaled > 0 && invoice.totalForeign >= 0 && invoice.totalYer >= 0) { "قيمة الفاتورة أو سعر الصرف غير صالح." }
        require(lines.isNotEmpty()) { "أضف صنفًا واحدًا على الأقل إلى الفاتورة." }
        val linesForeign = lines.fold(0L) { total, line -> Math.addExact(total, line.lineTotalForeign) }
        val linesYer = lines.fold(0L) { total, line -> Math.addExact(total, line.lineTotalYer) }
        require(linesForeign == invoice.totalForeign && linesYer == invoice.totalYer) { "إجمالي الفاتورة لا يطابق مجموع أصنافها." }
        val invoiceId: Long
        if (invoice.id == 0L) {
            invoiceId = insertInvoice(invoice.copy(id = 0))
        } else {
            invoiceId = invoice.id
            val oldLines = getInvoiceItems(invoiceId)
            oldLines.forEach { old ->
                val stock = getStockItemById(old.stockItemId) ?: error("تعذر العثور على صنف المخزون المرتبط بالفاتورة.")
                check(stock.quantityBase >= old.quantityBase) {
                    "لا يمكن تعديل الفاتورة؛ استُخدمت بعض كمياتها بالفعل. أعد الكميات المستخدمة أولًا."
                }
                updateStockItem(stock.copy(
                    quantityBase = stock.quantityBase - old.quantityBase,
                    totalReceivedBase = (stock.totalReceivedBase - old.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("INVOICE", invoiceId)
            deleteInvoiceItems(invoiceId)
            updateInvoice(invoice)
        }
        lines.forEach { draft ->
            require(draft.productName.isNotBlank() && draft.productType.isNotBlank() && draft.packageSize > 0 && draft.quantityBase > 0 && draft.packageCount > 0 && draft.unitPriceForeign >= 0 && draft.lineTotalForeign >= 0 && draft.lineTotalYer >= 0) { "تحقق من اسم وكمية وسعر الصنف." }
            val baseUnit = if (draft.unit == "كجم" || draft.unit == "جرام") "g" else "ml"
            val existing = findStockItem(draft.productType, draft.productName.trim(), baseUnit)
            val stockId = if (existing == null) {
                insertStockItem(StockItemEntity(
                    productType = draft.productType,
                    productName = draft.productName.trim(),
                    activeIngredient = draft.activeIngredient.trim(),
                    baseUnit = baseUnit
                ))
            } else existing.id
            val stock = getStockItemById(stockId) ?: error("تعذر إنشاء صنف المخزون.")
            updateStockItem(stock.copy(
                activeIngredient = draft.activeIngredient.ifBlank { stock.activeIngredient },
                quantityBase = Math.addExact(stock.quantityBase, draft.quantityBase),
                totalReceivedBase = Math.addExact(stock.totalReceivedBase, draft.quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            insertInvoiceItem(draft.copy(id = 0, invoiceId = invoiceId, stockItemId = stockId))
            insertStockMovement(StockMovementEntity(
                stockItemId = stockId,
                referenceType = "INVOICE",
                referenceId = invoiceId,
                quantityBase = draft.quantityBase,
                dateMillis = invoice.dateMillis,
                description = "استلام من فاتورة ${invoice.invoiceNumber}"
            ))
        }
        return invoiceId
    }

    @Transaction
    suspend fun deleteInvoiceSafely(invoiceId: Long): Boolean {
        val lines = getInvoiceItems(invoiceId)
        val requiredByStock = lines.groupBy { it.stockItemId }.mapValues { (_, rows) ->
            rows.fold(0L) { total, row -> Math.addExact(total, row.quantityBase) }
        }
        for ((stockId, required) in requiredByStock) {
            val stock = getStockItemById(stockId) ?: return false
            if (stock.quantityBase < required) return false
        }
        lines.forEach { line ->
            val stock = getStockItemById(line.stockItemId) ?: return@forEach
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - line.quantityBase,
                totalReceivedBase = (stock.totalReceivedBase - line.quantityBase).coerceAtLeast(0),
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        deleteMovements("INVOICE", invoiceId)
        deleteInvoiceRow(invoiceId)
        return true
    }

    @Transaction
    suspend fun addOpeningStock(type: String, name: String, ingredient: String, unit: String, quantityBase: Long) {
        require(quantityBase > 0) { "أدخل كمية أكبر من صفر." }
        val baseUnit = if (unit == "كجم" || unit == "جرام") "g" else "ml"
        val item = findStockItem(type, name.trim(), baseUnit)
        val id = if (item == null) insertStockItem(StockItemEntity(
            productType = type, productName = name.trim(), activeIngredient = ingredient.trim(), baseUnit = baseUnit
        )) else item.id
        val stock = getStockItemById(id) ?: error("تعذر إنشاء صنف المخزون.")
        updateStockItem(stock.copy(
            activeIngredient = ingredient.ifBlank { stock.activeIngredient },
            quantityBase = Math.addExact(stock.quantityBase, quantityBase),
            totalReceivedBase = Math.addExact(stock.totalReceivedBase, quantityBase),
            updatedAtMillis = System.currentTimeMillis()
        ))
        insertStockMovement(StockMovementEntity(
            stockItemId = id, referenceType = "OPENING", referenceId = id,
            quantityBase = quantityBase, description = "إضافة رصيد يدوي"
        ))
    }

    @Transaction
    suspend fun saveExpenseWithStock(
        expense: ExpenseEntity,
        stockType: String? = null,
        stockBaseUnit: String? = null,
        quantityBase: Long = 0L
    ): Long {
        require(quantityBase >= 0L) { "كمية الاستخدام لا يمكن أن تكون سالبة." }
        if (expense.id != 0L) {
            getMovements("EXPENSE", expense.id).forEach { movement ->
                val stock = getStockItemById(movement.stockItemId) ?: error("صنف المخزون غير موجود.")
                updateStockItem(stock.copy(
                    quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                    totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                    updatedAtMillis = System.currentTimeMillis()
                ))
            }
            deleteMovements("EXPENSE", expense.id)
            updateExpense(expense)
        }
        val expenseId = if (expense.id == 0L) insertExpense(expense) else expense.id
        if (!stockType.isNullOrBlank() && !stockBaseUnit.isNullOrBlank() && quantityBase > 0) {
            val stock = findStockItem(stockType, expense.title.trim(), stockBaseUnit)
                ?: error("الصنف «${expense.title}» غير مسجل في المخزون. أضف رصيده من الفاتورة أو من شاشة المخزون أولًا.")
            check(stock.quantityBase >= quantityBase) {
                "الرصيد المتبقي من «${expense.title}» غير كافٍ. المتاح ${stock.quantityBase} ${stock.baseUnit}."
            }
            updateStockItem(stock.copy(
                quantityBase = stock.quantityBase - quantityBase,
                totalUsedBase = Math.addExact(stock.totalUsedBase, quantityBase),
                updatedAtMillis = System.currentTimeMillis()
            ))
            insertStockMovement(StockMovementEntity(
                stockItemId = stock.id,
                referenceType = "EXPENSE",
                referenceId = expenseId,
                quantityBase = -quantityBase,
                dateMillis = expense.dateMillis,
                description = "استخدام في عملية ${expense.category}"
            ))
        }
        return expenseId
    }

    @Transaction
    suspend fun deleteExpenseAndRestoreStock(expense: ExpenseEntity) {
        getMovements("EXPENSE", expense.id).forEach { movement ->
            val stock = getStockItemById(movement.stockItemId) ?: return@forEach
            updateStockItem(stock.copy(
                quantityBase = Math.addExact(stock.quantityBase, -movement.quantityBase),
                totalUsedBase = (stock.totalUsedBase + movement.quantityBase).coerceAtLeast(0),
                updatedAtMillis = System.currentTimeMillis()
            ))
        }
        deleteMovements("EXPENSE", expense.id)
        deleteExpense(expense)
    }
}

@Database(
    entities = [PlantationEntity::class, ExpenseEntity::class, InvoiceEntity::class, StockItemEntity::class, InvoiceItemEntity::class, StockMovementEntity::class],
    version = 2,
    exportSchema = true
)
abstract class MiyarDatabase : RoomDatabase() {
    abstract fun dao(): MiyarDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `invoices` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `supplier` TEXT NOT NULL, `invoiceNumber` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `paymentStatus` TEXT NOT NULL, `currency` TEXT NOT NULL, `exchangeRateScaled` INTEGER NOT NULL, `totalForeign` INTEGER NOT NULL, `totalYer` INTEGER NOT NULL, `notes` TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `productType` TEXT NOT NULL, `productName` TEXT NOT NULL, `activeIngredient` TEXT NOT NULL, `baseUnit` TEXT NOT NULL, `quantityBase` INTEGER NOT NULL, `totalReceivedBase` INTEGER NOT NULL, `totalUsedBase` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_stock_items_productType_productName_baseUnit` ON `stock_items` (`productType`, `productName`, `baseUnit`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `invoice_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `invoiceId` INTEGER NOT NULL, `stockItemId` INTEGER NOT NULL, `productType` TEXT NOT NULL, `productName` TEXT NOT NULL, `activeIngredient` TEXT NOT NULL, `packageName` TEXT NOT NULL, `packageSize` INTEGER NOT NULL, `packageCount` INTEGER NOT NULL, `unit` TEXT NOT NULL, `quantityBase` INTEGER NOT NULL, `unitPriceForeign` INTEGER NOT NULL, `lineTotalForeign` INTEGER NOT NULL, `lineTotalYer` INTEGER NOT NULL, FOREIGN KEY(`invoiceId`) REFERENCES `invoices`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_items_invoiceId` ON `invoice_items` (`invoiceId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_invoice_items_stockItemId` ON `invoice_items` (`stockItemId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_movements` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `stockItemId` INTEGER NOT NULL, `referenceType` TEXT NOT NULL, `referenceId` INTEGER NOT NULL, `quantityBase` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `description` TEXT NOT NULL, FOREIGN KEY(`stockItemId`) REFERENCES `stock_items`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_stockItemId` ON `stock_movements` (`stockItemId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_referenceType_referenceId` ON `stock_movements` (`referenceType`, `referenceId`)")
            }
        }

        @Volatile private var INSTANCE: MiyarDatabase? = null

        fun get(context: Context): MiyarDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MiyarDatabase::class.java,
                    "miyar.db"
                ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
            }
    }
}
